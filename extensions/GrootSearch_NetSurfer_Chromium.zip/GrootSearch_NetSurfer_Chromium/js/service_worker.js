function GrootSearch(info,tab){chrome.tabs.create({url:"https://groot.ssuiteoffice.com/#gsc.tab=0&gsc.sort=&gsc.q="+info.selectionText});};
chrome.contextMenus.removeAll(function(){chrome.contextMenus.create({id:"Groot",title:"Groot Search: %s",contexts:["selection"]});});
chrome.runtime.onInstalled.addListener(function(){chrome.tabs.create({url:"https://www.ssuiteoffice.com/software.htm"});});
chrome.runtime.setUninstallURL("https://www.ssuiteoffice.com/software.htm");
chrome.contextMenus.onClicked.addListener(function(info,tab){if(info.menuItemId=="Groot"){GrootSearch(info,tab);}});