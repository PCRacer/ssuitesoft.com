//function GrootSearch(info,tab){chrome.tabs.create({url:"https://groot.ssuiteoffice.com/#gsc.tab=0&gsc.sort=&gsc.q="+info.selectionText});};
//chrome.contextMenus.removeAll(function(){chrome.contextMenus.create({id:"Groot",title:"Groot Search: %s",contexts:["selection"]});});
//chrome.runtime.onInstalled.addListener(function(){chrome.tabs.create({url:"https://www.ssuiteoffice.com/software.htm"});});
//chrome.runtime.setUninstallURL("https://www.ssuiteoffice.com/software.htm");
//chrome.contextMenus.onClicked.addListener(function(info,tab){if(info.menuItemId=="Groot"){GrootSearch(info,tab);}});
// Create context menu when extension is installed
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "Groot",
    title: "Groot Search: %s",
    contexts: ["selection"]
  });
  chrome.runtime.setUninstallURL("https://www.ssuiteoffice.com/software.htm");
  chrome.tabs.create({
    url: "https://www.ssuiteoffice.com/software.htm"
  });
});

async function GrootSearch() {
  try {
    // Create a new tab and wait for it to finish
    const newTab = await chrome.tabs.create({ 
      url: "https://groot.ssuiteoffice.com/", 
      active: true 
    });
    // Ensure the window of the new tab is focused
    await chrome.windows.update(newTab.windowId, { focused: true });
  } catch (err) {
    console.error("Failed to open Groot tab:", err);
  }
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "Groot" && info.selectionText) {
    try {
      // Copy text + show alert in current page
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: async (text) => {
          try {
            await navigator.clipboard.writeText(text);
            alert("\n\nYour selected text has been copied to the clipboard. ▶ 📋\n\nChoose an AI Chat engine for further processing...\n\n...on the Groot Portal web page, which will now open... 🔥🌐\n\n");
          } catch (e) {
            alert("Failed to copy selected text.");
          }
        },
        args: [info.selectionText]
      });
    } catch (err) {
      console.error("Script injection failed:", err);
    }};
	  await GrootSearch();	
});