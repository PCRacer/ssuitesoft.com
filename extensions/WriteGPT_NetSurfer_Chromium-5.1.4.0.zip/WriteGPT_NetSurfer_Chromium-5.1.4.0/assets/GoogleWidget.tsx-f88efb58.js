import{e as h,j as o}from"./client-109e060b.js";const u=(e,t,l=document)=>new Promise((r,f)=>{const s=l.querySelector(e);if(s)t(s,r);else{const g=setInterval(()=>{const d=l.querySelector(e);d&&(t(d,r),clearInterval(g))},500)}}),n=document.createElement("div");n.id="google-widget-element";const m=n.attachShadow({mode:"open"}),i=document.createElement("div");i.id="google-mountpoint";const a=document.createElement("div");a.id="google-emotionRoot";m.appendChild(i);m.appendChild(a);const c=e=>{document.title.substring(0,document.title.length-16);const t=e.firstChild;h.createRoot(i).render(o.jsx(o.Fragment,{children:o.jsx("style",{children:`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          font-family: Arial, sans-serif;
        }
        `})})),e.insertBefore(n,t)},p=document.getElementById("rhs");if(p===null){const e=document.getElementById("rcnt"),t=document.createElement("div");t.id="rhs",e==null||e.appendChild(t),c(t)}else u("#rhs",e=>{c(e)});
