// CKEditor 5 bridge — runs in the PAGE world (has access to `element.ckeditorInstance`).
//
// This bridge is the single source of truth for flattening the CKEditor *model* into
// the plain-text string the extension checks. Both the text and the offset->position
// mapping come from ONE walk (`flatten`), so they can never drift apart.
//
// State is published through a hidden DOM element (`#__scribens_ckstate`) rather than
// postMessage, because the content script reads editor text SYNCHRONOUSLY (during paste /
// mutation handling) and an async message always loses that race. The content script and
// the page share the DOM, so a synchronous read is possible; only the version handshake
// and the replace result still go over postMessage.
//
//   - text + caret : written on `model change:data` (model is current immediately, no DOM
//                    needed) so the synchronous check always sees fresh text.
//   - segments     : per-text-run DOM locators; refreshed after the view renders (rAF),
//                    since highlights are drawn later (once the server responds).
//   - CKE_REPLACE  : map flat [startIndex, endIndex] -> model positions via the same
//                    flatten walk, then model.insertContent(). No hand-rolled counting.
//
// Docs:
//   https://ckeditor.com/docs/ckeditor5/latest/framework/architecture/editing-engine.html
//   https://ckeditor.com/docs/ckeditor5/latest/framework/how-tos.html

// Dev-only logging: the content script sets `data-debug="1"` on this script tag in
// development builds (it can't be read from process.env here — the bridge isn't bundled).
const __CKE_DEBUG = (() => {
  try { return !!(document.currentScript && document.currentScript.dataset.debug === '1'); }
  catch (e) { return false; }
})();
const log = (...args) => { if (__CKE_DEBUG) console.log(...args); };

window.postMessage({ type: 'CKE_VERSION', payload: { version: window.CKEDITOR_VERSION } }, '*');

(() => {
  if (window.__ckeReplaceBridgeInstalled) return; // guard against double-inject
  window.__ckeReplaceBridgeInstalled = true;

  const EDITABLE_SELECTOR = '.ck-editor__editable_inline';
  const STATE_ELEMENT_ID = '__scribens_ckstate';

  const getEditable = () => document.querySelector(EDITABLE_SELECTOR);
  const getEditor = () => getEditable()?.ckeditorInstance;

  const reply = (payload) => window.postMessage({ type: 'CKE_RESULT', payload }, '*');

  // Hidden element the content script reads synchronously. `type="application/json"` keeps
  // it inert (not rendered, not executed).
  let stateEl = null;
  let seq = 0;
  function writeState(snapshot) {
    if (!stateEl) {
      stateEl = document.createElement('script');
      stateEl.type = 'application/json';
      stateEl.id = STATE_ELEMENT_ID;
      (document.documentElement || document.head).appendChild(stateEl);
    }
    seq += 1;
    stateEl.setAttribute('data-seq', String(seq));
    stateEl.textContent = JSON.stringify(snapshot);
  }

  // Resolve a model position to a { DOM text node, offset } pair.
  // `viewPositionToDom` returns an ELEMENT-anchored position ({ parent: <p>, offset })
  // whenever the position sits at a container boundary — e.g. the start of a paragraph
  // or right after a <softBreak>/<br>. Every text run in a <br>-separated paragraph
  // starts at such a boundary, so we descend to the neighbouring text node.
  function domTextPointForModelPos(mapper, domConverter, modelPos) {
    const viewPos = mapper.toViewPosition(modelPos);
    const domPos = domConverter.viewPositionToDom(viewPos);
    if (!domPos || !domPos.parent) return null;

    const { parent, offset } = domPos;
    if (parent.nodeType === Node.TEXT_NODE) return { node: parent, offset };

    const at = parent.childNodes[offset];
    if (at && at.nodeType === Node.TEXT_NODE) return { node: at, offset: 0 };

    const prev = parent.childNodes[offset - 1];
    if (prev && prev.nodeType === Node.TEXT_NODE) return { node: prev, offset: prev.length };

    return null;
  }

  // Serialize a DOM node to a child-index path relative to `root`, so the (isolated-world)
  // content script can resolve the SAME live node — DOM refs can't cross into it.
  function domPath(node, root) {
    const path = [];
    let n = node;
    while (n && n !== root) {
      const p = n.parentNode;
      if (!p) return null;
      path.unshift(Array.prototype.indexOf.call(p.childNodes, n));
      n = p;
    }
    return n === root ? path.join('.') : null;
  }

  // Pass 1 — walk the model to the flat text + record each text run. No DOM needed, so this
  // is safe to call synchronously on `change:data` (before the view renders).
  function flattenModel(editor) {
    const model = editor.model;
    const schema = model.schema;
    const root = model.document.getRoot();

    let text = '';
    const runs = [];

    for (const value of model.createRangeIn(root).getWalker({ ignoreElementEnd: true })) {
      if (value.type === 'text') {
        const data = value.item.data;
        runs.push({ flatStart: text.length, length: data.length, modelPos: value.previousPosition });
        text += data;
      } else if (value.type === 'elementStart') {
        const el = value.item;
        if (el.name === 'softBreak') {
          text += '\n';
        } else if (schema.isBlock(el) && text.length > 0 && text[text.length - 1] !== '\n') {
          text += '\n';
        }
      }
    }

    // Best-effort caret: the run that contains the model selection focus.
    let caret = -1;
    const focus = model.document.selection.focus;
    if (focus) {
      for (const r of runs) {
        if (r.modelPos.parent === focus.parent
          && focus.offset >= r.modelPos.offset
          && focus.offset <= r.modelPos.offset + r.length) {
          caret = r.flatStart + (focus.offset - r.modelPos.offset);
          break;
        }
      }
    }

    return { text, runs, caret };
  }

  // Pass 2 — build DOM locators for each run. MUST run against the rendered DOM. Uses the
  // engine mapper first, then falls back to aligning runs with the editable's DOM text
  // nodes in document order (CKEditor renders one text node per run).
  function buildSegments(editor, runs) {
    const mapper = editor.editing.mapper;
    const domConverter = editor.editing.view.domConverter;
    const editable = getEditable();

    const domTextNodes = [];
    if (editable) {
      const tw = document.createTreeWalker(editable, NodeFilter.SHOW_TEXT, null);
      for (let n = tw.nextNode(); n; n = tw.nextNode()) domTextNodes.push(n);
    }

    const segments = [];
    let mapperHits = 0;
    let alignHits = 0;

    for (let i = 0; i < runs.length; i++) {
      const r = runs[i];
      let point = null;

      try {
        point = domTextPointForModelPos(mapper, domConverter, r.modelPos);
      } catch (e) { point = null; }

      if (point && point.node.nodeType === Node.TEXT_NODE) {
        mapperHits += 1;
      } else if (domTextNodes[i]) {
        point = { node: domTextNodes[i], offset: 0 };
        alignHits += 1;
      } else {
        point = null;
      }

      if (point) {
        const path = domPath(point.node, editable);
        if (path !== null) segments.push([r.flatStart, r.length, path, point.offset]);
      }
    }

    return { segments, mapperHits, alignHits, domTextNodeCount: domTextNodes.length };
  }

  // Map a flat offset to a model position using the runs from `flattenModel`.
  //   bias 'start' : offsets on a block separator snap forward (next run start)
  //   bias 'end'   : ... snap backward (previous run end)
  function modelPosForOffset(model, runs, offset, bias) {
    for (const r of runs) {
      if (offset >= r.flatStart && offset <= r.flatStart + r.length) {
        return r.modelPos.getShiftedBy(offset - r.flatStart);
      }
    }
    if (bias === 'start') {
      const r = runs.find((x) => x.flatStart >= offset);
      if (r) return r.modelPos;
    } else {
      let r = null;
      for (const x of runs) if (x.flatStart + x.length <= offset) r = x;
      if (r) return r.modelPos.getShiftedBy(r.length);
    }
    return model.createPositionAt(model.document.getRoot(), 'end');
  }

  let lastSegments = [];
  let lastSegmentsVersion = -1;
  let replacing = false; // true while WE mutate the model (CKE_REPLACE) — see notifyEdit

  // `model.document.version` increments once per operation, so it stamps exactly which model
  // state a publish describes. The content script compares the two stamps below to know whether
  // the DOM locators still match the text it is checking.
  const modelVersion = (editor) => {
    try { return editor.model.document.version; } catch (e) { return -1; }
  };

  // Synchronous: publish fresh text + caret immediately (DOM not required). The segments carried
  // along are the previous ones — flagged as such by `segmentsVersion` < `version`.
  function publishText(editor) {
    try {
      const { text, caret } = flattenModel(editor);
      writeState({
        text,
        caret,
        segments: lastSegments,
        version: modelVersion(editor),
        segmentsVersion: lastSegmentsVersion,
      });
    } catch (e) {
      log('[CKE-bridge] publishText error', e);
    }
  }

  // Post-render: recompute DOM locators and republish. Text and locators are taken from the same
  // model version here, so the published snapshot is self-consistent.
  function publishSegments(editor) {
    try {
      const { text, runs, caret } = flattenModel(editor);
      const { segments, mapperHits, alignHits, domTextNodeCount } = buildSegments(editor, runs);
      const version = modelVersion(editor);
      lastSegments = segments;
      lastSegmentsVersion = version;
      log('[CKE-bridge] publishSegments textLen=', text.length,
        'segments=', segments.length, '(mapper=', mapperHits, 'align=', alignHits,
        'domTextNodes=', domTextNodeCount, ') caret=', caret, 'version=', version);
      writeState({ text, caret, segments, version, segmentsVersion: version });
    } catch (e) {
      log('[CKE-bridge] publishSegments error', e);
    }
  }

  // Tell the content script the model changed. Writing the state element is a silent DOM write —
  // nothing in the extension polls it — so without this ping a user edit (typing, backspace,
  // toolbar undo, drag & drop, IME, programmatic setData) leaves marks over text that is gone.
  // Our own corrections are skipped: CKE_RESULT already reconciles those.
  function notifyEdit() {
    if (replacing) return;
    window.postMessage({ type: 'CKE_EDIT' }, '*');
  }

  function scheduleSegments(editor) {
    if (scheduleSegments.pending) return;
    scheduleSegments.pending = true;
    requestAnimationFrame(() => {
      scheduleSegments.pending = false;
      publishSegments(editor);
    });
  }

  // Wait for the editor instance to exist, then start mirroring model state.
  (function ready(tries) {
    const editor = getEditor();
    if (editor) {
      log('[CKE-bridge] editor found after', 50 - tries, 'retries; attaching change:data');
      editor.model.document.on('change:data', () => {
        publishText(editor);      // sync: text is current now
        scheduleSegments(editor); // async: locators after the view renders
        notifyEdit();             // async: content script reconciles marks
      });

      // Locators must be built against the RENDERED DOM. `render` fires at the end of the change
      // block — same task as the keystroke — whereas the rAF above can lose the race against the
      // content script's own 15ms post-keydown reconcile and leave the locators one edit behind
      // (marks then resolve to the wrong offsets, or to nothing and get dropped as unresolvable).
      try {
        editor.editing.view.on('render', () => {
          if (lastSegmentsVersion === modelVersion(editor)) return; // already up to date
          publishSegments(editor);
        });
      } catch (e) {
        log('[CKE-bridge] view render hook unavailable', e);
      }

      publishText(editor);
      scheduleSegments(editor);
      return;
    }
    if (tries > 0) {
      setTimeout(() => ready(tries - 1), 200);
    } else {
      log('[CKE-bridge] editor NOT found after 50 retries (~10s)');
    }
  })(50);

  window.addEventListener('message', (e) => {
    if (e.source !== window || e.data?.type !== 'CKE_REPLACE') return;

    const { text, startIndex, endIndex, diff } = e.data;
    const editor = getEditor();

    if (!editor) {
      reply({ ok: false, error: 'Editor not found.' });
      return;
    }

    try {
      editor.focus();
      const model = editor.model;
      const { runs } = flattenModel(editor);

      replacing = true;
      try {
        model.change((writer) => {
          const start = modelPosForOffset(model, runs, startIndex, 'start');
          const end = modelPosForOffset(model, runs, endIndex, 'end');
          const range = model.createRange(start, end);
          model.insertContent(writer.createText(text), range);
        });
      } finally {
        replacing = false;
      }

      // The content script shifts marks (`redrawAfter`) and redraws SYNCHRONOUSLY when it
      // receives this reply, so the shared state must already hold post-correction text AND
      // segments — otherwise it renders shifted marks against stale segment positions.
      // Force the view to render, then publish fresh segments before replying.
      try { editor.editing.view.forceRender(); } catch (e) { /* older engines */ }
      publishSegments(editor);

      reply({ ok: true, startIndex, endIndex, diff, text });
    } catch (err) {
      reply({ ok: false, error: String(err) });
    }
  });
})();
