(function () {
  /**
    {
      "all_frames": true,
      "matches": [
        "<all_urls>"
      ],
      "js": [ "js/word365Injector.js" ],
      "run_at": "document_start"
    }
   */
  const file = chrome.runtime.getURL(`js/word365PrintView.js`);
  const script = document.createElement('script');
  script.type = 'text/javascript';
  script.async = false;
  script.defer = false;
  script.src = file;
  script.onload = () => {
    setTimeout(() => {
      script.remove();
    }, 300);
  };
  document.documentElement.appendChild(script);
})();