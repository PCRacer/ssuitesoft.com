!(function () {
  window.g_paginationIsEnabled = true;
  console.log('g_paginationIsEnabled');
})();