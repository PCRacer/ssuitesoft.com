!(function () {
  var t;
  const n = null === (t = document.currentScript) || void 0 === t ? void 0 : t.getAttribute('data-ext-id');
  self._docs_force_html_by_ext = n || 'undefined';

  if (!location.href.includes('mode=html')) {
    if (location.href.includes('?')) {
      location.href = location.href.replace('?', '?mode=html&');
    }
    else if (location.href.includes('#')) {
      location.href = location.href.replace('#', '#?mode=html#');
    }
    else {
      location.href += '?mode=html';
    }
  }

  function forceHtmlRenderingMode(n) {
    if (window._docs_flag_initialData) {
      window._docs_flag_initialData['kix-awcp'] = true;
    }
    else if (n > 0) {
      setTimeout(forceHtmlRenderingMode.bind(null, n - 1), 0);
    }
    else {
      console.warn('Could not set kix-awcp flag');
    }
  }
  forceHtmlRenderingMode(100);
})();