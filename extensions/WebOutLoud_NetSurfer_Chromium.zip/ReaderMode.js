function ReaderMode(){let a={show:async(b,c)=>{await browserRuntimeSendMessage({cmd:"toggleReader",readermodeURL,domNodes:b,attribution:c})}};ReaderMode=()=>a;return a};
