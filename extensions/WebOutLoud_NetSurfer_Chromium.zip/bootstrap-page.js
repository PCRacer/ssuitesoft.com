if(!customElements.get("wol-component")){class a extends HTMLElement{}customElements.define("wol-component",a)};
