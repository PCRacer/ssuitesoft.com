try{importScripts("shared.js","aws-sdk-2.1068.0.min.js","common.js","background.js")}catch(a){console.error(a)};
