const s=document.createElement("script");s.src=chrome.runtime.getURL("bootstrap-page.js");(document.head||document.documentElement).appendChild(s);s.remove();
