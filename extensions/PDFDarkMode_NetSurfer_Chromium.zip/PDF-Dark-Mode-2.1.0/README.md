![PDF Dark Mode Logo](/images/PDM%20128x128.png)

# PDF Dark Mode

Browser extension that adds customizable dark mode support for PDF files to reduce eye strain while reading.

## License

This project is licensed under the GNU General Public License v3.0 (GPL-3.0).  
See the [LICENSE](./LICENSE) file for details.

## Attribution

This project was originally inspired by and partially derived from:

- DarkPDF by ArshSB  
  https://github.com/ArshSB/DarkPDF

DarkPDF is licensed under GPL-3.0, and this project complies with the terms of that license.

All modifications, additional features, UI changes, entitlement logic, and ongoing maintenance in this repository are independently developed for PDF Dark Mode.

## Background

I had to read a bunch of PDFs at night during exams. Black text on a white background caused significant eye strain, and existing extensions did not provide enough customization for readability and comfort. PDF Dark Mode was built to solve that problem with adjustable reading controls and additional viewing modes.

## Features

### Free Features

- Supports both online and offline PDFs
- Toggle dark mode
- Adjustable darkness strength
- Adjustable contrast
- Core PDF dark reading experience

### Pro Features

- Additional reading modes:
  - Sepia
  - AMOLED
- Per-site allow/block rules
- Lemon Squeezy license key activation and validation
- Future premium productivity and customization features

## Pro License Validation Policy

- Pro access is activated using a Lemon Squeezy license key.
- License status is validated automatically in the background (no manual validate step in popup).
- Validation is throttled to periodic checks (about every 24 hours), not on every popup open.
- Stale-while-revalidate behavior is used: if a previously active license is stored locally, Pro remains available while background validation runs.
- If Lemon Squeezy reports the license as invalid/inactive (for example after cancellation/refund), Pro access is removed on the next successful validation.

## Privacy

PDF Dark Mode does not collect or transmit personal browsing data.

Current analytics functionality is:
- local-only
- stored on-device
- not sent to external servers

## Installation

- Chrome Web Store: https://chromewebstore.google.com/detail/pdf-dark-mode/clabimobhdkbfpkdeloigeneocldkmdc
- Microsoft Edge Add-ons: https://microsoftedge.microsoft.com/addons/detail/pdf-dark-mode/nghkmkbjhpgdibgopgekgjnbocfmnjdo


## Contributing

Contributions, bug reports, and feature suggestions are welcome.

Please open an issue or submit a pull request if you would like to contribute.

## Commercial Use

Commercial distribution and paid feature offerings are permitted under GPL-3.0, provided that GPL obligations and license terms are respected.

## Updates

- Updates will continue gradually
- Additional accessibility and reading features are planned

## Disclaimer

PDF Dark Mode is an independent project and is not affiliated with or endorsed by the original DarkPDF project or its contributors.