
const ICON_SVG = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#0f173b" width="16px" height="16px">
    <path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
</svg>
`;

let iconElement = null;
let currentSelection = "";

// Check if extension context is still valid
function isExtensionContextValid() {
    try {
        return chrome.runtime && !!chrome.runtime.id;
    } catch (e) {
        return false;
    }
}

function createIcon() {
  if (iconElement) return iconElement;

  const div = document.createElement('div');
  div.id = 'cambridge-lookup-icon';
  div.innerHTML = ICON_SVG;
  div.style.position = 'absolute';
  div.style.zIndex = '2147483647'; // Max z-index
  div.style.background = '#fec400';
  div.style.borderRadius = '50%';
  div.style.width = '26px';
  div.style.height = '26px';
  div.style.display = 'flex';
  div.style.alignItems = 'center';
  div.style.justifyContent = 'center';
  div.style.cursor = 'pointer';
  div.style.boxShadow = '0 2px 5px rgba(0,0,0,0.3)';
  div.style.transition = 'opacity 0.2s';
  div.style.opacity = '0'; // Start hidden
  div.style.pointerEvents = 'none'; // Start non-clickable

  div.addEventListener('mousedown', (e) => {
    e.preventDefault(); // Prevent text deselection
    e.stopPropagation();
  });

  div.addEventListener('click', (e) => {
    e.stopPropagation();
    e.preventDefault();
    if (currentSelection && isExtensionContextValid()) {
        try {
            chrome.runtime.sendMessage({
                action: 'lookup',
                term: currentSelection
            });
        } catch (err) {
            console.log('Extension context invalidated, please refresh the page.');
        }
        removeIcon();
    }
  });

  // Fix #6: Check if document.body exists before appending
  if (document.body) {
    document.body.appendChild(div);
  } else {
    console.warn('document.body not ready');
    return null;
  }
  
  return div;
}

function removeIcon() {
  if (iconElement) {
    iconElement.style.opacity = '0';
    iconElement.style.pointerEvents = 'none';
  }
}

function showIcon(x, y) {
    if (!iconElement) iconElement = createIcon();
    
    // Position just above the selection
    const iconSize = 26;
    iconElement.style.top = `${y - iconSize - 10}px`;
    iconElement.style.left = `${x}px`;
    iconElement.style.display = 'flex';
    
    // Force reflow
    iconElement.getBoundingClientRect();
    
    iconElement.style.opacity = '1';
    iconElement.style.pointerEvents = 'auto';
}

document.addEventListener('mouseup', (e) => {
    // Check if extension context is still valid
    if (!isExtensionContextValid()) {
        return;
    }

    // Delay slightly to let selection finalize
    setTimeout(() => {
        const selection = window.getSelection();
        const text = selection.toString().trim();

        if (text.length > 0) {
            currentSelection = text;
            
            // Check settings before showing
            if (!isExtensionContextValid()) return;
            
            try {
                chrome.storage.local.get({showFloatingIcon: true}, (items) => {
                    if (chrome.runtime.lastError) {
                        console.log('Extension context invalidated');
                        return;
                    }
                    if (items.showFloatingIcon) {
                        const range = selection.getRangeAt(0);
                        const rect = range.getBoundingClientRect();
                        
                        // Fix #9: Ensure icon stays within viewport boundaries
                        // Position so icon's right edge aligns with selection's right edge
                        const iconWidth = 26;
                        let x = rect.right + window.scrollX - iconWidth;
                        let y = rect.top + window.scrollY;
                        
                        // Keep icon within horizontal bounds (with 10px margin)
                        x = Math.max(window.scrollX + 10, Math.min(x, window.innerWidth + window.scrollX - iconWidth - 10));
                        
                        // Keep icon within vertical bounds (with 10px margin from top)
                        y = Math.max(window.scrollY + 10, y);

                        showIcon(x, y);
                    }
                });
            } catch (err) {
                console.log('Extension context invalidated, please refresh the page.');
            }
        } else {
            removeIcon();
        }
    }, 10);
});

document.addEventListener('mousedown', (e) => {
    if (iconElement && e.target !== iconElement && !iconElement.contains(e.target)) {
        removeIcon();
    }
});

// Listener for hotkey support - return selected text to background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getSelection') {
        const text = window.getSelection().toString().trim();
        sendResponse({ text: text });
    }
    return true; // Required for async sendResponse
});
