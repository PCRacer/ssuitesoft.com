import { capitalize } from './helper.js';

// Settings button - open options page in new tab
document.getElementById('settings-btn').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

// Render History 

const renderHistory = (arr) => {
  const historyHTML = arr.map((item) => `<li data-value=${item}><span>${item}</span><i title="Remove this" class="btn-remove">&times;</i></li>`).join("");
  document.querySelector("#lookup-history ol").innerHTML = historyHTML;
};

// Fix #11: Use event delegation to prevent memory leaks
document.querySelector("#lookup-history ol").addEventListener("click", function(e) {
  const li = e.target.closest('li');
  if (!li) return;
  
  if (e.target.nodeName === "SPAN") {
    chrome.runtime.sendMessage({
      action: 'lookup',
      term: li.dataset.value
    });
  }
  
  if (e.target.classList.contains("btn-remove")) {
    chrome.storage.local.get(["cambridge-history"], function (result) {
      const list = result["cambridge-history"] || [];
      const index = Array.from(li.parentElement.children).indexOf(li);
      list.splice(index, 1);
      chrome.storage.local.set({ "cambridge-history": list });
    });
  }
});

const btnExchangeHTML = `<i title="Change language direction" class="btn-exchange">⇆</i>`;
document.querySelectorAll('#dictionary-selector li').forEach((item) => {
  const value = item.dataset.value;
  item.innerText = value;
  if (item.closest('.bilingual-dictionary')) {
    item.insertAdjacentHTML('beforeend', btnExchangeHTML);
  }

  chrome.storage.local.get(['dictionary'], function (result) {
    value === result.dictionary && (item.classList.add('active'));
  });

  item.addEventListener('click', function (e) {
    if (e.target.classList.contains("btn-exchange")) {
      this.dataset.value = this.dataset.value.split("-").reverse().join("-");
      this.childNodes[0].nodeValue = capitalize(this.dataset.value);
      return;
    }

    document.querySelector('#dictionary-selector li.active') !== null && document.querySelector('#dictionary-selector li.active').classList.remove('active');
    document.querySelector('.current-dictionary span').innerText = this.dataset.value;
    this.classList.add('active');
    chrome.storage.local.set({ dictionary: this.dataset.value }, () => {
      console.log('dictionary is set to ' + this.dataset.value);
    });
    document.querySelector('.dictionary-checkbox').checked = false;
  });
});

chrome.storage.local.get(['dictionary'], function (result) {
  document.querySelector('#form-input').setAttribute('placeholder', `Search ${capitalize(result.dictionary)}`);
  document.querySelector('.current-dictionary span').innerText = result.dictionary;
  document.querySelector('#form-input').focus();
});

chrome.storage.onChanged.addListener(function(changes, namespace) {
  if ("dictionary" in changes) {
    document.querySelector('#form-input').setAttribute('placeholder', `Search ${capitalize(changes.dictionary.newValue)}`);
    document.querySelector('#form-input').focus();
  }

  if ("cambridge-history" in changes) {
    const { newValue } = changes["cambridge-history"];
    renderHistory(newValue || []);
  }
});

// Fix #4: Add null check with default empty array
chrome.storage.local.get(["cambridge-history"], function (result) {
  const list = result["cambridge-history"] || [];
  renderHistory(list);
});

document.querySelector('#form').addEventListener('submit', function (e) {
  e.preventDefault();
  // Fix #13: Trim input and check if empty
  const input = document.querySelector('#form-input').value.trim();
  if (!input) return;
  
  console.log(input);

  // Send message to background to open dictionary window
  chrome.storage.local.get(['dictionary'], function(result) {
      chrome.runtime.sendMessage({
        action: 'lookup',
        term: input
      });
      document.querySelector('#form-input').value = '';
  });

  // Update history - move to top if already exists
  chrome.storage.local.get(["cambridge-history"], function (result) {
    let list = result["cambridge-history"] || [];
    
    // Remove if already exists (will be re-added at top)
    const existingIndex = list.indexOf(input);
    if (existingIndex > -1) {
      list.splice(existingIndex, 1);
    }
    
    // Add to top, limit to 20 items
    list = [input, ...list].slice(0, 20);
    
    chrome.storage.local.set({ 'cambridge-history': list }, () => {
      console.log('History updated:', list);
    });
  });
});
