let createdWindowIds = [];

// Function to close windows with specified IDs
function closeWindowsByIds(windowIds) {
  windowIds.forEach(windowId => {
    // Check if the window exists before attempting to close it
    chrome.windows.get(windowId, function(windowInfo) {
      if (chrome.runtime.lastError || !windowInfo) {
        console.log('Window with ID', windowId, 'does not exist or has already been closed.');
      } else {
        chrome.windows.remove(windowId, function() {
          console.log('Window with ID', windowId, 'has been closed.');
        });
      }
    });
  });
}

const lookupCambridge = (data, dictionary) => {
  let url;
  data = data.toLowerCase().trim();
  if (dictionary === 'british-grammar') {
    url = `https://dictionary.cambridge.org/grammar/british-grammar/${data}`;
  } else if (dictionary === 'thesaurus') {
    url = `https://dictionary.cambridge.org/thesaurus/${data}`;
  } else {
    url = `https://dictionary.cambridge.org/dictionary/${dictionary}/${data}`;  
  }
  

  closeWindowsByIds(createdWindowIds);
  createdWindowIds = [];

  chrome.windows.create({
    url,
    type: 'popup',
    width: 500,
    height: 610,
    left: screen.width / 2 - 500 / 2,
    top: screen.height / 2 - 610 / 2,
  }, function(newWindow) {
    const newWindowId = newWindow.id;
    console.log('New window ID:', newWindowId);
  
    createdWindowIds.push(newWindowId);
  });
}

const capitalize = (str = 'english') => {
  str = str
    .split('-')
    .map((word) => {
      return word[0].toUpperCase() + word.substring(1);
    })
    .join('-');
  return str;
}

export { lookupCambridge , capitalize }