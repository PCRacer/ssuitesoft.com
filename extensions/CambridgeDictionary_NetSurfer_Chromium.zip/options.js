
// Save options to chrome.storage
function saveOptions() {
  const showFloatingIcon = document.getElementById('showFloatingIcon').checked;
  const autoCloseOnBlur = document.getElementById('autoCloseOnBlur').checked;
  const popupWidth = document.getElementById('popupWidth').value;
  const popupHeight = document.getElementById('popupHeight').value;

  chrome.storage.local.set(
    {
      showFloatingIcon: showFloatingIcon,
      autoCloseOnBlur: autoCloseOnBlur,
      popupWidth: parseInt(popupWidth) || 500,
      popupHeight: parseInt(popupHeight) || 610,
    },
    () => {
      // Update status to let user know options were saved.
      const status = document.getElementById('status');
      status.style.display = 'block';
      setTimeout(() => {
        status.style.display = 'none';
      }, 2000);
    }
  );
}

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restoreOptions() {
  chrome.storage.local.get(
    {
      showFloatingIcon: true,
      autoCloseOnBlur: true,
      popupWidth: 500,
      popupHeight: 610,
    },
    (items) => {
      document.getElementById('showFloatingIcon').checked = items.showFloatingIcon;
      document.getElementById('autoCloseOnBlur').checked = items.autoCloseOnBlur;
      document.getElementById('popupWidth').value = items.popupWidth;
      document.getElementById('popupHeight').value = items.popupHeight;
    }
  );
}

document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);
