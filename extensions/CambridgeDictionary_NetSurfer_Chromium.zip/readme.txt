v1.0:
- While on https://dictionary.cambridge.org, auto focus to the search box whenever key event is triggered.
- Reactive tab that open dictionary.
