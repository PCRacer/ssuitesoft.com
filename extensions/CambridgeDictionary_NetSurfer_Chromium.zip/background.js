let createdWindowIds = [];

// Function to close windows with specified IDs (returns Promise)
function closeWindowsByIds(windowIds) {
  return Promise.all(windowIds.map(windowId => {
    return new Promise((resolve) => {
      chrome.windows.get(windowId, function(windowInfo) {
        if (chrome.runtime.lastError || !windowInfo) {
          console.log('Window with ID', windowId, 'does not exist or has already been closed.');
          resolve();
        } else {
          chrome.windows.remove(windowId, function() {
            console.log('Window with ID', windowId, 'has been closed.');
            resolve();
          });
        }
      });
    });
  }));
}

const lookupCambridge = async (data, dictionary) => {
  let url;
  data = data.toLowerCase().trim();
  if (dictionary === 'british-grammar') {
    url = `https://dictionary.cambridge.org/grammar/british-grammar/${data}`;
  } else if (dictionary === 'thesaurus') {
    url = `https://dictionary.cambridge.org/thesaurus/${data}`;
  } else {
    url = `https://dictionary.cambridge.org/dictionary/${dictionary}/${data}`;
  }

  chrome.system.display.getInfo(async function (displays) {
    chrome.storage.local.get({popupWidth: 500, popupHeight: 610}, async (items) => {
        // Fix #8: Handle missing primary display
        const primaryDisplay = displays.find((display) => display.isPrimary) || displays[0];
        
        if (!primaryDisplay) {
          console.error('No display found');
          return;
        }

        // Fix #7: Validate popup dimensions (min: 300, max: 1920x1080)
        const windowWidth = Math.max(300, Math.min(items.popupWidth, 1920));
        const windowHeight = Math.max(300, Math.min(items.popupHeight, 1080));
    
        const windowLeft = Math.round(primaryDisplay.bounds.left + primaryDisplay.bounds.width / 2 - windowWidth / 2);
        const windowTop = Math.round(primaryDisplay.bounds.top + primaryDisplay.bounds.height / 2 - windowHeight / 2);
    
        // Close existing windows first and wait for completion
        if (createdWindowIds.length > 0) {
          await closeWindowsByIds(createdWindowIds);
          createdWindowIds = [];
        }
    
        chrome.windows.create(
          {
            url,
            type: 'popup',
            width: windowWidth,
            height: windowHeight,
            left: windowLeft,
            top: windowTop,
          },
          function (newWindow) {
            if (newWindow) {
              const newWindowId = newWindow.id;
              console.log('New window ID:', newWindowId);
              createdWindowIds = [newWindowId]; // Only keep the latest window
            }
          }
        );
    });
  });
};

// Helper function to add term to history (moves to top if exists)
function addToHistory(term) {
  chrome.storage.local.get(['cambridge-history'], function (result) {
    let list = result['cambridge-history'] || [];
    
    // Remove if already exists (will be re-added at top)
    const existingIndex = list.indexOf(term);
    if (existingIndex > -1) {
      list.splice(existingIndex, 1);
    }
    
    // Add to top, limit to 20 items
    list = [term, ...list].slice(0, 20);
    
    chrome.storage.local.set({ 'cambridge-history': list }, () => {
      console.log('History updated:', list);
    });
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'lookup' && request.term) {
        const selectionText = request.term;
        
        chrome.storage.local.get(['dictionary'], function (result) {
            const dict = result.dictionary || 'english';
            lookupCambridge(selectionText, dict);
        });

        // Add to history (moved to top if exists)
        addToHistory(selectionText);
    }
});

const capitalize = (str = 'english') => {
  str = str
    .split('-')
    .map((word) => {
      return word[0].toUpperCase() + word.substring(1);
    })
    .join('-');
  return str;
};

chrome.runtime.onInstalled.addListener(function (details) {
  // Fix #1 & #2: Only set default if dictionary doesn't exist
  chrome.storage.local.get(['dictionary'], function (result) {
    const dict = result.dictionary || 'english';
    
    // Only set if not already set (preserve user's choice)
    if (!result.dictionary) {
      chrome.storage.local.set({ dictionary: dict }, () => {
        console.log('Set default dictionary:', dict);
      });
    }
    
    // Create context menu with proper dictionary value
    chrome.contextMenus.create({
      id: 'cambridge-dictionary',
      title: `All-in-One Cambridge Dictionary (${capitalize(dict)}): '%s' `,
      contexts: ['selection'],
    });
  });

  // Create lookup history
  chrome.storage.local.get(['cambridge-history'], function (result) {
    if (!result['cambridge-history']) {
      chrome.storage.local.set(
        {
          'cambridge-history': [],
        },
        () => {
          console.log('Created cambridge-history');
        }
      );
    }
  });
});

chrome.contextMenus.onClicked.addListener(function (info) {
  const selectionText = info.selectionText;
  chrome.storage.local.get(['dictionary'], function (result) {
    if (result.dictionary) {
      lookupCambridge(selectionText, result.dictionary);
    }
  });

  // Add to history (moved to top if exists)
  addToHistory(selectionText);
});

chrome.storage.onChanged.addListener(function (changes, namespace) {
  if ('dictionary' in changes) {
    chrome.contextMenus.update('cambridge-dictionary', {
      title: `All-in-One Cambridge Dictionary (${capitalize(changes.dictionary.newValue)}): '%s' `,
    });
  }
});

// Feature: Auto-close dictionary window when losing focus
chrome.windows.onFocusChanged.addListener((windowId) => {
  // Only proceed if there are created windows to close
  if (createdWindowIds.length === 0) return;
  
  // Check if auto-close is enabled
  chrome.storage.local.get({ autoCloseOnBlur: true }, (items) => {
    if (!items.autoCloseOnBlur) return;
    
    // Close if focus is lost (WINDOW_ID_NONE) or switched to another window
    if (windowId === chrome.windows.WINDOW_ID_NONE || !createdWindowIds.includes(windowId)) {
      closeWindowsByIds(createdWindowIds);
      createdWindowIds = [];
    }
  });
});

// Cleanup when dictionary window is manually closed
chrome.windows.onRemoved.addListener((windowId) => {
  const index = createdWindowIds.indexOf(windowId);
  if (index > -1) {
    createdWindowIds.splice(index, 1);
    console.log('Window removed, updated createdWindowIds:', createdWindowIds);
  }
});

// Feature: Hotkey support (Ctrl+Shift+D)
chrome.commands.onCommand.addListener((command) => {
  if (command === 'lookup-selection') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]?.id) return;
      
      chrome.tabs.sendMessage(tabs[0].id, { action: 'getSelection' }, (response) => {
        if (chrome.runtime.lastError) {
          console.log('Could not get selection:', chrome.runtime.lastError.message);
          return;
        }
        
        if (response && response.text) {
          chrome.storage.local.get(['dictionary'], (result) => {
            const dict = result.dictionary || 'english';
            lookupCambridge(response.text, dict);
          });
          
          // Add to history (moved to top if exists)
          addToHistory(response.text);
        }
      });
    });
  }
});
