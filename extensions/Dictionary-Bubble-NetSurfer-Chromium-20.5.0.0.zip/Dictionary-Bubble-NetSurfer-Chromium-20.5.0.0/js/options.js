/* © 2024 goodwordguide.com. All Rights Reserved. */
(()=>{const E=this,G=E.document,aa=JSON.stringify,ba=JSON.parse,I=E.chrome||this.browser,fa=JSON.stringify,ha=JSON.parse,L=E.Array,ia=E.String,Y=L.isArray,la=function(){function f(b){return Object.prototype.toString.call(b).slice(8,-1).toLowerCase()}function q(b){return"false null undefined 0 -0 NaN 0n -0n".split(" ").includes(void 0===b?"":b)}function e(b,c,d,p){if(!b||!c)return Error("You did not provide an element or event name.");c=new CustomEvent(c,{bubbles:!0,cancelable:!p,detail:d});return b.dispatchEvent(c)}
function m(b,c){function d(A){for(let K in b)b.hasOwnProperty(K)&&(A[K]=m(b[K],c))}function p(){let A={};d(A);return A}function x(){return b.map(function(A){return m(A,c)})}function u(){let A=new Map;for(let K of b){let [T,M]=K;A.set(T,m(M,c))}return A}function B(){let A=new Set;for(let K of b)A.add(m(K,c));return A}function F(){let A=b.bind(this);d(A);return A}function Q(){return b.replace(/javascript:/gi,"").replace(/[^\w-_. ]/gi,function(A){return`&#${A.charCodeAt(0)};`})}let D=f(b);return"object"===
D?p():"array"===D?x():"map"===D?u():"set"===D?B():"function"===D?F():"string"!==D||c?b:Q()}function h(b){b.I&&window.cancelAnimationFrame(b.I);b.I=window.requestAnimationFrame(function(){b.C()})}function k(b){return{get:function(c,d){return-1<["object","array"].indexOf(f(c[d]))?new Proxy(c[d],k(b)):c[d]},set:function(c,d,p){if(c[d]===p)return!0;c[d]=p;h(b);return!0}}}function l(b){let c=(new DOMParser).parseFromString(b,"text/html");c.head&&c.head.childNodes&&0<c.head.childNodes.length&&L.from(c.head.childNodes).reverse().forEach(function(d){c.body.insertBefore(d,
c.body.firstChild)});return c.body||document.createElement("body")}function r(b,c){c.forEach(function(d){if("class"===d.g)b.className=d.value;else if("style"===d.g)b.style.cssText=d.value;else{if(d.g in b)try{b[d.g]=d.value,b[d.g]||0===b[d.g]||(b[d.g]="value"===d.g?d.value:!0)}catch(p){}try{b.setAttribute(d.g,d.value)}catch(p){}}})}function v(b,c){c.forEach(function(d){if("class"===d.g)b.className="";else if("style"===d.g)b.style.cssText="";else{if(d.g in b)try{b[d.g]=""}catch(p){}try{b.removeAttribute(d.g)}catch(p){}}})}
function a(b,c){return{g:b,value:c}}function g(b,c){return 1!==b.nodeType?[]:L.from(b.attributes).map(function(d){if(!(c&&Z.includes(d.name)&&ja.includes(b.tagName.toLowerCase()))){if(!c&&Z.includes(d.name))return a(d.name,b[d.name]);if(!ca.includes(d.name)){if(c&&da.includes(d.name)){let p=d.name.replace("reef-","");return W.includes(p)?a(p,q(d.value)?null:p):a(p,d.value)}return a(d.name,d.value)}}}).filter(function(d){return!!d})}function n(b,c){let d=g(b,!0),p=g(c);b=p.filter(function(u){let B=
d.find(function(F){return u.g===F.g});return void 0===B&&!Z.includes(u.g)||B&&W.includes(B.g)&&null===B.value});let x=d.filter(function(u){if(W.includes(u.g)&&null===u.value)return!1;let B=p.find(function(F){return u.g===F.g});return void 0===B||B.value!==u.value});r(c,x);v(c,b)}function w(b){1===b.nodeType&&(L.from(b.attributes).forEach(function(c){if(da.includes(c.name)||ca.includes(c.name)){var d=c.name.replace("reef-default-","").replace("reef-",""),p=W.includes(d);v(b,[a(c.name,c.value)]);p&&
q(c.value)||r(b,[p?a(d,d):a(d,c.value)])}}),b.childNodes&&L.from(b.childNodes).forEach(function(c){w(c)}))}function t(b){return 3===b.nodeType?"text":8===b.nodeType?"comment":b.tagName.toLowerCase()}function N(b){return b.childNodes&&0<b.childNodes.length?null:b.textContent}function V(b,c){return t(b)!==t(c)||b.id!==c.id||b.src!==b.src}function R(b,c,d){return L.from(c).slice(d+1).find(function(p){return!V(b,p)})}function ka(b,c){c=b.length-c.length;if(!(1>c))for(;0<c;c--)b[b.length-c].remove(b[b.length-
c])}function X(b,c,d){d=void 0===d?[]:d;let p=c.childNodes;b=b.childNodes;b.forEach(function(x,u){if(p[u]){if(V(x,p[u])){var B=R(x,p,u);if(!B){w(x);p[u].before(x.cloneNode(!0));return}p[u].before(B)}n(x,p[u]);0<d.filter(function(F){return![3,8].includes(x.nodeType)&&x.matches(F)}).length||((B=N(x))&&B!==N(p[u])&&(p[u].textContent=B),0<p[u].childNodes.length&&1>x.childNodes.length?p[u].innerHTML="":1>p[u].childNodes.length&&0<x.childNodes.length?(B=document.createDocumentFragment(),X(x,B,d),p[u].appendChild(B)):
0<x.childNodes.length&&X(x,p[u],d))}else w(x),c.append(x.cloneNode(!0))});ka(p,b)}function ea(b,c){b&&b.forEach(function(d){d.l.includes(c)?O(`"${c.o}" has attached nodes that it is also attached to, creating an infinite loop.`):"render"in d&&d.C()})}function P(b,c){console.log(b);if(b||c&&c.B)if(c&&(c.m||c.B)){var d=this,p=c.ka?c.store?null:c.data:c.data&&!c.store?new Proxy(c.data,k(d)):null,x=c.G?"array"===f(c.G)?c.G:[c.G]:[],{store:u,J:B,ka:F,La:Q}=c;d.I=null;Object.defineProperties(d,{o:{value:b},
m:{value:c.m},S:{value:c.S},B:{value:c.B},store:{value:u},l:{value:[]},methods:{value:c.methods||{}},H:{value:c.H||(()=>{})},data:{get:function(){return F?m(p,!0):p},set:function(D){if(u||F)return!0;p=new Proxy(D,k(d));h(d);return!0},configurable:!0},get:{value:function(D){if(u||!Q)O("There are no getters for this component.");else{if(Q[D]){var A=L.from(arguments);A[0]=p;return Q[D].apply(d,A)}O("There is no getter with this name.")}},configurable:!0}});B&&"addComponent"in B&&B.Fa(d);u&&"attach"in
u&&u.T(d);x.length&&x.forEach(function(D){"attach"in D&&D.T(d)});e(document,"reef:initialized",d)}else O("You did not provide a template for this component.");else O("You did not provide an element to make into a component.")}let O;O=()=>{};let Z=["checked","selected","value"],W=["checked","selected"],ja=["input","option","textarea"],da=["reef-checked","reef-selected","reef-value"],ca=["reef-default-checked","reef-default-selected","reef-default-value"];P.prototype.C=function(b){if(this.B)ea(this.l,
this);else if(this.m){var c="string"===f(this.o)?document.querySelector(this.o):this.o;if(c){var d=m((this.store?this.store.data:this.data)||{},this.S),p="function"===f(this.m)?this.m(d,this.methods,this.J&&this.J.current?this.J.current:c,c):this.m;if(["string","number"].includes(f(p))&&e(c,"reef:before-render",d)){var x=this.l.map(function(u){return u.o});X(l(p),c,x);e(c,"reef:render",d);e(c,"render",d);ea(this.l,this);d=c.querySelectorAll("*");for(let u=0,B=d.length;u<B;u++){p=d[u];x=p.getAttributeNames();
for(let F=0,Q=x.length;F<Q;F++){let D=x[F];if(-1<D.indexOf("on:")){let A=D.substr(3).split("."),K=p.getAttribute(D);p["on"+A[0]]=T=>{-1!==A.indexOf("stop")&&(T.stopPropagation(),T.stopImmediatePropagation());-1!==A.indexOf("prevent")&&T.preventDefault();var M,S,J=null==(M=K)?void 0:null==(S=M.trim())?void 0:S.split("(",2);S=[];M=J.shift();J.length&&(J=J[0],")"===J.charAt(J.length-1)&&(J="["+J.substring(0,J.length-1)+"]"),S=JSON.parse(J));S.push(T);if(M)return console.log("==> parts:",M,"=> args:",
S,"=> methods:",this.methods),this.methods[M.split(".")[1]].apply(this,S)}}}}b&&b();return c}}else O("The DOM element to render your template into was not found.")}else O("No template was provided.")};P.prototype.T=function(b){b="array"===f(b)?b:[b];for(let c of b)this.l.push(c);e(document,"reef:attached",{ga:this,l:b})};P.prototype.detach=function(b){b="array"===f(b)?b:[b];for(let c of b){let d=this.l.indexOf(c);if(0>d)return;this.l.splice(d,1)}e(document,"reef:detached",{ga:this,detached:b})};P.use=
function(b){b.U&&"function"===typeof b.U&&(b.U(P,{Ia:X}),e(document,"reef:plugin-added",b))};P.debug=function(){};P.clone=m;e(document,"reef:ready");return P}(),y={};(()=>{const f=["0","0","0","0","0"],q=f.length;y.X=e=>Y(e)?e.length:Object.keys(e).length;y.V=e=>ha(fa(e));y.M=(e,m)=>{if(Y(e)){var h=e.length;for(let k=0;k<h&&!1!==m(e[k],k,e);k++);}else if(e)for(h in e)if(!1===m(e[h],h,e))break};y.F=()=>{Y(void 0)||y.M(void 0,(e,m)=>{delete (void 0)[m]})};y.v=e=>!!navigator.userAgent.match(new RegExp(e+
"/","i"));y.qa=e=>!y.X(e);y.ra=(e,m)=>{if(e==m)return!0;if(!e||!m)return!1;const h=Object.getOwnPropertyNames(e);if(h.length!=Object.getOwnPropertyNames(m).length)return!1;const k=h.length;for(let l=0;l<k;l++){const r=h[l];if(e[r]!==m[r])return!1}return!0};y.ta=e=>"function"==typeof e;y.ua=e=>"string"==typeof e;y.va=function(e){for(let m,h=1,k=arguments.length;h<k;)m=arguments[h],y.M(m,(l,r)=>{e[r]=l}),h++;return e};y.wa=e=>{const m=document.createElement("a");m.href=e;return m};y.xa=()=>(Math.random()+
1).toString(36).substring(2);y.Ca=()=>{let e=q,m;for(;e;){e--;m=f[e].charCodeAt(0);if(57==m)return f[e]="A",f.join("");if(90==m)f[e]="0";else return f[e]=ia.fromCharCode(m+1),f.join("")}f.unshift("0");return f.join("")};y.Da=()=>"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,e=>{const m=16*Math.random()|0;return("x"==e?m:m&3|8).toString(16)});y.Ea=e=>{const m=[];for(let h in e)m.push(e[h]);return m};y.la=(e,m,h,k)=>{h=Math.min(h/e,k/m);return{width:e*h,height:m*h}};y.sa=y.v("Firefox");y.oa=
y.v("Chrome")&&!y.v("Edg");y.pa=y.v("Edg")})();const z={};(()=>{const f={},q=I.extension&&"function"===typeof I.extension.getBackgroundPage?I.extension.getBackgroundPage():null;let e=Object.is(q,E);const m=(k,l)=>({command:k,args:l||null}),h=(k,l,r)=>{if("backgroundPage"===k.target&&!e)return!1;const v=f[k.command]||[],a=v.length;if(a)for(let g=0;g<a;g++)v[g](k.args,n=>{r(n);g=a},l);return!0};e&&(E.__MessageReceiver=h);z.ma=()=>{e=!0;E.__MessageReceiver=h};z.Z=k=>{var l;if(l="__ECHO_SERVICE__","function"===
typeof k){var r=f[l]||[];r.push(k);f[l]=r}};z.na=(k,l)=>{l=l.split(":");k=f[k];const r=l[1]?E.parseInt(l[1],10):0;return k&&l[1]&&r&&k[r]?(k.splice(r-1,1),!0):!1};z.ba=(k,l,r)=>{k=(k||"").trim();if(!k)return!1;"function"===typeof l&&(r=l,l=null);try{I.runtime.sendMessage(m(k,l),r)}catch(v){return!1}return!0};z.A=(k,l,r,v)=>{l=(l||"").trim();if(k&&l){"function"===typeof r&&(v=r,r=null);try{I.tabs.sendMessage(k,m(l,r),v)}catch(a){}}};z.za=(k,l,r)=>{k=(k||"").trim();if(!k)return!1;"function"===typeof l&&
(r=l,l=null);try{return I.tabs.getCurrent(v=>{z.A(v.id,m(k,l),r,null)}),!0}catch(v){return v.stack.match("Cannot read property 'getCurrent' of undefined")?z.j("__ECHO_SERVICE__",{command:k,args:l,callback:r?!0:!1},r):!1}};z.ca=(k,l,r)=>{k=(k||"").trim();if(!k)return!1;"function"===typeof l&&(r=l,l=null);try{return I.tabs.query({},v=>{for(let a=0,g=v.length;a<g;a++)z.A(v[a].id,k,l,r)}),!0}catch(v){return!1}};z.Aa=(k,l,r)=>{k=(k||"").trim();if(!k)return!1;"function"===typeof l&&(r=l,l=null);try{I.tabs.query({active:!0,
currentWindow:!0},v=>{z.A(v[0].id,k,l,r)})}catch(v){return!1}return!0};z.ya=(k,l,r)=>z.ba(k,l,r)&&z.ca(k,l,r);z.j=(k,l,r)=>{k=(k||"").trim();if(!k)return!1;"function"===typeof l&&(r=l,l=null);try{if(q)q.__MessageReceiver(m(k,ba(aa(l))),{},v=>{console.log("==> Message._send:",v);v=ba(aa(v));r(v)});else{const v=m(k,l);v.target="backgroundPage";I.runtime.sendMessage(v,r)}}catch(v){return!1}return!0};I.runtime.onMessage.addListener(h);e&&z.Z((k,l,r)=>{z.A(r.tab.id,k.command,k.args,k.callback?v=>{l(v)}:
null)})})();(()=>{const f=E.onerror;E.onerror=(q,e,m,h,k)=>{if(k&&G.body){const l={msg:q,stack:k.stack,url:e,lineNo:m,columNo:h,location:E.location};"function"===typeof reportError?reportError(l,null):z.j("ERROR",l)}"function"===typeof f&&f(q,e,m,h,k)}})();var C;(()=>{function f(){}let q=!1,e=[];const m=!E.addEventListener&&E.attachEvent?(a,g,n)=>{a.attachEvent("on"+g,n)}:(a,g,n,w)=>{a.addEventListener(g,n,w)},h=a=>function(g,n){g?this.h(w=>{m(w,a,t=>{t.aa=t.preventDefault?t.preventDefault:()=>t.returnValue=
!1;t.ea=t.stopPropagation?t.stopPropagation:()=>{t.cancelBubble=!0};t.da=t.stopImmediatePropagation?t.stopImmediatePropagation:()=>{t.fa=!0};t.Ba=()=>{t.aa();t.ea();t.da()};if(!t.fa)return!1===g(t,w)?!1:!0},n)}):this.h(w=>{{let t;if(w[a])w[a]();else G.createEvent?(t=G.createEvent("HTMLEvents"),t.initEvent(a,!0,!0)):(t=G.createEventObject(),t.ia=a),t.Ja=a,G.createEvent?w.dispatchEvent(t):w.fireEvent("on"+t.ia,t)}});return this};f.prototype=[];f.prototype.constructor=f;f.prototype.Y=f.prototype.indexOf;
f.prototype.i=f.prototype.push;f.prototype.h=function(a){for(let g=0,n=this.length;g<n&&!1!==a(this[g],g,this);g++);};h("abort");h("beforeunload");h("blur");h("change");h("click");h("dblclick");h("error");h("focus");h("focusin");h("focusout");h("gesturestart");h("gesturechange");h("input");h("keydown");h("keypress");h("keyup");h("load");h("orientationchange");h("message");h("mousedown");h("mouseenter");h("mouseleave");h("mousemove");h("mouseout");h("mouseover");h("mouseup");h("popstate");h("resize");
h("scroll");h("select");h("selectionchange");h("submit");h("touchstart");h("touchmove");h("touchend");h("touchcancel");h("unload");f.prototype.K=function(a){const g=C(a);this.h(n=>{g.h(w=>{n.appendChild(w)})})};f.prototype.L=function(a){return this[0]&&this[0].getAttribute?this[0].getAttribute(a):""};f.prototype.V=function(a){const g=C([]);this.h(n=>{g.i(n.cloneNode(a))});return g};f.prototype.W=function(){const a=C([]);this.h(g=>{a.i.apply(a,g.childNodes)});return a};f.prototype.F=function(){this.h(a=>
{for(;a.firstChild;)a.removeChild(a.firstChild)});return this};f.prototype.N=function(a){if("string"===typeof a){let g=C(a,l(this[0]));return C(this.filter(n=>-1<g.Y(n)))}return"function"===typeof a?C(this.filter(a)):this};f.prototype.O=function(a){if(void 0===a)return this.W().N(g=>1===g.nodeType);a instanceof f?(this.F(),this.K(a)):null!==a&&this.h(g=>{C(g).F().K(C(a))});return this};f.prototype.P=function(a,g){const n=this;let w;if("function"===typeof g){w=g;var t=void 0}else w=N=>{const V=N.target;
let R=C(V).$();R.i(V);R=R.N(g);if(R.length)return(void 0)(N,R[0])};C(a.replace(/\s+/g,"").split(",")).h(N=>{h(N).call(n,w,t)})};f.prototype.$=function(){const a=C([]);this.h(g=>{const n=[];for(;g;)n.unshift(g),g=g.parentNode;a.i.apply(a,n)});return a};f.prototype.R=function(a){if(void 0===a){const g=[];this.h(n=>{g.push(n.value)});return 2>g.length?g.join():g}this.h(g=>{if("checkbox"===g.type||"radio"===g.type)if(!0===a)g.checked=!0;else if(!1===a)g.checked=!1;else{const n=C(g).L("value");g.checked=
n===a+""}else g.value=a});return this};C=(a,g)=>{const n=new f;if(a)if("function"===typeof a)q?a():e.push(a);else if("string"===typeof a){a=a.trim();if(a.match(/^</))return C(C.O(a));k(n,a,g)}else a.nodeName?n.i(a):((g=L.isArray(a))||(g=Object.prototype.toString.call(a),g="object"===typeof a&&/^\[object (HTMLCollection|NodeList|Object)\]$/.test(g)&&"number"===typeof a.length&&(0===a.length||"object"===typeof a[0]&&0<a[0].nodeType)),g||a instanceof f?n.i.apply(n,a):n.i(a));return n};C.O=a=>{var g=
document.implementation.createHTMLDocument(""),n=g.createDocumentFragment(),w=a.match(/^(<tbody|<thead|<tfoot)/i)?"table":"body";w=a.match(/^<tr/i)?"tbody":w;w=a.match(/^<td/i)?"tr":w;if(a.match(/^<link/i)&&g.createStyleSheet){n=a.match("href=[\"'](.*)?[\"']")[1];w=a.match("rel=[\"'](.*)?[\"']");a=a.match("media=[\"'](.*)?[\"']");try{var t=g.createStyleSheet(n)}catch(N){t=g.createElement("link"),t.href=n}w&&(t.rel=w[1]);a&&(t.media=a[1]);return[t]}if(a.match(/^<script/i))return a=a.match("src=[\"'](.*)?[\"']"),
g=g.createElement("script"),g.async=!0,a&&(g.src=a[1]),[g];g=g.createElement(w);g.innerHTML=a;for(t=[];a=g.firstChild;)t.push(a),n.appendChild(a);return t};const k=(a,g,n)=>{g=(g||"").trim();n=(n="string"===typeof n?n.trim():n)||G;n="string"===typeof n?G.querySelectorAll(n):n;"length"in n?C(n).h(w=>{a.i.apply(a,w.querySelectorAll(g))}):a.i.apply(a,n.querySelectorAll(g))},l=a=>{if(a){if(11===a.getRootNode().nodeType)return a.getRootNode();if(9===a.nodeType)return a;if(a.ownerDocument)return a.ownerDocument}return G},
r=a=>{q=!0;for(let g=0,n=e.length;g<n;g++)e[g](a);e=[]},v=G.readyState;"complete"===v||"interactive"===v?r():m(E,"DOMContentLoaded",r)})();const ma={m:function(f,q){return`<div id="container">
	<div id="header">
		<h1>Dictionary Bubble</h1>
	</div>
	<div id="page">
		<form id="content" method="post">
			<h2>Extension Options</h2>
			<span id="version">Version: <span>${f.version}</span></span>

			<div class="col_ab">
				<div class="col_a">Display bubble</div>
				<div class="col_b">
					<input type="checkbox" id="doubleClickEnabled" />
					<label for="doubleClickEnabled">When I double-click a word</label>
					<div class="dblclick_checkbox key_group ${q.className({disabled:!f.form.doubleClickEnabled})}">
						<label for="doubleClickKey">Trigger key:</label>
						<select id="doubleClickKey"	${f.form.doubleClickEnabled?"":"disabled"}>
							<option value="">None</option>
							<option value="ctrlKey">Ctrl</option>
							<option value="altKey">Alt</option>
							<option value="shiftKey">Shift</option>
						</select>
					</div>

					<input type="checkbox" id="selectionEnabled" />
					<label for="selectionEnabled">When I select a word or phrase</label>
					<div class="select_checkbox key_group ${q.className({disabled:!f.form.selectionEnabled})}">
						<label for="selectionKey">Trigger key:</label>
						<select id="selectionKey" ${f.form.selectionEnabled?"":"disabled"}>
							<option value="">None</option>
							<option value="ctrlKey">Ctrl</option>
							<option value="altKey">Alt</option>
							<option value="shiftKey">Shift</option>
						</select>
					</div>

					<input type="checkbox" id="longClickEnabled" />
					<label for="longClickEnabled">When I long click <div class="label_note">(Hold left click for a second or longer)</div></label>
				</div>
			</div>

			<div class="col_ab">
				<div class="col_a">Font size</div>
				<div class="col_b">
					<select id="fontSize">
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
						<option value="16">16</option>
						<option value="17">17</option>
						<option value="18">18</option>
					</select> pixels
				</div>
			</div>

			<div class="col_ab" style="display:table;clear:both">
				<div class="col_a">Word history</div>
				<div class="col_b">
					<input type="checkbox" id="wordHistoryEnabled" />
					<label for="wordHistoryEnabled">Store words I look up</label><br />
					<label style="display: inline-block; padding-left: 25px">Number of words stored in history:	<span>${f.u}</span></label>
					<br />
					<br />
					<div style="display: inline-block; padding-left: 25px">
						<a href="#" id="download-history-link" download="DictionaryBubbleHistory.csv"></a>
						<button ${f.u?"":"disabled"} id="downloadHistory">Download history</button>
						<button ${f.u?"":"disabled"} id="clearHistory">Clear history</button>
					</div>
				</div>
			</div>

			<div class="col_ab" style="display:table;clear:both">
				<p style="color:#666;font-size:13px">Note: based on users' demand, search keyword for address bar is now changed from "<span style="color:black;font-weight:bold">define</span>" to "<span style="color:black;font-weight:bold">gwg</span>".</p>
			</div>

			<div class="col_ab">
				<div class="col_a"></div>
				<div class="col_b align_center">
					<button ${f.s?"disabled":""} id="submit">Save</button>
					<button ${f.s?"disabled":""} id="reset" type="reset">Reset</button>
					<span style="color:white;background-color:#666;display:inline-block;visibility:hidden;padding:3px 10px 5px 8px;border-radius:3px;font-weight:bold;visibility:${f.D?"visible":"hidden"}">
						<img src="../images/tick.png" style="margin:2px 8px 0 0;float:left;" /> Options saved
					</span>
				</div>
			</div>

		</form>
		<div id="footer">
			Copyright &copy; <span class="year">2012 - ${f.ha}</span> GoodWordGuide.com.
		</div>
	</div>
</div>

<div id="dialog-wrapper" v-if="firstRun && dialog.open" style="height:100%;width:100%" v-cloak>
	<div id="dialog">
		<div id="dialog-title" v-text="dialog.title"></div>
		<div id="dialog-content">
			<div id="dialog-message" v-text="dialog.message"></div>
			<button id="dialog-button" v-text="dialog.buttonLabel" v-on:click="dialog.open = false"></button>
		</div>
	</div>
</div>`},data:{form:{doubleClickEnabled:!0,selectionEnabled:!1,longClickEnabled:!0},D:!1,s:!0,ha:(new Date).getFullYear(),Ha:{Ga:"Ok",message:"The pop-up bubble will not work in tabs that were open prior to installation; such tabs must be refreshed. Also, note that all extensions are disabled on app Store pages.",open:!0,title:"Important"},version:I.runtime.getManifest().version,u:0},methods:{className:function(f){const q=[];for(let e in f)f[e]&&q.push(e);return q.join(" ")},clearHistory:function(f){f.preventDefault();
z.j("WORD_HISTORY_CLEAR",()=>{H.u=0});return!1},downloadHistory:function(f){f.preventDefault();z.j("WORD_HISTORY_GET_ALL",q=>{let e='"Word","Count","URL","Last lookup date/time"\n';const m=G.getElementById("download-history-link");q.forEach(h=>{h=h.value;e+='"'+h.word+'","';e+=h.count+'","';e+="https://www.goodwordguide.com/define/"+h.word.replace(/\s+/g,"+")+'","';e+=(new Date(h.date)).toLocaleString()+'"\n'});m.href=E.URL.createObjectURL(new Blob([e],{type:"text/plain"}));q=G.createEvent("MouseEvents");
q.initEvent("click",!0,!0);m.dispatchEvent(q)});return!1},ja:function(){z.j("WORD_HISTORY_COUNT",f=>{H.u=f})},reset:function(f){f&&f.preventDefault();z.j("SETTINGS_GET_ALL",q=>{for(let e in q){H.form[e]=q[e];let m=C("#"+e)[0];console.log(e,q[e]);m&&("checkbox"===m.type?m.checked=q[e]:C(m).R(q[e]))}setTimeout(()=>{H.s=!0},200)});return!1},submit:function(f){const q=Object.assign({},H.form);H.s=!0;f.preventDefault();q.doubleClickEnabled||(q.doubleClickKey="");q.selectionEnabled||(q.selectionKey="");
q.fontSize=E.parseInt(q.fontSize,10);z.j("SETTINGS_SET_ALL",q,()=>{H.D=!0;setTimeout(()=>{H.D=!1},2225)});return!1},C:function(){}},H:function(){U.methods.ja();U.methods.reset();H.D=!1;z.j("FIRST_RUN",f=>{H.Ka=f})}},U=new la(G.getElementById("gwg-body"),ma),H=U.data;U.C(()=>{U.H()});C("#content").P("change",f=>{f=f.srcElement;let q=C(f).R(),e=C(f).L(q);"checkbox"===f.type&&(q=f.checked?e||!0:!1);H.form[f.id]=q;H.s=!1});C("#content").P("click",f=>{const q=f.srcElement;if("BUTTON"===q.tagName)U.methods[q.id](f,
q)})})();
//# sourceMappingURL=options.js.map