
function GrootSearch1(info,tab){chrome.tabs.create({url:"https://office.ssuiteoffice.com/"});};

function GrootSearch2(info,tab){chrome.tabs.create({url:"https://speed.ssuiteoffice.com/"});};

function GrootSearch3(info,tab){chrome.tabs.create({url:"https://dune.ssuiteoffice.com/"});};

function GrootSearch4(info,tab){chrome.tabs.create({url:"https://grabby.ssuiteoffice.com/"});};

function GrootSearch5(info,tab){chrome.tabs.create({url:"https://paint.ssuiteoffice.com/"});};

function GrootSearch6(info,tab){chrome.tabs.create({url:"https://opmmarket.ssuiteoffice.com/"});};

function GrootSearch7(info,tab){chrome.tabs.create({url:"https://tv.ssuiteoffice.com/"});};


// Create a context menu item when the extension is installed
chrome.runtime.onInstalled.addListener(() => {
	
	
  chrome.contextMenus.create({
    id: 'test-me',
    title: 'SSuite Office ToolBox',
    contexts: ['all']
  });
  
  
// Adding Sub-Menus to the context menu popup shortcut!  
  // Create the first sub-menu item
  chrome.contextMenus.create({
    id: 'sub-menu-1',
    parentId: 'test-me',
    title: '🚀  Internet Speed Check',
    contexts: ['all']
  });

  // Create the second sub-menu item
  chrome.contextMenus.create({
    id: 'sub-menu-2',
    parentId: 'test-me',
    title: '🌦  Dune Local Weather',
    contexts: ['all']
  });
  
  // Create the second sub-menu item
  chrome.contextMenus.create({
    id: 'sub-menu-3',
    parentId: 'test-me',
    title: '🔊  Grabby AV Recorder',
    contexts: ['all']
  });
  
  // Create the second sub-menu item
  chrome.contextMenus.create({
    id: 'sub-menu-4',
    parentId: 'test-me',
    title: '🎨  MS Paint Editor',
    contexts: ['all']
  });
  
  // Create the second sub-menu item
  chrome.contextMenus.create({
    id: 'sub-menu-5',
    parentId: 'test-me',
    title: '📈  OPM Market Watch',
    contexts: ['all']
  });
  
  // Create the second sub-menu item
  chrome.contextMenus.create({
    id: 'sub-menu-6',
    parentId: 'test-me',
    title: '📺  Stream-TV Portal',
    contexts: ['all']
  });
  
});


// Handle clicks on the context menu item
chrome.contextMenus.onClicked.addListener((info,tab) => {
	
	//if(info.menuItemId=="test-me"){GrootSearch(info,tab)};
	
  switch (info.menuItemId) {
    case 'test-me':
      GrootSearch1(info,tab);
      break;
    case 'sub-menu-1':
      GrootSearch2(info,tab);
      break;
    case 'sub-menu-2':
      GrootSearch3(info,tab);
      break;
	case 'sub-menu-3':
      GrootSearch4(info,tab);
      break;
	case 'sub-menu-4':
      GrootSearch5(info,tab);
      break;
	case 'sub-menu-5':
      GrootSearch6(info,tab);
      break;
	case 'sub-menu-6':
      GrootSearch7(info,tab);
      break;
  } 
});

chrome.runtime.onInstalled.addListener(function(){chrome.tabs.create({url:"https://www.ssuiteoffice.com/software.htm"});});
chrome.runtime.setUninstallURL("https://www.ssuiteoffice.com/software.htm");