export default {
    "id": 1,
    "group": "GlobalWhitelist",
    "priority": 2,
    "action": {
        "type": "allow"
    },
    "condition": {
        "resourceTypes": ["main_frame"],
        "requestDomains": []
    }
}