if (typeof window !== 'undefined') {
    window.modules = window.modules || {};
    window.require = window.require || function (modulePath) {
        if (window.modules[modulePath]) {
            return window.modules[modulePath];
        }
        if (modulePath === './content-exports-shim' || modulePath === './module-compat') {
            window.modules[modulePath] = {};
            return window.modules[modulePath];
        }
        console.warn(`Module ${modulePath} not found in cache. Using empty object.`);
        window.modules[modulePath] = {};
        return window.modules[modulePath];
    };
    if (typeof require === 'undefined') {
        var require = window.require;
    }
}
export {};
//# sourceMappingURL=content-require-shim.js.map