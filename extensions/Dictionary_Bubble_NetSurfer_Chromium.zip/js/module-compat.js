if (typeof window !== 'undefined') {
    if (typeof window.exports === 'undefined') {
        window.exports = {};
    }
    if (typeof exports === 'undefined') {
        var exports = window.exports;
    }
}
export {};
//# sourceMappingURL=module-compat.js.map