// Define exports object for CommonJS compatibility in browser
if (typeof window !== 'undefined') {
    if (typeof window.exports === 'undefined') {
        window.exports = {};
    }
    if (typeof exports === 'undefined') {
        var exports = window.exports;
    }
}