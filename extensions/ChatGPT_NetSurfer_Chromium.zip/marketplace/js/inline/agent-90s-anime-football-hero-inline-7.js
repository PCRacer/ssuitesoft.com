window.__AITOPIA_AGENT_RUN__ = {
    agentId: '90s-anime-football-hero',
    useModelSelector: true
  };