window.__AITOPIA_AGENT_RUN__ = {
    agentId: '3d-store',
    useModelSelector: true
  };