window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'anime-generator-pro-2',
    useModelSelector: true
  };