window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'amazon-seo-research-v2',
    useModelSelector: true
  };