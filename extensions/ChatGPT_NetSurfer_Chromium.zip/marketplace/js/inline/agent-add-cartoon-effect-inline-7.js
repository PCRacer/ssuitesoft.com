window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'add-cartoon-effect',
    useModelSelector: true
  };