window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'ai-ugc-creator-video-copy',
    useModelSelector: true
  };