window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'ai-background-generator-pro-2',
    useModelSelector: true
  };