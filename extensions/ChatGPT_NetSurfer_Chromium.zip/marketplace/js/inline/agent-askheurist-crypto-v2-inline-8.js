window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'askheurist-crypto-v2',
    useModelSelector: true
  };