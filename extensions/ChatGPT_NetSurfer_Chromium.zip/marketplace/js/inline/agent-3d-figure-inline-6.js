import GtagEvents from '/marketplace/js/shared/gtag-events.js';
    const agent = window.__agent;
    // view_item is NOT pushed on page-load: the agent's per-run credit cost depends on the
    // selected model + form state, both of which are settled later by embed-runner.js. We wait
    // for the first 'aitopia:agent-credits-changed' event (fired by updateRunButtonCredits in
    // embed-runner.js — which runs once on model-selector init and again on every change) and
    // push view_item with the actual credit value the user sees on the Generate button.
    let lastCredits = null;
    document.addEventListener('aitopia:agent-credits-changed', (e) => {
      if (!agent) return;
      const credits = Number(e.detail?.credits);
      if (!Number.isFinite(credits) || credits <= 0) return;
      if (credits === lastCredits) return; // skip redundant re-pushes
      lastCredits = credits;
      agent.credits = credits;
      GtagEvents.pushFor('agentDetail', 'view_item', { agent });
    });
    document.addEventListener('aitopia:agent-generate-success', () => {
      if (!agent) return;
      GtagEvents.pushFor('agentDetail', 'spend_virtual_currency', { agent });
    });
    document.addEventListener('aitopia:agent-credit-limit', (e) => {
      const limitType = e.detail?.limitType || 'Out of credits';
      GtagEvents.pushFor('agentDetail', 'trail_limit', { limitType });
    });