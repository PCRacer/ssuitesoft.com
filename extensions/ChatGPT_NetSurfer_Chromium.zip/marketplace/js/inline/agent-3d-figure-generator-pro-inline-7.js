window.__AITOPIA_AGENT_RUN__ = {
    agentId: '3d-figure-generator-pro',
    useModelSelector: true
  };