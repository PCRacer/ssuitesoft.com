window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'action-hero-scenes-2',
    useModelSelector: true
  };