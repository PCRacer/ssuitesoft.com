window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'background-remover-v2-2',
    useModelSelector: true
  };