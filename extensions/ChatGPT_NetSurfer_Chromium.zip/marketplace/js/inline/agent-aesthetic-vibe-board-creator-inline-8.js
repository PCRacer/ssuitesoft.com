window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'aesthetic-vibe-board-creator',
    useModelSelector: true
  };