window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'agency-campaign-image-studio',
    useModelSelector: true
  };