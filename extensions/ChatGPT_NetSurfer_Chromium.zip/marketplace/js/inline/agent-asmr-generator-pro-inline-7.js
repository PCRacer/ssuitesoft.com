window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'asmr-generator-pro',
    useModelSelector: true
  };