import { listDrafts, deleteDraft, cloneDraft, importDraftFromObject, upsertDraftFromServer } from '/marketplace/js/agent-builder/state.js';

    // Import JSON → new draft slot → jump into its edit page.
    const importBtn = document.getElementById('import-json-btn');
    const importInput = document.getElementById('import-json-file');
    if (importBtn && importInput) {
      importBtn.addEventListener('click', () => { importInput.value = ''; importInput.click(); });
      importInput.addEventListener('change', async () => {
        const file = importInput.files?.[0];
        if (!file) return;
        try {
          const parsed = JSON.parse(await file.text());
          const newId = importDraftFromObject(parsed);
          window.location.href = `/agent-builder/edit/${encodeURIComponent(newId)}`;
        } catch (err) {
          console.error('[agent-builder] draft import failed', err);
          alert('Import failed: ' + (err?.message || 'invalid JSON'));
        } finally {
          importInput.value = '';
        }
      });
    }

    const PASS_LABELS = {
      1: 'Metadata',
      2: 'Media',
      3: 'Steps',
      4: 'Fields',
      5: 'Publish',
    };

    // Server-side rows for the calling author, fetched once from
    // GET /api/agent-builder/mine. id → { name, version, status, data }.
    // Lets each card render the published copy and re-seed a cleared slot.
    const serverById = new Map();
    async function loadServer() {
      try {
        const res = await fetch('https://aitopia.ai/api/agent-builder/mine', { credentials: 'include' });
        const json = res.ok ? await res.json() : null;
        if (json && Array.isArray(json.agents)) {
          for (const a of json.agents) {
            if (a && typeof a.id === 'string') serverById.set(a.id, a);
          }
        }
      } catch {
        // Offline / unauthenticated — fall back to localStorage-only rendering.
      }
    }

    /**
     * Merge localStorage drafts with the server rows into the list the grid
     * renders. The source is decided by the version marker alone — no content
     * compare:
     *   - local-only (no DB row)         → render local.
     *   - DB-only (slot cleared)         → render DB.data, re-seed localStorage.
     *   - local.publishedVersion === DB.version → in sync → render DB.data.
     *   - otherwise (a "-local" marker, or null) → edited locally → render local.
     * An author edit stamps "-local" onto publishedVersion (state.notify), so a
     * synced slot keeps the bare version and an edited one never matches the DB.
     */
    function buildRows() {
      const local = listDrafts();
      const localById = new Map(local.map(r => [r.id, r]));
      const rows = [];

      for (const lr of local) {
        const srv = serverById.get(lr.id);
        const inSync = !!srv
          && lr.publishedVersion != null
          && lr.publishedVersion === srv.version;
        if (inSync) {
          // Render the authoritative server copy; keep the local pass for the
          // meta pill. Re-seed localStorage so the slot holds the current DB
          // doc (a remote edit could have advanced it).
          upsertDraftFromServer(lr.id, srv.data, srv.version);
          rows.push({ id: lr.id, agent: srv.data, pass: lr.pass, source: 'db', status: srv.status, updatedAt: lr.updatedAt || 0 });
        } else {
          rows.push({ id: lr.id, agent: lr.agent, pass: lr.pass, source: 'local', status: srv?.status ?? null, updatedAt: lr.updatedAt || 0 });
        }
      }

      // DB rows with no local slot (localStorage was cleared) — re-seed so the
      // author can keep editing, and render from the server doc.
      for (const [id, srv] of serverById) {
        if (localById.has(id)) continue;
        upsertDraftFromServer(id, srv.data, srv.version);
        rows.push({ id, agent: srv.data, pass: 5, source: 'db', status: srv.status, updatedAt: 0 });
      }

      // Most recently edited first. `_new-*` placeholders (no real id yet) go
      // last. Ties / legacy slots without a timestamp fall back to id order.
      rows.sort((a, b) => {
        const aNew = a.id.startsWith('_new-');
        const bNew = b.id.startsWith('_new-');
        if (aNew !== bNew) return aNew ? 1 : -1;
        if (a.updatedAt !== b.updatedAt) return b.updatedAt - a.updatedAt;
        return a.id.localeCompare(b.id);
      });
      return rows;
    }

    // Free-text filter over the current draft list. Empty string shows all.
    let searchQuery = '';
    function matchesSearch(row) {
      if (!searchQuery) return true;
      const haystack = [
        row.id,
        row.agent?.name,
        row.agent?.description,
        row.agent?.category,
        Array.isArray(row.agent?.tags) ? row.agent.tags.join(' ') : '',
      ].join(' ').toLowerCase();
      return haystack.includes(searchQuery);
    }

    function render() {
      const grid = document.getElementById('drafts-grid');
      const empty = document.getElementById('empty-state');
      // Explicitly release each card's media player before tearing the grid
      // down. Dropping a <video> from the DOM does NOT immediately free its
      // WebMediaPlayer in Chrome — across the frequent re-renders (every search
      // keystroke, every storage event) the players pile up and trip the cap.
      // Pausing + clearing src + load() forces the release now.
      grid.querySelectorAll('video').forEach(v => {
        try { v.pause(); v.removeAttribute('src'); v.load(); } catch {}
      });
      grid.innerHTML = '';
      const allRows = buildRows();
      const rows = allRows.filter(matchesSearch);

      if (allRows.length === 0) {
        // No agents at all.
        empty.querySelector('h2').textContent = 'No agents yet';
        empty.querySelector('p').innerHTML = 'Click <strong>New agent</strong> above to start your first one.';
        empty.hidden = false;
        return;
      }
      if (rows.length === 0) {
        // Agents exist but the search filtered them all out.
        empty.querySelector('h2').textContent = 'No matching agents';
        empty.querySelector('p').textContent = `Nothing matches “${searchQuery}”.`;
        empty.hidden = false;
        return;
      }
      empty.hidden = true;

      for (const row of rows) {
        const card = document.createElement('div');
        const isApproved = row.status === 'approved';
        card.className = isApproved ? 'draft-card approved' : 'draft-card';

        const name = String(row.agent.name || '').trim() || (row.id.startsWith('_new-') ? 'Untitled agent' : row.id);
        const desc = String(row.agent.description || '').trim();
        const category = String(row.agent.category || '').trim();
        const passLabel = PASS_LABELS[row.pass] || `Pass ${row.pass}`;
        const isUnsaved = row.id.startsWith('_new-');

        card.innerHTML = `
          <div>
            <div class="draft-card-title">${escapeHtml(name)}</div>
            <div class="draft-card-id">${escapeHtml(isUnsaved ? 'unsaved · no id yet' : row.id)}</div>
          </div>
          ${renderMediaBlock(row.agent)}
          ${desc ? `<div class="draft-card-desc">${escapeHtml(desc)}</div>` : ''}
          <div class="draft-card-meta">
            ${isApproved ? '<span class="draft-pill approved">✓ Approved</span>' : ''}
            <span class="draft-pill">${escapeHtml(passLabel)}</span>
            ${category ? `<span class="draft-pill">${escapeHtml(category)}</span>` : ''}
            ${Array.isArray(row.agent.fields) && row.agent.fields.length ? `<span class="draft-pill">${row.agent.fields.length} field${row.agent.fields.length === 1 ? '' : 's'}</span>` : ''}
            ${Array.isArray(row.agent.steps) && row.agent.steps.length ? `<span class="draft-pill">${row.agent.steps.length} step${row.agent.steps.length === 1 ? '' : 's'}</span>` : ''}
          </div>
          <div class="draft-card-actions">
            <a class="btn primary" href="/marketplace/agent-builder/edit/${encodeURIComponent(row.id)}">Open</a>
            <button type="button" class="btn" data-action="duplicate" title="Duplicate this agent into a new one">
              <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
              Duplicate
            </button>
          </div>
          <button type="button" class="delete-btn" data-action="delete" aria-label="Delete agent" title="Delete agent">
            <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>
            </svg>
          </button>
        `;

        card.querySelector('[data-action="delete"]').addEventListener('click', () => {
          if (row.status === 'approved') {
            alert('Approved agents cannot be deleted from this surface.');
            return;
          }
          const what = name === row.id || isUnsaved ? `this agent (${name})` : `"${name}" (${row.id})`;
          if (!confirm(`Delete ${what}? This cannot be undone.`)) return;
          deleteDraft(row.id);
          render();
        });

        card.querySelector('[data-action="duplicate"]').addEventListener('click', () => {
          // Approved rows can still be cloned — the clone lands as a fresh
          // draft owned by the author, untouched on the server side.
          const newId = cloneDraft(row.id);
          if (!newId) {
            alert('Could not duplicate this agent.');
            return;
          }
          // Jump straight into the new draft so the author can rename + edit.
          window.location.href = `/agent-builder/edit/${encodeURIComponent(newId)}`;
        });

        // Play the preview only while the pointer is over the card. This keeps
        // at most one WebMediaPlayer active at a time, so a large grid never
        // trips Chrome's player cap. On leave we pause and rewind so the next
        // hover starts clean.
        const video = card.querySelector('video');
        if (video) {
          card.addEventListener('mouseenter', () => { video.play().catch(() => {}); });
          card.addEventListener('mouseleave', () => { video.pause(); video.currentTime = 0; });
        }

        grid.appendChild(card);
      }
    }

    function isVideoUrl(url) {
      const s = String(url || '').toLowerCase();
      return /\.(mp4|mov|webm|m4v)(\?|#|$)/.test(s) || s.startsWith('data:video/') || s.includes('/video/');
    }

    function pickShowcaseMedia(agent) {
      const videos = Array.isArray(agent?.showcase_videos) ? agent.showcase_videos.filter(Boolean) : [];
      const images = Array.isArray(agent?.showcase_images) ? agent.showcase_images.filter(Boolean) : [];
      if (images.length) return { kind: 'image', url: String(images[0]) };
      if (videos.length) return { kind: 'video', url: String(videos[0]) };
      return null;
    }

    function renderMediaBlock(agent) {
      const media = pickShowcaseMedia(agent);
      if (!media) return '';
      const url = escapeHtml(media.url);
      const treatAsVideo = media.kind === 'video' || isVideoUrl(media.url);
      if (treatAsVideo) {
        // Do NOT autoplay. Every autoplaying <video> holds a WebMediaPlayer, and
        // Chrome caps how many can exist at once (crbug.com/1144736) — a grid of
        // autoplaying cards blows past the limit and freezes the page. Instead we
        // preload only metadata (so the first frame shows as a poster) and play
        // on hover; the card's mouseenter/leave handlers drive it.
        return `
          <div class="draft-card-media">
            <video src="${url}" muted loop playsinline preload="metadata"></video>
            <span class="media-badge">Video</span>
          </div>`;
      }
      return `
        <div class="draft-card-media">
          <img src="${url}" alt="" loading="lazy">
        </div>`;
    }

    function escapeHtml(s) {
      return String(s ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    }

    // Live search — re-render on every keystroke (the list is tiny, no debounce
    // needed).
    document.getElementById('drafts-search')?.addEventListener('input', (e) => {
      searchQuery = String(e.target.value || '').trim().toLowerCase();
      render();
    });

    // Re-render if another tab/window mutates a draft. Debounced: a single
    // user action can fire several draft `storage` events in a burst, and
    // render() itself re-seeds synced slots — coalescing into one render keeps
    // multiple open tabs from ping-ponging. upsertDraftFromServer is now a
    // no-op when nothing changed, so this can't loop, but the debounce also
    // smooths legitimate bursts.
    let storageRenderTimer = null;
    window.addEventListener('storage', (e) => {
      if (!e.key || !e.key.startsWith('aitopia.agent-builder.v4.draft.')) return;
      if (storageRenderTimer) clearTimeout(storageRenderTimer);
      storageRenderTimer = setTimeout(() => { storageRenderTimer = null; render(); }, 150);
    });

    // First paint from localStorage (instant), then merge in the server rows —
    // approved styling, published-copy rendering, and cleared-slot recovery all
    // land on the second render once /mine resolves.
    render();
    loadServer().then(render);