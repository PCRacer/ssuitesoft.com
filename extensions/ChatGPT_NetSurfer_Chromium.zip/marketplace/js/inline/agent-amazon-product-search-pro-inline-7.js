window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'amazon-product-search-pro',
    useModelSelector: true
  };