window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'ai-cinematic-product-ad',
    useModelSelector: true
  };