window.__AITOPIA_AGENT_RUN__ = {
    agentId: '60s-cafe-time-machine',
    useModelSelector: true
  };