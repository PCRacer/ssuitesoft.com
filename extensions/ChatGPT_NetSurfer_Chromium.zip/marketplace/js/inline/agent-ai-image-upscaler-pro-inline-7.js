window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'ai-image-upscaler-pro',
    useModelSelector: true
  };