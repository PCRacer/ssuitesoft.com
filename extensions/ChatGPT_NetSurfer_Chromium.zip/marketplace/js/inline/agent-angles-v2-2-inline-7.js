window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'angles-v2-2',
    useModelSelector: true
  };