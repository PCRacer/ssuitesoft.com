window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'ai-task-coordinator',
    useModelSelector: true
  };