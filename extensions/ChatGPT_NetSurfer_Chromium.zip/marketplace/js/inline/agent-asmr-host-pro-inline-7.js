window.__AITOPIA_AGENT_RUN__ = {
    agentId: 'asmr-host-pro',
    useModelSelector: true
  };