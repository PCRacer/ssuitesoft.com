(function() {
  const AF_VERSION = 'advanced-features-v1';
  if (window.__AITOPIA_ADVANCED_FEATURES__ === AF_VERSION) return;
  window.__AITOPIA_ADVANCED_FEATURES__ = AF_VERSION;

  const FEATURES = [
    {
      title: 'AI Agents for Automation & Content Creation',
      description: 'Generate images, videos, and audio - automate any creative workflow with AI agents.',
      image: 'https://aitopia.ai/agent-images/on-fire-1.webp',
      href: '/marketplace/agents.html',
    },
    {
      title: 'AI Image & Video Remix Studio',
      description: 'Remix and regenerate AI images and videos instantly. Share with your team',
      image: 'https://aitopia.ai/agent-images/features-remix.webp',
      href: '/marketplace/outputs.html',
    },
    {
      title: 'Explore AI Models & Generator',
      description: 'Access 64+ AI video, image, and audio generation models including Kling, Veo 3, Seedance.',
      image: 'https://aitopia.ai/agent-images/features-models.webp',
      href: '/marketplace/models.html',
    },
  ];

  let activeIndex = 0;
  let mobileAutoInterval = null;

  function arrowIcon() {
    return '<svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>';
  }

  function renderFeatureItem(feature, index) {
    const isActive = index === activeIndex;
    const activeCls = isActive
      ? 'bg-[#F0F0F2] dark:bg-[#0F0F0F] border-transparent'
      : 'bg-transparent border-transparent hover:bg-[#F5F5F7] dark:hover:bg-[#111]';
    return `<a href="${feature.href}" data-feature="${index}" class="af-item group flex items-center justify-between w-full text-left p-4 lg:p-5 rounded-2xl border h-[120px] ${activeCls} transition-all duration-300 cursor-pointer no-underline">
      <div class="min-w-0 pr-4">
        <h3 class="font-[600] mb-1 text-[16px] lg:text-[20px] ${isActive ? 'text-gray-900 dark:text-white' : 'text-gray-400 dark:text-white/40'} transition-colors duration-300" style="line-height:28px">${feature.title}</h3>
        <p class="text-[12px] xl:text-[14px] font-[400] ${isActive ? 'text-muted-foreground' : 'text-gray-300 dark:text-white/25'} transition-colors duration-300" style="line-height:24px">${feature.description}</p>
      </div>
      <div class="w-9 h-9 rounded-full border border-gray-200 dark:border-white/10 flex items-center justify-center shrink-0 ${isActive ? 'text-gray-500 dark:text-white/50 opacity-100' : 'opacity-0'} transition-all duration-300">
        ${arrowIcon()}
      </div>
    </a>`;
  }

  function render() {
    const container = document.getElementById('advanced-features-container');
    if (!container) return;

    container.innerHTML = `
<section class="bg-white dark:bg-[#0a0a0a] px-3 sm:px-4 mt-3 sm:mt-6">
  <div class="max-w-[1370px] mx-auto">

    <!-- Mobile layout -->
    <div class="lg:hidden">
      <div class="font-[600] text-gray-900 dark:text-white mb-4 text-center text-[20px] sm:text-[24px]">Discover Advanced AI Tools for Creators</div>

      <div class="relative rounded-2xl overflow-hidden bg-[#F5F5F7] dark:bg-[#111] mb-4" style="aspect-ratio:16/10">
        <img id="af-mobile-image" src="${FEATURES[0].image}" alt="${FEATURES[0].title}" class="w-full h-full object-cover transition-opacity duration-500" loading="lazy">
        <button id="af-prev" class="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 backdrop-blur flex items-center justify-center text-white/80 active:scale-95 transition-all">
          <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M15 19l-7-7 7-7"/></svg>
        </button>
        <button id="af-next" class="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 backdrop-blur flex items-center justify-center text-white/80 active:scale-95 transition-all">
          <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg>
        </button>
      </div>

      <a href="${FEATURES[0].href}" id="af-mobile-card" class="flex items-center justify-between p-4 rounded-2xl bg-[#F0F0F2] dark:bg-[#0F0F0F] no-underline mb-4">
        <div class="min-w-0 pr-4">
          <h3 id="af-mobile-title" class="font-[700] text-gray-900 dark:text-white mb-1 text-[16px]" style="line-height:20px">${FEATURES[0].title}</h3>
          <p id="af-mobile-desc" class="text-[12px] font-[400] text-muted-foreground" style="line-height:18px">${FEATURES[0].description}</p>
        </div>
        <div class="w-9 h-9 rounded-full border border-gray-200 dark:border-white/10 flex items-center justify-center shrink-0 text-gray-500 dark:text-white/50">
          ${arrowIcon()}
        </div>
      </a>

      <div class="flex justify-center gap-2" id="af-dots">
        ${FEATURES.map((_, i) => `<button data-dot="${i}" class="w-2 h-2 rounded-full transition-all duration-300 ${i === 0 ? 'bg-primary' : 'bg-gray-300 dark:bg-white/20'}"></button>`).join('')}
      </div>
    </div>

    <!-- Desktop layout -->
    <div class="hidden lg:block">
      <div class="font-[700] text-gray-900 dark:text-white mb-6 lg:mb-8 text-[20px] sm:text-[24px]">Discover Advanced AI Tools for Creators</div>

      <div class="flex flex-row gap-8">
        <div class="lg:w-[55%] shrink-0">
          <div class="relative rounded-2xl overflow-hidden bg-[#F5F5F7] dark:bg-[#111]" style="aspect-ratio:16/9">
            <img id="af-image" src="${FEATURES[0].image}" alt="${FEATURES[0].title}" class="w-full h-full object-cover transition-opacity duration-500" loading="lazy">
          </div>
        </div>
        <div class="flex-1 flex flex-col gap-2 justify-center" id="af-list">
          ${FEATURES.map((f, i) => renderFeatureItem(f, i)).join('')}
        </div>
      </div>
    </div>

  </div>
</section>`;

    bindEvents();
    startMobileAuto();
  }

  function setMobileActive(index) {
    activeIndex = index;
    const imgEl = document.getElementById('af-mobile-image');
    const titleEl = document.getElementById('af-mobile-title');
    const descEl = document.getElementById('af-mobile-desc');
    const cardEl = document.getElementById('af-mobile-card');
    const dotsEl = document.getElementById('af-dots');
    if (!imgEl || !titleEl || !descEl || !cardEl || !dotsEl) return;

    imgEl.style.opacity = '0';
    setTimeout(() => {
      imgEl.src = FEATURES[index].image;
      imgEl.alt = FEATURES[index].title;
      imgEl.style.opacity = '1';
    }, 250);

    titleEl.textContent = FEATURES[index].title;
    descEl.textContent = FEATURES[index].description;
    cardEl.href = FEATURES[index].href;

    dotsEl.innerHTML = FEATURES.map((_, i) => `<button data-dot="${i}" class="w-2 h-2 rounded-full transition-all duration-300 ${i === index ? 'bg-primary' : 'bg-gray-300 dark:bg-white/20'}"></button>`).join('');

    dotsEl.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.dataset.dot, 10);
        setMobileActive(idx);
        restartMobileAuto();
      });
    });
  }

  function startMobileAuto() {
    if (mobileAutoInterval) clearInterval(mobileAutoInterval);
    mobileAutoInterval = setInterval(() => {
      setMobileActive((activeIndex + 1) % FEATURES.length);
    }, 4000);
  }

  function restartMobileAuto() {
    if (mobileAutoInterval) clearInterval(mobileAutoInterval);
    startMobileAuto();
  }

  function setActive(index) {
    if (index === activeIndex) return;
    activeIndex = index;

    const imageEl = document.getElementById('af-image');
    const listEl = document.getElementById('af-list');
    if (!imageEl || !listEl) return;

    imageEl.style.opacity = '0';
    setTimeout(() => {
      imageEl.src = FEATURES[index].image;
      imageEl.alt = FEATURES[index].title;
      imageEl.style.opacity = '1';
    }, 300);

    listEl.innerHTML = FEATURES.map((f, i) => renderFeatureItem(f, i)).join('');
    bindEvents();
  }

  function bindEvents() {
    const items = document.querySelectorAll('.af-item');
    items.forEach(item => {
      item.addEventListener('mouseenter', () => {
        const idx = parseInt(item.dataset.feature, 10);
        setActive(idx);
      });
      item.addEventListener('click', (e) => {
        const idx = parseInt(item.dataset.feature, 10);
        if (idx !== activeIndex) {
          e.preventDefault();
          setActive(idx);
        }
      });
    });

    const prevBtn = document.getElementById('af-prev');
    const nextBtn = document.getElementById('af-next');
    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        setMobileActive((activeIndex - 1 + FEATURES.length) % FEATURES.length);
        restartMobileAuto();
      });
    }
    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        setMobileActive((activeIndex + 1) % FEATURES.length);
        restartMobileAuto();
      });
    }

    const dotsEl = document.getElementById('af-dots');
    if (dotsEl) {
      dotsEl.querySelectorAll('button').forEach(btn => {
        btn.addEventListener('click', () => {
          const idx = parseInt(btn.dataset.dot, 10);
          setMobileActive(idx);
          restartMobileAuto();
        });
      });
    }
  }

  function init() {
    render();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
