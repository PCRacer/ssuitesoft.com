(function () {
  const FOOTER_VERSION = 'site-footer-v1';
  if (window.__AITOPIA_SITE_FOOTER__ === FOOTER_VERSION) return;
  window.__AITOPIA_SITE_FOOTER__ = FOOTER_VERSION;

  const DISCOVER_COL = {
    title: 'Discover',
    collapseAfter: 7,
    links: [
      { label: 'Extensions', href: 'https://chromewebstore.google.com/detail/chat-with-all-ai-models-g/becfinhbfclcgokjlobojlnldbfillpf' },
      { label: 'Affiliates', href: 'https://partners.dub.co/aitopia' },
      { label: 'Pricing', href: '/marketplace/pricing.html' },
      { label: 'Creator Program', href: '/marketplace/earn.html' },
      { label: 'Discord', href: 'https://discord.gg/NACTvaE95A' },
      { label: 'Terms of Service', href: '/terms-conditions' },
      { label: 'Privacy Policy', href: '/privacy-policy' },
    ],
  };

  const FOLLOW_COL = {
    title: 'Follow Us',
    links: [
      { label: 'Instagram', href: 'https://www.instagram.com/aitopiaai/' },
      { label: 'X', href: 'https://x.com/AITOPIAai' },
      { label: 'Youtube', href: 'https://www.youtube.com/@AITOPIAAI' },
      { label: 'Tiktok', href: 'https://www.tiktok.com/@aitopiaai' },
    ],
  };

  const COLUMNS_TOP = [
    {
      title: 'Image',
      collapseAfter: 6,
      links: [
        { label: 'Create Image', href: '/agents/image-generator' },
        { label: 'Image Upscale', href: '/agents/image-upscaler' },
        { label: 'Background Remover', href: '/agents/background-remover' },
        { label: 'Pixel Game Style', href: '/agents/pixel-game' },
        { label: 'Background Replacer', href: '/agents/background-replacer' },
        { label: '3D Figure Generator', href: '/agents/3d-figure' },
        { label: 'Flux 2', href: '/black-forest-labs/flux-2-flex' },
        { label: 'GPT Image 2', href: '/openai/gpt-image-2' },
      ],
    },
    {
      title: 'Video',
      collapseAfter: 6,
      links: [
        { label: 'Seedance 2.0', href: '/bytedance/seedance-2.0' },
        { label: 'Face Swap', href: '/agents/face-swap' },
        { label: 'Character Swap', href: '/agents/character-swap' },
        { label: 'Happy Horse', href: '/alibaba/happy-horse' },
        { label: 'Kling 3.0', href: '/kwaivgi/kling-v3-video' },
        { label: 'Veo 3.1', href: '/google/veo-3.1' },
        { label: 'Lip Sync Studio', href: '/agents/lipsync-studio' },
        { label: 'Video Upscale', href: '/agents/video-upscaler' },
        { label: 'Wan 2.6', href: '/wan-video/wan-2.6-t2v' },
      ],
    },
    {
      title: 'Productivity',
      collapseAfter: 6,
      links: [
        { label: 'Meeting Transcriber', href: '/agents/meeting-transcriber' },
        { label: 'Subtitle Translator', href: '/agents/subtitle-translate-pro' },
        { label: 'Image Translator', href: '/agents/image-translator' },
        { label: 'Resume Builder', href: '/agents/resume-builder' },
        { label: 'E-mail Template Generator', href: '/agents/email-template-generator' },
        { label: 'Youtube Summary', href: '/agents/youtube-to-social' },
        { label: 'AI Assistant', href: '/agents/ai-assistant' },
      ],
    },
    {
      title: 'Commerce',
      collapseAfter: 6,
      links: [
        { label: 'Virtual Try-on', href: '/agents/virtual-try-on' },
        { label: 'Product Description Writer', href: '/agents/product-description-writer' },
        { label: 'Product Photographer', href: '/agents/product-photographer' },
        { label: 'Product Angles Generator', href: '/agents/angles' },
        { label: 'Product Creative Studio', href: '/agents/product-creative-studio' },
        { label: 'Mockup Studio', href: '/agents/mockup-studio' },
        { label: 'Product Packshot', href: '/agents/packshot' },
        { label: 'Amazon Product Search', href: '/agents/amazon-product-search' },
        { label: 'Amazon SEO Research', href: '/agents/amazon-seo-research' },
        { label: 'HTML Landing Page Builder', href: '/agents/html-landing-builder' },
        { label: 'Chinese Dress Try-on', href: '/agents/chinese-dress-tryon' },
      ],
    },
  ];

  const COLUMNS_BOTTOM = [
    {
      title: 'Marketing',
      collapseAfter: 6,
      links: [
        { label: 'Social Media Caption Generator', href: '/agents/social-media-caption-generator' },
        { label: 'SEO Content Optimizer', href: '/agents/seo-content-optimizer' },
        { label: 'Giant Product', href: '/agents/giant-product' },
        { label: 'Video Script Generator', href: '/agents/video-script-generator' },
        { label: 'Insta Dump Generator', href: '/agents/instadump' },
        { label: 'Billboard Ad Generator', href: '/agents/billboard-ad' },
        { label: 'YouTube Thumbnail Generator', href: '/agents/youtube-thumbnail-gen' },
        { label: 'YouTube Title Generator', href: '/agents/youtube-title-generator' },
        { label: 'Caption AI', href: '/agents/caption-ai' },
        { label: 'Content Pilot AI', href: '/agents/content-pilot-ai' },
        { label: 'YouTube to Social', href: '/agent/youtube-to-social' },
        { label: 'Studio Portrait', href: '/agents/studio-portrait' },
        { label: 'Quipple Meme Generator', href: '/agents/quipple-meme-generator' },
        { label: 'Keyword SEO Tool', href: '/agents/kw-seo-tool' },
        { label: 'Instant SEO Blog', href: '/agents/instant-seo-blog' },
        { label: 'AI Social Creator', href: '/agents/ai-social-creator' },
        { label: 'Reddit Hunter', href: '/agents/reddit-hunter' },
        { label: 'One Prompt 10 Replies', href: '/agents/one-prompt-10-replies' },
      ],
    },
    {
      title: 'Audio & Voice',
      links: [
        { label: 'Music Generator', href: '/agents/music-generator' },
      ],
    },
    {
      title: 'Dev & Data',
      links: [
        { label: 'Smart Data Analyzer', href: '/agents/smart-data-analyzer' },
        { label: 'Data Visualisation Advisor', href: '/agents/data-visualization' },
        { label: 'Paper Review Agent', href: '/agents/paper-review-agent' },
        { label: 'Smart Q Analytics', href: '/agents/smart-q' },
        { label: 'n8n Stylist', href: '/agents/n8n-stylist' },
        { label: 'Ask Heurist Crypto', href: '/agents/askheurist' },
      ],
    },
    {
      title: 'Business',
      links: [
        { label: 'Product Description Writer', href: '/agents/product-description-writer' },
        { label: 'Product Photographer', href: '/agents/product-photographer' },
        { label: 'Product Creative Studio', href: '/agents/product-creative-studio' },
        { label: 'Amazon Product Search', href: '/agents/amazon-product-search' },
        { label: 'HTML Landing Page Builder', href: '/agents/html-landing-builder' },
      ],
    },
  ];

  function renderLink(l) {
    var ext = l.href.startsWith('http') ? ' target="_blank" rel="noopener"' : '';
    return '<a href="' + l.href + '"' + ext + ' class="block text-gray-600 dark:text-[#A1A1AA] hover:text-gray-900 dark:hover:text-white transition-colors text-[12px] leading-[15px] sm:text-[14px] sm:leading-[18px] font-normal">' + l.label + '</a>';
  }

  function renderCol(col) {
    var limit = col.collapseAfter;
    var hasMore = limit && col.links.length > limit;
    var visible = hasMore ? col.links.slice(0, limit) : col.links;
    var hidden = hasMore ? col.links.slice(limit) : [];

    var html = '<div><h4 class="text-gray-900 dark:text-white font-medium text-[14px] leading-[15px] sm:text-[16px] sm:leading-[18px] mb-4">' + col.title + '</h4><div class="flex flex-col gap-2.5">' +
      visible.map(renderLink).join('');

    if (hasMore) {
      html += '<div class="footer-more-links hidden flex-col gap-2.5">' + hidden.map(renderLink).join('') + '</div>' +
        '<button type="button" class="footer-more-toggle text-left text-gray-900 dark:text-white underline text-[14px] leading-[20px] hover:text-primary transition-colors cursor-pointer mt-0.5">More</button>';
    }

    html += '</div></div>';
    return html;
  }

  function render() {
    var container = document.getElementById('site-footer');
    if (!container) return;

    container.innerHTML =
      '<footer class="bg-[#F3F5F9] dark:bg-[#0a0a0a] border-t border-black/[0.06] dark:border-white/[0.06] mt-6">' +
        '<div class="max-w-[1370px] mx-auto px-6 sm:px-10 lg:px-16 pt-14 pb-10">' +
          '<div class="mb-12">' +
            '<a href="/marketplace/" class="inline-block" aria-label="AITOPIA">' +
              '<img src="/marketplace/Logo_footer.svg" alt="AITOPIA" class="h-7 w-auto" width="205" height="40" loading="lazy">' +
            '</a>' +
          '</div>' +
          // Desktop: Discover + category columns in top row
          '<div class="hidden sm:grid sm:grid-cols-3 lg:grid-cols-5 gap-x-8 gap-y-10 mb-14">' +
            renderCol(DISCOVER_COL) + COLUMNS_TOP.map(renderCol).join('') +
          '</div>' +
          // Mobile: only category columns in top row
          '<div class="grid grid-cols-2 sm:hidden gap-x-8 gap-y-10 mb-14">' +
            COLUMNS_TOP.map(renderCol).join('') +
          '</div>' +
          '<div class="pt-10">' +
            // Desktop: bottom row + Follow Us
            '<div class="hidden sm:grid sm:grid-cols-3 lg:grid-cols-5 gap-x-8 gap-y-10">' +
              COLUMNS_BOTTOM.map(renderCol).join('') + renderCol(FOLLOW_COL) +
            '</div>' +
            // Mobile: only bottom row (no Follow Us)
            '<div class="grid grid-cols-2 sm:hidden gap-x-8 gap-y-10">' +
              COLUMNS_BOTTOM.map(renderCol).join('') +
            '</div>' +
          '</div>' +
          // Mobile-only: Discover + Follow Us at bottom
          '<div class="grid grid-cols-2 sm:hidden gap-x-8 gap-y-10 border-t border-black/[0.06] dark:border-white/[0.06] mt-10 pt-10">' +
            renderCol(DISCOVER_COL) + renderCol(FOLLOW_COL) +
          '</div>' +
          '<div class="border-t border-black/[0.06] dark:border-white/[0.06] mt-14 pt-6 text-center">' +
            '<p class="text-gray-500 dark:text-[#71717A] text-[13px]">&copy; ' + new Date().getFullYear() + ' AITOPIA. All rights reserved.</p>' +
          '</div>' +
        '</div>' +
      '</footer>';

    container.querySelectorAll('.footer-more-toggle').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var links = btn.previousElementSibling;
        var isHidden = links.classList.contains('hidden');
        if (isHidden) {
          links.classList.remove('hidden');
          links.classList.add('flex');
          btn.textContent = 'Less';
        } else {
          links.classList.add('hidden');
          links.classList.remove('flex');
          btn.textContent = 'More';
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', render);
  } else {
    render();
  }
})();
