(function () {
  const FOOTER_VERSION = 'site-footer-v1';
  if (window.__AITOPIA_SITE_FOOTER__ === FOOTER_VERSION) return;
  window.__AITOPIA_SITE_FOOTER__ = FOOTER_VERSION;

  const DISCOVER_COL = {
    title: 'Discover',
    collapseAfter: 7,
    links: [
      { label: 'Extensions', href: 'https://chromewebstore.google.com/detail/chat-with-all-ai-models-g/becfinhbfclcgokjlobojlnldbfillpf' },
      { label: 'Affiliates', href: 'https://partners.dub.co/aitopia' },
      { label: 'Pricing', href: '/marketplace/pricing.html' },
      { label: 'Creator Program', href: '/marketplace/earn.html' },
      { label: 'Discord', href: 'https://discord.gg/NACTvaE95A' },
      { label: 'Terms of Service', href: '/terms-conditions' },
      { label: 'Privacy Policy', href: '/privacy-policy' },
    ],
  };

  const FOLLOW_COL = {
    title: 'Follow Us',
    links: [
      { label: 'Instagram', href: 'https://www.instagram.com/aitopiaai/' },
      { label: 'X', href: 'https://x.com/AITOPIAai' },
      { label: 'Youtube', href: 'https://www.youtube.com/@AITOPIAAI' },
      { label: 'Tiktok', href: 'https://www.tiktok.com/@aitopiaai' },
    ],
  };

  const COLUMNS_TOP = [
    {
      title: 'Image',
      collapseAfter: 6,
      links: [
        { label: 'Create Image', href: '/agents/image-generator' },
        { label: 'Nano Banana 2', href: '/google/nano-banana-2' },
        { label: 'GPT Image 2', href: '/openai/gpt-image-2' },
        { label: 'Flux 2 Pro', href: '/black-forest-labs/flux-2-pro' },
        { label: 'Image Upscale', href: '/agents/image-upscaler' },
        { label: 'Background Remover', href: '/agents/background-remover' },
        { label: 'Background Replacer', href: '/agents/background-replacer' },
        { label: 'Product Photographer v2', href: '/agents/product-photographer-v2' },
        { label: 'Headshot Generator v2', href: '/agents/headshot-generator-v2' },
        { label: 'Style Clone', href: '/agents/style-clone' },
        { label: 'Mockup Studio v2', href: '/agents/mockup-studio-v2' },
        { label: 'Seedream 5 Pro', href: '/bytedance/seedream-5-pro' },
        { label: 'Nano Banana Pro', href: '/google/nano-banana-pro' },
        { label: 'Grok Imagine Image', href: '/xai/grok-imagine-image' },
        { label: 'Qwen Image 2 Pro', href: '/qwen/qwen-image-2-pro' },
        { label: 'Imagen 4 Ultra', href: '/google/imagen-4-ultra' },
        { label: 'Kling Image O3', href: '/kwaivgi/kling-image-o3' },
      ],
    },
    {
      title: 'Video',
      collapseAfter: 6,
      links: [
        { label: 'Seedance 2.5', href: '/bytedance/seedance-2.5' },
        { label: 'Kling 3.0', href: '/kwaivgi/kling-v3-video' },
        { label: 'Veo 3.1', href: '/google/veo-3.1' },
        { label: 'Sora 2', href: '/openai/sora-2' },
        { label: 'Face Swap', href: '/agents/face-swap' },
        { label: 'Lip Sync Studio', href: '/agents/lipsync-studio' },
        { label: 'Character Swap', href: '/agents/character-swap' },
        { label: 'Video Upscale', href: '/agents/video-upscaler' },
        { label: 'Paparazzi v2', href: '/agents/paparazzi' },
        { label: 'Bullet Time Scenes Pro', href: '/agents/bullet-time-scenes-pro' },
        { label: 'Behind the Scenes v2', href: '/agents/behind-the-scenes-v2' },
        { label: 'Pro Video Watermark Remover', href: '/agents/pro-video-watermark-remover' },
        { label: 'Seedance 2.0', href: '/bytedance/seedance-2.0' },
        { label: 'Wan 2.7', href: '/wan-video/wan-2.7-i2v' },
        { label: 'Grok Imagine Video 1.5', href: '/xai/grok-imagine-video-1.5' },
        { label: 'Hailuo 2.3', href: '/minimax/hailuo-2.3' },
        { label: 'Happy Horse 1.1', href: '/alibaba/happy-horse-1.1' },
        { label: 'Pixverse 5.6', href: '/pixverse/v5.6' },
      ],
    },
    {
      title: 'Productivity',
      collapseAfter: 6,
      links: [
        { label: 'Subtitle Translator', href: '/agents/subtitle-translate-pro' },
        { label: 'Image Translator', href: '/agents/image-translator' },
        { label: 'Resume Builder', href: '/agents/resume-builder' },
        { label: 'E-mail Template Generator', href: '/agents/email-template-generator' },
        { label: 'Youtube Summary', href: '/agents/youtube-to-social' },
        { label: 'AI Assistant', href: '/agents/ai-assistant' },
        { label: 'Doc to Presentation', href: '/agents/doc2presentation' },
        { label: 'UpCV Resume Generator', href: '/agents/upcv-resume-gen' },
      ],
    },
    {
      title: 'Commerce',
      collapseAfter: 6,
      links: [
        { label: 'Virtual Try-on', href: '/agents/virtual-try-on' },
        { label: 'Product Packshot v2', href: '/agents/product-packshot-v2' },
        { label: 'Product Creative Studio v2', href: '/agents/product-creative-studio-v2' },
        { label: 'Product Lifestyle Scene v2', href: '/agents/product-lifestyle-scene-v2' },
        { label: 'Ecom Photo Maker', href: '/agents/ecom-photo-maker' },
        { label: 'White Background Product Photo', href: '/agents/white-background-product-photo' },
        { label: 'Product Angles v2', href: '/agents/product-angles-v2' },
        { label: 'HTML Landing Page Builder', href: '/agents/html-landing-builder' },
      ],
    },
  ];

  const COLUMNS_BOTTOM = [
    {
      title: 'Marketing',
      collapseAfter: 6,
      links: [
        { label: 'YouTube to Social', href: '/agents/youtube-to-social' },
        { label: 'Billboard Ad Generator Pro', href: '/agents/billboard-ad-generator-pro-2' },
        { label: 'YouTube Thumbnail Generator v2', href: '/agents/youtube-thumbnail-generator' },
        { label: 'Social Media Ad Creator', href: '/agents/social-media-ad-creator' },
        { label: 'AI UGC Creator Video', href: '/agents/ai-ugc-creator-video-copy' },
        { label: 'Viral Fridge Ad Hero', href: '/agents/viral-fridge-ad-hero' },
        { label: 'Insta Dump Generator v2', href: '/agents/insta-dump-generator-v2' },
        { label: 'Quipple Meme Generator', href: '/agents/quipple-meme-generator' },
        { label: 'AI Social Creator', href: '/agents/ai-social-creator' },
        { label: 'One Prompt 10 Replies', href: '/agents/one-prompt-10-replies' },
      ],
    },
    {
      title: 'Audio & Voice',
      collapseAfter: 6,
      links: [
        { label: 'Music Generator Pro 2', href: '/agents/music-generator-pro-2' },
        { label: 'Viral Podcast Studio', href: '/agents/viral-podcast-studio' },
        { label: 'Voice Cloner', href: '/agents/voice-cloner' },
        { label: 'ASMR Classic Pro', href: '/agents/asmr-classic-pro' },
        { label: 'Lyria 3 Pro', href: '/google/lyria-3-pro' },
        { label: 'ElevenLabs v3', href: '/elevenlabs/v3' },
        { label: 'MiniMax Speech 2.8', href: '/minimax/speech-2.8-hd' },
        { label: 'MiniMax Music 2.6', href: '/minimax/music-2.6' },
        { label: 'Grok TTS', href: '/xai/grok-text-to-speech' },
      ],
    },
    {
      title: 'Dev & Data',
      links: [
        { label: 'Smart Data Analyzer', href: '/agents/smart-data-analyzer' },
        { label: 'Data Visualisation Advisor', href: '/agents/data-visualization' },
        { label: 'Paper Review Agent', href: '/agents/paper-review-agent' },
        { label: 'Smart Q Analytics', href: '/agents/smart-q' },
        { label: 'n8n Stylist', href: '/agents/n8n-stylist' },
      ],
    },
    {
      title: 'Business',
      links: [
        { label: 'HTML Landing Page Builder', href: '/agents/html-landing-builder' },
        { label: 'Knowledge Card Factory v2', href: '/agents/knowledge-card-factory-v2' },
        { label: 'ResumePic LinkedIn v2', href: '/agents/resumepic-linkedin' },
        { label: 'Agency Campaign Image Studio', href: '/agents/agency-campaign-image-studio' },
      ],
    },
  ];

  function renderLink(l) {
    var ext = l.href.startsWith('http') ? ' target="_blank" rel="noopener"' : '';
    return '<a href="' + l.href + '"' + ext + ' class="block text-gray-600 dark:text-[#A1A1AA] hover:text-gray-900 dark:hover:text-white transition-colors text-[12px] leading-[15px] sm:text-[14px] sm:leading-[18px] font-normal">' + l.label + '</a>';
  }

  function renderCol(col) {
    var limit = col.collapseAfter;
    var hasMore = limit && col.links.length > limit;
    var visible = hasMore ? col.links.slice(0, limit) : col.links;
    var hidden = hasMore ? col.links.slice(limit) : [];

    var html = '<div><h4 class="text-gray-900 dark:text-white font-medium text-[14px] leading-[15px] sm:text-[16px] sm:leading-[18px] mb-4">' + col.title + '</h4><div class="flex flex-col gap-2.5">' +
      visible.map(renderLink).join('');

    if (hasMore) {
      html += '<div class="footer-more-links hidden flex-col gap-2.5">' + hidden.map(renderLink).join('') + '</div>' +
        '<button type="button" class="footer-more-toggle text-left text-gray-900 dark:text-white underline text-[14px] leading-[20px] hover:text-primary transition-colors cursor-pointer mt-0.5">More</button>';
    }

    html += '</div></div>';
    return html;
  }

  function render() {
    var container = document.getElementById('site-footer');
    if (!container) return;

    container.innerHTML =
      '<footer class="bg-[#F3F5F9] dark:bg-[#0a0a0a] border-t border-black/[0.06] dark:border-white/[0.06] mt-6">' +
        '<div class="max-w-[1370px] mx-auto px-6 sm:px-10 lg:px-16 pt-14 pb-10">' +
          '<div class="mb-12">' +
            '<a href="/marketplace/" class="inline-block" aria-label="AITOPIA">' +
              '<img src="/marketplace/Logo_footer.svg" alt="AITOPIA" class="h-7 w-auto" width="205" height="40" loading="lazy">' +
            '</a>' +
          '</div>' +
          // Desktop: Discover + category columns in top row
          '<div class="hidden sm:grid sm:grid-cols-3 lg:grid-cols-5 gap-x-8 gap-y-10 mb-14">' +
            renderCol(DISCOVER_COL) + COLUMNS_TOP.map(renderCol).join('') +
          '</div>' +
          // Mobile: only category columns in top row
          '<div class="grid grid-cols-2 sm:hidden gap-x-8 gap-y-10 mb-14">' +
            COLUMNS_TOP.map(renderCol).join('') +
          '</div>' +
          '<div class="pt-10">' +
            // Desktop: bottom row + Follow Us
            '<div class="hidden sm:grid sm:grid-cols-3 lg:grid-cols-5 gap-x-8 gap-y-10">' +
              COLUMNS_BOTTOM.map(renderCol).join('') + renderCol(FOLLOW_COL) +
            '</div>' +
            // Mobile: only bottom row (no Follow Us)
            '<div class="grid grid-cols-2 sm:hidden gap-x-8 gap-y-10">' +
              COLUMNS_BOTTOM.map(renderCol).join('') +
            '</div>' +
          '</div>' +
          // Mobile-only: Discover + Follow Us at bottom
          '<div class="grid grid-cols-2 sm:hidden gap-x-8 gap-y-10 border-t border-black/[0.06] dark:border-white/[0.06] mt-10 pt-10">' +
            renderCol(DISCOVER_COL) + renderCol(FOLLOW_COL) +
          '</div>' +
          '<div class="border-t border-black/[0.06] dark:border-white/[0.06] mt-14 pt-6 text-center">' +
            '<p class="text-gray-500 dark:text-[#71717A] text-[13px]">&copy; ' + new Date().getFullYear() + ' AITOPIA. All rights reserved.</p>' +
          '</div>' +
        '</div>' +
      '</footer>';

    container.querySelectorAll('.footer-more-toggle').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var links = btn.previousElementSibling;
        var isHidden = links.classList.contains('hidden');
        if (isHidden) {
          links.classList.remove('hidden');
          links.classList.add('flex');
          btn.textContent = 'Less';
        } else {
          links.classList.add('hidden');
          links.classList.remove('flex');
          btn.textContent = 'More';
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', render);
  } else {
    render();
  }
})();
