(function() {
  const SHOWCASE_VERSION = 'showcase-v1';
  if (window.__AITOPIA_SHOWCASE__ === SHOWCASE_VERSION) return;
  window.__AITOPIA_SHOWCASE__ = SHOWCASE_VERSION;

  const FEATURED_CARDS = [
    {
      id: 'lipsync-studio',
      title: 'AI Voice & Lip-Sync Studio',
      image: 'https://aitopia.ai/agent-images/lipsync-studio-1.webp',
      video: 'https://aitopia.ai/agent-images/home-lip-sync.mp4',
      badge: 'Trending',
      href: '/agents/lipsync-studio',
      type: 'tall',
    },
    {
      id: 'video-generator',
      title: 'AI Video Generator',
      subtitle: 'Ultra-realistic flagship foundation model',
      image: 'https://aitopia.ai/agent-images/video-generator-1.webp',
      video: 'https://aitopia.ai/agent-images/home-video-generator.mp4',
      badge: 'Seedance 2.0',
      href: '/agents/video-generator',
      type: 'featured',
    },
    {
      id: 'nano-banana',
      title: 'GPT Image 2',
      preTitle: 'Create Image with',
      image: 'https://aitopia.ai/agent-images/gpt-image-2.webp',
      newBadge: true,
      href: '/agents/image-generator',
      type: 'new',
    },
  ];

  const SHOWCASE_THUMBS = [
    { image: 'https://aitopia.ai/agent-images/scene-generator-1.webp', label: 'AI Scene Generator', href: '/agents/scene-generator' },
    { image: 'https://aitopia.ai/agent-images/nano-strike-1.webp', label: 'AI Nano Strike', href: '/agents/nano-strike' },
  ];

  const STATS = [
    { value: '150+', label: 'AI Agents', href: '/marketplace/agents.html' },
    { value: '500+', label: 'AI Models', href: '/marketplace/models.html' },
  ];

  const CATEGORIES = [
    { label: 'AI Image', icon: 'image', href: '/agents?category=image' },
    { label: 'AI Video', icon: 'video', href: '/agents?category=video' },
  ];


  const categoryIconSvg = {
    image: '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.125" stroke-linecap="round" stroke-linejoin="round"><path d="M6.75 16.5H11.25C15 16.5 16.5 15 16.5 11.25V6.75C16.5 3 15 1.5 11.25 1.5H6.75C3 1.5 1.5 3 1.5 6.75V11.25C1.5 15 3 16.5 6.75 16.5Z"/><path d="M6.75 7.5C7.57843 7.5 8.25 6.82843 8.25 6C8.25 5.17157 7.57843 4.5 6.75 4.5C5.92157 4.5 5.25 5.17157 5.25 6C5.25 6.82843 5.92157 7.5 6.75 7.5Z"/><path d="M2.00244 14.2125L5.69994 11.73C6.29244 11.3325 7.14744 11.3775 7.67994 11.835L7.92744 12.0525C8.51244 12.555 9.45744 12.555 10.0424 12.0525L13.1624 9.37498C13.7474 8.87248 14.6924 8.87248 15.2774 9.37498L16.4999 10.425"/></svg>',
    video: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="14" height="12" rx="3"/><path d="M16 10l5-3v10l-5-3z"/></svg>',
    zap: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L3 14h7l-1 8 10-12h-7l1-8z"/></svg>',
  };

  function categoryIcon(type) {
    return `<span class="inline-flex items-center justify-center w-[18px] h-[18px] text-gray-900 dark:text-white group-hover:text-primary-foreground transition-colors duration-300">${categoryIconSvg[type] || categoryIconSvg.zap}</span>`;
  }

  function arrowDiagonal() {
    return '<svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M7 17L17 7M17 7H7M17 7v10"/></svg>';
  }

  function arrowRight() {
    return '<svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>';
  }

  function renderTallCard(card) {
    const skeleton = card.video ? ' showcase-skeleton' : '';
    const media = card.video
      ? `<video data-src="${card.video}" loop muted playsinline preload="none" class="showcase-video absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"></video>`
      : `<img src="${card.image}" alt="${card.title}" class="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy">`;
    return `<a href="${card.href}" class="group relative flex-1 min-h-[280px] xl:min-h-[440px] 2xl:min-h-[504px] 3xl:min-h-[550px] rounded-[24px] overflow-hidden block shadow-sm dark:shadow-none${skeleton}">
      ${media}
      <div class="absolute bottom-0 left-0 right-0 pt-12 pb-4 px-4 z-10 bg-gradient-to-t from-[#F5F5F7] via-[#F5F5F7]/90 to-transparent dark:from-[#0E0F0F] dark:via-[#0E0F0F]/90 dark:to-transparent">
        <span class="inline-block bg-primary rounded-full text-[11px] font-semibold text-primary-foreground px-2.5 py-0.5 mb-2">${card.badge}</span>
        <h3 class="text-gray-900 dark:text-white font-bold leading-snug" style="font-family:Inter,sans-serif;font-size:16px;line-height:20px">${card.title}</h3>
      </div>
    </a>`;
  }

  function renderFeaturedCard(card) {
    const skeleton = card.video ? ' showcase-skeleton' : '';
    const media = card.video
      ? `<video data-src="${card.video}" loop muted playsinline preload="none" class="showcase-video w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" style="aspect-ratio:16/10"></video>`
      : `<img src="${card.image}" alt="${card.title}" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" style="aspect-ratio:16/10">`;
    return `<a href="${card.href}" class="group relative block rounded-[24px] overflow-hidden shadow-sm dark:shadow-none${skeleton} xl:h-[285px] 2xl:h-[315px] 3xl:h-[370px]">
      ${media}
      <div class="absolute bottom-0 left-0 right-0 pt-12 pb-4 px-4 bg-gradient-to-t from-[#F5F5F7] via-[#F5F5F7]/90 to-transparent dark:from-[#0E0F0F] dark:via-[#0E0F0F]/90 dark:to-transparent">
        <div class="flex items-center gap-2 mb-0.5">
          <h3 class="text-gray-900 dark:text-white text-[14px] leading-[23px] lg:text-[16px] lg:leading-[20px] font-[700]">${card.title}</h3>
          <span class="inline-block bg-primary text-primary-foreground rounded-full text-[11px] font-semibold px-2.5 py-0.5">${card.badge}</span>
        </div>
        <p class="font-[500] text-gray-500 dark:text-white/60 text-[12px] leading-[32px] lg:text-[14px] lg:leading-[20px]" style="letter-spacing:-0.53px">${card.subtitle}</p>
      </div>
    </a>`;
  }

  function renderNewCard(card) {
    const badge = card.newBadge
      ? `<span class="absolute top-3 right-3 z-20 inline-flex items-center bg-brand-purple text-white rounded-full text-[10px] font-bold italic tracking-wider px-2.5 py-1 shadow-md">NEW</span>`
      : '';
    return `<a href="${card.href}" class="group relative flex-1 min-h-[280px] xl:min-h-[440px] 2xl:min-h-[504px] 3xl:min-h-[550px] rounded-[24px] overflow-hidden block shadow-sm dark:shadow-none">
      <img src="${card.image}" alt="${card.title}" class="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy">
      ${badge}
      <div class="absolute bottom-0 left-0 right-0 pt-12 pb-4 px-4 z-10 bg-gradient-to-t from-[#F5F5F7] via-[#F5F5F7]/90 to-transparent dark:from-[#0E0F0F] dark:via-[#0E0F0F]/90 dark:to-transparent">
        <span class="text-gray-500 dark:text-white/60 text-xs font-semibold tracking-wider">${card.preTitle}</span>
        <h3 class="text-gray-900 dark:text-white font-bold mt-0.5" style="font-family:Inter,sans-serif;font-size:16px;line-height:20px">${card.title}</h3>
      </div>
    </a>`;
  }

  function renderMobileCard(item) {
    const skeleton = item.video ? ' showcase-skeleton' : '';
    const media = item.video
      ? `<video data-src="${item.video}" loop muted playsinline preload="none" class="showcase-video absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"></video>`
      : `<img src="${item.image}" alt="${item.label}" class="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy">`;
    return `<a href="${item.href}" class="group relative h-[200px] rounded-[24px] overflow-hidden block shadow-sm dark:shadow-none${skeleton}">
      ${media}
      <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent"></div>
      <span class="absolute bottom-3 left-3 text-white text-[14px] font-[700] leading-[23px]">${item.label}</span>
    </a>`;
  }

  function renderThumb(thumb) {
    return `<a href="${thumb.href}" class="group relative h-[120px] lg:h-[140px] xl:h-[185px] 2xl:h-[218px] 3xl:h-[218px] rounded-[24px] overflow-hidden block shadow-sm dark:shadow-none">
      <img src="${thumb.image}" alt="${thumb.label}" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy">
      <div class="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors duration-200"></div>
      <span class="absolute bottom-2 left-2 bg-black/60 backdrop-blur text-white text-[11px] font-semibold py-1 px-2.5 rounded-lg">${thumb.label}</span>
    </a>`;
  }

  function renderStatCard(stat, variant) {
    return `<a href="${stat.href}" class="group flex items-center justify-between p-5 rounded-[16px] lg:rounded-[24px] xl:h-[116px] 2xl:h-[116px] 3xl:h-[125px] bg-[#F5F5F7] dark:bg-[#0F0F0F] transition-all duration-300 hover:bg-primary dark:hover:bg-primary">
      <div>
        <span class="text-gray-900 dark:text-white group-hover:text-primary-foreground text-2xl font-bold block transition-colors duration-300">${stat.value}</span>
        <span class="text-gray-500 dark:text-white/50 group-hover:text-primary-foreground/80 text-sm font-medium transition-colors duration-300">${stat.label}</span>
      </div>
      <div class="hidden lg:flex w-11 h-11 rounded-full border border-gray-300/50 dark:border-white/15 bg-gray-100 dark:bg-[#1a1a1a] items-center justify-center text-gray-400 dark:text-white/50 group-hover:hidden transition-colors duration-200">
        ${arrowRight()}
      </div>
      <div class="hidden group-hover:lg:flex items-center gap-1.5 bg-primary-foreground/20 rounded-full px-4 py-2 text-primary-foreground text-sm font-semibold">
        Explore ${arrowRight()}
      </div>
    </a>`;
  }

  function renderCategoryPill(cat) {
    return `<a href="${cat.href}" class="group flex items-center gap-3 bg-[#F5F5F7] dark:bg-[#0F0F0F] hover:bg-primary dark:hover:bg-primary h-[48px] lg:h-auto xl:h-[71px] 2xl:h-[71px] 3xl:h-[71px] rounded-[16px] lg:rounded-[24px] px-4 py-3 transition-all duration-300">
      <div class="w-10 h-10 rounded-xl bg-[#EEE] dark:bg-[#262626] group-hover:bg-primary-foreground/20 flex items-center justify-center shrink-0 transition-colors duration-300">
        ${categoryIcon(cat.icon)}
      </div>
      <span class="text-gray-900 dark:text-white group-hover:text-primary-foreground text-[12px] lg:text-[16px] font-[500] flex-1 transition-colors duration-300">${cat.label}</span>
      <div class="hidden group-hover:flex w-10 h-10 rounded-full bg-primary-foreground/20 items-center justify-center text-primary-foreground shrink-0">
        ${arrowRight()}
      </div>
    </a>`;
  }

  function render() {
    const container = document.getElementById('showcase-grid-container');
    if (!container) return;

    const lipSync = FEATURED_CARDS.find(c => c.type === 'tall');
    const videoGen = FEATURED_CARDS.find(c => c.type === 'featured');
    const nanoBanana = FEATURED_CARDS.find(c => c.type === 'new');

    container.innerHTML = `
<section class="bg-white dark:bg-[#0a0a0a] px-3 sm:px-4 lg:px-6 pb-8 lg:pb-12">
  <div class="max-w-[1370px] mx-auto">
    <!-- Mobile layout -->
    <div class="flex flex-col gap-3 lg:hidden">
      ${renderFeaturedCard(videoGen)}
      <div class="flex overflow-x-auto snap-x snap-mandatory gap-3 hide-scrollbar">
        ${[
          { image: nanoBanana.image, video: nanoBanana.video, label: nanoBanana.title, href: nanoBanana.href },
          { image: lipSync.image, video: lipSync.video, label: lipSync.title, href: lipSync.href },
          ...SHOWCASE_THUMBS.map(t => ({ image: t.image, label: t.label, href: t.href }))
        ].map(item => `<div class="min-w-[45%] shrink-0 snap-start">${renderMobileCard(item)}</div>`).join('')}
      </div>
      <div class="grid grid-cols-2 gap-3">
        ${renderStatCard(STATS[0], 'purple')}
        ${renderStatCard(STATS[1], 'purple')}
      </div>
      <div class="grid grid-cols-2 gap-3">
        ${CATEGORIES.slice(0, 2).map(c => renderCategoryPill(c)).join('')}
      </div>
    </div>

    <!-- Desktop layout: 3-col bento -->
    <div class="hidden lg:grid lg:grid-cols-[30%_42%_28%] xl:grid-cols-[1fr_2fr_1fr] gap-3 lg:gap-4">

      <!-- Column 1 -->
      <div class="flex flex-col gap-3 lg:gap-4">
        ${renderTallCard(lipSync)}
        ${renderStatCard(STATS[0], 'purple')}
      </div>

      <!-- Column 2 -->
      <div class="flex flex-col gap-3 lg:gap-4">
        ${renderFeaturedCard(videoGen)}
        <div class="grid grid-cols-2 gap-3 lg:gap-4">
          ${SHOWCASE_THUMBS.map(t => renderThumb(t)).join('')}
        </div>
        <div class="grid grid-cols-2 gap-3 lg:gap-4">
          ${CATEGORIES.slice(0, 2).map(c => renderCategoryPill(c)).join('')}
        </div>
      </div>

      <!-- Column 3 -->
      <div class="flex flex-col gap-3 lg:gap-4">
        ${renderNewCard(nanoBanana)}
        ${renderStatCard(STATS[1], 'purple')}
      </div>

    </div>
  </div>
</section>`;
  }

  function injectSkeletonStyles() {
    if (document.getElementById('showcase-skeleton-styles')) return;
    const style = document.createElement('style');
    style.id = 'showcase-skeleton-styles';
    style.textContent = `
      @keyframes showcaseShimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
      .showcase-skeleton { background: linear-gradient(90deg, #1a1a1a 25%, #262626 50%, #1a1a1a 75%); background-size: 200% 100%; animation: showcaseShimmer 1.5s ease-in-out infinite; }
    `;
    document.head.appendChild(style);
  }

  function observeVideos() {
    const videos = document.querySelectorAll('.showcase-video');
    if (!videos.length) return;
    injectSkeletonStyles();

    videos.forEach(v => {
      v.style.opacity = '0';
      v.style.transition = 'opacity 0.4s ease';
      v.addEventListener('playing', () => {
        v.style.opacity = '1';
        v.closest('.showcase-skeleton')?.classList.remove('showcase-skeleton');
      }, { once: true });
    });

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        const video = entry.target;
        if (entry.isIntersecting) {
          if (!video.src && video.dataset.src) {
            video.src = video.dataset.src;
          }
          video.play().catch(() => {});
        } else {
          video.pause();
        }
      });
    }, { threshold: 0.25 });
    videos.forEach(v => observer.observe(v));
  }

  function init() {
    render();
    observeVideos();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
