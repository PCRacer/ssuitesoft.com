(function() {
  const CTA_VERSION = 'cta-banner-v1';
  if (window.__AITOPIA_CTA_BANNER__ === CTA_VERSION) return;
  window.__AITOPIA_CTA_BANNER__ = CTA_VERSION;

  function render() {
    const container = document.getElementById('cta-banner-container');
    if (!container) return;

    container.innerHTML = `
<section class="bg-[#F0F0F2] dark:bg-[#0F0F0F] border-t border-[#E0E0E0] dark:border-[#262626] min-h-[280px] sm:min-h-[320px] flex items-center justify-center mt-4">
  <div class="flex flex-col items-center text-center px-6 py-12">
    <div class="text-gray-900 dark:text-white font-bold mb-4 text-[24px] leading-[30px] sm:text-[26px] sm:leading-[32px] lg:text-[29px] lg:leading-[35px] xl:text-[32px] xl:leading-[38px]" style="font-family:Inter,sans-serif">Infinite creation, one platform.</div>
    <p class="text-gray-500 dark:text-white/60 font-normal mb-8 max-w-[440px] text-[14px] leading-[20px] sm:text-[15px] sm:leading-[22px] xl:text-[16px] xl:leading-[24px]" style="font-family:Inter,sans-serif">Stop switching between tools. Start orchestrating your genius in one unified space.</p>
    <a href="/marketplace/agents.html" class="inline-flex items-center justify-center py-3.5 px-10 text-[16px] font-[600] text-primary-foreground bg-primary hover:bg-primary/90 active:scale-[0.97] rounded-full transition-all duration-200" style="box-shadow: 0 0 40px hsl(var(--ait-m-primary) / 0.4)">Get Started for Free</a>
  </div>
</section>`;
  }

  function init() {
    render();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
