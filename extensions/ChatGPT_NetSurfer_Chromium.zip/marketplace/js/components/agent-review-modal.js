/**
 * Agent Review Modal Component
 */

const MODAL_ID = 'agent-review-modal';

const STAR_PATH = 'M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z';

function buildStarSlot(n) {
  return `
    <div class="relative w-9 h-9" data-review-star-slot="${n}">
      <svg class="absolute inset-0 w-9 h-9 pointer-events-none fill-white stroke-[#D1D5DB] dark:fill-[#272727] dark:stroke-[#444545]" stroke-width="0.4" viewBox="0 0 20 20"><path d="${STAR_PATH}"/></svg>
      <svg class="absolute inset-0 w-9 h-9 pointer-events-none transition-[clip-path] duration-100 fill-ios-yellow" data-review-star-fill style="clip-path: inset(0 100% 0 0)" viewBox="0 0 20 20"><path d="${STAR_PATH}"/></svg>
      <button type="button" class="absolute inset-y-0 left-0 w-1/2 cursor-pointer bg-transparent" data-review-half data-value="${n - 0.5}" aria-label="${n - 0.5} stars"></button>
      <button type="button" class="absolute inset-y-0 right-0 w-1/2 cursor-pointer bg-transparent" data-review-half data-value="${n}" aria-label="${n} star${n > 1 ? 's' : ''}"></button>
    </div>
  `;
}

function buildModal() {
  const modal = document.createElement('div');
  modal.id = MODAL_ID;
  modal.className = 'fixed inset-0 z-[80] hidden items-end justify-center pb-4 md:items-center md:pb-0 bg-black/60 backdrop-blur-sm';
  modal.setAttribute('role', 'dialog');
  modal.setAttribute('aria-modal', 'true');
  modal.setAttribute('aria-labelledby', 'agent-review-modal-title');
  modal.innerHTML = `
    <div class="relative w-full max-w-md mx-4 rounded-2xl bg-[#EEF2F8] dark:bg-[#121212] p-7 shadow-2xl">
      <button type="button" data-review-modal-close class="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full text-gray-500 hover:text-gray-900 hover:bg-black/5 dark:text-white/60 dark:hover:text-white dark:hover:bg-white/5 transition-colors" aria-label="Close">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
      </button>
      <h2 id="agent-review-modal-title" class="text-[24px] leading-[42px] font-bold text-gray-900 dark:text-white text-center pt-2">How was the agent?</h2>
      <div class="flex items-center justify-center gap-2 mt-5" data-review-stars role="radiogroup" aria-label="Rating">
        ${[1, 2, 3, 4, 5].map(buildStarSlot).join('')}
      </div>
      <p class="text-sm text-gray-600 dark:text-white/50 text-center mt-4 leading-relaxed">Your feedback is essential in helping us better understand your needs, allowing us to tailor our services to suit you more effectively.</p>
      <textarea data-review-comment placeholder="Add a comment" maxlength="2000" class="w-full mt-5 h-28 rounded-xl bg-white border border-gray-200 px-4 py-3 text-sm text-gray-900 placeholder-gray-400 dark:bg-white/[0.03] dark:border-white/10 dark:text-white dark:placeholder-white/30 resize-none focus:outline-none focus:border-gray-400 dark:focus:border-white/20"></textarea>
      <div data-review-error class="hidden text-xs text-red-500 dark:text-red-400 mt-2 text-center"></div>
      <button type="button" data-review-submit disabled class="w-full mt-5 h-12 rounded-full bg-primary hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed text-primary-foreground font-semibold transition-colors">Submit Now</button>
    </div>
  `;
  return modal;
}

function mount() {
  if (document.getElementById(MODAL_ID)) return;
  document.body.appendChild(buildModal());
}

if (document.body) {
  mount();
} else {
  document.addEventListener('DOMContentLoaded', mount, { once: true });
}
