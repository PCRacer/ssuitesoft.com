(function () {
  'use strict';

  var turnstileToken = null;
  var turnstileWidgetId = null;
  var currentStep = 1;

  // Social URL values persisted across steps
  var socialUrls = {
    instagramUrl: '',
    youtubeUrl: '',
    xUrl: '',
    tiktokUrl: '',
  };

  window.onTurnstileLoad = function () {
    var container = document.getElementById('turnstile-container');
    if (!container) return;
    turnstileWidgetId = turnstile.render('#turnstile-container', {
      sitekey: '0x4AAAAAACyW3ulRepzEW6OE',
      theme: document.documentElement.classList.contains('dark') ? 'dark' : 'light',
      callback: function (token) { turnstileToken = token; },
      'expired-callback': function () { turnstileToken = null; },
      'error-callback': function () { turnstileToken = null; },
    });
  };

  var inputClass = 'bg-gray-50 dark:bg-[#121212] border-gray-200 dark:border-[#181818] text-gray-900 dark:text-white';
  var inputStyle = 'width:400px;max-width:100%;height:62px;padding:0 20px;border-radius:16px;border-width:1px;border-style:solid;font-size:14px;outline:none;box-sizing:border-box;';

  var errorBorderStyle = 'border-color:#f87171 !important;';
  var fieldErrorStyle = 'color:#f87171;font-size:12px;margin-top:6px;display:flex;align-items:center;gap:4px;';
  var errorIcon = '<svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor" style="flex-shrink:0;"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>';

  function buildInput(id, name, type, placeholder, autocomplete) {
    return '<div style="margin-bottom:16px;">' +
      '<input id="' + id + '" name="' + name + '" type="' + type + '" placeholder="' + placeholder + '" autocomplete="' + autocomplete + '" ' +
        'class="' + inputClass + '" style="' + inputStyle + '" />' +
      '<div id="' + id + '-error" style="' + fieldErrorStyle + 'display:none;"></div>' +
    '</div>';
  }

  function showFieldError(inputId, msg) {
    var input = document.getElementById(inputId);
    var errorEl = document.getElementById(inputId + '-error');
    if (input) input.style.borderColor = '#f87171';
    if (errorEl) {
      errorEl.innerHTML = errorIcon + '<span>' + msg + '</span>';
      errorEl.style.display = 'flex';
    }
  }

  function clearFieldError(inputId) {
    var input = document.getElementById(inputId);
    var errorEl = document.getElementById(inputId + '-error');
    if (input) input.style.borderColor = '';
    if (errorEl) errorEl.style.display = 'none';
  }

  function clearAllFieldErrors(ids) {
    ids.forEach(function (id) { clearFieldError(id); });
  }

  function wrapperStart() {
    return '<div style="display:flex;align-items:center;justify-content:center;padding:24px;">' +
      '<div class="w-full max-w-[1600px] mt-4 rounded-3xl py-8 px-5 sm:py-16 sm:px-20 bg-white dark:bg-[#0E0E0E] border border-gray-200 dark:border-[#1F1E1F]" style="position:relative;overflow:hidden;">' +
        '<div class="w-[250px] h-[250px] sm:w-[500px] sm:h-[500px]" style="position:absolute;top:0;right:0;background:radial-gradient(circle at top right,var(--invite-gradient, #F0EBF5),transparent 70%);pointer-events:none;"></div>' +
        '<div class="w-[250px] h-[250px] sm:w-[500px] sm:h-[500px]" style="position:absolute;bottom:0;left:0;background:radial-gradient(circle at bottom left,var(--invite-gradient, #F0EBF5),transparent 70%);pointer-events:none;"></div>' +
        '<h1 class="text-center mb-6 font-bold text-[24px] leading-[32px] sm:text-[42px] sm:leading-[60px] text-gray-900 dark:text-white">' +
          'Join the Waitlist for the<br><span style="color:hsl(var(--ait-m-primary));">Super Agents</span>' +
        '</h1>' +
        '<p class="text-center text-gray-500 dark:text-[#a1a1aa]" style="font-size:14px;line-height:22px;margin-bottom:40px;max-width:480px;margin-left:auto;margin-right:auto;">' +
          'We are pre-launching the first version of our super agents this month, step-by-step, for invitation code holders and Creator Plan users.<br><strong class="text-gray-800 dark:text-[#d4d4d8]">Request your spot.</strong>' +
        '</p>';
  }

  function wrapperEnd() {
    return '<div style="margin-top:24px;display:flex;justify-content:center;">' +
          '<p class="bg-gray-100 dark:bg-[#151516]" style="text-align:center;color:hsl(var(--ait-m-primary));font-style:italic;font-size:12px;line-height:20px;border-radius:9999px;padding:12px 28px;display:inline-block;">' +
            'Invitation code holders &amp; creator plan users get priority access.' +
          '</p>' +
        '</div>' +
      '</div>' +
    '</div>';
  }

  function renderStep1() {
    return wrapperStart() +
      '<form id="invite-form-step1" autocomplete="on" style="max-width:400px;margin:0 auto;">' +
        '<p class="text-center text-gray-500 dark:text-[#a1a1aa]" style="font-size:13px;margin-bottom:16px;">Share at least one of your social profiles</p>' +
        buildInput('invite-instagram', 'instagram', 'text', 'Instagram', 'off') +
        buildInput('invite-youtube', 'youtube', 'text', 'Youtube', 'off') +
        buildInput('invite-x', 'x', 'text', 'X (Twitter)', 'off') +
        buildInput('invite-tiktok', 'tiktok', 'text', 'TikTok', 'off') +
        '<div id="invite-error" class="hidden p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm mb-4"></div>' +
        '<button id="invite-continue" type="submit" ' +
          'style="width:400px;max-width:100%;height:56px;border-radius:16px;border:none;background:hsl(var(--ait-m-primary));color:#fff;font-size:16px;line-height:28px;font-weight:700;cursor:pointer;transition:opacity .15s;">' +
          'Continue (1/2)' +
        '</button>' +
      '</form>' +
      wrapperEnd();
  }

  function renderStep2() {
    return wrapperStart() +
      '<form id="invite-form-step2" autocomplete="on" style="max-width:400px;margin:0 auto;">' +
        buildInput('invite-name', 'name', 'text', 'Full Name*', 'name') +
        buildInput('invite-email', 'email', 'email', 'E-mail*', 'email') +
        '<div id="turnstile-container" style="margin-bottom:24px;display:flex;justify-content:center;min-height:65px;"></div>' +
        '<div id="invite-error" class="hidden p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm mb-4"></div>' +
        '<div id="invite-success" class="hidden p-3 bg-green-50 border border-green-100 rounded-xl text-green-600 text-sm mb-4"></div>' +
        '<button id="invite-submit" type="submit" ' +
          'style="width:400px;max-width:100%;height:56px;border-radius:16px;border:none;background:hsl(var(--ait-m-primary));color:#fff;font-size:16px;line-height:28px;font-weight:700;cursor:pointer;transition:opacity .15s;">' +
          'Join the Waitlist (2/2)' +
        '</button>' +
        '<div style="margin-top:16px;text-align:center;">' +
          '<a id="invite-back" href="#" style="color:hsl(var(--ait-m-primary));font-size:14px;text-decoration:none;font-weight:600;">&larr; Back</a>' +
        '</div>' +
      '</form>' +
      wrapperEnd();
  }

  function render() {
    var root = document.getElementById('invite-app');
    if (!root) return;

    if (currentStep === 1) {
      root.innerHTML = renderStep1();
      // Restore saved values
      document.getElementById('invite-instagram').value = socialUrls.instagramUrl;
      document.getElementById('invite-youtube').value = socialUrls.youtubeUrl;
      document.getElementById('invite-x').value = socialUrls.xUrl;
      document.getElementById('invite-tiktok').value = socialUrls.tiktokUrl;
      document.getElementById('invite-form-step1').addEventListener('submit', handleStep1);
    } else {
      root.innerHTML = renderStep2();
      document.getElementById('invite-form-step2').addEventListener('submit', handleSubmit);
      document.getElementById('invite-back').addEventListener('click', function (e) {
        e.preventDefault();
        currentStep = 1;
        render();
      });
      // Re-render Turnstile widget
      if (typeof window.onTurnstileLoad === 'function') {
        turnstileToken = null;
        window.onTurnstileLoad();
      }
    }
  }

  function saveSocialUrls() {
    socialUrls.instagramUrl = (document.getElementById('invite-instagram').value || '').trim();
    socialUrls.youtubeUrl = (document.getElementById('invite-youtube').value || '').trim();
    socialUrls.xUrl = (document.getElementById('invite-x').value || '').trim();
    socialUrls.tiktokUrl = (document.getElementById('invite-tiktok').value || '').trim();
  }

  function handleStep1(e) {
    e.preventDefault();
    hideError();
    var step1Ids = ['invite-instagram', 'invite-youtube', 'invite-x', 'invite-tiktok'];
    clearAllFieldErrors(step1Ids);
    saveSocialUrls();

    var hasAny = socialUrls.instagramUrl || socialUrls.youtubeUrl || socialUrls.xUrl || socialUrls.tiktokUrl;
    if (!hasAny) {
      step1Ids.forEach(function (id) {
        var input = document.getElementById(id);
        if (input) input.style.borderColor = '#f87171';
      });
      showFieldError('invite-tiktok', 'At least one social profile is required');
      return;
    }

    currentStep = 2;
    render();
  }

  function showError(msg) {
    var el = document.getElementById('invite-error');
    if (!el) return;
    el.textContent = msg;
    el.classList.remove('hidden');
  }

  function hideError() {
    var el = document.getElementById('invite-error');
    if (el) el.classList.add('hidden');
  }

  function escapeHtml(str) {
    var div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
  }

  function showSuccess(email) {
    var root = document.getElementById('invite-app');
    if (!root) return;
    var safeEmail = escapeHtml(email);
    root.innerHTML =
      '<div style="min-height:calc(100vh - 64px);display:flex;align-items:center;justify-content:center;padding:24px;">' +
        '<div class="w-full max-w-[560px] rounded-3xl py-8 px-5 sm:py-16 sm:px-20 bg-white dark:bg-[#0E0E0E] border border-gray-200 dark:border-[#1F1E1F]" style="position:relative;overflow:hidden;">' +
          '<div class="w-[250px] h-[250px] sm:w-[500px] sm:h-[500px]" style="position:absolute;top:0;right:0;background:radial-gradient(circle at top right,var(--invite-gradient, #F0EBF5),transparent 70%);pointer-events:none;"></div>' +
          '<div class="w-[250px] h-[250px] sm:w-[500px] sm:h-[500px]" style="position:absolute;bottom:0;left:0;background:radial-gradient(circle at bottom left,var(--invite-gradient, #F0EBF5),transparent 70%);pointer-events:none;"></div>' +
          '<div style="text-align:center;margin:0 auto;position:relative;">' +
            '<div class="bg-[#E5DFF7] dark:bg-[#21172A]" style="width:96px;height:96px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 24px;">' +
              '<img src="/marketplace/images/success-icon.svg" alt="Success" style="width:67px;height:67px;" />' +
            '</div>' +
            '<h2 class="text-gray-900 dark:text-white text-[24px] leading-[32px] sm:text-[36px] sm:leading-[42px] font-bold" style="margin-bottom:12px;">We\u2019ve added you to<br>our waiting list.</h2>' +
            '<p class="text-gray-500 dark:text-[#a1a1aa]" style="font-size:14px;line-height:22px;">' +
              'Request received! We\'ll notify you at <strong class="text-gray-800 dark:text-[#d4d4d8]">' + safeEmail + '</strong><br>as soon as your invitation code is ready.' +
            '</p>' +
            '<a href="/marketplace/agents.html" style="display:inline-block;margin-top:24px;padding:14px 48px;border-radius:16px;background:hsl(var(--ait-m-primary));color:#fff;font-size:16px;font-weight:700;text-decoration:none;">Discover Agents</a>' +
          '</div>' +
        '</div>' +
      '</div>';
  }

  async function handleSubmit(e) {
    e.preventDefault();
    hideError();
    clearAllFieldErrors(['invite-name', 'invite-email']);

    var name = (document.getElementById('invite-name').value || '').trim();
    var email = (document.getElementById('invite-email').value || '').trim();

    var hasError = false;
    if (!name) { showFieldError('invite-name', 'Full name is required'); hasError = true; }
    if (!email) { showFieldError('invite-email', 'E-mail is required'); hasError = true; }
    if (hasError) return;

    var btn = document.getElementById('invite-submit');
    btn.disabled = true;
    btn.textContent = 'Submitting...';
    btn.style.opacity = '0.6';

    try {
      var detail = {};
      if (socialUrls.instagramUrl) detail.instagramUrl = socialUrls.instagramUrl;
      if (socialUrls.youtubeUrl) detail.youtubeUrl = socialUrls.youtubeUrl;
      if (socialUrls.xUrl) detail.xUrl = socialUrls.xUrl;
      if (socialUrls.tiktokUrl) detail.tiktokUrl = socialUrls.tiktokUrl;

      var body = {
        email: email,
        fullName: name,
        detail: detail,
      };
      if (turnstileToken) body['cf-turnstile-response'] = turnstileToken;

      var res = await fetch('https://aitopia.ai/api/invite/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (res.status === 201) {
        showSuccess(email);
        return;
      }

      var data = {};
      try { data = await res.json(); } catch (_) {}

      showError(data.error || 'Something went wrong. Please try again.');

      // Reset Turnstile on error
      if (typeof turnstile !== 'undefined' && turnstileWidgetId != null) {
        turnstile.reset(turnstileWidgetId);
        turnstileToken = null;
      }
    } catch (err) {
      showError('Network error. Please check your connection and try again.');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Join the Waitlist (2/2)';
      btn.style.opacity = '1';
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', render);
  } else {
    render();
  }
})();
