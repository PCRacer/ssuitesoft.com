/**
 * Generation Dock — site-wide visibility for in-flight generations.
 *
 * Self-contained IIFE (navbar.js conventions): exposes `window.GenerationDock`.
 * Structured as three swappable roles so later phases can extend without a rewrite:
 *   - DataSource : produces DockJob[] (Phase A: FixtureDataSource; Phase C: LiveDataSource).
 *   - Store      : job map keyed by jobId, monotonic-progress clamp, dismissed set,
 *                  collapsed pref, caught-up flag. Notifies View on change.
 *   - View       : keyed row rendering + panel/pill chrome. addEventListener only
 *                  (CSP-safe); user strings rendered via textContent (never innerHTML).
 *
 * DockJob contract (§5.2 — field names are frozen; later phases depend on them):
 *   jobId, queueItemId, agentId, displayName, kind, status, progress,
 *   etaSeconds?, createdAt, prompt?, credits?, thumbnailUrl?, deepLinkUrl, error?
 *   plus the additive optional `retrying?` boolean — a queue `retrying` row maps to
 *   status:'processing' + retrying:true so the View can show the "Retrying…" metric
 *   without overloading the frozen status enum (A3).
 */
(function () {
  'use strict';

  const DOCK_VERSION = 'gen-dock-v1';
  if (window.__AITOPIA_GEN_DOCK__ === DOCK_VERSION) return;
  window.__AITOPIA_GEN_DOCK__ = DOCK_VERSION;

  const LS = { collapsed: 'genDock.collapsed', dismissed: 'genDock.dismissed', mini: 'genDock.mini', pos: 'genDock.pos' };
  const OUTPUTS_URL = '/marketplace/outputs.html?tab=mine';        // /outputs redirects here (apps/web/src/server.js); tab=mine opens "My creations"
  const ACTIVE_STATUSES = ['queued', 'processing', 'waiting_input'];
  const CAUGHT_UP_FADE_MS = 1600;

  // Phase C (live data + lifecycle) constants.
  const POLL_MS = 3000;                             // ~3s while ≥1 active job (§3.2)
  const HIDDEN_POLL_MS = 15000;                     // slower background cadence while hidden (keeps the favicon live)
  const WAKE_DELAY_MS = 1500;                       // 202 lands after the generate click; re-fetch late
  const RETENTION_MS = 30 * 24 * 60 * 60 * 1000;    // queue retention window (src/jobs/cleanup.ts DEFAULT_RETENTION_DAYS)
  const CATALOG_FRESH_MS = 5 * 60 * 1000;           // matches the endpoints' Cache-Control max-age
  const SNAPSHOT_KEY = 'genDock.snapshot';          // sessionStorage — instant first paint, reconciled by first fetch
  const CATALOG_KEY = 'genDock.catalog';            // sessionStorage — cached name/kind/credits lookups
  // Active: pin the ceiling (server default is 20) — a run's live step row
  // pushed out of the window would fake an idle "Needs input" frontier.
  const ACTIVE_QUERY = 'status=pending,processing,retrying&limit=100';
  // Settled: over-fetch, because hidden builder-history rows spend server-side
  // LIMIT slots before poll()'s filter runs; trim back after filtering.
  const SETTLED_QUERY = 'status=completed,failed,dead,cancelled&limit=30';
  const SETTLED_VISIBLE_MAX = 10;                   // real settled rows shown per poll — the pre-over-fetch budget

  // Draggable dock + mini bubble.
  const DRAG_THRESHOLD_PX = 5;                      // mouse: below this a pointerdown/up stays a plain click
  const TOUCH_DRAG_THRESHOLD_PX = 10;               // finger wobble overshoots the mouse threshold and would eat taps
  const EDGE_MARGIN_PX = 20;                        // the resting .gen-dock inset (>720px), kept by the snapped edge
  const MOBILE_EDGE_MARGIN_PX = 14;                 // the ≤720px resting inset; safe-area rides on top (CSS + probes)
  const VIEWPORT_GAP_PX = 8;                        // minimum breathing room while a drag is in progress
  const BOTTOM_TABS_BAR_PX = 61;                    // the global bottom bar the dock must clear (see its media rule)
  const BOTTOM_TABS_MAX_WIDTH_PX = 1024;            // the bar is Tailwind lg:hidden
  const SNAP_LANDED_MS = 350;                       // > the .28s snap; reduced motion fires no transitionend
  const CLICK_SUPPRESS_MS = 500;                    // a post-drag click that never arrives must not eat a later one

  // ---------------------------------------------------------------------------
  // Utilities
  // ---------------------------------------------------------------------------
  // Strip only the characters that could break out of a double-quoted CSS url("...").
  function cssUrl(url) {
    return 'url("' + String(url ?? '').replace(/["\\\n\r]/g, '') + '")';
  }

  function fmtTime(seconds) {
    const s = Math.max(0, Math.round(Number(seconds) || 0));
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  }

  function isActive(job) {
    return ACTIVE_STATUSES.includes(job.status);
  }

  // Kind resolution with snapshot back-compat: old sessionStorage snapshots
  // carry thumbnailUrl but no thumbnailKind.
  const VIDEO_URL_RE = /\.(mp4|webm|mov|m4v)([?#]|$)/i;
  function thumbKind(job) {
    if (job.thumbnailKind) return job.thumbnailKind;
    return VIDEO_URL_RE.test(String(job.thumbnailUrl || '')) ? 'video' : 'image';
  }

  // Finished tile: real media when paintable — image thumbnail, or the video's
  // own first frame — otherwise the static glyph tile. Never a gradient, never
  // motion: settled rows are completely still.
  function applyDoneMedia(el, job) {
    const thumb = el.querySelector('.thumb');
    const url = job.thumbnailUrl;
    const kind = url ? thumbKind(job) : null;
    if (kind === 'image') {
      const staleVideo = thumb.querySelector('video');
      if (staleVideo) staleVideo.remove();       // kind corrected video→image: don't let the old frame cover the thumbnail
      thumb.style.background = `${cssUrl(url)} center/cover no-repeat`;
      el.classList.add('has-media');
      return;
    }
    if (kind === 'video') {
      if (thumb.dataset.failedSrc === url) { el.classList.remove('has-media'); return; }   // latched: don't refetch a dead URL every poll
      let video = thumb.querySelector('video');
      if (!video || video.dataset.src !== url) {
        thumb.textContent = '';
        video = document.createElement('video');
        video.dataset.src = url;
        video.muted = true;
        video.playsInline = true;
        video.preload = 'metadata';
        video.addEventListener('error', () => {
          thumb.dataset.failedSrc = url;
          video.remove();
          el.classList.remove('has-media');
        }, { once: true });
        video.src = url + '#t=0.1';
        thumb.appendChild(video);
      }
      el.classList.add('has-media');
      return;
    }
    el.classList.remove('has-media');            // audio / no URL → glyph floor
  }

  const GLYPHS = {
    video: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="14" height="14" rx="3"/><path d="m16 10 6-3v10l-6-3"/></svg>',
    image: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="m21 15-4-4-8 8"/></svg>',
    audio: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
    text: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7V5h16v2M9 5v14M7 19h4"/></svg>',
    builder: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 2 7l10 5 10-5-10-5Z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/></svg>',
    other: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v4l3 2"/></svg>',
  };

  // The Generate button's filled credit bolt — shared credit-badge language.
  const CREDIT_BOLT = '<svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>';

  // 16px at stroke-width 2 on a 24 viewBox renders the design's 1.33px stroke.
  const chevron = (d) => `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${d}"/></svg>`;
  const CHEVRON_UP = chevron('m18 15-6-6-6 6');
  const CHEVRON_RIGHT = chevron('m9 18 6-6-6-6');
  const MINUS = chevron('M6 12h12');

  // ---------------------------------------------------------------------------
  // Styles (injected once — follows countdown-banner.js / hero-banner.js convention)
  // ---------------------------------------------------------------------------
  function injectStyles() {
    if (document.getElementById('gen-dock-styles')) return;
    const style = document.createElement('style');
    style.id = 'gen-dock-styles';
    style.textContent = STYLE_TEXT;
    document.head.appendChild(style);
  }

  const STYLE_TEXT = `
  @property --gd-angle { syntax: '<angle>'; inherits: false; initial-value: 0deg; }
  /* Dock-local tokens: --success/--warning/--info are not defined site-wide, so the
     dock supplies namespaced --gd-* versions (light + dark). Everything else comes from
     the brand palette (--primary/--card/--border/--secondary/--muted-foreground/--ait-m-foreground). */
  .gen-dock {
    --gd-success: 128 45% 28%;
    --gd-warning: 45 93% 47%;
    --gd-info: 199 89% 48%;
    --gd-danger: 0 84.2% 60.2%;
    /* Safe-area probes — env() is CSS-only, so the drag clamps read these. */
    --gd-safe-left: env(safe-area-inset-left, 0px);
    --gd-safe-right: env(safe-area-inset-right, 0px);
    --gd-safe-bottom: env(safe-area-inset-bottom, 0px);
  }
  .dark .gen-dock {
    --gd-success: 128 45% 56%;
    --gd-warning: 45 93% 58%;
    --gd-info: 199 89% 60%;
    --gd-danger: 0 72% 58%;
  }

  .gen-dock {
    position: fixed; right: 20px; bottom: 20px; z-index: 200;
    display: flex; flex-direction: column; align-items: flex-end;
    font-family: 'Inter', system-ui, sans-serif;
    transition: opacity .4s, transform .4s;
  }
  .gen-dock.gone { opacity: 0; transform: translateY(16px); pointer-events: none; }

  .dock-surface {
    background: hsl(var(--ait-m-card));
    border: 1px solid hsl(var(--ait-m-border));
  }

  /* Expanded panel */
  .dock-panel {
    width: min(360px, calc(100vw - 32px));
    border-radius: 16px;
    box-shadow: 0 20px 48px -20px rgb(0 0 0 / .5);
    overflow: hidden; transform-origin: bottom right;
    animation: gdPanelIn .34s cubic-bezier(.22,1,.36,1);
  }
  @keyframes gdPanelIn { from { opacity: 0; transform: scale(.88) translateY(16px); } }
  .gen-dock.collapsed .dock-panel { display: none; }

  .dock-head { position: relative; display: flex; align-items: center; gap: 10px; padding: 20px 20px 21px; }
  .dock-head::after {
    content: ''; position: absolute; left: 20px; right: 20px; bottom: 0; height: 1px;
    background: hsl(var(--ait-m-muted-foreground) / .2);
  }
  .dock-title { font-size: 16px; font-weight: 600; line-height: 18px; color: hsl(var(--ait-m-foreground)); }
  .dock-sub { margin-top: 1px; font-size: 12px; line-height: 18px; color: hsl(var(--ait-m-muted-foreground)); font-variant-numeric: tabular-nums; }
  .dock-mini-btn {
    margin: 0 -4px 0 auto; padding: 0;
    border: none; background: transparent; color: hsl(var(--ait-m-muted-foreground));
    width: 24px; height: 24px; border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; transition: background .15s, color .15s;
  }
  .dock-mini-btn:hover { background: hsl(var(--ait-m-secondary) / .8); color: hsl(var(--ait-m-foreground)); }

  .dock-rows { max-height: 348px; overflow-y: auto; padding: 0 0 8px; }
  /* The 6px below keeps a row's hover off the title. */
  .group-label {
    font-size: 14px; font-weight: 600; line-height: 21px;
    color: hsl(var(--ait-m-muted-foreground)); padding: 15px 20px 6px;
  }

  .dock-footer { display: flex; flex-direction: column; align-items: center; gap: 10px; padding: 14px 20px 16px; }
  .dock-footer a {
    font-size: 12px; font-weight: 600; line-height: 18px;
    color: hsl(var(--ait-m-primary)); text-decoration: none;
  }
  .dock-footer a:hover { text-decoration: underline; }
  .dock-clear {
    border: none; background: transparent; padding: 0; cursor: pointer;
    font-family: inherit; font-size: 12px; font-weight: 600; line-height: 18px;
    color: hsl(var(--ait-m-muted-foreground)); transition: color .15s;
  }
  .dock-clear:hover { color: hsl(var(--ait-m-foreground)); }

  /* Rows — edge-to-edge so a row's hover bleeds the full panel width. */
  .dock-row {
    position: relative; display: flex; align-items: center; gap: 12px; padding: 8px 20px;
    transition: background .15s, opacity .3s, transform .3s;
  }
  .dock-row:hover { background: hsl(var(--ait-m-secondary) / .35); }
  .dock-row.removing { opacity: 0; transform: translateX(30px); }

  .row-media {
    position: relative; width: 48px; height: 48px; border-radius: 16px; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    background: hsl(var(--ait-m-secondary)); overflow: hidden;
  }
  .row-media .type-glyph { position: relative; z-index: 1; color: hsl(var(--ait-m-muted-foreground) / .9); display: flex; }
  .row-media .thumb {
    position: absolute; inset: 0; z-index: 2; opacity: 0; transform: scale(1.3);
    transition: opacity .5s, transform .8s cubic-bezier(.2,1.1,.35,1);
  }
  .row-media .thumb video { width: 100%; height: 100%; object-fit: cover; display: block; }
  /* Solid play badge — centered chip on real media, green corner chip on the glyph floor. */
  .row-media .play {
    position: absolute; z-index: 3; display: none; align-items: center; justify-content: center;
    left: 50%; top: 50%; transform: translate(-50%, -50%);
    width: 20px; height: 20px; border-radius: 999px;
    background: rgb(0 0 0 / .55); color: #fff; font-size: 8px; line-height: 1; padding-left: 2px;
    box-shadow: 0 1px 6px rgb(0 0 0 / .35);
  }
  .dock-row[data-status="done"].is-video:not(.has-media) .row-media .play {
    left: auto; top: auto; right: 4px; bottom: 4px; transform: none;
    width: 16px; height: 16px; font-size: 7px;
    background: hsl(var(--gd-success) / .9);
  }
  /* Failure speaks from the tile corner; the kind glyph stays visible. */
  .row-media .fail-x {
    position: absolute; right: 4px; bottom: 4px; z-index: 3;
    width: 16px; height: 16px; border-radius: 999px;
    display: none; align-items: center; justify-content: center;
    background: hsl(var(--gd-danger) / .92); color: #fff;
    font-size: 8px; line-height: 1; font-weight: 700;
    box-shadow: 0 1px 4px rgb(0 0 0 / .35);
  }

  .row-body { flex: 1; min-width: 0; }
  .row-top { display: flex; align-items: center; gap: 10px; }
  .row-name { min-width: 0; font-size: 14px; font-weight: 500; line-height: 18px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: hsl(var(--ait-m-foreground)); }
  .row-metric { flex-shrink: 0; margin-left: auto; font-size: 12px; line-height: 18px; color: hsl(var(--ait-m-muted-foreground)); white-space: nowrap; font-variant-numeric: tabular-nums; }
  .row-sub { display: flex; align-items: center; gap: 6px; margin-top: 2px; font-size: 12px; line-height: 18px; color: hsl(var(--ait-m-muted-foreground)); white-space: nowrap; overflow: hidden; }
  .row-sub .prompt { overflow: hidden; text-overflow: ellipsis; }
  /* A failed row states its reason where the prompt was; tooltip stays as backup. */
  .row-sub .err { display: none; color: hsl(var(--gd-danger) / .9); overflow: hidden; text-overflow: ellipsis; }
  .row-credits { flex-shrink: 0; display: inline-flex; align-items: center; gap: 2px; font-size: 10px; font-weight: 600; padding: 1px 7px; border-radius: 999px; background: hsl(var(--ait-m-primary) / .14); color: hsl(var(--ait-m-primary)); }

  /* Ink, not pills: the only settled word left is an actionable one. */
  .row-metric.tone-info { color: hsl(var(--gd-info)); }

  /* Row actions */
  .row-action { flex-shrink: 0; display: flex; align-items: center; gap: 2px; margin-right: -4px; }
  .btn-open, .btn-dismiss, .btn-retry {
    width: 24px; height: 24px; padding: 0; border: none; background: transparent; border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    color: hsl(var(--ait-m-muted-foreground)); font-size: 12px; line-height: 1; cursor: pointer;
    transition: opacity .15s, background .15s, color .15s;
  }
  /* The chevron is the row's route into the run, and non-destructive — so it stays
     on screen rather than hiding behind a hover like the ✕ next to it. */
  .btn-dismiss { opacity: 0; }
  .dock-row:hover .btn-dismiss { opacity: 1; }
  /* Touch devices have no hover — keep row actions visible and comfortably tappable. */
  @media (hover: none) {
    .btn-dismiss { opacity: 1; }
    .btn-open, .btn-dismiss, .btn-retry { width: 32px; height: 32px; }
  }
  .btn-open:hover, .btn-dismiss:hover, .btn-retry:hover { background: hsl(var(--ait-m-secondary) / .8); color: hsl(var(--ait-m-foreground)); }
  .dock-row[data-status="cancelled"] .btn-dismiss { opacity: .8; }

  /* In-flight tile: the type glyph stays visible (the tile says WHAT is coming);
     a thin light tracing the rim says it's being worked on. */
  .dock-row[data-status="queued"] .row-media::before,
  .dock-row[data-status="processing"] .row-media::before { content: ''; }
  .row-media::before {
    content: none; position: absolute; inset: 0; z-index: 1;
    border-radius: inherit; padding: 1.5px;
    background: conic-gradient(from var(--gd-angle, 0deg), transparent 0turn .58turn, hsl(var(--ait-m-primary) / .95) .8turn, transparent .96turn);
    -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
    -webkit-mask-composite: xor;
    mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
    mask-composite: exclude;
    animation: gdTrace 2.6s linear infinite;
  }
  @keyframes gdTrace { to { --gd-angle: 360deg; } }
  /* Queued — same placeholder, parked: dimmed tile, trace not moving. */
  .dock-row[data-status="queued"] .row-media { opacity: .5; }
  .dock-row[data-status="queued"] .row-media::before { animation-play-state: paused; }
  .dock-row[data-status="queued"] .row-metric { color: hsl(var(--gd-warning)); }

  /* Done */
  .dock-row[data-status="done"] .row-media .thumb { opacity: 1; transform: scale(1); }
  .dock-row[data-status="done"].has-media .row-media .type-glyph { display: none; }
  .dock-row[data-status="done"].is-video .row-media .play { display: flex; }
  .dock-row.just-done { animation: gdDonePulse 1.15s ease-out 1; }
  @keyframes gdDonePulse {
    0%   { box-shadow: inset 0 0 0 0 hsl(var(--gd-success) / .5); }
    70%  { box-shadow: inset 0 0 0 3px hsl(var(--gd-success) / 0); }
    100% { box-shadow: inset 0 0 0 0 hsl(var(--gd-success) / 0); }
  }

  /* Failed + dead */
  .dock-row[data-status="failed"] .row-media .fail-x,
  .dock-row[data-status="dead"] .row-media .fail-x { display: flex; }
  .dock-row[data-status="failed"] .prompt, .dock-row[data-status="dead"] .prompt { display: none; }
  .dock-row[data-status="failed"] .err, .dock-row[data-status="dead"] .err { display: inline; }

  /* Waiting for input (checkpoint-paused builder runs) — distinct, never a spinner */
  .dock-row[data-status="waiting_input"] .row-media .type-glyph { color: hsl(var(--gd-info)); }

  /* Cancelled — neutral gray */
  .dock-row[data-status="cancelled"] { opacity: .75; }
  .dock-row[data-status="cancelled"] .row-media { color: hsl(var(--ait-m-muted-foreground) / .6); }
  .dock-row[data-status="cancelled"] .row-name { color: hsl(var(--ait-m-muted-foreground)); }

  /* All caught up */
  .all-done { display: none; flex-direction: column; align-items: center; gap: 8px; padding: 26px 0 22px; color: hsl(var(--ait-m-muted-foreground)); }
  .all-done .big { font-size: 26px; color: hsl(var(--gd-success)); }
  .all-done .msg { font-size: 12.5px; font-weight: 600; }
  .dock-rows.empty .all-done { display: flex; }

  /* Collapsed pill */
  .dock-pill {
    display: none; align-items: center; gap: 11px; padding: 8px 18px 8px 8px; border-radius: 999px;
    color: hsl(var(--ait-m-foreground)); cursor: pointer;
    box-shadow: 0 10px 28px -12px rgb(0 0 0 / .45);
    transition: transform .18s, box-shadow .25s;
    animation: gdPanelIn .3s cubic-bezier(.22,1,.36,1);
  }
  .gen-dock.collapsed .dock-pill { display: flex; }
  .dock-pill:hover { transform: translateY(-2px); box-shadow: 0 14px 34px -12px rgb(0 0 0 / .55); }
  .dock-pill:active { transform: scale(.97); }
  .pill-ring {
    position: relative; width: 34px; height: 34px; border-radius: 999px; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    background:
      radial-gradient(closest-side, hsl(var(--ait-m-card)) 74%, transparent 75% 100%),
      conic-gradient(hsl(var(--ait-m-primary)) calc(var(--pct) * 1%), hsl(var(--ait-m-secondary)) 0);
  }
  .dock-pill.all-ready .pill-ring {
    background:
      radial-gradient(closest-side, hsl(var(--ait-m-card)) 74%, transparent 75% 100%),
      conic-gradient(hsl(var(--gd-success)) 100%, hsl(var(--ait-m-secondary)) 0);
  }
  .pill-count { font-size: 13px; font-weight: 850; font-variant-numeric: tabular-nums; }
  .pill-label { font-size: 13px; font-weight: 700; letter-spacing: -0.01em; }
  .pill-eta { font-size: 11px; color: hsl(var(--ait-m-muted-foreground)); font-variant-numeric: tabular-nums; font-weight: 600; }
  .pill-ready { display: none; align-items: center; gap: 6px; font-size: 11px; font-weight: 800; padding: 4px 11px; border-radius: 999px; background: hsl(var(--gd-success) / .15); color: hsl(var(--gd-success)); }
  .pill-ready .dot { width: 6px; height: 6px; border-radius: 999px; background: hsl(var(--gd-success)); animation: gdReadyBlink 1.6s ease-in-out infinite; }
  @keyframes gdReadyBlink { 50% { opacity: .35; } }
  .dock-pill.has-ready .pill-ready { display: flex; }
  .dock-pill.pulse { animation: gdPillPulse 1.2s ease-out 1; }
  @keyframes gdPillPulse {
    0%   { box-shadow: 0 10px 28px -12px rgb(0 0 0 / .45), 0 0 0 0 hsl(var(--gd-success) / .45); }
    70%  { box-shadow: 0 10px 28px -12px rgb(0 0 0 / .45), 0 0 0 11px hsl(var(--gd-success) / 0); }
    100% { box-shadow: 0 10px 28px -12px rgb(0 0 0 / .45), 0 0 0 0 hsl(var(--gd-success) / 0); }
  }

  /* -------------------------------------------------------------------------
     Phase E — mobile: pill (or bubble) resting state + bottom sheet (≤720px).
     The .dock-panel is reused verbatim as the sheet (same jobId-keyed rows,
     header, footer, finish-moment flip); only chrome + positioning change here.
     ------------------------------------------------------------------------- */
  .dock-scrim, .dock-grabber { display: none; }
  .gd-sheet-lock { overflow: hidden; }

  /* Global bottom tab bar (global-nav.js injects nav[data-bottom-tabs] +
     body.has-bottom-tabs; Tailwind lg:hidden, so it shows <1024px). The resting
     dock clears the 60px bar + border instead of covering its tabs. The sheet
     and scrim are position:fixed to the viewport, so while open they still
     cover the bar — intended bottom-sheet behavior. */
  @media (max-width: 1023.98px) {
    body.has-bottom-tabs .gen-dock { bottom: calc(61px + 20px + env(safe-area-inset-bottom)); }
  }

  @media (max-width: 720px) {
    .gen-dock {
      right: calc(14px + env(safe-area-inset-right)); left: auto;
      bottom: calc(14px + env(safe-area-inset-bottom));
    }
    body.has-bottom-tabs .gen-dock { bottom: calc(61px + 14px + env(safe-area-inset-bottom)); }

    /* Pill (or the bubble when minimized) is the resting surface; the sheet
       lives off-screen until opened. */
    .gen-dock .dock-pill { display: flex; max-width: calc(100vw - 28px); }
    .gen-dock.sheet-open .dock-pill { display: none; }

    /* The sheet header shows the minimize button (.gen-dock lifts it over the
       shared display:none, which is later in the source). */
    .gen-dock .dock-head [data-act="mini"] { display: flex; margin-right: 0; }
    .gen-dock .dock-head [data-act="mini"] + .dock-mini-btn { margin-left: 0; }

    /* Chip reveal — mobile ignores .collapsed: the pill rests whenever the
       sheet is closed. The touch reveals are the (hover: none) block below. */
    .gen-dock:not(.sheet-open):not(.mini):hover .pill-mini { display: flex; }
    .gen-dock.mini:hover .bubble-expand { display: flex; }

    /* Scrim behind the sheet (child of .gen-dock; fixed to the viewport). */
    .dock-scrim {
      display: block; position: fixed; inset: 0; z-index: 1;
      background: rgb(0 0 0 / .5); opacity: 0; pointer-events: none;
      transition: opacity .3s ease;
    }
    .gen-dock.sheet-open .dock-scrim { opacity: 1; pointer-events: auto; }

    /* Panel to full-width bottom sheet. The grouped selector also outranks the
       desktop collapsed-panel display:none rule (equal specificity, later source
       order) so the sheet opens whatever the collapsed pref happens to be. */
    .gen-dock .dock-panel,
    .gen-dock.collapsed .dock-panel {
      display: flex; flex-direction: column;
      position: fixed; left: 0; right: 0; bottom: 0; z-index: 2;
      width: 100%; max-width: 100%; max-height: 88vh; max-height: 88dvh;
      border-radius: 16px 16px 0 0;
      padding-bottom: env(safe-area-inset-bottom);
      transform: translateY(110%);
      transition: transform .34s cubic-bezier(.32,.72,0,1);
      animation: none;
      will-change: transform; pointer-events: none;
    }
    .gen-dock.sheet-open .dock-panel { transform: translateY(0); pointer-events: auto; }

    .gen-dock .dock-rows { max-height: none; flex: 1 1 auto; }

    /* Drag handle (injected once; only meaningful inside the sheet). */
    .dock-grabber {
      display: flex; align-items: center; justify-content: center;
      height: 22px; flex-shrink: 0; touch-action: none; cursor: grab;
    }
    .dock-grabber::before {
      content: ''; width: 40px; height: 4px; border-radius: 999px;
      background: hsl(var(--ait-m-muted-foreground) / .4);
    }
  }

  /* Touch reveal for the ≤720px chips (hover cannot gate them there). */
  @media (max-width: 720px) and (hover: none) {
    .gen-dock:not(.sheet-open):not(.mini) .pill-mini { display: flex; }
    .gen-dock.mini .bubble-expand { display: flex; }
  }

  /* -------------------------------------------------------------------------
     Draggable dock + mini bubble — shared across widths. The bubble is the
     third resting surface everywhere; ≤720px it stands in for the pill and a
     tap opens the sheet. Surfaces are hidden by default (like .dock-scrim /
     .dock-grabber): the header's minimize button because .dock-head is also
     the mobile sheet's header (the mobile block and the min-width block each
     reveal it), the pill chip until its hover / touch reveal rules. Cursors
     and the hover reveal stay in the min-width block below.
     ------------------------------------------------------------------------- */
  .dock-bubble, .pill-mini, .bubble-expand, .dock-head [data-act="mini"] { display: none; }

  /* Bubble outranks the pill rules by specificity and the panel rules by
     specificity or source order (incl. the mobile sheet's display:flex). */
  .gen-dock.mini .dock-panel, .gen-dock.mini .dock-pill { display: none; }
  .gen-dock.mini .dock-bubble { display: flex; }

  .dock-bubble {
    position: relative; width: 44px; height: 44px; padding: 0; border-radius: 999px;
    align-items: center; justify-content: center;
    color: hsl(var(--ait-m-foreground)); cursor: pointer;
    box-shadow: 0 10px 28px -12px rgb(0 0 0 / .45);
    transition: transform .18s, box-shadow .25s;
    animation: gdPanelIn .3s cubic-bezier(.22,1,.36,1);
  }
  .dock-bubble:hover { transform: translateY(-2px); box-shadow: 0 14px 34px -12px rgb(0 0 0 / .55); }
  .dock-bubble:active { transform: scale(.97); }
  .bubble-ring {
    position: relative; width: 34px; height: 34px; border-radius: 999px;
    display: flex; align-items: center; justify-content: center;
    background:
      radial-gradient(closest-side, hsl(var(--ait-m-card)) 74%, transparent 75% 100%),
      conic-gradient(hsl(var(--ait-m-primary)) calc(var(--pct) * 1%), hsl(var(--ait-m-secondary)) 0);
  }
  .dock-bubble.all-ready .bubble-ring {
    background:
      radial-gradient(closest-side, hsl(var(--ait-m-card)) 74%, transparent 75% 100%),
      conic-gradient(hsl(var(--gd-success)) 100%, hsl(var(--ait-m-secondary)) 0);
  }
  .bubble-count { font-size: 13px; font-weight: 850; font-variant-numeric: tabular-nums; }
  .bubble-dot {
    display: none; position: absolute; top: 1px; right: 1px; width: 8px; height: 8px; border-radius: 999px;
    background: hsl(var(--gd-success)); animation: gdReadyBlink 1.6s ease-in-out infinite;
  }
  .dock-bubble.has-ready .bubble-dot { display: block; }
  .dock-bubble.pulse { animation: gdPillPulse 1.2s ease-out 1; }

  /* Corner chip pair — the two resting surfaces swap WITHOUT opening anything:
     – on the pill minimizes to the bubble, + on the bubble restores the pill.
     Siblings, not children — nesting a button in a button would be invalid
     HTML. The root is position:fixed and its box equals the resting surface's,
     so the chip pins to its corner. */
  .pill-mini, .bubble-expand {
    position: absolute; top: -7px; left: -7px; z-index: 1;
    width: 18px; height: 18px; padding: 0; border-radius: 999px;
    align-items: center; justify-content: center;
    background: hsl(var(--ait-m-card)); border: 1px solid hsl(var(--ait-m-border));
    font-family: inherit; font-size: 12px; font-weight: 700; line-height: 1;
    color: hsl(var(--ait-m-muted-foreground)); cursor: pointer;
  }
  .pill-mini:hover, .bubble-expand:hover { color: hsl(var(--ait-m-foreground)); }
  /* Always-on (no hover to gate it) means it must be finger-sized. */
  @media (hover: none) { .pill-mini, .bubble-expand { width: 24px; height: 24px; } }

  /* Docked to the left edge: surfaces grow rightwards from it. */
  .gen-dock.edge-left { align-items: flex-start; }
  .gen-dock.edge-left .dock-panel { transform-origin: bottom left; }
  .gen-dock.edge-left .pill-mini, .gen-dock.edge-left .bubble-expand { left: auto; right: -7px; }

  /* Same reason as .dock-grabber's touch-action: a drag would otherwise become
     a scroll and pointercancel would kill every gesture. user-select and
     touch-callout: a slow drag start must not open text selection or the iOS
     callout on the pill label. */
  .dock-pill, .dock-bubble { touch-action: none; -webkit-user-select: none; user-select: none; -webkit-touch-callout: none; }
  html.gd-dock-dragging, html.gd-dock-dragging * { user-select: none !important; }
  .gen-dock.dragging { transition: none !important; }
  .gen-dock.snapping { transition: left .28s ease, bottom .28s ease; }

  @media (min-width: 720.02px) {
    /* Two header buttons now: the first claims the free space, and the -4px
       optical offset against the panel padding belongs to the last one. */
    .dock-head [data-act="mini"] { display: flex; margin-right: 0; }
    .dock-head [data-act="mini"] + .dock-mini-btn { margin-left: 0; }

    .gen-dock.collapsed:not(.mini):hover .pill-mini { display: flex; }
    .gen-dock.mini:hover .bubble-expand { display: flex; }

    /* Draggable surfaces advertise it at rest with the open hand (touch has no
       cursor). Holding pinches it: the :active form is the pure-CSS guarantee,
       and the html class (armed on pointerdown) keeps the grabbing cursor
       wherever the pointer travels — element cursors only apply while it is
       over the dock. */
    .dock-pill, .dock-bubble, .dock-head { cursor: grab; }
    .dock-pill:active, .dock-bubble:active, .dock-head:active { cursor: grabbing; }
    html.gd-dock-dragging, html.gd-dock-dragging * { cursor: grabbing !important; }
    /* The head is a drag surface only here — on mobile it is the sheet's header. */
    .dock-head { touch-action: none; }
  }
  /* Touch at desktop widths (iPad): the chips cannot be hovered in — keep them on. */
  @media (min-width: 720.02px) and (hover: none) {
    .gen-dock.collapsed:not(.mini) .pill-mini { display: flex; }
    .gen-dock.mini .bubble-expand { display: flex; }
  }

  @media (prefers-reduced-motion: reduce) {
    .gen-dock, .gen-dock *, .gen-dock *::before, .gen-dock *::after { animation: none !important; transition: none !important; }
  }
  `;

  const PANEL_TEMPLATE = `
    <div class="dock-panel dock-surface">
      <div class="dock-head">
        <div>
          <div class="dock-title">Generations</div>
          <div class="dock-sub" id="gdSub"></div>
        </div>
        <button type="button" class="dock-mini-btn" id="gdMini" data-act="mini" title="Minimize" aria-label="Minimize to bubble">${MINUS}</button>
        <button type="button" class="dock-mini-btn" id="gdCollapse" data-act="collapse" title="Collapse" aria-label="Collapse">${CHEVRON_UP}</button>
      </div>
      <div class="dock-rows" id="gdRows">
        <div class="group-label" id="gdActiveLabel">In Progress</div>
        <div id="gdActiveList"></div>
        <div class="group-label" id="gdReadyLabel">Ready</div>
        <div id="gdReadyList"></div>
        <div class="all-done"><span class="big">✓</span><span class="msg">All caught up</span></div>
      </div>
      <div class="dock-footer">
        <a href="${OUTPUTS_URL}">View all generations →</a>
        <button type="button" class="dock-clear" id="gdClear" data-act="clear" title="Clear finished">Clear done</button>
      </div>
    </div>
    <button type="button" class="dock-pill dock-surface" id="gdPill" data-act="expand" title="Show generations">
      <span class="pill-ring" id="gdPillRing" style="--pct:0"><span class="pill-count" id="gdPillCount">0</span></span>
      <span class="pill-label" id="gdPillLabel">Generating</span>
      <span class="pill-eta" id="gdPillEta"></span>
      <span class="pill-ready" id="gdPillReady"><span class="dot"></span><span id="gdPillReadyCount">0 Ready</span></span>
    </button>
    <button type="button" class="pill-mini" data-act="mini" title="Minimize" aria-label="Minimize to bubble">–</button>
    <button type="button" class="dock-bubble dock-surface" id="gdBubble" data-act="expand" title="Show generations" aria-label="Show generations">
      <span class="bubble-ring" id="gdBubbleRing" style="--pct:0"><span class="bubble-count" id="gdBubbleCount">0</span></span>
      <span class="bubble-dot" aria-hidden="true"></span>
    </button>
    <button type="button" class="bubble-expand" data-act="restore" title="Expand" aria-label="Expand from bubble">+</button>
  `;

  const ROW_SKELETON = `
    <div class="row-media">
      <span class="type-glyph"></span>
      <span class="thumb"></span>
      <span class="play">▶</span>
      <span class="fail-x">✕</span>
    </div>
    <div class="row-body">
      <div class="row-top"><span class="row-name"></span><span class="row-metric"></span></div>
      <div class="row-sub"><span class="prompt"></span><span class="err"></span><span class="row-credits"></span></div>
    </div>
    <span class="row-action"></span>`;

  // ---------------------------------------------------------------------------
  // Store
  // ---------------------------------------------------------------------------
  function clampProgress(store, job) {
    const out = { ...job };
    let p = Number(out.progress);
    if (!Number.isFinite(p)) p = 0;
    p = Math.min(100, Math.max(0, p));
    if (isActive(out)) {
      const seen = store.maxProgress.get(out.jobId) || 0;
      p = Math.max(seen, p);                       // monotonic per job — never render a lower %
      store.maxProgress.set(out.jobId, p);
    } else if (out.status === 'done') {
      p = 100;
      store.maxProgress.set(out.jobId, 100);
    }
    out.progress = p;
    return out;
  }

  const Store = {
    jobs: new Map(),          // jobId -> DockJob
    maxProgress: new Map(),   // jobId -> highest progress seen (monotonic clamp)
    dismissed: new Set(),
    dismissedAt: new Map(),   // jobId -> dismiss time (ms); pruned against RETENTION_MS on load
    dismissWatermark: 0,      // Phase C prunes this against the queue retention window
    collapsed: false,
    mini: false,              // third resting surface: the ~44px bubble (wins over collapsed)
    caughtUp: false,
    autoFadeCaughtUp: true,   // live mode fades the "All caught up" card; fixtures hold it
    live: false,              // set by initLiveMode — gates sessionStorage snapshot writes
    _miss: new Map(),         // jobId -> consecutive fetch-misses (active→settled handoff grace)
    _subs: [],

    load() {
      try {
        this.collapsed = localStorage.getItem(LS.collapsed) === '1';
        this.mini = localStorage.getItem(LS.mini) === '1';
      } catch {}
      this._loadDismissed();
    },

    // Read the dismissed set + per-id timestamps, dropping ids older than the
    // queue retention window (their queue rows are purged, so they can never
    // reappear — no need to keep suppressing them). Rewrites the pruned set.
    _loadDismissed() {
      this.dismissed.clear();
      this.dismissedAt.clear();
      try {
        const raw = JSON.parse(localStorage.getItem(LS.dismissed) || 'null');
        if (raw && Array.isArray(raw.ids)) {
          const at = (raw.at && typeof raw.at === 'object') ? raw.at : {};
          const cutoff = Date.now() - RETENTION_MS;
          let pruned = false;
          raw.ids.forEach((id) => {
            const t = Number(at[id]);
            if (Number.isFinite(t) && t < cutoff) { pruned = true; return; }
            this.dismissed.add(id);
            if (Number.isFinite(t)) this.dismissedAt.set(id, t);
          });
          this.dismissWatermark = Number(raw.watermark) || 0;
          if (pruned) this._persistDismissed();
        }
      } catch {}
    },

    subscribe(fn) { this._subs.push(fn); },
    _emit() { this._subs.forEach((fn) => fn()); },

    get(id) { return this.jobs.get(id); },
    firstActive() { for (const j of this.jobs.values()) if (isActive(j)) return j; return null; },

    upsert(job) {
      if (!job || !job.jobId || this.dismissed.has(job.jobId)) return;
      this.jobs.set(job.jobId, clampProgress(this, job));
      this.caughtUp = false;
      this._emit();
    },

    upsertMany(list) {
      (list || []).forEach((job) => {
        if (job && job.jobId && !this.dismissed.has(job.jobId)) {
          this.jobs.set(job.jobId, clampProgress(this, job));
        }
      });
      this.caughtUp = false;
      this._emit();
    },

    // Phase C refines active-vs-settled precedence + dedupe; Phase A merges by jobId.
    reconcile(list) { this.upsertMany(list); },

    dismiss(id) {
      this.jobs.delete(id);
      this.maxProgress.delete(id);
      this._miss.delete(id);
      this._recordDismissed(id);
      this._persistDismissed();
      this.saveSnapshot();
      this._maybeCaughtUp();
      this._emit();
    },

    clearSettled() {
      for (const [id, job] of [...this.jobs]) {
        if (!isActive(job)) {
          this.jobs.delete(id);
          this.maxProgress.delete(id);
          this._miss.delete(id);
          this._recordDismissed(id);
        }
      }
      this._persistDismissed();
      this.saveSnapshot();
      this._maybeCaughtUp();
      this._emit();
    },

    _recordDismissed(id) {
      const now = Date.now();
      this.dismissed.add(id);
      this.dismissedAt.set(id, now);
      this.dismissWatermark = now;
    },

    setCollapsed(v) {
      this.collapsed = !!v;
      try { localStorage.setItem(LS.collapsed, v ? '1' : '0'); } catch {}
      this._emit();
    },

    setMini(v) {
      this.mini = !!v;
      try { localStorage.setItem(LS.mini, v ? '1' : '0'); } catch {}
      this._emit();
    },

    getGrouped() {
      const active = [];
      const ready = [];
      for (const job of this.jobs.values()) (isActive(job) ? active : ready).push(job);
      return { active, ready };
    },

    _maybeCaughtUp() {
      if (this.jobs.size > 0) return;
      this.caughtUp = true;
      if (this.autoFadeCaughtUp) {
        setTimeout(() => {
          if (this.jobs.size === 0) { this.caughtUp = false; this._emit(); }
        }, CAUGHT_UP_FADE_MS);
      }
    },

    _persistDismissed() {
      try {
        const at = {};
        for (const [id, t] of this.dismissedAt) at[id] = t;
        localStorage.setItem(LS.dismissed, JSON.stringify({ ids: [...this.dismissed], at, watermark: this.dismissWatermark }));
      } catch {}
    },

    // -----------------------------------------------------------------------
    // Phase C — live reconciliation, snapshot, multi-tab sync
    // -----------------------------------------------------------------------

    // Merge the two live fetches into the job map (§5.1 / D10). Dedupe by jobId:
    // a completing job can appear in BOTH lists for one cycle — active wins so
    // the row stays processing until settled is confirmed the next cycle, giving
    // a single clean active→done flip (the finish-pulse). Jobs that vanish from
    // both lists are pruned: active ones after a short grace (bridges the
    // active→settled handoff), settled ones persist until dismissed (R7 purge
    // happens on reload via retention).
    reconcileLive(active, settled) {
      const incoming = new Map();
      (settled || []).forEach((j) => { if (j && j.jobId) incoming.set(j.jobId, j); });
      (active || []).forEach((j) => { if (j && j.jobId) incoming.set(j.jobId, j); });

      for (const job of incoming.values()) {
        if (this.dismissed.has(job.jobId)) continue;
        this.jobs.set(job.jobId, clampProgress(this, job));
        this._miss.delete(job.jobId);
      }

      for (const [id, job] of [...this.jobs]) {
        if (incoming.has(id)) continue;
        if (isActive(job)) {
          const n = (this._miss.get(id) || 0) + 1;
          if (n >= 2) { this.jobs.delete(id); this.maxProgress.delete(id); this._miss.delete(id); }
          else this._miss.set(id, n);
        }
      }

      this.caughtUp = false;
      this._emit();
    },

    saveSnapshot() {
      if (!this.live) return;
      try { sessionStorage.setItem(SNAPSHOT_KEY, JSON.stringify([...this.jobs.values()])); } catch {}
    },

    restoreSnapshot() {
      try {
        const arr = JSON.parse(sessionStorage.getItem(SNAPSHOT_KEY) || 'null');
        if (Array.isArray(arr)) {
          arr.forEach((j) => {
            if (j && j.jobId && !this.dismissed.has(j.jobId)) this.jobs.set(j.jobId, clampProgress(this, j));
          });
        }
      } catch {}
    },

    // storage-event handlers (another tab dismissed/cleared or toggled collapse).
    reloadDismissed() {
      this._loadDismissed();
      for (const id of this.dismissed) { this.jobs.delete(id); this.maxProgress.delete(id); this._miss.delete(id); }
      this._emit();
    },
    reloadCollapsed() {
      try { this.collapsed = localStorage.getItem(LS.collapsed) === '1'; } catch {}
      this._emit();
    },
    reloadMini() {
      try { this.mini = localStorage.getItem(LS.mini) === '1'; } catch {}
      this._emit();
    },

    // Fixtures-only: wipe everything (incl. dismissed persistence) so scenarios reload cleanly.
    reset() {
      this.jobs.clear();
      this.maxProgress.clear();
      this.dismissed.clear();
      this.dismissedAt.clear();
      this._miss.clear();
      this.caughtUp = false;
      try { localStorage.removeItem(LS.dismissed); } catch {}
      this._emit();
    },
  };

  // ---------------------------------------------------------------------------
  // View
  // ---------------------------------------------------------------------------
  const els = {};
  const rowEls = new Map();   // jobId -> row element (keyed rendering enables the in-place done-flip)

  function mount() {
    if (els.root) return;
    injectStyles();
    const root = document.createElement('div');
    root.className = 'gen-dock gone';
    root.id = 'genDock';
    root.innerHTML = PANEL_TEMPLATE;
    document.body.appendChild(root);

    els.root = root;
    els.sub = root.querySelector('#gdSub');
    els.clear = root.querySelector('#gdClear');
    els.rows = root.querySelector('#gdRows');
    els.activeLabel = root.querySelector('#gdActiveLabel');
    els.activeList = root.querySelector('#gdActiveList');
    els.readyLabel = root.querySelector('#gdReadyLabel');
    els.readyList = root.querySelector('#gdReadyList');
    els.pill = root.querySelector('#gdPill');
    els.pillRing = root.querySelector('#gdPillRing');
    els.pillCount = root.querySelector('#gdPillCount');
    els.pillLabel = root.querySelector('#gdPillLabel');
    els.pillEta = root.querySelector('#gdPillEta');
    els.pillReady = root.querySelector('#gdPillReady');
    els.pillReadyCount = root.querySelector('#gdPillReadyCount');
    els.bubble = root.querySelector('#gdBubble');
    els.bubbleRing = root.querySelector('#gdBubbleRing');
    els.bubbleCount = root.querySelector('#gdBubbleCount');

    // Single delegated click listener (CSP-safe: no inline handlers).
    root.addEventListener('click', onClick);
  }

  function onClick(event) {
    const btn = event.target.closest('[data-act]');
    if (!btn || !els.root.contains(btn)) return;
    const act = btn.getAttribute('data-act');
    const rowEl = btn.closest('[data-job-id]');
    const jobId = rowEl ? rowEl.getAttribute('data-job-id') : null;
    handleAction(act, jobId);
  }

  function ensureRow(job) {
    let el = rowEls.get(job.jobId);
    if (!el) {
      el = document.createElement('div');
      el.className = 'dock-row';
      el.setAttribute('data-job-id', job.jobId);
      el.innerHTML = ROW_SKELETON;                 // static markup only — no user data here
      rowEls.set(job.jobId, el);
    }
    return el;
  }

  // Longest believable in-flight run — past this the anchor is a skewed DB
  // timestamp, not an hour-old generation; show nothing over a bogus clock.
  const ELAPSED_TRUST_MS = 60 * 60_000;

  // ETA when an estimate exists; otherwise elapsed time counting up. The row
  // already sits under "In Progress" — a "Generating…" label would say nothing.
  function etaMetric(job) {
    if (job.etaSeconds != null) {
      return Number(job.etaSeconds) <= 0 ? 'finishing…' : '~' + fmtTime(job.etaSeconds);
    }
    const startMs = Date.parse(job.startedAt || job.createdAt || '');
    if (!Number.isFinite(startMs)) return '';
    const elapsedMs = Date.now() - startMs;
    return elapsedMs > ELAPSED_TRUST_MS ? '' : fmtTime(elapsedMs / 1000);
  }

  function metricText(job) {
    switch (job.status) {
      case 'queued': return 'Queued';
      case 'processing': return job.retrying ? 'Retrying…' : etaMetric(job);
      case 'waiting_input': return 'Needs input';
      case 'done': return '';
      case 'failed':
      case 'dead': return '';
      case 'cancelled': return 'Cancelled';
      default: return '';
    }
  }

  // Only the state that asks something of the user gets colored ink; every other metric stays plain.
  const METRIC_TONE = { waiting_input: 'info' };

  function metricClass(job) {
    const tone = METRIC_TONE[job.status];
    return tone ? `row-metric tone-${tone}` : 'row-metric';
  }

  function actionHtml(job) {
    const dismiss = '<button type="button" class="btn-dismiss" data-act="dismiss" title="Dismiss" aria-label="Dismiss">✕</button>';
    const retry = '<button type="button" class="btn-retry" data-act="retry" title="Retry" aria-label="Retry">↻</button>';
    // Jumps to the run's own waiting card (`?jobId=` force-opens the agent's
    // History tab). Stays rightmost so every row has the same route in.
    const open = `<button type="button" class="btn-open" data-act="open" title="Open this generation" aria-label="Open this generation">${CHEVRON_RIGHT}</button>`;
    switch (job.status) {
      // No cancel affordance: store runs execute fire-and-forget at submission
      // (jobs row is 'processing' within ~30ms), so the server refuses almost
      // every cancel (400 CANNOT_CANCEL / INVALID_STATUS) — a ✕ here would be
      // a broken promise. Active rows only offer the way into the run.
      case 'queued':
      case 'processing': return open;
      // A waiting_input row's job is already completed and its run idle — the
      // one ACTIVE state the user can acknowledge away, so it gets dismiss.
      case 'waiting_input':
      case 'done':
      case 'failed': return dismiss + open;
      case 'dead': return dismiss + retry + open;
      case 'cancelled': return dismiss;
      default: return '';
    }
  }

  function updateRow(job) {
    const el = ensureRow(job);
    const prev = el.dataset.status;
    el.dataset.status = job.status;
    el.classList.toggle('is-video', job.kind === 'video');

    el.querySelector('.type-glyph').innerHTML = GLYPHS[job.kind] || GLYPHS.other;

    // User-originated strings via textContent (the escaping mechanism — never innerHTML).
    el.querySelector('.row-name').textContent = job.displayName || prettifyId(job.agentId);

    const promptEl = el.querySelector('.prompt');
    if (job.prompt) { promptEl.textContent = job.prompt; promptEl.style.display = ''; }
    else promptEl.style.display = 'none';

    const creditsEl = el.querySelector('.row-credits');
    if (typeof job.credits === 'number') { creditsEl.innerHTML = `${CREDIT_BOLT}${job.credits}`; creditsEl.style.display = ''; }
    else creditsEl.style.display = 'none';                 // chip hidden when unknown

    if (job.status === 'done') applyDoneMedia(el, job);
    else el.classList.remove('has-media');

    if (job.status === 'failed' || job.status === 'dead') el.title = job.error || 'Generation failed';
    else el.removeAttribute('title');

    el.querySelector('.err').textContent =
      (job.status === 'failed' || job.status === 'dead') ? (job.error || 'Generation failed') : '';

    const metricEl = el.querySelector('.row-metric');
    metricEl.className = metricClass(job);
    metricEl.textContent = metricText(job);

    el.querySelector('.row-action').innerHTML = actionHtml(job);

    // Finish moment: same jobId-keyed element flips to thumbnail with a green double-pulse.
    if (job.status === 'done' && prev && prev !== 'done') {
      el.classList.add('just-done');
      setTimeout(() => el.classList.remove('just-done'), 2500);
      if (pillIsCollapsedSurface()) pulsePill();
    }
    return el;
  }

  function syncGroup(list, container) {
    list.forEach((job) => {
      const el = updateRow(job);
      // Only move when the group changed — re-inserting restarts the row's animations otherwise.
      if (el.parentElement !== container) container.appendChild(el);
    });
  }

  function removeStaleRows(validIds) {
    for (const [id, el] of [...rowEls]) {
      if (validIds.has(id)) continue;
      el.classList.add('removing');
      setTimeout(() => el.remove(), 300);
      rowEls.delete(id);
    }
  }

  function renderPill(active, ready) {
    const done = ready.filter((j) => j.status === 'done');
    const pct = active.length
      ? active.reduce((sum, j) => sum + (j.status === 'processing' ? j.progress : 0), 0) / active.length
      : 100;
    els.pillRing.style.setProperty('--pct', Math.round(pct));
    els.pillCount.textContent = active.length || done.length;
    els.pillLabel.textContent = active.length ? 'Generating' : 'Ready';

    const etas = active
      .filter((j) => j.status === 'processing' && Number(j.etaSeconds) > 0)
      .map((j) => Number(j.etaSeconds));
    const maxEta = etas.length ? Math.max(...etas) : 0;
    els.pillEta.textContent = maxEta > 0 ? '~' + fmtTime(maxEta) : '';

    els.pill.classList.toggle('has-ready', done.length > 0 && active.length > 0);
    els.pill.classList.toggle('all-ready', done.length > 0 && active.length === 0);
    els.pillReadyCount.textContent = `${done.length} Ready`;

    // The bubble is the same summary at 44px: ring, count, ready dot.
    els.bubbleRing.style.setProperty('--pct', Math.round(pct));
    els.bubbleCount.textContent = active.length || done.length;
    els.bubble.classList.toggle('has-ready', done.length > 0 && active.length > 0);
    els.bubble.classList.toggle('all-ready', done.length > 0 && active.length === 0);
  }

  function pulsePill() {
    [els.pill, els.bubble].forEach((el) => {
      el.classList.remove('pulse');
      void el.offsetWidth;                         // reflow so the animation restarts
      el.classList.add('pulse');
    });
  }

  function render() {
    if (!els.root) return;
    const { active, ready } = Store.getGrouped();
    const total = active.length + ready.length;
    const showCaughtUp = Store.caughtUp && total === 0;

    els.root.classList.toggle('gone', total === 0 && !showCaughtUp);
    els.root.classList.toggle('collapsed', Store.collapsed);
    els.root.classList.toggle('mini', Store.mini);

    const done = ready.filter((j) => j.status === 'done').length;
    const failed = ready.filter((j) => j.status === 'failed' || j.status === 'dead').length;
    const bits = [];
    if (failed) bits.push(`${failed} Error`);
    if (active.length) bits.push(`${active.length} In Progress`);
    if (done) bits.push(`${done} Completed`);
    els.sub.textContent = showCaughtUp ? 'All caught up' : bits.join(', ');

    els.activeLabel.style.display = active.length ? '' : 'none';
    els.readyLabel.style.display = ready.length ? '' : 'none';
    els.clear.style.display = ready.length ? '' : 'none';
    els.rows.classList.toggle('empty', showCaughtUp);

    syncGroup(active, els.activeList);
    syncGroup(ready, els.readyList);
    removeStaleRows(new Set([...active, ...ready].map((j) => j.jobId)));

    renderPill(active, ready);
  }

  function prettifyId(id) {
    return String(id || 'Generation')
      .replace(/^.*\//, '')
      .replace(/[-_]+/g, ' ')
      .replace(/\b\w/g, (c) => c.toUpperCase());
  }

  // ---------------------------------------------------------------------------
  // Actions — swappable per mode. Phase C replaces `actions` with live endpoints
  // (POST /api/queue/dead/:id/requeue, deep-link navigation).
  // ---------------------------------------------------------------------------
  let actions = null;
  let liveController = null;   // Phase C poll lifecycle handle (kick/ensure/stop)
  let applyDockPosition = null;   // set by setupDockDrag — lets the storage sync re-apply another tab's position

  function handleAction(act, jobId) {
    switch (act) {
      case 'collapse': Store.setCollapsed(true); Store.setMini(false); return;
      case 'expand': Store.setMini(false); Store.setCollapsed(false); return;
      case 'mini': Store.setMini(true); return;
      // The bubble chip's inverse of 'mini': back to the surface that was
      // minimized (pill or panel — collapsed untouched), never opening anything.
      case 'restore': Store.setMini(false); return;
      case 'clear': Store.clearSettled(); return;
      case 'retry': if (jobId) actions?.retry?.(jobId); return;
      case 'dismiss': if (jobId) actions?.dismiss?.(jobId); return;
      case 'open': if (jobId) actions?.open?.(jobId); return;
      default: return;
    }
  }

  // ---------------------------------------------------------------------------
  // FixtureDataSource — deterministic fake jobs (Phase A). Extracted from the prototype.
  // Every state is reachable via explicit controls (no timers required for determinism).
  // ---------------------------------------------------------------------------
  function FixtureDataSource() {
    let counter = 0;
    const nextId = () => `fix-${++counter}`;

    const PRESETS = {
      image: { kind: 'image', displayName: 'Flux Image Studio', prompt: 'isometric wooden workshop', credits: 2, etaSeconds: 12 },
      video: { kind: 'video', displayName: 'Cinematic Video Pro', prompt: 'neon city flyover at dusk', credits: 12, etaSeconds: 46 },
      audio: { kind: 'audio', displayName: 'Voice Cloner', prompt: 'warm narrator, calm pacing', credits: 4, etaSeconds: 18 },
      builder: { kind: 'builder', displayName: 'Agent Builder', prompt: 'checkpoint: choose a style', credits: undefined, etaSeconds: 0 },
    };

    function make(overrides) {
      const preset = PRESETS[overrides.kind] || PRESETS.image;
      const jobId = overrides.jobId || nextId();
      return {
        jobId,
        queueItemId: `q-${jobId}`,
        agentId: overrides.agentId || 'demo-agent',
        displayName: preset.displayName,
        kind: preset.kind,
        status: overrides.status || 'processing',
        progress: overrides.progress != null ? overrides.progress : 0,
        etaSeconds: overrides.etaSeconds != null ? overrides.etaSeconds : preset.etaSeconds,
        createdAt: '2026-07-22T00:00:00.000Z',
        prompt: overrides.prompt != null ? overrides.prompt : preset.prompt,
        credits: overrides.credits != null ? overrides.credits : preset.credits,
        thumbnailUrl: overrides.thumbnailUrl,
        deepLinkUrl: `/marketplace/agent/${overrides.agentId || 'demo-agent'}?jobId=${jobId}`,
        error: overrides.error,
        retrying: overrides.retrying || false,
      };
    }

    // A tiny inline SVG so the thumbnailUrl path is exercised without a network image.
    const SAMPLE_THUMB = 'data:image/svg+xml,' + encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7C3AED"/><stop offset="1" stop-color="#DB2777"/></linearGradient></defs><rect width="80" height="80" fill="url(#g)"/></svg>');

    const SCENARIOS = {
      gallery: () => [
        make({ status: 'queued', kind: 'image' }),
        make({ status: 'processing', kind: 'video', progress: 72, etaSeconds: 22 }),
        make({ status: 'processing', kind: 'audio', progress: 40, etaSeconds: 15, retrying: true }),
        make({ status: 'waiting_input', kind: 'builder' }),
        make({ status: 'done', kind: 'video', progress: 100, thumbnailUrl: SAMPLE_THUMB }),
        make({ status: 'done', kind: 'image', progress: 100 }),
        make({ status: 'failed', kind: 'image', error: 'Content flagged by the safety filter. Try a different prompt.' }),
        make({ status: 'dead', kind: 'video', error: 'Provider timed out after 3 attempts.' }),
        make({ status: 'cancelled', kind: 'image' }),
      ],
      queued: () => [make({ status: 'queued', kind: 'image' })],
      processing: () => [make({ status: 'processing', kind: 'video', progress: 63, etaSeconds: 18 })],
      retrying: () => [make({ status: 'processing', kind: 'audio', progress: 30, etaSeconds: 20, retrying: true })],
      waiting_input: () => [make({ status: 'waiting_input', kind: 'builder' })],
      done: () => [make({ status: 'done', kind: 'video', progress: 100, thumbnailUrl: SAMPLE_THUMB })],
      failed: () => [make({ status: 'failed', kind: 'image', error: 'Content flagged by the safety filter. Try a different prompt.' })],
      dead: () => [make({ status: 'dead', kind: 'video', error: 'Provider timed out after 3 attempts.' })],
      cancelled: () => [make({ status: 'cancelled', kind: 'image' })],
      'all-ready': () => [
        make({ status: 'done', kind: 'video', progress: 100, thumbnailUrl: SAMPLE_THUMB }),
        make({ status: 'done', kind: 'image', progress: 100 }),
      ],
      collapsed: () => [
        make({ status: 'processing', kind: 'video', progress: 55, etaSeconds: 24 }),
        make({ status: 'processing', kind: 'image', progress: 80, etaSeconds: 6 }),
        make({ status: 'done', kind: 'video', progress: 100, thumbnailUrl: SAMPLE_THUMB }),
      ],
    };

    return {
      make,
      scenarios: SCENARIOS,
      load(name) {
        Store.reset();
        const build = SCENARIOS[name] || SCENARIOS.gallery;
        Store.upsertMany(build());
        Store.setCollapsed(name === 'collapsed' || name === 'all-ready');
      },
      addJob(kind) { Store.upsert(make({ kind, status: 'processing', progress: 8 })); },
    };
  }

  function fixtureActions(source) {
    return {
      retry(jobId) {
        const job = Store.get(jobId);
        if (job) Store.upsert({ ...job, status: 'processing', progress: 5, etaSeconds: job.etaSeconds || 20, retrying: false, error: undefined });
      },
      open(jobId) {
        const job = Store.get(jobId);
        if (!job) return;
        console.info('[gen-dock] open', job.deepLinkUrl);   // fixtures: no navigation (keeps e2e stable)
      },
      dismiss(jobId) { Store.dismiss(jobId); },
    };
  }

  // ---------------------------------------------------------------------------
  // Bootstrap
  // ---------------------------------------------------------------------------
  function isFixtureMode() {
    try { return new URLSearchParams(window.location.search).has('dockFixtures'); } catch { return false; }
  }

  function initFixtureMode() {
    const source = FixtureDataSource();
    actions = fixtureActions(source);
    Store.autoFadeCaughtUp = false;                // hold the "All caught up" card for screenshots

    // Fixture control surface consumed by public/dock-fixtures.html.
    window.GenerationDock.fixtures = {
      scenario: (name) => source.load(name),
      addJob: (kind) => source.addJob(kind),
      finishNext: () => {
        const job = Store.firstActive();
        if (job) Store.upsert({ ...job, status: 'done', progress: 100, etaSeconds: 0, retrying: false });
      },
      failNext: () => {
        const job = Store.firstActive();
        if (job) Store.upsert({ ...job, status: 'failed', error: 'The model provider returned an error. Please try again.' });
      },
      clearDone: () => Store.clearSettled(),
      collapse: (v) => Store.setCollapsed(v !== false),
      mini: (v) => Store.setMini(v !== false),
      reset: () => Store.reset(),
    };

    source.load('gallery');
  }

  // ---------------------------------------------------------------------------
  // Live mode (Phase C) — DockJob mapping, catalog lookups, poll lifecycle,
  // real actions, wake-up wiring. Fetches only /api/queue (D9) + two read-only
  // catalogs the store pages already load (C3).
  // ---------------------------------------------------------------------------

  function jsonFetch(url) {
    return fetch(url, { method: 'GET', credentials: 'include', headers: { Accept: 'application/json' } })
      .then((r) => (r.ok ? r.json() : null))
      .catch(() => null);
  }

  // Media-type/category token → DockJob kind.
  function mapMediaToKind(value) {
    switch (String(value || '').toLowerCase()) {
      case 'image': return 'image';
      case 'video': return 'video';
      case 'audio':
      case 'audio-voice':
      case 'voice': return 'audio';
      case 'text': return 'text';
      default: return null;
    }
  }

  // Keyword fallback when the catalog hasn't loaded (or lacks the id).
  function inferKind(id) {
    const s = String(id || '').toLowerCase();
    if (/(video|clip|veo|kling|seedance|runway|wan|hunyuan|ltx|animat|motion|minimax\/video)/.test(s)) return 'video';
    if (/(audio|voice|music|speech|tts|sound|eleven|whisper|mmaudio|lyria|suno)/.test(s)) return 'audio';
    if (/(image|img|photo|flux|sdxl|imagen|nano-banana|ideogram|recraft|dall|qwen-image|seedream|kontext)/.test(s)) return 'image';
    if (/(text|gpt|claude|llama|chat|writer|prompt|caption|title|humaniz|translat|summar)/.test(s)) return 'text';
    return 'other';
  }

  function agentKindFromEntry(a) {
    const mods = Array.isArray(a.modalities) ? a.modalities : [];
    return mapMediaToKind(a.primaryCategory)
      || mapMediaToKind(mods.find((m) => m && m !== 'text'))
      || mapMediaToKind(mods[0])
      || inferKind(a.id);
  }

  // Agents' costEstimate is currency-denominated; only surface it as a credits
  // chip when the currency actually is credits (else the number would be wrong).
  function agentCreditsFromEntry(a) {
    const c = a.costEstimate;
    if (c && c.currency === 'credits' && Number.isFinite(Number(c.minCost))) return Number(c.minCost);
    return undefined;
  }

  // Read-only name/kind/credits catalog, populated from the two endpoints the
  // store pages already load, cached in sessionStorage (5-min freshness matching
  // their Cache-Control). Lookups are synchronous against in-memory maps; until
  // the fetch lands, mapping degrades to prettify(id) + keyword kind.
  const Catalog = {
    agents: new Map(),
    models: new Map(),
    primed: false,
    _loading: false,

    prime(onReady) {
      if (this.primed) { if (onReady) onReady(); return; }
      let cached = null;
      try { cached = JSON.parse(sessionStorage.getItem(CATALOG_KEY) || 'null'); } catch {}
      if (cached && cached.ts && (Date.now() - cached.ts) < CATALOG_FRESH_MS) {
        this._absorb(cached);
        this.primed = true;
        if (onReady) onReady();
        return;
      }
      if (cached) this._absorb(cached);   // stale: use immediately, refresh below
      if (this._loading) return;
      this._loading = true;
      Promise.all([
        jsonFetch('https://aitopia.ai/api/store'),
        jsonFetch('https://aitopia.ai/api/models/all?callableOnly=true&limit=-1'),
      ]).then(([store, models]) => {
        const data = { agents: [], models: [], ts: Date.now() };
        if (store && Array.isArray(store.agents)) {
          store.agents.forEach((a) => {
            if (a && a.id) data.agents.push([a.id, { displayName: a.name || prettifyId(a.id), kind: agentKindFromEntry(a), credits: agentCreditsFromEntry(a) }]);
          });
        }
        if (models && Array.isArray(models.models)) {
          models.models.forEach((m) => {
            if (!m || !m.id) return;
            const credits = m.creditsEstimated && Number.isFinite(Number(m.creditsEstimated.credits)) ? Number(m.creditsEstimated.credits) : undefined;
            data.models.push([m.id, { displayName: m.displayName || prettifyId(m.id), kind: mapMediaToKind(m.mediaType) || inferKind(m.id), credits }]);
          });
        }
        this._absorb(data);
        this.primed = true;
        try { sessionStorage.setItem(CATALOG_KEY, JSON.stringify(data)); } catch {}
        if (onReady) onReady();
      }).finally(() => { this._loading = false; });
    },

    _absorb(data) {
      (data.agents || []).forEach(([id, v]) => this.agents.set(id, v));
      (data.models || []).forEach(([id, v]) => this.models.set(id, v));
    },

    // Resolve { displayName, kind, credits } for a queue row.
    lookup(agentId, input) {
      const inputKind = input && typeof input === 'object' ? input.kind : undefined;
      if (inputKind === 'builder-preview' || inputKind === 'builder-step') {
        const base = String(agentId || '').replace(/_step-\d+$/, '');
        const a = this.agents.get(base);
        return { displayName: (a && a.displayName) || prettifyId(base), kind: 'builder', credits: undefined };
      }
      if (String(agentId || '').includes('/')) {
        const m = this.models.get(agentId);
        return { displayName: (m && m.displayName) || prettifyId(agentId), kind: (m && m.kind) || inferKind(agentId), credits: m ? m.credits : undefined };
      }
      // `_step-N` is builder-only row naming (resolveBuilderRowAgentId). An
      // orphaned row — its job deleted by the Remove teardown — arrives with no
      // input to say so; strip the suffix anyway so the base agent still names it.
      const base = String(agentId || '').replace(/_step-\d+$/, '');
      const a = this.agents.get(base);
      return { displayName: (a && a.displayName) || prettifyId(base), kind: (a && a.kind) || inferKind(base), credits: a ? a.credits : undefined };
    },
  };

  // A checkpoint-paused builder run manifests as a `completed` builder-step job
  // whose queue agentId is an INTERMEDIATE step (`<docId>_step-<N+1>`, per
  // resolveBuilderRowAgentId — the final step and single-shot preview use the
  // bare docId). But that row shape alone doesn't mean "paused": the builder's
  // isolated per-step Play produces it too (no run is waiting), and a run that
  // continued past the step leaves it behind as history. The rows of one run
  // share input.parentRunId (Play rows have none), so a row asks for input ONLY
  // when it is its run's newest row and nothing in the run is still executing.
  function isBuilderStepIntermediate(item) {
    return item?.input && item.input.kind === 'builder-step' && /_step-\d+$/.test(String(item.agentId || ''));
  }

  function buildBuilderRunIndex(items) {
    const runs = new Map();
    for (const item of items) {
      const parentRunId = item?.input && item.input.kind === 'builder-step' ? item.input.parentRunId : undefined;
      if (!parentRunId) continue;
      let run = runs.get(parentRunId);
      if (!run) { run = { hasActive: false, newestQueueId: null, newestAt: -Infinity }; runs.set(parentRunId, run); }
      if (item.status === 'pending' || item.status === 'processing' || item.status === 'retrying') run.hasActive = true;
      const at = Date.parse(item.createdAt || '') || 0;
      if (at > run.newestAt) { run.newestAt = at; run.newestQueueId = item.id; }
    }
    return runs;
  }

  function isPausedBuilderCheckpoint(item, runIndex) {
    if (!isBuilderStepIntermediate(item)) return false;
    const run = runIndex.get(item.input.parentRunId);
    return !!run && !run.hasActive && run.newestQueueId === item.id;
  }

  function mapQueueStatus(item, runIndex) {
    switch (item.status) {
      case 'pending': return { status: 'queued' };
      case 'processing': return { status: 'processing' };
      case 'retrying': return { status: 'processing', retrying: true };
      case 'completed': return isPausedBuilderCheckpoint(item, runIndex) ? { status: 'waiting_input' } : { status: 'done' };
      case 'failed': return { status: 'failed' };
      case 'dead': return { status: 'dead' };
      case 'cancelled': return { status: 'cancelled' };
      default: return { status: 'processing' };
    }
  }

  function extractPrompt(input) {
    if (!input || typeof input !== 'object') return undefined;
    for (const key of ['prompt', 'text', 'description']) {
      const v = input[key];
      if (typeof v === 'string' && v.trim()) return v.trim();
    }
    // Builder rows carry the user's fields one level down, in input.userInput.
    const nested = input.userInput;
    if (nested && typeof nested === 'object') {
      for (const key of ['prompt', 'text', 'description']) {
        const v = nested[key];
        if (typeof v === 'string' && v.trim()) return v.trim();
      }
    }
    return undefined;
  }

  // An anchor in the future or absurdly past the estimate is a clock-skewed DB
  // timestamp, not a job finishing — show progress-only rather than eternal "finishing…".
  const ETA_OVERRUN_GRACE_MS = 60 * 60_000;

  function computeEtaSeconds(item) {
    const est = Number(item.estimatedDurationMs);
    if (!Number.isFinite(est) || est <= 0) return undefined;
    const anchor = item.startedAt || item.createdAt;
    const startMs = anchor ? Date.parse(anchor) : NaN;
    if (!Number.isFinite(startMs)) return undefined;
    const elapsed = Date.now() - startMs;
    if (elapsed < 0 || elapsed > est + ETA_OVERRUN_GRACE_MS) return undefined;
    return Math.round((est - elapsed) / 1000);   // ≤0 → View renders "finishing…"
  }

  function resolveDeepLink(agentId, jobId) {
    if (String(agentId || '').includes('/')) return OUTPUTS_URL;   // model runs: model.html ignores ?jobId= (Q2) → /creations
    const base = String(agentId || '').replace(/_step-\d+$/, '');  // builder intermediate → base agent/doc page
    // A base id the store catalog doesn't know (builder draft previews,
    // deactivated agents) has no live /agents page — send those to /creations.
    // Only a primed NON-EMPTY catalog can vouch for an id being unknown: a
    // failed catalog fetch primes empty (jsonFetch → null), and before priming
    // we can't tell either — both keep the agent link. Rows are remapped every
    // poll, so this corrects itself once the real catalog lands.
    if (Catalog.primed && Catalog.agents.size > 0 && !Catalog.agents.has(base)) return OUTPUTS_URL;
    return `/marketplace/agent/${encodeURIComponent(base)}?jobId=${encodeURIComponent(jobId)}`;
  }

  // Enriched /api/queue row → DockJob (§5.2). Missing optional fields degrade
  // gracefully: an old dead row with no job record has no input/thumb/error and
  // still renders as glyph + prettified name + deep-link.
  function toDockJob(item, runIndex) {
    const jobId = item.refId;
    const agentId = item.agentId || '';
    const meta = Catalog.lookup(agentId, item.input);
    const { status, retrying } = mapQueueStatus(item, runIndex);

    const job = {
      jobId,
      queueItemId: item.id,
      agentId,
      displayName: meta.displayName,
      kind: meta.kind,
      status,
      progress: Number.isFinite(Number(item.progress)) ? Number(item.progress) : (status === 'done' ? 100 : 0),
      createdAt: item.createdAt,
      deepLinkUrl: resolveDeepLink(agentId, jobId),
    };
    if (retrying) job.retrying = true;
    const prompt = extractPrompt(item.input);
    if (prompt) job.prompt = prompt;
    if (status === 'processing') {
      if (item.startedAt) job.startedAt = item.startedAt;
      const eta = computeEtaSeconds(item);
      if (eta != null) job.etaSeconds = eta;
    }
    if (typeof meta.credits === 'number') job.credits = meta.credits;
    if (item.thumbnailUrl) job.thumbnailUrl = item.thumbnailUrl;
    if (item.thumbnailKind) job.thumbnailKind = item.thumbnailKind;
    if (item.error) job.error = item.error;
    return job;
  }

  function LiveDataSource() {
    function fetchList(query) {
      return jsonFetch(`https://aitopia.ai/api/queue?${query}`).then((json) => (json && Array.isArray(json.items) ? json.items : []));
    }
    return {
      poll() {
        return Promise.all([fetchList(ACTIVE_QUERY), fetchList(SETTLED_QUERY)])
          .then(([active, settled]) => {
            // Pause detection needs the run's rows from BOTH feeds: the step
            // that is still executing arrives in the active list.
            const runIndex = buildBuilderRunIndex(active.concat(settled));
            // One generation, one row: a completed intermediate step that is
            // NOT the run's live checkpoint is pipeline history (or an isolated
            // builder Play) — /api/me/creations hides those rows too. What
            // remains: the active step, the frontier, the final bare-id row.
            // Real settled rows are trimmed to the pre-over-fetch budget
            // (feed is newest-first); paused frontiers ride along free — they
            // belong to the active section, not the recent-history budget.
            const visibleSettled = [];
            let shown = 0;
            for (const item of settled) {
              if (isPausedBuilderCheckpoint(item, runIndex)) { visibleSettled.push(item); continue; }
              if (item.status === 'completed' && isBuilderStepIntermediate(item)) continue;
              if (shown >= SETTLED_VISIBLE_MAX) continue;
              shown++;
              visibleSettled.push(item);
            }
            return {
              active: active.map((item) => toDockJob(item, runIndex)),
              settled: visibleSettled.map((item) => toDockJob(item, runIndex)),
            };
          });
      },
    };
  }

  function liveActions() {
    return {
      // Dead-letter requeue targets the QUEUE ITEM id (queue.ts:322 / requeueDead).
      retry(jobId) {
        const job = Store.get(jobId);
        const queueItemId = job && job.queueItemId;
        if (!queueItemId) return;
        fetch(`https://aitopia.ai/api/queue/dead/${encodeURIComponent(queueItemId)}/requeue`, {
          method: 'POST', credentials: 'include',
          headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, body: '{}',
        })
          .catch(() => {})
          .finally(() => { liveController && liveController.kick(); });
      },
      // Navigation only — ✕ and "Clear done" are the only ways a row leaves the dock.
      open(jobId) {
        const job = Store.get(jobId);
        if (!job || !job.deepLinkUrl) return;
        try { window.location.assign(job.deepLinkUrl); } catch {}
      },
      dismiss(jobId) { Store.dismiss(jobId); },
    };
  }

  // Best-effort smoother progress between polls. The event's jobId is the run's
  // parentRunId (checkpoint driver only) and usually will NOT match a queue
  // refId, so this no-ops for most runs — the 3s poll is the real driver.
  function applyProgressEvent(detail) {
    if (!detail || !detail.jobId) return;
    const job = Store.get(detail.jobId);
    if (!job || !isActive(job)) return;
    let pct = Number(detail.progress);
    if (!Number.isFinite(pct)) {
      const m = /\((\d+)%\)/.exec(String(detail.status || ''));
      if (m) pct = Number(m[1]);
    }
    if (!Number.isFinite(pct)) return;
    Store.upsert({ ...job, status: 'processing', progress: pct });   // monotonic clamp in upsert()
  }

  function initLiveMode() {
    Store.live = true;
    const source = LiveDataSource();
    actions = liveActions();
    Store.restoreSnapshot();          // instant first paint; reconciled by the first fetch

    // Absorb the sessionStorage catalog BEFORE the first poll maps rows — an
    // unprimed first mapping degrades to keyword kinds ('image-animator' →
    // image) and visibly flips a known tile once the catalog lands.
    Catalog.prime(() => { liveController && liveController.kick(); });

    let timer = null;
    let inFlight = false;

    function ensure() {
      if (timer) return;
      // Hidden tabs keep polling, just slower (multi-tab request budget), so the
      // favicon can reflect a finish/failure while the user is on another tab.
      timer = setInterval(() => { pollOnce(); }, document.hidden ? HIDDEN_POLL_MS : POLL_MS);
    }
    function stop() { if (timer) { clearInterval(timer); timer = null; } }

    function pollOnce() {
      if (inFlight) return;
      inFlight = true;
      source.poll().then(({ active, settled }) => {
        Store.reconcileLive(active, settled);
        Store.saveSnapshot();
        if (!Catalog.primed && (active.length + settled.length) > 0) Catalog.prime(() => { liveController && liveController.kick(); });
      }).catch(() => {}).finally(() => {
        inFlight = false;
        if (Store.firstActive()) ensure(); else stop();
      });
    }
    function kick() { pollOnce(); ensure(); }

    liveController = { pollOnce, ensure, stop, kick };

    // Switch cadence on visibility change: an active queue keeps polling while
    // hidden (slower) so the favicon stays live; an idle tab parks as before.
    // Coming back refreshes immediately at the normal cadence.
    document.addEventListener('visibilitychange', () => {
      stop();
      if (document.hidden) { if (Store.firstActive()) ensure(); }
      else kick();
    });

    // Wake-up: a generate click fires this (pre-202). The queue row only lands
    // after the 202, so re-fetch late, with one retry. Agent pages fire
    // `agent-generate-start` (embed-runner.js:5229); model pages fire
    // `model-generate-start` (model.html:4808) — both are in-scope run surfaces,
    // and without this an idle (non-polling) dock would miss a fresh submit.
    const onGenerateStart = () => { setTimeout(kick, WAKE_DELAY_MS); setTimeout(kick, WAKE_DELAY_MS * 2); };
    document.addEventListener('aitopia:agent-generate-start', onGenerateStart);
    document.addEventListener('aitopia:model-generate-start', onGenerateStart);

    window.addEventListener('aitopia-creation-progress', (e) => { try { applyProgressEvent(e.detail); } catch {} });

    // Multi-tab consistency (best-effort): another tab dismissed/cleared or toggled collapse.
    window.addEventListener('storage', (e) => {
      if (!e) return;
      if (e.key === LS.dismissed) Store.reloadDismissed();
      else if (e.key === LS.collapsed) Store.reloadCollapsed();
      else if (e.key === LS.mini) Store.reloadMini();
      else if (e.key === LS.pos && applyDockPosition) applyDockPosition();
    });

    kick();   // first fetch also discovers jobs started on a previous page
  }

  // ---------------------------------------------------------------------------
  // Favicon status indicator
  // ---------------------------------------------------------------------------
  // Badges the browser tab so a user working in another tab can watch their
  // generations progress, finish or fail without switching back. Colour priority
  // mirrors the panel's own semantics: error (red) beats active (yellow) beats
  // done (green). It's a while-away cue — a visible tab has the dock itself — so
  // becoming visible restores the default.
  const DEFAULT_FAVICON = '/marketplace/favicon.svg';
  const FAVICON_TINT = { active: '#f5a623', error: '#e5484d', done: '#2fa96b' };

  let faviconBase = null;                   // cached base logo; null → dot-only until it loads
  let faviconBaseLoading = false;
  let faviconDoneCleared = false;           // a visit acknowledged the current "all done" → don't re-green
  let lastFaviconKey = null;

  // Pure state → indicator descriptor. Priority: error > active > done > default.
  function faviconDescriptor({ active, done, failed }) {
    if (failed > 0) return { kind: 'error', count: failed };
    if (active > 0) return { kind: 'active', count: active };
    if (done > 0) return { kind: 'done', count: done };
    return { kind: 'default', count: 0 };
  }

  function faviconCounts() {
    const { active, ready } = Store.getGrouped();
    return {
      active: active.length,
      done: ready.filter((j) => j.status === 'done').length,
      failed: ready.filter((j) => j.status === 'failed' || j.status === 'dead').length,
    };
  }

  function faviconLink() {
    let link = document.querySelector('link[rel~="icon"]');
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      document.head.appendChild(link);
    }
    if (!link.dataset.gdDefault) link.dataset.gdDefault = link.getAttribute('href') || DEFAULT_FAVICON;
    return link;
  }

  function restoreDefaultFavicon() {
    const link = faviconLink();
    const def = link.dataset.gdDefault || DEFAULT_FAVICON;
    if (link.getAttribute('href') !== def) link.setAttribute('href', def);
  }

  // Decode the site logo once so paints are synchronous; repaint the current
  // state when it arrives (paints before then are a plain dot on transparent).
  function preloadFaviconBase() {
    if (faviconBase || faviconBaseLoading || typeof Image === 'undefined') return;
    faviconBaseLoading = true;
    const img = new Image();
    img.onload = () => { faviconBase = img; faviconBaseLoading = false; lastFaviconKey = null; updateFavicon(); };
    img.onerror = () => { faviconBaseLoading = false; };
    img.src = faviconLink().dataset.gdDefault || DEFAULT_FAVICON;
  }

  function paintFavicon(descriptor) {
    const size = 64;
    const canvas = document.createElement('canvas');
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;                                    // no 2d context (e.g. jsdom)
    if (faviconBase) ctx.drawImage(faviconBase, 0, 0, size, size);
    const r = size * 0.30;
    const cx = size - r - size * 0.02;
    const cy = size - r - size * 0.02;
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = FAVICON_TINT[descriptor.kind] || FAVICON_TINT.active;
    ctx.fill();
    ctx.lineWidth = size * 0.05; ctx.strokeStyle = '#ffffff'; ctx.stroke();
    if (descriptor.count > 0) {
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.round(r * 1.15)}px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(descriptor.count > 9 ? '9+' : String(descriptor.count), cx, cy + size * 0.02);
    }
    try { faviconLink().setAttribute('href', canvas.toDataURL('image/png')); } catch (_) {}
  }

  // Repaint from the live Store. While the tab is visible the dock speaks for
  // itself, so we hold the default favicon (revert-on-visit); while hidden we
  // paint the current state — the "all done" green holds until the user looks.
  function updateFavicon() {
    if (typeof document === 'undefined') return;
    if (document.visibilityState === 'visible') {
      faviconDoneCleared = faviconDescriptor(faviconCounts()).kind === 'done';  // a look acknowledges completion
      lastFaviconKey = 'default';
      restoreDefaultFavicon();
      return;
    }
    const d = faviconDescriptor(faviconCounts());
    if (d.kind === 'done' && faviconDoneCleared) { restoreDefaultFavicon(); return; }
    if (d.kind !== 'done') faviconDoneCleared = false;
    const key = d.kind + ':' + d.count;
    if (key === lastFaviconKey) return;
    lastFaviconKey = key;
    if (d.kind === 'default') { restoreDefaultFavicon(); return; }
    paintFavicon(d);
  }

  function start() {
    mount();
    Store.load();
    Store.subscribe(render);
    Store.subscribe(updateFavicon);
    document.addEventListener('visibilitychange', updateFavicon);
    preloadFaviconBase();
    if (isFixtureMode()) initFixtureMode();
    else initLiveMode();
    render();

    // The elapsed fallback is a clock — tick it each second between polls so it
    // counts smoothly instead of jumping by POLL_MS. Metric text only.
    setInterval(() => {
      if (document.hidden) return;
      for (const [jobId, el] of rowEls) {
        const job = Store.get(jobId);
        if (!job || job.status !== 'processing' || job.retrying || job.etaSeconds != null) continue;
        el.querySelector('.row-metric').textContent = etaMetric(job);
      }
    }, 1000);
  }

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------
  window.GenerationDock = {
    // Optional additive hook (C4): nudge a re-fetch right after a 202 submit.
    // The existing `aitopia:agent-generate-start` document event already wakes
    // the dock, so this is a no-op-safe timing refinement, not a dependency.
    notifySubmitted() { try { liveController && liveController.kick(); } catch { /* not in live mode */ } },

    // Seams for Phase C / E.
    _store: Store,
    _faviconState: () => faviconDescriptor(faviconCounts()),
    setActions(next) { if (next) actions = next; },
    render,
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }

  // ---------------------------------------------------------------------------
  // Phase E — mobile bottom sheet (open/close chrome + drag-to-dismiss).
  // Reuses the existing .dock-panel as the sheet; only manages sheet visibility,
  // body-scroll lock and safe-area — never the DataSource/Store/poll regions.
  // Runs after start() so els.* are mounted (this block is textually last).
  // ---------------------------------------------------------------------------

  // A collapsed surface stands in for the panel on both breakpoints: desktop when
  // the panel is collapsed or minimized to the bubble, mobile whenever the sheet
  // is closed. The finish-moment pulse (§3.1) fires whenever one of them is that
  // surface. (Hoisted; used by updateRow.)
  function pillIsCollapsedSurface() {
    return Store.collapsed || Store.mini
      || (window.matchMedia('(max-width: 720px)').matches
          && !!els.root && !els.root.classList.contains('sheet-open'));
  }

  function setupMobileSheet() {
    if (!els.root || els.root.__gdSheet) return;
    const panel = els.root.querySelector('.dock-panel');
    if (!panel) return;
    els.root.__gdSheet = true;

    const mq = window.matchMedia('(max-width: 720px)');
    const isMobile = () => mq.matches;
    const isOpen = () => els.root.classList.contains('sheet-open');
    const lockBody = (on) => document.documentElement.classList.toggle('gd-sheet-lock', on);

    const scrim = document.createElement('div');
    scrim.className = 'dock-scrim';
    els.root.insertBefore(scrim, els.root.firstChild);

    const grabber = document.createElement('div');
    grabber.className = 'dock-grabber';
    grabber.setAttribute('aria-hidden', 'true');
    panel.insertBefore(grabber, panel.firstChild);

    function openSheet() {
      if (isOpen()) return;
      panel.style.transition = '';
      panel.style.transform = '';
      els.root.classList.add('sheet-open');
      lockBody(true);
    }
    function closeSheet() {
      panel.style.transition = '';
      panel.style.transform = '';
      els.root.classList.remove('sheet-open');
      lockBody(false);
      if (applyDockPosition) applyDockPosition();   // position emits while open were deferred
    }

    // On mobile the pill/bubble opens the sheet and the header ⌄ closes it,
    // instead of driving the desktop collapse pref. Capture-phase
    // stopPropagation keeps the shared delegated click handler from also
    // calling Store.setCollapsed — which is why expand clears mini here:
    // handleAction's own Store.setMini(false) never runs on mobile.
    els.root.addEventListener('click', (event) => {
      if (!isMobile()) return;
      const btn = event.target.closest('[data-act]');
      if (!btn) return;
      const act = btn.getAttribute('data-act');
      if (act === 'expand') { event.stopPropagation(); Store.setMini(false); openSheet(); }
      else if (act === 'collapse') { event.stopPropagation(); closeSheet(); }
    }, true);

    scrim.addEventListener('click', closeSheet);

    // Drag-down to dismiss, initiated only from the grab handle (not the rows,
    // so vertical scrolling inside the sheet is unaffected).
    let dragging = false, startY = 0, dy = 0;
    const CLOSE_PX = 90;
    grabber.addEventListener('pointerdown', (event) => {
      if (!isMobile() || !isOpen()) return;
      dragging = true; startY = event.clientY; dy = 0;
      panel.style.transition = 'none';
      try { grabber.setPointerCapture(event.pointerId); } catch (_) {}
    });
    grabber.addEventListener('pointermove', (event) => {
      if (!dragging) return;
      dy = Math.max(0, event.clientY - startY);
      panel.style.transform = `translateY(${dy}px)`;
    });
    const endDrag = () => {
      if (!dragging) return;
      dragging = false;
      if (dy > CLOSE_PX) closeSheet();          // resets transition/transform, slides down
      else { panel.style.transition = ''; panel.style.transform = ''; }
    };
    grabber.addEventListener('pointerup', endDrag);
    grabber.addEventListener('pointercancel', endDrag);

    // If the dock empties (All caught up → gone) while the sheet is open — or
    // mini lands from the sheet's own minimize button or another tab — tear the
    // sheet down so the body-scroll lock never sticks.
    new MutationObserver(() => {
      if (isOpen() && (els.root.classList.contains('gone') || els.root.classList.contains('mini'))) closeSheet();
    }).observe(els.root, { attributes: true, attributeFilter: ['class'] });

    // Dropping back to desktop width closes the sheet cleanly.
    const onChange = () => { if (!mq.matches && isOpen()) closeSheet(); };
    if (mq.addEventListener) mq.addEventListener('change', onChange);
    else if (mq.addListener) mq.addListener(onChange);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupMobileSheet, { once: true });
  } else {
    setupMobileSheet();
  }

  // ---------------------------------------------------------------------------
  // Draggable dock — drag the pill, bubble or panel header (>720px only for the
  // header: on mobile it is the sheet's), snap to the nearest side on release,
  // persist { side, bottom } at LS.pos. Horizontal is always a snapped edge, so
  // only the side is stored; vertical is a bottom offset, which keeps
  // panel↔pill↔bubble swaps anchored while the surfaces grow upwards. The one
  // { side, bottom } is shared across widths — applyPos re-clamps per viewport.
  // Runs after start() so els.* are mounted.
  // ---------------------------------------------------------------------------
  function setupDockDrag() {
    if (!els.root || els.root.__gdDrag) return;
    els.root.__gdDrag = true;

    const root = els.root;
    const mobileQuery = window.matchMedia('(max-width: 720px)');
    const isMobile = () => mobileQuery.matches;

    let dragging = false;
    let snapping = false;              // an in-flight snap owns the inline styles until it lands
    let surface = null;                // the element that captured the pointer
    let activePointerId = null;        // ignore other pointers (second touch) mid-gesture
    let startX = 0, startY = 0;
    let startRect = null;
    let dragThreshold = DRAG_THRESHOLD_PX;   // per-gesture: fingers wobble more than mice (D4)
    let dragLeft = 0, dragBottom = 0;  // the position the drag last wrote (never re-measured)
    let suppressNextClick = false;
    let suppressTimer = null;
    let resizeFrame = 0;

    function clamp(value, min, max) { return Math.min(Math.max(value, min), max); }

    // env(safe-area-inset-*) is CSS-only — the token block publishes it through
    // the --gd-safe-* probes so the clamps can honor the notch/home indicator.
    function safeInset(name) {
      return parseFloat(getComputedStyle(root).getPropertyValue(name)) || 0;
    }

    function sideInset(side) {
      if (!isMobile()) return EDGE_MARGIN_PX;
      return MOBILE_EDGE_MARGIN_PX + safeInset(side === 'left' ? '--gd-safe-left' : '--gd-safe-right');
    }

    // The global bottom tab bar (body.has-bottom-tabs, <1024px) owns the last
    // 61px — the same floors the resting CSS offsets respect (the bar rule
    // includes the bottom safe-area at every width, the plain inset only ≤720px).
    function minBottom() {
      const inset = isMobile() ? MOBILE_EDGE_MARGIN_PX : EDGE_MARGIN_PX;
      const overTabs = document.body.classList.contains('has-bottom-tabs')
        && window.innerWidth < BOTTOM_TABS_MAX_WIDTH_PX;
      if (overTabs) return BOTTOM_TABS_BAR_PX + inset + safeInset('--gd-safe-bottom');
      return isMobile() ? inset + safeInset('--gd-safe-bottom') : inset;
    }

    function clampBottom(value, height) {
      const floor = minBottom();
      return clamp(value, floor, Math.max(floor, window.innerHeight - height - VIEWPORT_GAP_PX));
    }

    function readPos() {
      try {
        const raw = JSON.parse(localStorage.getItem(LS.pos) || 'null');
        if (raw && (raw.side === 'left' || raw.side === 'right') && Number.isFinite(Number(raw.bottom))) {
          return { side: raw.side, bottom: Number(raw.bottom) };
        }
      } catch {}
      return null;
    }

    // Nothing stored → no inline positioning at all, so the resting CSS
    // (including the has-bottom-tabs offsets) keeps working untouched.
    function clearInlinePos() {
      if (root.style.left || root.style.right || root.style.bottom) {
        root.style.left = '';
        root.style.right = '';
        root.style.bottom = '';
      }
      root.classList.remove('edge-left');
    }

    // Re-applies the stored corner after every render: a surface swap changes the
    // height, so the bottom clamp has to be recomputed. Only the displayed value
    // is clamped — the stored one is rewritten on drag end alone, so collapsing
    // returns to the spot the user chose.
    function applyPos() {
      if (dragging || snapping) return;            // the gesture owns the inline styles
      // While the sheet is open every resting surface is hidden and the root's
      // in-flow height is 0 — clamping now could park the pill off-screen, so
      // closeSheet() re-applies instead.
      if (root.classList.contains('sheet-open')) return;
      const pos = readPos();
      if (!pos) { clearInlinePos(); return; }
      root.style.bottom = clampBottom(pos.bottom, root.getBoundingClientRect().height) + 'px';
      if (pos.side === 'left') {
        root.style.left = sideInset('left') + 'px';
        root.style.right = 'auto';
      } else {
        root.style.right = sideInset('right') + 'px';
        root.style.left = 'auto';
      }
      root.classList.toggle('edge-left', pos.side === 'left');
    }

    // `left: <px>` → `left: auto` does not interpolate, so the glide always runs
    // in left coordinates; the right-anchored form (which keeps the dock hugging
    // the edge when the surface width changes) is installed once it lands.
    function snapTo(side, bottom, width) {
      snapping = true;
      root.classList.add('snapping');
      root.classList.toggle('edge-left', side === 'left');
      root.style.left = (side === 'left'
        ? sideInset('left')
        : Math.max(sideInset('left'), window.innerWidth - width - sideInset('right'))) + 'px';
      root.style.right = 'auto';
      root.style.bottom = bottom + 'px';

      const land = (event) => {
        if (event && event.target !== root) return;   // a row's own transition also bubbles here
        clearTimeout(landedTimer);
        root.removeEventListener('transitionend', land);
        root.classList.remove('snapping');
        snapping = false;
        applyPos();
      };
      const landedTimer = setTimeout(land, SNAP_LANDED_MS);   // reduced motion fires no transitionend
      root.addEventListener('transitionend', land);
    }

    function armClickSuppression() {
      suppressNextClick = true;
      if (suppressTimer) clearTimeout(suppressTimer);
      suppressTimer = setTimeout(disarmClickSuppression, CLICK_SUPPRESS_MS);
    }

    function disarmClickSuppression() {
      suppressNextClick = false;
      if (suppressTimer) { clearTimeout(suppressTimer); suppressTimer = null; }
    }

    // Other pointers (a second finger) must not steer or end someone else's gesture.
    function samePointer(event) {
      return event.pointerId == null || activePointerId == null || event.pointerId === activePointerId;
    }

    function endGesture() {
      if (surface) {
        surface.removeEventListener('lostpointercapture', onLostCapture);
        surface = null;
      }
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onCancel);
      activePointerId = null;
      dragging = false;
      root.classList.remove('dragging');
      document.documentElement.classList.remove('gd-dock-dragging');
    }

    function onMove(event) {
      if (!surface || !samePointer(event)) return;
      if (root.classList.contains('gone')) { onCancel(); return; }   // dismissed elsewhere mid-drag
      // A release we never saw (capture failed and the button came up outside the
      // window): the first move back in with the button up finishes the gesture
      // instead of leaving the dock glued to the cursor.
      if ((event.buttons & 1) === 0) {
        if (dragging) onUp(); else endGesture();
        return;
      }
      const dx = event.clientX - startX;
      const dy = event.clientY - startY;
      if (!dragging) {
        if (Math.hypot(dx, dy) < dragThreshold) return;              // still a plain click
        dragging = true;
        root.classList.add('dragging');
      }
      dragLeft = clamp(startRect.left + dx, VIEWPORT_GAP_PX,
        Math.max(VIEWPORT_GAP_PX, window.innerWidth - startRect.width - VIEWPORT_GAP_PX));
      dragBottom = clampBottom(window.innerHeight - startRect.bottom - dy, startRect.height);
      root.style.left = dragLeft + 'px';
      root.style.right = 'auto';
      root.style.bottom = dragBottom + 'px';
    }

    function onUp(event) {
      if (event && !samePointer(event)) return;
      const dragged = dragging;
      endGesture();
      if (!dragged) return;
      const side = (dragLeft + startRect.width / 2) < window.innerWidth / 2 ? 'left' : 'right';
      try { localStorage.setItem(LS.pos, JSON.stringify({ side, bottom: dragBottom })); } catch {}
      armClickSuppression();
      snapTo(side, dragBottom, startRect.width);
    }

    function onCancel(event) {
      if (event && !samePointer(event)) return;
      const dragged = dragging;
      endGesture();
      if (dragged) applyPos();                     // back to the stored corner, nothing persisted
    }

    // The browser can revoke capture mid-gesture (system gesture, focus steal);
    // mid-drag that is a release we will never see, so land it as a drop.
    function onLostCapture() {
      if (!surface) return;
      if (dragging) onUp(); else endGesture();
    }

    root.addEventListener('pointerdown', (event) => {
      disarmClickSuppression();
      if (surface || event.button !== 0) return;
      const target = event.target.closest('.dock-pill, .dock-bubble, .dock-head');
      if (!target || !root.contains(target)) return;
      // On mobile the head is the sheet's header — the sheet owns its own gestures.
      if (isMobile() && target.classList.contains('dock-head')) return;
      // The header's own buttons stay buttons; the .pill-mini chip is a sibling of
      // the pill, so it is outside this selector and never starts a drag.
      if (target.classList.contains('dock-head') && event.target.closest('[data-act]')) return;
      dragThreshold = (event.pointerType === 'touch' || event.pointerType === 'pen')
        ? TOUCH_DRAG_THRESHOLD_PX : DRAG_THRESHOLD_PX;
      surface = target;
      activePointerId = event.pointerId != null ? event.pointerId : null;
      dragging = false;
      startX = event.clientX;
      startY = event.clientY;
      startRect = root.getBoundingClientRect();
      try { surface.setPointerCapture(event.pointerId); } catch (_) {}
      // Armed on the press, not the threshold: browsers re-evaluate the cursor
      // lazily while a button is held, so the pinch must be in place from the
      // first millisecond of the hold to show reliably during the drag.
      document.documentElement.classList.add('gd-dock-dragging');
      surface.addEventListener('lostpointercapture', onLostCapture);
      // Window-level, so the gesture survives even when capture is unavailable
      // and the pointer leaves the surface (captured events bubble here too).
      window.addEventListener('pointermove', onMove);
      window.addEventListener('pointerup', onUp);
      window.addEventListener('pointercancel', onCancel);
    });

    // A gesture can also die without any pointer event reaching us: the window
    // loses focus mid-hold (Cmd-Tab, dropping onto another app) or Escape
    // abandons it. Both revert to the stored corner, persisting nothing.
    window.addEventListener('blur', () => { if (surface) onCancel(); });
    window.addEventListener('keydown', (event) => { if (event.key === 'Escape' && surface) onCancel(); });

    // Capture phase on window, so the click a drag leaves behind can never reach
    // the delegated handler (or the mobile sheet's root-capture one) and read as
    // an expand. Scoped to the dock so a click that never materializes cannot
    // eat an unrelated one elsewhere on the page.
    window.addEventListener('click', (event) => {
      if (!suppressNextClick) return;
      disarmClickSuppression();
      if (!root.contains(event.target)) return;
      event.preventDefault();
      event.stopPropagation();
    }, true);

    window.addEventListener('resize', () => {
      if (resizeFrame) return;
      resizeFrame = requestAnimationFrame(() => { resizeFrame = 0; applyPos(); });
    });

    // Crossing the breakpoint mid-gesture cancels it (the surface may swap or
    // vanish); either way the stored corner re-applies against the new geometry.
    const onBreakpointFlip = () => { if (surface) onCancel(); applyPos(); };
    if (mobileQuery.addEventListener) mobileQuery.addEventListener('change', onBreakpointFlip);
    else if (mobileQuery.addListener) mobileQuery.addListener(onBreakpointFlip);

    applyDockPosition = applyPos;
    Store.subscribe(applyPos);      // registered after render(), so it measures the post-render DOM
    applyPos();                     // same task as start() → in place before the first paint
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupDockDrag, { once: true });
  } else {
    setupDockDrag();
  }
})();
