(function() {
  // Load CSP-compliant event delegation handlers (once)
  if (!window.__CSP_HANDLERS_LOADED__) {
    window.__CSP_HANDLERS_LOADED__ = true;
    import(/* @vite-ignore */ '/marketplace/js/csp-event-handlers.js').catch(function(){});
  }

  const NAVBAR_VERSION = 'navbar-v5';
  if (window.__AITOPIA_NAVBAR__ === NAVBAR_VERSION) return;
  window.__AITOPIA_NAVBAR__ = NAVBAR_VERSION;

  const getCache = () => window.AitopiaCache;
  const getUserProfile = () => getCache()?.getUserProfile?.() ?? null;
  const setUserProfile = (data) => getCache()?.setUserProfile?.(data);
  const getUserCredits = () => getCache()?.getUserCredits?.() ?? null;
  const setUserCredits = (credits) => getCache()?.setUserCredits?.(credits);
  const clearUserCache = () => getCache()?.clearUserData?.();

  let notificationsPoller = null;
  let notificationsModal = null;
  let developerStatusPromise = null;
  let queuePoller = null;
  let activeQueueItems = [];
  let lastUnreadCount = -1;

  // ---------------------------------------------------------------------------
  // Job toast notifications
  // ---------------------------------------------------------------------------
  function showJobToast(message, variant, url) {
    const id = 'jobToast-' + Date.now();
    const isSuccess = variant === 'success';
    const borderColor = 'border-[#1C1E20]';
    const iconColor = isSuccess ? 'text-green-500' : 'text-red-500';
    const iconPath = isSuccess
      ? '<path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>'
      : '<path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>';

    const toast = document.createElement('div');
    toast.id = id;
    toast.className = `fixed top-4 right-4 z-[9999] flex items-center gap-3 px-4 py-3 rounded-xl border ${borderColor} bg-card shadow-lg transition-all duration-300 translate-x-full opacity-0`;
    toast.style.maxWidth = '360px';
    toast.innerHTML = `
      <svg width="20" height="20" class="w-5 h-5 flex-shrink-0 ${iconColor}" fill="none" stroke="currentColor" viewBox="0 0 24 24">${iconPath}</svg>
      <span class="text-sm font-medium text-foreground flex-1">${escapeHtml(message)}</span>
      <button type="button" class="ml-1 p-0.5 rounded hover:bg-secondary transition-colors" aria-label="Close">
        <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
      </button>
    `;
    if (url) toast.style.cursor = 'pointer';
    document.body.appendChild(toast);

    // Animate in
    requestAnimationFrame(() => {
      toast.classList.remove('translate-x-full', 'opacity-0');
      toast.classList.add('translate-x-0', 'opacity-100');
    });

    const dismiss = () => {
      toast.classList.add('translate-x-full', 'opacity-0');
      setTimeout(() => toast.remove(), 300);
    };

    toast.querySelector('button')?.addEventListener('click', (e) => { e.stopPropagation(); dismiss(); });
    if (url) toast.addEventListener('click', () => { dismiss(); window.location.href = url; });

    setTimeout(dismiss, 5000);
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function formatRelativeTime(value) {
    const date = value ? new Date(value) : null;
    if (!date || Number.isNaN(date.getTime())) return '';

    const now = Date.now();
    const diffMs = now - date.getTime();
    const minutes = Math.floor(diffMs / 60000);
    const hours = Math.floor(diffMs / 3600000);
    const days = Math.floor(diffMs / 86400000);

    if (minutes < 1) return 'just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 30) return `${days}d ago`;
    return date.toLocaleDateString();
  }

  function setNotificationsBadge(count) {
    const n = Math.max(0, Math.trunc(Number(count) || 0));
    const label = n > 99 ? '99+' : String(n);

    // Desktop badge
    const btn = document.getElementById('notificationsBtn');
    const badge = document.getElementById('notificationsBadge');
    if (btn instanceof HTMLElement && badge instanceof HTMLElement) {
      badge.textContent = label;
      badge.classList.toggle('hidden', n === 0);
    }

    // Mobile badge
    const mBadge = document.getElementById('mobileNotificationsBadge');
    if (mBadge instanceof HTMLElement) {
      mBadge.textContent = label;
      mBadge.classList.toggle('hidden', n === 0);
    }
  }

  async function loadUnreadNotificationsCount() {
    try {
      const res = await fetch('https://aitopia.ai/api/notifications/unread-count', { method: 'GET', credentials: 'include', headers: { Accept: 'application/json' } });
      if (!res.ok) {
        setNotificationsBadge(0);
        return;
      }
      const json = await res.json().catch(() => null);
      const count = json?.count ?? 0;
      setNotificationsBadge(count);

      // When unread count changes and we have active jobs — fetch queue once
      if (lastUnreadCount >= 0 && count !== lastUnreadCount && queuePoller) {
        tickQueue();
      }
      lastUnreadCount = count;
    } catch {
      // ignore
    }
  }

function setUrlCookie() {
  const currentPath = window.location.pathname;
  const unListingPages = ["pricing", "login", "register"];
  let checkPage = true;
  unListingPages.forEach((item) => {
    if (currentPath.indexOf(`/${item}`) !== -1) {
      checkPage = false;
    }
  });

  const cookieValue = checkPage ? window.location.href : window.location.origin;

  const expires = new Date(Date.now() + 3600000).toUTCString(); // 1 hour
  document.cookie = `aitopia_last_url=${encodeURIComponent(cookieValue)}; expires=${expires}; path=/; Secure; SameSite=None; Domain=.${window.location.hostname}`;
}

  const NOTIF_POLL_NORMAL = 10000;  // 30s — idle
  const NOTIF_POLL_FAST   = 1000;   // 1s  — while jobs are active
  let currentNotifInterval = NOTIF_POLL_NORMAL;

  function notifTick() {
    if (document.hidden) return;
    void loadUnreadNotificationsCount();
  }

  function startNotificationsPolling() {
    if (notificationsPoller) return;
    currentNotifInterval = NOTIF_POLL_NORMAL;
    notificationsPoller = window.setInterval(notifTick, currentNotifInterval);
  }

  function setNotificationsPollingSpeed(fast) {
    const desired = fast ? NOTIF_POLL_FAST : NOTIF_POLL_NORMAL;
    if (desired === currentNotifInterval || !notificationsPoller) return;
    window.clearInterval(notificationsPoller);
    currentNotifInterval = desired;
    notificationsPoller = window.setInterval(notifTick, currentNotifInterval);
  }

  function stopNotificationsPolling() {
    if (notificationsPoller) {
      window.clearInterval(notificationsPoller);
      notificationsPoller = null;
    }
    setNotificationsBadge(0);
  }

  async function tickQueue() {
    if (document.hidden) return;
    try {
      const res = await fetch('https://aitopia.ai/api/queue?limit=20', {
        method: 'GET',
        credentials: 'include',
        headers: { Accept: 'application/json' }
      });
      if (!res.ok) return;
      const json = await res.json();
      const items = Array.isArray(json?.items) ? json.items : [];

      const prevActiveIds = new Set(activeQueueItems.filter(i => i.status === 'pending' || i.status === 'processing').map(i => i.id));
      const newlyCompleted = items.filter(i =>
        (i.status === 'completed' || i.status === 'failed' || i.status === 'dead') &&
        prevActiveIds.has(i.id)
      );

      activeQueueItems = items;

      for (const item of newlyCompleted) {
        const agentLabel = item.agentId || 'Job';
        const shortId = (item.refId || item.id || '').slice(0, 8);
        const label = shortId ? `${agentLabel} #${shortId}` : agentLabel;
        if (item.status === 'completed') {
          const url = item.agentId ? `/marketplace/agent/${encodeURIComponent(item.agentId)}?jobId=${encodeURIComponent(item.refId || item.id)}` : null;
          showJobToast(`${label} completed successfully`, 'success', url);
        } else {
          showJobToast(`${label} failed`, 'error', null);
        }
      }

      if (newlyCompleted.length > 0) {
        await loadUnreadNotificationsCount();
      }

      const hasActive = items.some(i => i.status === 'pending' || i.status === 'processing');
      if (!hasActive) {
        stopQueuePolling();
      }
    } catch {
      // ignore network errors
    }
  }

  // Called when a job is submitted — does a single initial queue fetch,
  // marks that we have active jobs. Subsequent updates come from
  // unread-count changes detected in the fast notifications polling (3s).
  function startQueuePolling() {
    queuePoller = true;
    setNotificationsPollingSpeed(true);
    void tickQueue();
  }

  function stopQueuePolling() {
    queuePoller = null;
    setNotificationsPollingSpeed(false);
  }

  async function fetchIsDeveloper(forceRefresh = false) {
    if (!forceRefresh && developerStatusPromise) return developerStatusPromise;
    developerStatusPromise = (async () => {
      try {
        const res = await fetch('https://aitopia.ai/api/developers/me?soft=1', {
          method: 'GET',
          credentials: 'include',
          headers: { Accept: 'application/json' },
        });
        return res.ok;
      } catch {
        return false;
      }
    })();
    return developerStatusPromise;
  }

  function getNotificationIcon(type) {
    const base = 'inline-flex items-center justify-center w-7 h-7 rounded-lg flex-shrink-0';
    switch (type) {
      case 'job_completed':
        return `<span class="${base} bg-green-500/10 text-green-500"><svg width="14" height="14" class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path d="M5 13l4 4L19 7"/></svg></span>`;
      case 'job_failed':
      case 'job_dead':
        return `<span class="${base} bg-red-500/10 text-red-500"><svg width="14" height="14" class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path d="M6 18L18 6M6 6l12 12"/></svg></span>`;
      case 'remix':
        return `<span class="${base} bg-primary/10 text-primary/90"><svg width="14" height="14" class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg></span>`;
      case 'follow':
        return `<span class="${base} bg-blue-500/10 text-blue-500"><svg width="14" height="14" class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="8.5" cy="7" r="4"/><path d="M20 8v6M23 11h-6"/></svg></span>`;
      case 'like_milestone':
        return `<span class="${base} bg-pink-500/10 text-pink-500"><svg width="14" height="14" class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg></span>`;
      case 'comment':
        return `<span class="${base} bg-yellow-500/10 text-yellow-500"><svg width="14" height="14" class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg></span>`;
      default:
        return `<span class="${base} bg-panel-input text-muted-foreground"><span class="w-1.5 h-1.5 rounded-full bg-current"></span></span>`;
    }
  }

  // ---------------------------------------------------------------------------
  // Active queue items (progress rendering)
  // ---------------------------------------------------------------------------
  function renderActiveQueueItem(item) {
    const agent = escapeHtml(item.agentId || 'Job');
    const pct = Math.min(100, Math.max(0, Math.round(Number(item.progress) || 0)));
    const statusLabel = item.status === 'pending' ? 'Queued' : 'Processing';
    const barColor = item.status === 'pending' ? 'bg-yellow-500' : 'bg-primary/90';

    return `
      <div class="flex items-center gap-2.5 rounded-xl bg-primary/90/[0.04] dark:bg-primary/90/[0.06] border border-primary/10 px-3 py-2.5" data-queue-id="${escapeHtml(item.id)}">
        <span class="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-primary/10 text-primary/90 flex-shrink-0">
          <svg width="14" height="14" class="w-3.5 h-3.5 animate-spin" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="3" class="opacity-25"/><path fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" class="opacity-75"/></svg>
        </span>
        <div class="min-w-0 flex-1">
          <div class="flex items-center justify-between gap-2">
            <span class="text-[12px] font-medium text-foreground truncate">${agent}</span>
            <span class="text-[11px] text-muted-foreground flex-shrink-0">${statusLabel} · ${pct}%</span>
          </div>
          <div class="mt-1.5 w-full bg-panel-input rounded-full h-1 overflow-hidden">
            <div class="${barColor} h-full rounded-full transition-all duration-500" style="width:${pct}%"></div>
          </div>
        </div>
      </div>
    `;
  }

  let activeQueuePoller = null;

  function startActiveQueuePolling() {
    if (activeQueuePoller) return;
    const tick = async () => {
      if (!notificationsModal || notificationsModal.classList.contains('hidden')) {
        stopActiveQueuePolling();
        return;
      }
      try {
        const res = await fetch('https://aitopia.ai/api/queue?limit=20&status=pending,processing', {
          method: 'GET', credentials: 'include', headers: { Accept: 'application/json' },
        });
        if (!res.ok) return;
        const json = await res.json();
        const items = Array.isArray(json?.items) ? json.items : [];
        const container = notificationsModal.querySelector('[data-notif-active]');
        if (!container) return;

        if (items.length === 0) {
          container.innerHTML = '';
          stopActiveQueuePolling();
          return;
        }
        container.innerHTML = items.map(renderActiveQueueItem).join('');
      } catch { /* ignore */ }
    };
    activeQueuePoller = window.setInterval(tick, 2000);
    void tick();
  }

  function stopActiveQueuePolling() {
    if (activeQueuePoller) {
      window.clearInterval(activeQueuePoller);
      activeQueuePoller = null;
    }
  }

  function renderNotificationItem(n) {
    const icon = getNotificationIcon(n.type);
    const msg = escapeHtml(n?.message || 'Notification');
    const when = escapeHtml(formatRelativeTime(n?.createdAt || ''));
    const url = typeof n?.url === 'string' && n.url ? String(n.url) : '';
    const tag = url ? 'a' : 'div';
    const hrefAttr = url ? ` href="${escapeHtml(url)}"` : '';
    const unreadDot = !n.isRead ? '<span class="absolute top-1/2 -translate-y-1/2 right-2 w-1.5 h-1.5 rounded-full bg-primary/90"></span>' : '';

    // Job notification badges (agentId + short jobId + credits)
    const isJobNotif = n.type === 'job_completed' || n.type === 'job_failed' || n.type === 'job_dead';
    const meta = isJobNotif && n.metadata && typeof n.metadata === 'object' ? n.metadata : null;
    const agentBadge = "";//meta?.agentId ? `<span class="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-medium bg-primary/10 text-primary/90">${escapeHtml(meta.agentId)}</span>` : '';
    const jobIdBadge = "";//meta?.jobId ? `<span class="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-mono bg-secondary text-muted-foreground">#${escapeHtml(String(meta.jobId).slice(0, 8))}</span>` : '';
    const creditCount = typeof n.credits === 'number' ? n.credits : (typeof meta?.credits === 'number' ? meta.credits : 0);
    const creditsBadge = "";//creditCount > 0 ? `<span class="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-mono bg-secondary text-muted-foreground">${creditCount} credit${creditCount !== 1 ? 's' : ''}</span>` : '';
    const badgesHtml = (agentBadge || jobIdBadge || creditsBadge) ? `<div class="flex items-center gap-1.5 mt-1">${agentBadge}${jobIdBadge}${creditsBadge}</div>` : '';

    return `
      <${tag}${hrefAttr} class="relative flex items-start gap-2.5 rounded-xl px-3 py-2.5 hover:bg-[#E9EEF7] dark:hover:bg-[#1C1E20] transition-colors cursor-pointer group">
        ${unreadDot}
        ${icon}
        <div class="min-w-0 flex-1 pt-0.5">
          <p class="text-[12px] text-foreground leading-[1.4] ${n.isRead ? 'font-normal text-muted-foreground' : 'font-medium'}">${msg}</p>
          ${badgesHtml}
          <span class="text-[11px] text-muted-foreground/70 mt-0.5 block">${when}</span>
        </div>
      </${tag}>
    `;
  }

  let notifNextCursor = null;
  let notifIsLoading = false;

  async function loadNotifications(append = false) {
    if (notifIsLoading) return;
    notifIsLoading = true;

    const overlay = ensureNotificationsModal();
    const listEl = overlay.querySelector('[data-notif-list]');
    const emptyEl = overlay.querySelector('[data-notif-empty]');
    const loadMoreBtn = overlay.querySelector('[data-notif-load-more]');

    if (!append) {
      if (listEl) listEl.innerHTML = '<div class="text-sm text-muted-foreground">Loading…</div>';
      if (emptyEl) emptyEl.classList.add('hidden');
      notifNextCursor = null;
    }

    try {
      let url = 'https://aitopia.ai/api/notifications?limit=20';
      if (append && notifNextCursor) {
        url += '&cursor=' + encodeURIComponent(notifNextCursor);
      }

      const res = await fetch(url, {
        method: 'GET', credentials: 'include',
        headers: { Accept: 'application/json' }
      });
      if (!res.ok) throw new Error('fetch failed');

      const json = await res.json().catch(() => null);
      const items = Array.isArray(json?.notifications) ? json.notifications : [];
      notifNextCursor = json?.nextCursor || null;

      if (!append && items.length === 0) {
        if (listEl) listEl.innerHTML = '';
        if (emptyEl) emptyEl.classList.remove('hidden');
      } else {
        const html = items.map((n) => renderNotificationItem(n)).join('');
        if (append) {
          if (listEl) listEl.insertAdjacentHTML('beforeend', html);
        } else {
          if (listEl) listEl.innerHTML = html;
          if (emptyEl) emptyEl.classList.add('hidden');
        }
      }

      if (loadMoreBtn) {
        loadMoreBtn.classList.toggle('hidden', !notifNextCursor);
      }
      const footer = overlay.querySelector('[data-notif-footer]');
      if (footer) {
        footer.classList.toggle('hidden', !notifNextCursor);
      }
    } catch {
      if (!append && listEl) {
        listEl.innerHTML = '<div class="text-sm text-red-500">Failed to load notifications.</div>';
      }
    } finally {
      notifIsLoading = false;
    }
  }

  function closeNotificationsModal() {
    if (!notificationsModal) return;
    notificationsModal.classList.add('hidden');
    stopActiveQueuePolling();
  }

  function ensureNotificationsModal() {
    if (notificationsModal) return notificationsModal;

    const overlay = document.createElement('div');
    overlay.id = 'aitopiaNotificationsModal';
    overlay.className = 'hidden fixed inset-0 z-50';
    overlay.innerHTML = `
      <div class="fixed inset-0 bg-black/20" data-notif-backdrop></div>
      <div class="fixed top-14 right-3 sm:right-6 w-[calc(100vw-24px)] sm:w-[360px] max-h-[min(70vh,520px)] rounded-2xl border border-panel-border bg-white dark:bg-[#0F0F0F] shadow-2xl flex flex-col overflow-hidden">
        <div class="flex items-center justify-between px-4 py-3 border-b border-[#D9D9D9]/15 dark:border-[#D9D9D9]/[4%]">
          <span class="text-[13px] font-semibold text-foreground">Notifications</span>
          <button type="button" data-notif-close class="h-7 w-7 inline-flex items-center justify-center rounded-lg hover:bg-[#E9EEF7] dark:hover:bg-[#1C1E20] text-muted-foreground transition-colors">
            <svg width="14" height="14" class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="flex-1 overflow-y-auto px-2 py-1.5 min-h-0 space-y-0.5" style="scrollbar-width: thin;">
          <div class="space-y-0.5" data-notif-active></div>
          <div data-notif-list></div>
          <div class="py-10 text-center hidden" data-notif-empty>
            <svg width="32" height="32" class="w-8 h-8 mx-auto mb-2 text-muted-foreground/30" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0"/></svg>
            <p class="text-[12px] text-muted-foreground/60">No notifications yet</p>
          </div>
        </div>
        <div class="px-2 py-1.5 border-t border-[#D9D9D9]/15 dark:border-[#D9D9D9]/[4%] hidden" data-notif-footer>
          <button type="button" data-notif-load-more class="hidden w-full py-1.5 text-[11px] font-medium text-muted-foreground hover:text-foreground hover:bg-[#E9EEF7] dark:hover:bg-[#1C1E20] transition-colors rounded-lg">Load more</button>
        </div>
      </div>
    `;

    overlay.querySelector('[data-notif-backdrop]')?.addEventListener('click', closeNotificationsModal);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeNotificationsModal();
    });

    overlay.querySelector('[data-notif-close]')?.addEventListener('click', closeNotificationsModal);
    overlay.querySelector('[data-notif-load-more]')?.addEventListener('click', () => void loadNotifications(true));

    document.body.appendChild(overlay);
    notificationsModal = overlay;
    return overlay;
  }

  async function openNotificationsModal() {
    const overlay = ensureNotificationsModal();
    overlay.classList.remove('hidden');
    startActiveQueuePolling();
    await loadNotifications(false);

    await fetch('https://aitopia.ai/api/notifications/read', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({}),
    }).catch(() => {});
    await loadUnreadNotificationsCount();
  }

  function getHeaderSearchContext() {
    const pathname = String(window.location?.pathname || '').toLowerCase();
    const inModels = pathname.startsWith('/marketplace/models.html') || pathname.startsWith('/model/');
    const inAgents = pathname.startsWith('/marketplace/agents.html') || pathname.startsWith('/agent/');

    if (inModels) {
      return {
        targetPath: '/marketplace/models.html',
        queryParam: 'search',
        linkedInputId: 'search-input',
        sectionOrder: ['models', 'agents', 'categories'],
      };
    }

    if (inAgents) {
      return {
        targetPath: '/marketplace/agents.html',
        queryParam: 'q',
        linkedInputId: 'searchInput',
        sectionOrder: ['agents', 'models', 'categories'],
      };
    }

    return { targetPath: '/marketplace/search.html', queryParam: 'q', linkedInputId: null };
  }

  function autoBindNavbarAutocomplete() {
    const ctx = getHeaderSearchContext();
    if (!ctx || !ctx.sectionOrder) return;
    import('/marketplace/js/search/navbar-autocomplete.js')
      .then((mod) => {
        mod.bindNavbarAutocomplete({
          sectionOrder: ctx.sectionOrder,
          fallbackUrl: ctx.targetPath,
          fallbackParam: ctx.queryParam,
        });
      })
      .catch((error) => {
        console.warn('[navbar] failed to load autocomplete', error);
      });
  }

  function bindHeaderSearch() {
    const form = document.getElementById('navbarHeaderSearchForm');
    const input = document.getElementById('navbarHeaderSearchInput') || document.getElementById('searchInput');
    if (!(form instanceof HTMLFormElement) || !(input instanceof HTMLInputElement)) return;

    const { targetPath, queryParam, linkedInputId } = getHeaderSearchContext();
    const linkedEl = linkedInputId ? document.getElementById(linkedInputId) : null;
    const linkedSearchInput = linkedEl instanceof HTMLInputElement ? linkedEl : null;

    const params = new URLSearchParams(window.location.search);
    const queryFromUrl = params.get(queryParam) || params.get('q') || params.get('search') || '';

    if (linkedSearchInput?.value) {
      input.value = linkedSearchInput.value;
    } else if (queryFromUrl) {
      input.value = queryFromUrl;
    }

    let syncing = false;
    let dispatchTimer = null;

    const fireLinkedEvent = () => {
      syncing = true;
      try { linkedSearchInput.dispatchEvent(new Event('input', { bubbles: true })); }
      finally { syncing = false; }
    };

    const syncToLinkedInput = (immediate) => {
      if (!linkedSearchInput || syncing) return false;
      syncing = true;
      try {
        const changed = linkedSearchInput.value !== input.value;
        if (changed) linkedSearchInput.value = input.value;
        if (dispatchTimer) clearTimeout(dispatchTimer);
        if (immediate) {
          fireLinkedEvent();
        } else if (changed) {
          dispatchTimer = setTimeout(fireLinkedEvent, 500);
        }
        return true;
      } finally {
        syncing = false;
      }
    };

    if (linkedSearchInput) {
      linkedSearchInput.addEventListener('input', () => {
        if (syncing) return;
        if (input.value !== linkedSearchInput.value) input.value = linkedSearchInput.value;
      });
      if (input.value) syncToLinkedInput(true);
    }

    let clearQueryTimer = null;
    input.addEventListener('input', () => {
      if (clearQueryTimer) { clearTimeout(clearQueryTimer); clearQueryTimer = null; }

      if (syncToLinkedInput(false)) return;

      if (input.value.trim() !== '') return;
      const url = new URL(window.location.href);
      const hadQuery = url.searchParams.has(queryParam) || url.searchParams.has('q') || url.searchParams.has('search');
      if (!hadQuery) return;
      clearQueryTimer = setTimeout(() => {
        url.searchParams.delete(queryParam);
        url.searchParams.delete('q');
        url.searchParams.delete('search');
        window.location.assign(`${url.pathname}${url.search}`);
      }, 300);
    });

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      if (syncToLinkedInput(true)) return;

      const query = input.value.trim();
      const url = new URL(targetPath, window.location.origin);
      if (query) url.searchParams.set(queryParam, query);
      window.location.assign(`${url.pathname}${url.search}`);
    });
  }

  // Navbar HTML template
  function getNavbarHTML() {
    const container = document.getElementById('navbar-container');
    const isHome = container && container.getAttribute('data-navbar-context') === 'home';
    const searchInputId = isHome ? 'searchInput' : 'navbarHeaderSearchInput';
    const searchWrapClass =
      'navbar-search flex flex-1 justify-center min-w-0 ml-6 sm:ml-10 md:ml-14 lg:ml-20 mr-2 sm:mr-10 lg:mr-16';
    const searchFormClass = 'relative w-full min-w-0 max-w-[280px] sm:max-w-[320px] md:max-w-[360px]';
    const autocompleteHtml = '<div id="searchAutocompleteHeader" class="hidden absolute top-full left-0 right-0 mt-2 z-50 bg-card border border-border rounded-ios-xl shadow-2xl max-h-[420px] overflow-y-auto"></div>';

    return `
	  <header id="header" class="sticky top-0 z-50 w-full glass border-b border-border/40 safe-top transition-all duration-300">
    <div id="promo-announcement-bar" class="w-full overflow-hidden text-center bg-[var(--promo-bar-bg)] py-2 px-4" style="display:none;">
      <div class="relative flex items-center justify-center">
        <!-- Single marquee track — entire row scrolls together when it overflows -->
        <div id="promo-bar-inner" class="inline-flex items-center gap-2.5 whitespace-nowrap">
          <span class="inline-flex items-center gap-1.5 shrink-0 whitespace-nowrap rounded-full py-1 px-3 text-sm font-medium text-white bg-[var(--promo-bar-badge-bg)]">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="shrink-0"><path d="M12.9897 13.3478C12.7166 10.945 11.62 9.94907 10.8191 9.22282C10.2653 8.71876 9.99909 8.45657 9.99909 8.00001C9.99909 7.54969 10.2644 7.29251 10.8166 6.79876C11.6269 6.07469 12.7366 5.08282 12.9903 2.64751C13.0106 2.44291 12.9877 2.23633 12.9231 2.04114C12.8585 1.84594 12.7537 1.66649 12.6153 1.51438C12.4676 1.35192 12.2875 1.22221 12.0865 1.13361C11.8856 1.04502 11.6684 0.999505 11.4488 1.00001H4.5494C4.32951 0.999321 4.11191 1.04474 3.91066 1.13334C3.7094 1.22194 3.52896 1.35174 3.38096 1.51438C3.24304 1.6667 3.13858 1.84623 3.07431 2.0414C3.01005 2.23657 2.9874 2.44305 3.00784 2.64751C3.26065 5.07501 4.36628 6.05969 5.17346 6.77844C5.73096 7.27501 5.99909 7.53407 5.99909 8.00001C5.99909 8.47188 5.73034 8.73626 5.17096 9.24219C4.37409 9.96407 3.28034 10.9525 3.00846 13.3478C2.98641 13.5515 3.00757 13.7575 3.07058 13.9525C3.13358 14.1474 3.237 14.3268 3.37409 14.4791C3.52239 14.6436 3.70371 14.775 3.90622 14.8648C4.10873 14.9546 4.32789 15.0006 4.5494 15H11.4488C11.6703 15.0006 11.8894 14.9546 12.092 14.8648C12.2945 14.775 12.4758 14.6436 12.6241 14.4791C12.7612 14.3268 12.8646 14.1474 12.9276 13.9525C12.9906 13.7575 13.0118 13.5515 12.9897 13.3478ZM10.7272 13.5H5.2844C4.7969 13.5 4.6594 12.9375 5.00128 12.5888C5.82878 11.75 7.49909 11.1494 7.49909 10.1875V7.00001C7.49909 6.37969 6.31159 5.90626 5.5769 4.90001C5.45565 4.73407 5.46784 4.50001 5.77596 4.50001H10.2363C10.4991 4.50001 10.5557 4.73219 10.4363 4.89844C9.71221 5.90626 8.49909 6.37657 8.49909 7.00001V10.1875C8.49909 11.1416 10.24 11.6563 11.0116 12.5897C11.3225 12.9659 11.2138 13.5 10.7272 13.5Z" fill="#FFFFFF"/></svg>
            Discount Expires in <strong id="promo-bar-timer" class="text-sm font-bold tracking-[0.02em]">--h --m --s</strong>
          </span>
          <span id="promo-bar-text" class="text-[var(--promo-bar-text)] text-sm"></span>
          <a id="promo-bar-cta" href="/marketplace/pricing.html" class="text-[var(--promo-bar-text)] text-sm font-bold underline underline-offset-2 whitespace-nowrap"></a>
        </div>
        <!-- Close button -->
        <button id="promo-bar-close" data-action="dismissPromoBar" aria-label="Close" style="position:absolute;right:0;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;padding:4px;display:flex;align-items:center;opacity:0.6;" class="hover-fade">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>
      </div>
    </div>
	    <div class="max-w-[1600px] mx-auto px-3 sm:px-4 lg:px-6">
	      <div class="flex h-16 items-center">
	        <!-- Logo Section -->
	        <div class="flex shrink-0 items-center gap-2">
          <!-- Logo -->
	          <a href="/marketplace/" class="flex items-center">
            <img src="/marketplace/Logo.svg" alt="AITOPIA" width="36" height="36" class="h-9 w-9 sm:hidden" />
            <img src="/marketplace/Logo_all.svg" alt="AITOPIA" height="36" class="hidden sm:block h-9 w-auto" />
          </a>
        </div>

        <!-- Header search -->
        <div class="${searchWrapClass}">
          <form id="navbarHeaderSearchForm" class="${searchFormClass}">
            <label class="relative block min-w-0">
              <svg width="20" height="20" class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0"/>
              </svg>
              <input id="${searchInputId}" type="search" placeholder="Search..."
                class="w-full min-w-0 h-10 pl-10 pr-4 rounded-full bg-[#F2F5F9]/80 dark:bg-[#262626]/80 border-0 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all">
              ${autocompleteHtml}
            </label>
          </form>
        </div>

        <!-- Right side -->
        <div class="ml-auto flex shrink-0 items-center gap-1">
          <div class="hidden xl:flex items-center gap-1">
          <a href="/marketplace/agents.html" class="h-10 px-4 flex items-center justify-center gap-2 rounded-full hover:bg-secondary text-[14px] font-medium leading-5 transition-colors">
            <img src="https://aitopia.ai/icons/agents.svg" alt="" width="20" height="20" class="w-5 h-5 dark:invert" />
            Agents
          </a>
          <a href="/marketplace/models.html" class="h-10 px-4 flex items-center justify-center gap-2 rounded-full hover:bg-secondary text-[14px] font-medium leading-5 transition-colors">
            <img src="https://aitopia.ai/icons/models.svg" alt="" width="20" height="20" class="w-5 h-5 dark:invert" />
            Models
          </a>
          <a href="/marketplace/outputs.html" class="h-10 px-4 flex items-center justify-center gap-2 rounded-full hover:bg-secondary text-[14px] font-medium leading-5 transition-colors">
            <img src="https://aitopia.ai/icons/community.svg" alt="" width="20" height="20" class="w-5 h-5 dark:invert" />
            Community
          </a>
          <a href="/marketplace/pricing.html" id="nav-pricing-link" class="h-10 px-4 flex items-center justify-center gap-2 rounded-full hover:bg-secondary text-[14px] font-medium leading-5 transition-colors">
            <img src="https://aitopia.ai/icons/pricing.svg" alt="" width="20" height="20" class="w-5 h-5 dark:invert" />
            Pricing
          </a>
          </div>

          <div class="hidden lg:flex items-center justify-end gap-0.5 w-[130px] flex-shrink-0 ml-4">
            <!-- Credits Display -->
            <div id="creditsDisplay" class="hidden items-center gap-0.5 px-2 py-1.5 bg-primary/10 rounded-full w-[80px] flex-shrink-0 opacity-0 pointer-events-none">
              <svg width="16" height="16" class="w-4 h-4 text-primary/90 dark:text-primary flex-shrink-0" fill="currentColor" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
                <path d="M4.48963 7.68204H5.79855V11.5184C5.79855 12.0831 6.3577 12.3496 6.65422 11.9233L9.86088 7.34104C10.1405 6.94142 9.91595 6.31802 9.49235 6.31802H8.18342V2.48171C8.18342 1.91692 7.62426 1.65051 7.32774 2.07676L4.1211 6.65903C3.84576 7.05864 4.07026 7.68204 4.48963 7.68204Z"/>
              </svg>
              <span id="creditsAmount" class="text-sm font-semibold text-primary/90 dark:text-primary relative flex-1 text-right min-w-0">
                <span class="credits-shimmer inline-block">—</span>
              </span>
            </div>

            <!-- Login Button (shown when not logged in) -->
            <a href="/marketplace/login.html" id="loginBtn" class="hidden h-9 px-4 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-medium transition-colors hover:bg-primary/90">
              Sign in
            </a>

            <!-- Profile Dropdown (shown when logged in) -->
            <div class="relative hidden" id="profileDropdown">
            <button data-action="NavbarComponent.toggleProfileDropdown" class="flex items-center gap-2 h-10 px-3 rounded-full transition-colors btn-press cursor-pointer" aria-label="Profile menu">
              <div class="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <svg width="16" height="16" class="w-4 h-4 text-primary/90 dark:text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                  <circle cx="12" cy="7" r="4"/>
                </svg>
              </div>
            </button>
            <div id="profileMenu" class="hidden absolute right-0 top-full mt-2 w-56 bg-card border border-border rounded-xl shadow-xl z-50 py-1 overflow-hidden">
              <!-- User info header -->
              <div id="profileHeader" class="px-4 py-3 border-b border-border">
                <div class="flex items-center justify-between gap-2">
                  <p id="profileName" class="text-sm font-medium truncate"></p>
                  <span id="profilePlanBadge" class="px-2 py-0.5 text-[10px] font-semibold uppercase rounded-full bg-primary/5 text-primary"></span>
                </div>
                <p id="profileEmailFull" class="text-xs text-muted-foreground truncate mt-0.5"></p>
                <a id="profileUpgradeBtn" href="/marketplace/pricing.html" class="mt-2 w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-gradient-to-r from-primary to-primary/70 text-primary-foreground hover:opacity-90 transition-opacity">
                  <svg width="14" height="14" class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path d="M13 10V3L4 14h7v7l9-11h-7z"/>
                  </svg>
                  Upgrade
                </a>
              </div>
              <a id="profileLink" href="/marketplace/settings-profile.html" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                  <circle cx="12" cy="7" r="4"/>
                </svg>
                Profile
              </a>
              <a href="/marketplace/outputs.html" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
                Creations
              </a>
              <!--
              <a href="/marketplace/create.html" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M12 4v16m8-8H4"/>
                </svg>
                Create
              </a>
              <a href="/marketplace/feed.html" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2"/>
                </svg>
                Feed
              </a>
              <a href="/marketplace/discover.html" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <circle cx="12" cy="12" r="10"/>
                  <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>
                </svg>
                Discover
              </a>
              -->
              <a href="/marketplace/earnings.html" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <line x1="12" y1="1" x2="12" y2="23"/>
                  <path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/>
                </svg>
                Earnings
              </a>
              <a id="profileDeveloperLink" href="/marketplace/developers-dashboard.html" class="hidden items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <rect x="3" y="3" width="7" height="7" rx="1"/>
                  <rect x="14" y="3" width="7" height="7" rx="1"/>
                  <rect x="3" y="14" width="7" height="7" rx="1"/>
                  <rect x="14" y="14" width="7" height="7" rx="1"/>
                </svg>
                Developer Dashboard
              </a>
              <!--
              <a href="https://chat.aitopia.ai/app/profile" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                  <circle cx="12" cy="7" r="4"/>
                </svg>
                My Account
              </a>
              <a href="https://chat.aitopia.ai/subscription" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
                  <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
                  <line x1="12" y1="22.08" x2="12" y2="12"/>
                </svg>
                My Plan
              </a>
              <a href="https://chat.aitopia.ai/src/html/options.html?mode=contact" class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
                Feedback
              </a>
              -->
              <div class="border-t border-border my-1"></div>
              <button data-action="NavbarComponent.handleLogout" class="w-full flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors text-red-500 cursor-pointer">
                <svg width="16" height="16" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                  <polyline points="16 17 21 12 16 7"/>
                  <line x1="21" y1="12" x2="9" y2="12"/>
                </svg>
                Logout
              </button>
            </div>
          </div>
          </div>

          <!-- Mobile Pricing button -->
          <div id="mobile-pricing-btn-wrap" class="lg:hidden relative">
            <a href="/marketplace/pricing.html" class="h-10 px-4 flex items-center justify-center rounded-full border border-border text-sm font-medium whitespace-nowrap hover:bg-secondary transition-colors">
              Pricing
            </a>
            <span id="mobile-pricing-badge" style="display:none;position:absolute;bottom:0;left:50%;transform:translate(-50%,50%);font-size:10px;font-weight:700;color:var(--promo-nav-badge-text);background:var(--promo-nav-badge-bg);border-radius:100px;padding:1px 7px;white-space:nowrap;letter-spacing:0.03em;pointer-events:none;z-index:10;"></span>
          </div>
          <!-- Mobile notifications (always in DOM — avoids race condition with global-nav.js) -->
          <button id="mobileNotificationsBtn" type="button" class="hidden relative h-10 w-10 items-center justify-center rounded-full hover:bg-secondary transition-colors btn-press lg:hidden" aria-label="Notifications">
            <svg width="20" height="20" class="w-5 h-5 text-foreground/80" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
              <path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/>
              <path d="M13.73 21a2 2 0 01-3.46 0"/>
            </svg>
            <span id="mobileNotificationsBadge" class="hidden absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[10px] font-extrabold flex items-center justify-center">0</span>
          </button>

          <!-- Notifications (shown when logged in, desktop) -->
          <button id="notificationsBtn" type="button" class="hidden max-lg:hidden lg:flex relative h-10 w-10 items-center justify-center rounded-full hover:bg-secondary transition-colors btn-press" aria-label="Notifications">
            <svg width="20" height="20" class="w-5 h-5 text-foreground/80" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
              <path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/>
              <path d="M13.73 21a2 2 0 01-3.46 0"/>
            </svg>
            <span id="notificationsBadge" class="hidden absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[10px] font-extrabold flex items-center justify-center">0</span>
          </button>

          <!-- Dark Mode Toggle (desktop only — inside hamburger drawer on mobile) -->
          <button data-action="NavbarComponent.toggleTheme" class="hidden lg:flex w-10 h-10 rounded-full items-center justify-center hover:bg-secondary transition-colors btn-press" aria-label="Toggle theme">
            <svg width="20" height="20" class="w-5 h-5 dark:hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-width="2" d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
            </svg>
            <svg width="20" height="20" class="w-5 h-5 hidden dark:block" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="5" stroke-width="2"/>
              <path stroke-width="2" d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>
            </svg>
          </button>
        </div>
      </div>
    </div>
    <span id="nav-pricing-badge" style="display:none;position:absolute;bottom:0;transform:translate(-50%,50%);font-size:10px;font-weight:700;color:var(--promo-nav-badge-text);background:var(--promo-nav-badge-bg);border-radius:100px;padding:1px 7px;white-space:nowrap;letter-spacing:0.03em;pointer-events:none;z-index:10;"></span>
  </header>
    `;
  }

  window.NavbarComponent = {
    startQueuePolling: startQueuePolling,
    stopQueuePolling: stopQueuePolling,

    showRunToast: function(agentLabel, url) {
      showJobToast(`${agentLabel} added to queue`, 'success', url);
    },

    incrementNotificationBadge: function(delta) {
      const n = Math.max(1, Math.trunc(Number(delta) || 1));
      const badge = document.getElementById('notificationsBadge');
      const current = badge ? parseInt(badge.textContent, 10) || 0 : 0;
      setNotificationsBadge(current + n);
    },

    invalidateCreditsCache: function(refresh = true) {
      window.AitopiaCache?.remove?.(window.AitopiaCache?.KEYS?.USER_CREDITS);
      if (refresh) {
        this.loadUserCredits();
      }
    },

    decrementCreditsOptimistic: function(deltaCredits) {
      const delta = Math.max(0, Math.trunc(Number(deltaCredits) || 0));
      if (!delta) return;

      const creditsAmount = document.getElementById('creditsAmount');
      const creditsShimmer = creditsAmount?.querySelector('.credits-shimmer');

      const currentCached = getUserCredits();
      const current =
        typeof currentCached === 'number' && Number.isFinite(currentCached)
          ? currentCached
          : (() => {
              const raw = creditsShimmer?.textContent ? String(creditsShimmer.textContent).trim() : '';
              const parsed = raw ? Number.parseInt(raw.replace(/[^0-9]/g, ''), 10) : NaN;
              return Number.isFinite(parsed) ? parsed : null;
            })();

      if (current === null) return;

      const next = Math.max(0, current - delta);
      setUserCredits(next);

      if (creditsShimmer) {
        creditsShimmer.textContent = String(next);
        creditsShimmer.classList.add('loaded');
      }
    },

    toggleTheme: function() {
      const html = document.documentElement;
      const isDark = html.classList.contains('dark');
      if (isDark) {
        html.classList.remove('dark');
        localStorage.setItem('theme', 'light');
      } else {
        html.classList.add('dark');
        localStorage.setItem('theme', 'dark');
      }
      if (typeof window.injectHeaderCss == 'function') window.injectHeaderCss();
    },

    toggleProfileDropdown: function() {
      const menu = document.getElementById('profileMenu');
      if (menu) menu.classList.toggle('hidden');
    },

    handleLogout: async function() {
      try {
        clearUserCache();
        stopQueuePolling();
        await fetch('https://aitopia.ai/auth/logout', { method: 'POST', credentials: 'include' });
      } catch (e) {
        console.error('Logout error:', e);
      }
      window.location.reload();
    },

    loadUserProfile: async function() {
      const loginBtn = document.getElementById('loginBtn');
      const notificationsBtn = document.getElementById('notificationsBtn');
      const profileDropdown = document.getElementById('profileDropdown');
      const creditsDisplay = document.getElementById('creditsDisplay');
      const profileName = document.getElementById('profileName');
      const profileEmailFull = document.getElementById('profileEmailFull');
      const profilePlanBadge = document.getElementById('profilePlanBadge');
      const profileDeveloperLink = document.getElementById('profileDeveloperLink');

      const setDeveloperLinkVisible = (visible) => {
        if (!profileDeveloperLink) return;
        if (visible) {
          profileDeveloperLink.classList.remove('hidden');
          profileDeveloperLink.classList.add('flex');
          return;
        }
        profileDeveloperLink.classList.add('hidden');
        profileDeveloperLink.classList.remove('flex');
      };

      const updateUI = (profileData) => {
        // Fresh lookup — global-nav.js may create this element after navbar.js init
        const mobileNotifBtn = document.getElementById('mobileNotificationsBtn');

        if (!profileData) {
          if (loginBtn) {
            loginBtn.classList.remove('hidden');
            loginBtn.classList.add('flex');
          }
          if (notificationsBtn) {
            notificationsBtn.classList.add('hidden');
            notificationsBtn.classList.remove('flex');
          }
          if (mobileNotifBtn) {
            mobileNotifBtn.classList.add('hidden');
            mobileNotifBtn.classList.remove('flex');
          }
          if (profileDropdown) profileDropdown.classList.add('hidden');
          if (creditsDisplay) {
            creditsDisplay.classList.add('hidden', 'opacity-0', 'pointer-events-none');
            creditsDisplay.classList.remove('flex', 'opacity-100');
          }
          setDeveloperLinkVisible(false);
          developerStatusPromise = null;
          stopNotificationsPolling();
          return;
        }

        const { fullName, email, plan } = profileData;
        if (loginBtn) {
          loginBtn.classList.add('hidden');
          loginBtn.classList.remove('flex');
        }
        if (notificationsBtn) {
          notificationsBtn.classList.remove('hidden');
          notificationsBtn.classList.add('flex');
        }
        if (mobileNotifBtn) {
          mobileNotifBtn.classList.remove('hidden');
          mobileNotifBtn.classList.add('flex');
        }
        if (profileDropdown) profileDropdown.classList.remove('hidden');
        if (creditsDisplay) {
          creditsDisplay.classList.remove('hidden', 'opacity-0', 'pointer-events-none');
          creditsDisplay.classList.add('flex', 'opacity-100');
        }
        if (profileName) profileName.textContent = fullName;
        if (profileEmailFull) profileEmailFull.textContent = email;
        if (profilePlanBadge && plan) {
          profilePlanBadge.textContent = plan.toUpperCase();
        }
        setDeveloperLinkVisible(false);
        void fetchIsDeveloper().then((isDeveloper) => {
          setDeveloperLinkVisible(Boolean(isDeveloper));
        });
        // Fetch notification badge FIRST, then check queue
        loadUnreadNotificationsCount().finally(() => {
          startNotificationsPolling();
          // Check if there are active queue jobs on login
          fetch('https://aitopia.ai/api/queue?limit=5', { method: 'GET', credentials: 'include', headers: { Accept: 'application/json' } })
            .then(r => r.ok ? r.json() : null)
            .then(json => {
              const items = Array.isArray(json?.items) ? json.items : [];
              if (items.some(i => i.status === 'pending' || i.status === 'processing')) {
                startQueuePolling();
              }
            })
            .catch(() => {});
        });
      };

      const cached = getUserProfile();
      if (cached) {
        updateUI(cached);
        this.loadUserCredits();
        this.loadSocialProfile();
        return;
      }
      const h = window.location.hostname;
      const isLocal = h.indexOf("localhost") !== -1;
      const parts = h.split(".");
      const rootDomain = parts.length > 2 ? parts.slice(-2).join(".") : h;
      const url = isLocal
      ? `https://extensions.aitopia.ai/extensions/app/key`
      : `https://extensions.${rootDomain}/extensions/app/key`;
      try {
        const aitopia_response = await fetch(
          url,
          { method: "GET", credentials: "include" },
        );
        if (aitopia_response?.key) {
          document.cookie = `hopekey=${aitopia_response?.key}; expires=${365 * 24 * 60 * 60 * 1000}; path=/; Secure; SameSite=None; Domain=.${window.location.hostname}`;
        }
      } catch (e) {}
      try {
        const response = await fetch('https://aitopia.ai/auth/me', { method: 'GET', credentials: 'include' });
        if (response.ok) {
          const resp = await response.json();
          const userData = resp?.data?.user || resp?.data || resp?.user || resp;
          const isLoggedIn = userData && !Array.isArray(userData) && typeof userData === 'object' && (userData.email || userData.key);

          if (isLoggedIn) {
            const email = userData.email || '';
            const name = userData.name || '';
            const lastname = userData.lastname || '';
            const fullName = [name, lastname].filter(Boolean).join(' ') || (email ? email.split('@')[0] : 'User');
            const plan = resp?.data?.plan || resp?.data?.licences?.plan_type || userData.plan || userData.planName || '';
            const licences = resp?.data?.licences || null;
            const extra = resp?.data?.extra || null;

            const profileData = { fullName, email, plan, licences, extra };
            setUserProfile(profileData);
            updateUI(profileData);
            this.loadUserCredits();
            this.loadSocialProfile();
            // Hide promo elements for creator plan users
            if (String(plan || '').toLowerCase() === 'creator') {
              document.getElementById('nav-pricing-badge')?.style?.setProperty('display', 'none', 'important');
              document.getElementById('mobile-pricing-badge')?.style?.setProperty('display', 'none', 'important');
              const promoBar = document.getElementById('promo-announcement-bar');
              if (promoBar) promoBar.style.display = 'none';
              localStorage.removeItem('promo_bar_active');
            }
            return;
          }
        }
      } catch (e) {
      }

      updateUI(null);
    },

    loadUserCredits: async function() {
      const creditsAmount = document.getElementById('creditsAmount');
      const creditsShimmer = creditsAmount?.querySelector('.credits-shimmer');

      const updateCreditsUI = (credits, animate = false) => {
        if (creditsShimmer) {
          creditsShimmer.textContent = credits !== null ? String(credits) : '—';
          if (animate) {
            setTimeout(() => creditsShimmer.classList.add('loaded'), 300);
          } else {
            creditsShimmer.classList.add('loaded');
          }
        }
      };

      const cached = getUserCredits();
      if (cached !== null) {
        updateCreditsUI(cached, false);
        return;
      }
      if (creditsShimmer) {
        creditsShimmer.classList.remove('loaded');
      }

      try {
        let balanceData;
        if (window.AitopiaCredits?.loadCreditsBalance) {
          balanceData = await window.AitopiaCredits.loadCreditsBalance();
        } else {
          const res = await fetch('https://aitopia.ai/api/credits/balance', { credentials: 'include' });
          if (res.ok) balanceData = await res.json();
        }
        if (!balanceData?.balance) {
          updateCreditsUI(null, true);
          return;
        }
        const totalCredits = balanceData.balance.totalCredits ?? balanceData.balance.totalCreditsRemaining ?? 0;

        setUserCredits(totalCredits);
        updateCreditsUI(totalCredits, true);
      } catch (e) {
        updateCreditsUI(null, true);
      }
    },

    loadSocialProfile: async function() {
      try {
        const res = await fetch('https://aitopia.ai/api/users/me', { method: 'GET', credentials: 'include' });
        if (!res.ok) return;
        const json = await res.json();
        const username = json?.profile?.username;
        if (username) {
          const profileLink = document.getElementById('profileLink');
          if (profileLink) {
            profileLink.href = `/marketplace/profile.html?username=${encodeURIComponent(username)}`;
          }
        }
      } catch (e) {
        // Ignore errors
      }
    },

    init: function() {
      const container = document.getElementById('navbar-container');
      const notificationsBtn = document.getElementById('notificationsBtn');

      if (!container) {
        if (notificationsBtn) {
          notificationsBtn.addEventListener('click', () => void openNotificationsModal());
          window.AitopiaNavbarNotifications = {
            startPolling: startNotificationsPolling,
            stopPolling: stopNotificationsPolling,
            openModal: openNotificationsModal,
          };
        } else {
          console.warn('NavbarComponent: #navbar-container not found');
        }
        return;
      }

      container.innerHTML = getNavbarHTML();
      initPromoBar();
      var ctx = getHeaderSearchContext();
      if (ctx && ctx.linkedInputId && !document.getElementById(ctx.linkedInputId)) {
        document.addEventListener('DOMContentLoaded', function () { bindHeaderSearch(); }, { once: true });
      } else {
        bindHeaderSearch();
      }
      autoBindNavbarAutocomplete();
      try {
        document.documentElement.classList.remove('global-nav-loading');
        document.documentElement.classList.add('global-nav-ready');
      } catch {}

      this.loadUserProfile();

      document.getElementById('notificationsBtn')?.addEventListener('click', () => void openNotificationsModal());
      document.getElementById('mobileNotificationsBtn')?.addEventListener('click', () => void openNotificationsModal());
      try {
        const url = new URL(window.location.href);
        const shouldOpen = url.searchParams.get('openNotifications');
        if (shouldOpen === '1' || shouldOpen === 'true') {
          url.searchParams.delete('openNotifications');
          const nextSearch = url.searchParams.toString();
          window.history.replaceState({}, '', `${url.pathname}${nextSearch ? `?${nextSearch}` : ''}${url.hash || ''}`);
          void openNotificationsModal();
        }
      } catch {}

      window.addEventListener('aitopia-credits-updated', (e) => {
        const totalCredits = e.detail?.balance?.totalCredits ?? e.detail?.balance?.totalCreditsRemaining;
        if (typeof totalCredits === 'number') {
          setUserCredits(totalCredits);
          const creditsShimmer = document.getElementById('creditsAmount')?.querySelector('.credits-shimmer');
          if (creditsShimmer) {
            creditsShimmer.textContent = String(totalCredits);
            creditsShimmer.classList.add('loaded');
          }
        }
      });

      document.addEventListener('click', (e) => {
        const dropdown = document.getElementById('profileDropdown');
        if (dropdown && !dropdown.contains(e.target)) {
          const menu = document.getElementById('profileMenu');
          if (menu) menu.classList.add('hidden');
        }
      });
    }
  };

  window.toggleTheme = window.NavbarComponent.toggleTheme;
  window.handleLogout = window.NavbarComponent.handleLogout;
  window.toggleProfileDropdown = window.NavbarComponent.toggleProfileDropdown;

  function initPromoBar() {
    function applyPromoBar(cfg) {
      const text       = cfg.text         || 'NanoBanana 2 UNLIMITED on Premium. Nano Banana Pro 2K & Seedream 4.5K generations.';
      const ctaText    = cfg.ctaText      || 'Personal %52 OFF';
      const ctaHref    = cfg.ctaHref      || '/marketplace/pricing.html';
      const badgeText  = cfg.badgeText    || '%52 OFF';
      const durationMs = (cfg.durationHours ?? 3) * 3600000;

      const textEl  = document.getElementById('promo-bar-text');
      const ctaEl   = document.getElementById('promo-bar-cta');
      const timerEl = document.getElementById('promo-bar-timer');
      const cachedPlan = (getUserProfile()?.plan || '').toLowerCase();
      const hidePromo = cachedPlan === 'creator';
      const badgeEl = document.getElementById('nav-pricing-badge');
      if (badgeEl) badgeEl.textContent = badgeText;
      const mobileBadge = document.getElementById('mobile-pricing-badge');
      if (mobileBadge && !hidePromo) { mobileBadge.textContent = badgeText; mobileBadge.style.display = 'inline-block'; }
      if (!hidePromo) _positionPricingBadge();

      if (textEl) textEl.textContent = text;
      if (ctaEl) { ctaEl.textContent = ctaText; ctaEl.href = ctaHref; }

      // Enable marquee when content overflows the bar width
      requestAnimationFrame(function () {
        const inner = document.getElementById('promo-bar-inner');
        const outer = document.getElementById('promo-announcement-bar');
        if (!inner || !outer || inner.scrollWidth <= outer.clientWidth) return;
        // Duplicate content for seamless loop
        outer.style.textAlign = 'left';
        const sep = '<span style="display:inline-block;width:48px;flex-shrink:0;" aria-hidden="true"></span>';
        const original = inner.innerHTML;
        inner.innerHTML = original + sep + original + sep;
        inner.style.animation = 'promo-marquee 22s linear infinite';
      });

      if (!document.getElementById('promo-bar-timer')) return;

      const STORAGE_KEY = 'promo_expiry';
      let endMs = parseInt(localStorage.getItem(STORAGE_KEY), 10);
      if (!endMs || endMs < Date.now()) {
        endMs = Date.now() + durationMs;
        localStorage.setItem(STORAGE_KEY, endMs);
      }

      function fmt(n) { return String(n).padStart(2, '0'); }
      function tick() {
        const rem = Math.max(0, endMs - Date.now());
        const h = Math.floor(rem / 3600000);
        const m = Math.floor((rem % 3600000) / 60000);
        const s = Math.floor((rem % 60000) / 1000);
        const text = `${fmt(h)}h ${fmt(m)}m ${fmt(s)}s`;
        document.querySelectorAll('#promo-bar-timer').forEach(function (el) { el.textContent = text; });
        if (rem === 0) {
          endMs = Date.now() + durationMs;
          localStorage.setItem('promo_expiry', endMs);
        }
      }
      tick();
      setInterval(tick, 1000);
    }

    fetch('https://aitopia.ai/store/promo-config.json')
      .then(function (r) { return r.ok ? r.json() : {}; })
      .catch(function () { return {}; })
      .then(applyPromoBar);
  }

  function runInit() {
    if (window.__AITOPIA_NAVBAR_INIT_DONE__) return;
    window.__AITOPIA_NAVBAR_INIT_DONE__ = true;
    window.NavbarComponent.init();
    setUrlCookie();
    window.dismissPromoBar = function () {
      const bar = document.getElementById('promo-announcement-bar');
      if (bar) bar.style.display = 'none';
      localStorage.setItem('promo_bar_dismissed', '1');
      localStorage.removeItem('promo_bar_active');
    };
    if (localStorage.getItem('promo_bar_active') && !localStorage.getItem('promo_bar_dismissed')) {
      const bar = document.getElementById('promo-announcement-bar');
      if (bar) bar.style.display = '';
    }
  }
  if (document.getElementById('navbar-container')) {
    runInit();
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runInit);
  } else {
    runInit();
  }


  function _positionPricingBadge() {
    const badge = document.getElementById('nav-pricing-badge');
    const link = document.getElementById('nav-pricing-link');
    const header = document.getElementById('header');
    if (!badge || !link || !header) return;
    const linkRect = link.getBoundingClientRect();
    if (linkRect.width === 0) {
      badge.style.display = 'none';
      return;
    }
    const headerRect = header.getBoundingClientRect();
    const centerX = linkRect.left + linkRect.width / 2 - headerRect.left;
    badge.style.left = centerX + 'px';
    badge.style.display = 'inline-block';
  }

  window.showNavPricingBadge = function () {
    _positionPricingBadge();
  };

  window.addEventListener('resize', () => {
    const badge = document.getElementById('nav-pricing-badge');
    if (badge) _positionPricingBadge();
  });

})();
