(function () {
  const BUILDER_URL = '/agent-builder/edit/_new';
  const DESIGN = 'https://aitopia.ai/agent-builder-landing/design';

  const STEPS = [
    {
      dark: DESIGN + '/build-studio-dark.webp', dw: 2088, dh: 1225,
      light: DESIGN + '/build-studio-light.webp', lw: 2088, lh: 1209,
      alt: 'Agent Builder Studio with the prompt bar',
      title: 'Build Agent With One Prompt',
      copy: 'Describe the agent you need in a single prompt - no code, no setup. The assistant researches real models and schemas, then assembles a complete, working agent for you in minutes.',
    },
    {
      dark: DESIGN + '/customize-dark.webp', dw: 2088, dh: 1233,
      light: DESIGN + '/customize-light.webp', lw: 2088, lh: 1239,
      alt: 'Agent setup step with name, category, tags and templates',
      title: 'Customize it, Choose Template',
      copy: "Shape your agent's identity; name, category, tags and capabilities - then pick a template for its marketplace card. Refine everything visually and publish when it feels right.",
    },
  ];

  const FAQS = [
    {
      question: 'How do I qualify for the creator program?',
      answer: "Publishing is all it takes. The moment your first agent or shared remix goes live on the marketplace, you're in. From then on, every run of your work automatically credits your share of the revenue to your account - no applications, no follower thresholds.",
    },
    {
      question: 'How does revenue sharing work?',
      answer: 'Every run of your agent spends credits, and a share of that spend becomes the distributable net. You take 70% of it and the platform keeps 30%. When the run is of a remixed version, your 70% becomes 50% for you and 20% for the remixer. You never invoice anyone - earnings land in your balance as your agents run.',
    },
    {
      question: 'What happens when someone remixes my agent?',
      answer: "You keep earning on every remix. When a remixed version of your agent runs, you still earn 50% of the net and the remixer takes 20% - the platform's 30% is unchanged. Remixes extend your reach without cutting you out.",
    },
    {
      question: 'What are credits?',
      answer: "Credits are the platform's currency for building and running agents. Generating an agent from a prompt uses a small amount, and each run costs credits based on the agent's capabilities. Your total is always visible in the Studio.",
    },
    {
      question: 'Do I need to know how to code?',
      answer: 'No. Agent Builder is fully no-code: describe what you need, let the assistant build it, and fine-tune the result in the visual Customizer. If you can write a sentence, you can ship an agent.',
    },
  ];

  const ARROW_ICON = `<svg class="w-4 h-4" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M9.62 3.95 13.67 8l-4.05 4.05M2.33 8h11.24" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  const CREDITS_ICON = `<svg class="w-4 h-4 opacity-80" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M14.6667 5.66634C14.6667 8.05967 12.7267 9.99967 10.3333 9.99967C10.22 9.99967 10.1 9.99302 9.98667 9.98635C9.82001 7.87302 8.12666 6.17967 6.01333 6.013C6.00666 5.89967 6 5.77967 6 5.66634C6 3.27301 7.94 1.33301 10.3333 1.33301C12.7267 1.33301 14.6667 3.27301 14.6667 5.66634Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M10 10.3333C10 12.7267 8.06004 14.6667 5.66671 14.6667C3.27337 14.6667 1.33337 12.7267 1.33337 10.3333C1.33337 7.94 3.27337 6 5.66671 6C5.78004 6 5.90003 6.00666 6.01337 6.01333C8.1267 6.17999 9.82005 7.87334 9.98671 9.98667C9.99338 10.1 10 10.22 10 10.3333Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.08 9.74699L5.66667 8.66699L6.25334 9.74699L7.33333 10.3337L6.25334 10.9203L5.66667 12.0003L5.08 10.9203L4 10.3337L5.08 9.74699Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

  const SECTION = 'px-3 sm:px-4 lg:px-6 mx-auto w-full max-w-[1440px]';
  const BAND = 'bg-[#F7F9FB] dark:bg-[#0F0E10]';
  const SURFACE = 'bg-[#F2F5F9] dark:bg-[#121014]';
  const H2 = 'text-gray-900 dark:text-white text-[30px] leading-[36px] sm:text-[42px] sm:leading-[49px] font-medium tracking-[-0.015em]';
  const LEDE = 'text-[#5B6472] dark:text-[#898A8B] text-[16px] leading-[24px]';
  const CTA = 'inline-flex items-center justify-center gap-2 h-[42px] px-6 rounded-[16px] bg-primary hover:bg-primary/90 text-white text-[16px] leading-none font-medium transition-colors';
  const SEG = `inline-flex gap-1 p-1 rounded-[16px] ${SURFACE} border border-[#E3E8EF] dark:border-[#232024] max-w-full`;
  const SEG_BTN = 'flex-1 min-w-0 px-2 py-[11px] sm:px-4 rounded-[12px] text-[13px] sm:text-[16px] leading-none text-[#7A8494] dark:text-[#898A8B] cursor-pointer transition-colors whitespace-normal sm:whitespace-nowrap aria-selected:font-medium aria-selected:bg-white aria-selected:text-[#121212] aria-selected:shadow-sm';
  const FIELD = `abl-number w-full h-[54px] px-5 rounded-[16px] ${SURFACE} border border-[#E3E8EF] dark:border-[#232024] text-gray-900 dark:text-white text-[16px] outline-none focus-visible:border-primary/60 transition-colors`;
  const FIELD_LABEL = 'block mb-3 text-[#7A8494] dark:text-[#898A8B] text-[14px] leading-4';

  const USD_PER_CREDIT = 0.02;  // .env USD_PER_CREDIT (src/config/env.ts)
  const PROFIT_RATE = 0.2;      // .env AICONOMY_PROFIT_RATE - the share of a spend
  const OWNER_SHARE = 0.7;      // AIConomy split of that net: 70% agent owner, 30% platform.

  // What one credit spent on your agent is worth to you: 0.2 x 0.7 x 0.02.
  const OWNER_USD_PER_CREDIT = PROFIT_RATE * OWNER_SHARE * USD_PER_CREDIT;

  function formatUsd(value) {
    const rounded = Math.round(value);
    return rounded >= 100
      ? '$' + rounded.toLocaleString('en-US')
      : '$' + value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function readNumber(el, fallback, max) {
    const n = parseFloat(el.value);
    if (!isFinite(n) || n < 0) return fallback;
    return Math.min(n, max);
  }

  function renderHeader() {
    const el = document.getElementById('abl-header');
    if (!el) return;

    el.innerHTML = `
<header class="mx-auto flex w-full max-w-[1440px] items-center justify-between gap-4 px-3 py-5 sm:px-4 sm:py-6 lg:px-6">
  <a class="flex items-center gap-3 sm:gap-6" href="/marketplace/">
    <img class="hidden h-8 w-auto sm:block" src="/marketplace/Logo_all.svg" alt="AITOPIA" width="185" height="36">
    <img class="h-9 w-9 sm:hidden" src="/marketplace/Logo.svg" alt="AITOPIA" width="40" height="40">
    <span class="inline-flex h-6 items-center rounded-[8px] bg-[#EFE1FC] px-2 text-[12px] leading-none text-[#9334EB] dark:bg-[rgba(147,52,235,.15)]">Agent-Builder</span>
  </a>
  <a class="${CTA}" href="${BUILDER_URL}">
    <span class="sm:hidden">Start Creating</span>
    <span class="hidden sm:inline">Start Creating Agent</span>
  </a>
</header>`;
  }

  function renderHero() {
    const el = document.getElementById('abl-hero');
    if (!el) return;

    el.innerHTML = `
<section class="${SECTION} pt-6">
  <!-- the hero card keeps its dark gradient in both themes, per the comps -->
  <div class="relative isolate mx-auto w-full rounded-[24px] overflow-hidden text-center"
       style="background:linear-gradient(180deg,#0C0C0C 0%,rgba(148,54,235,.6) 231.92%)">
    <div class="pointer-events-none absolute inset-x-[14.3%] top-[22%] h-[416px] rounded-full"
         style="background:rgba(147,52,235,.35);filter:blur(100px)" aria-hidden="true"></div>

    <div class="relative z-10 pt-10 sm:pt-[34px]">
      <h1 class="mx-auto max-w-[664px] px-4 text-[30px] leading-[1.25] sm:text-[42px] sm:leading-[1.145] font-normal text-white">
        <span class="abl-grad abl-grad-a">Create your AI agents Instantly &amp;</span>
        <span class="abl-accent relative italic font-medium">Earn up to 70%</span>
        <span class="abl-grad abl-grad-b">Revenue Share.</span>
      </h1>

      <div class="mt-8 sm:mt-9 flex flex-col sm:flex-row flex-wrap items-center justify-center gap-5 sm:gap-6">
        <a class="${CTA}" href="${BUILDER_URL}">Start Creating Agent</a>
        <a class="inline-flex items-center gap-2 text-[16px] leading-none text-[#C4A2F7] sm:text-[#A855F7] hover:text-[#C084FC] transition-colors" href="#abl-steps">
          See How It Works ${ARROW_ICON}
        </a>
      </div>

      <img class="mx-auto mt-8 sm:mt-6 block h-auto w-[87%] max-w-[972px]"
           data-abl-dark="${DESIGN}/banner-dark.webp" data-abl-light="${DESIGN}/banner-light.webp"
           data-abl-dark-w="1944" data-abl-dark-h="1020"
           data-abl-light-w="1944" data-abl-light-h="1004"
           data-abl-dark-mobile="${DESIGN}/banner-dark-mobile.webp" data-abl-light-mobile="${DESIGN}/banner-light-mobile.webp"
           data-abl-mobile-w="1200" data-abl-mobile-h="1590"
           src="${DESIGN}/banner-dark.webp" width="1944" height="1020"
           alt="The Agent Builder setup screen shown on a laptop">
    </div>
  </div>
</section>`;
  }

  function stepMarkup(step) {
    return `
<article class="abl-step w-full shrink-0 snap-start md:w-auto md:shrink">
  <img class="block h-auto w-full rounded-[22px] ${SURFACE}"
       data-abl-dark="${step.dark}" data-abl-light="${step.light}"
       data-abl-dark-w="${step.dw}" data-abl-dark-h="${step.dh}"
       data-abl-light-w="${step.lw}" data-abl-light-h="${step.lh}"
       src="${step.dark}" width="${step.dw}" height="${step.dh}" alt="${step.alt}" loading="lazy">
  <h3 class="mt-8 text-gray-900 dark:text-white text-[24px] leading-[1.1] font-normal">${step.title}</h3>
  <p class="mt-4 ${LEDE}">${step.copy}</p>
</article>`;
  }

  function renderSteps() {
    const el = document.getElementById('abl-steps');
    if (!el) return;

    el.innerHTML = `
<section class="${BAND} py-16 sm:py-24">
  <div class="${SECTION} text-center">
    <h2 class="${H2}">How it works</h2>
  </div>
  <!-- one swipeable card per screen on mobile, two side by side from md up -->
  <div class="abl-rail abl-step-rail mt-10 flex snap-x snap-mandatory gap-12 overflow-x-auto px-3 scroll-pl-3
              sm:px-4 sm:scroll-pl-4
              md:mx-auto md:grid md:w-full md:max-w-[1440px] md:grid-cols-2 md:gap-[51px] md:overflow-visible md:px-4 lg:px-6
              text-left">
    ${STEPS.map(stepMarkup).join('')}
  </div>

  <div class="mt-6 flex items-center justify-center gap-2 md:hidden" id="abl-step-dots" role="tablist" aria-label="How it works slides">
    ${STEPS.map((_, i) => `
      <button type="button" role="tab" data-slide="${i}" aria-selected="${i === 0}" aria-label="Slide ${i + 1}"
              class="abl-step-dot h-1 rounded-full transition-all duration-200 w-5 bg-[#D7DDE6] dark:bg-[#2A2A2E] aria-selected:w-12 aria-selected:bg-primary"></button>`).join('')}
  </div>
</section>`;

    bindStepRail();
  }

  function bindStepRail() {
    const rail = document.querySelector('.abl-step-rail');
    const dots = document.getElementById('abl-step-dots');
    if (!rail || !dots) return;

    const buttons = Array.prototype.slice.call(dots.querySelectorAll('button[data-slide]'));

    function activeIndex() {
      const cards = rail.querySelectorAll('.abl-step');
      if (!cards.length) return 0;
      const stride = cards.length > 1
        ? cards[1].getBoundingClientRect().left - cards[0].getBoundingClientRect().left
        : cards[0].getBoundingClientRect().width;
      return stride > 0 ? Math.round(rail.scrollLeft / stride) : 0;
    }

    function sync() {
      const i = activeIndex();
      buttons.forEach(function (b, n) { b.setAttribute('aria-selected', String(n === i)); });
    }

    let ticking = false;
    rail.addEventListener('scroll', function () {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function () { sync(); ticking = false; });
    }, { passive: true });

    buttons.forEach(function (btn, i) {
      btn.addEventListener('click', function () {
        const cards = rail.querySelectorAll('.abl-step');
        if (cards[i]) rail.scrollTo({ left: cards[i].offsetLeft - rail.offsetLeft, behavior: 'smooth' });
      });
    });

    sync();
  }

  function renderCalculator() {
    const el = document.getElementById('abl-calculator');
    if (!el) return;

    el.innerHTML = `
<section class="py-16 sm:py-24">
  <div class="${SECTION} text-center">
    <h2 class="${H2} mx-auto">
      <span class="text-[#9AA3B0] dark:text-[#898A8B]">Calculate</span> How much you will earn.
    </h2>
  </div>

  <div class="${SECTION} mt-12 grid grid-cols-1 lg:grid-cols-[minmax(0,44fr)_minmax(0,56fr)] gap-10 lg:gap-[84px] items-start">
    <div>
      <div>
        <span class="${FIELD_LABEL}" id="abl-scale-label">Earning Scale</span>
        <div class="${SEG}" id="abl-scale-tabs" role="tablist" aria-labelledby="abl-scale-label">
          <button type="button" role="tab" aria-selected="true" data-scale="annual" class="${SEG_BTN}">Annual</button>
          <button type="button" role="tab" aria-selected="false" data-scale="monthly" class="${SEG_BTN}">Monthly</button>
        </div>
      </div>

      <div class="mt-8">
        <label class="${FIELD_LABEL}" for="abl-agents">Number of Agents You Created</label>
        <input class="${FIELD}" type="number" id="abl-agents" min="1" max="500" step="1" value="10" inputmode="numeric">
      </div>

      <div class="mt-8">
        <label class="${FIELD_LABEL}" for="abl-credits">Credits for each of your agent</label>
        <input class="${FIELD}" type="number" id="abl-credits" min="1" max="10000" step="1" value="100" inputmode="numeric">
      </div>

      <div class="mt-8">
        <label class="${FIELD_LABEL}" for="abl-runs">Number of usage per month</label>
        <input class="${FIELD}" type="number" id="abl-runs" min="1" max="1000000" step="10" value="500" inputmode="numeric">
      </div>
    </div>

    <div class="flex min-h-0 lg:min-h-[497px] flex-col rounded-[20px] ${SURFACE} p-6 sm:p-8">
      <div class="flex items-start justify-between gap-4">
        <h3 class="text-gray-900 dark:text-white text-[22px] sm:text-[24px] leading-8 font-normal" id="abl-result-title">Estimated Annual Earning</h3>
        <span class="hidden sm:block shrink-0 pt-1.5 text-[14px] ${LEDE}" id="abl-result-summary">10 Agent, 100 Credits</span>
      </div>
      <p class="mt-2 text-[38px] sm:text-[54px] leading-[1.15] font-normal tracking-[-0.01em] tabular-nums text-gray-900 dark:text-white" id="abl-result-value">$16,800</p>

      <div class="relative my-8 flex-[1_1_200px]" aria-hidden="true">
        <svg class="block h-full w-full" viewBox="0 0 518 208" preserveAspectRatio="none" role="presentation">
          <defs>
            <linearGradient id="ablCurve" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stop-color="#541F85"/>
              <stop offset="55%" stop-color="#8B32DE"/>
              <stop offset="100%" stop-color="#A855F7"/>
            </linearGradient>
          </defs>
          <line x1="0" y1="4" x2="518" y2="4" stroke="currentColor" class="text-black/5 dark:text-white/5"/>
          <line x1="0" y1="104" x2="518" y2="104" stroke="currentColor" class="text-black/5 dark:text-white/5"/>
          <line x1="0" y1="204" x2="518" y2="204" stroke="currentColor" class="text-black/5 dark:text-white/5"/>
          <path d="M0 204 C 170 204, 300 150, 380 84 C 440 34, 480 12, 518 4 L 518 204 Z" fill="url(#ablCurve)"/>
        </svg>
        <!-- the svg is stretched, so a <circle> would render as an ellipse -->
        <span id="abl-chart-dot" class="absolute -ml-[9px] -mt-[9px] h-[18px] w-[18px] rounded-full bg-white shadow"></span>
      </div>

    </div>
  </div>
</section>`;

    bindCalculator();
  }

  const CURVE = [
    [[0, 204], [170, 204], [300, 150], [380, 84]],
    [[380, 84], [440, 34], [480, 12], [518, 4]],
  ];

  function curvePoint(t) {
    const seg = t < 0.5 ? CURVE[0] : CURVE[1];
    const u = t < 0.5 ? t * 2 : (t - 0.5) * 2;
    const k = 1 - u;
    const f = (i) => k * k * k * seg[0][i] + 3 * k * k * u * seg[1][i] + 3 * k * u * u * seg[2][i] + u * u * u * seg[3][i];
    return [f(0), f(1)];
  }

  function moveChartDot(monthly) {
    const dot = document.getElementById('abl-chart-dot');
    if (!dot) return;
    const t = Math.min(0.97, Math.max(0.03, 0.5 + Math.log10(Math.max(monthly, 0.01) / 1400) / 6));
    const [x, y] = curvePoint(t);
    dot.style.left = (x / 518 * 100).toFixed(2) + '%';
    dot.style.top = (y / 208 * 100).toFixed(2) + '%';
  }

  function updateResult() {
    const agentsEl = document.getElementById('abl-agents');
    const creditsEl = document.getElementById('abl-credits');
    const runsEl = document.getElementById('abl-runs');
    const titleEl = document.getElementById('abl-result-title');
    const valueEl = document.getElementById('abl-result-value');
    const summaryEl = document.getElementById('abl-result-summary');
    const activeScale = document.querySelector('#abl-scale-tabs button[aria-selected="true"]');
    if (!agentsEl || !creditsEl || !runsEl || !titleEl || !valueEl) return;

    const agents = readNumber(agentsEl, 1, 500);
    const credits = readNumber(creditsEl, 1, 10000);
    const runs = readNumber(runsEl, 1, 1000000);
    const annual = !activeScale || activeScale.dataset.scale === 'annual';
    const months = annual ? 12 : 1;

    const perRun = credits * OWNER_USD_PER_CREDIT;

    titleEl.textContent = 'Estimated ' + (annual ? 'Annual' : 'Monthly') + ' Earning';
    valueEl.textContent = formatUsd(perRun * runs * agents * months);
    moveChartDot(perRun * runs * agents);
    if (summaryEl) {
      summaryEl.textContent =
        `${agents.toLocaleString('en-US')} Agent, ${credits.toLocaleString('en-US')} Credits`;
    }
  }

  function bindCalculator() {
    const tabs = document.getElementById('abl-scale-tabs');
    if (tabs) {
      tabs.addEventListener('click', function (e) {
        const btn = e.target.closest('button[data-scale]');
        if (!btn) return;
        tabs.querySelectorAll('button[data-scale]').forEach(function (b) {
          b.setAttribute('aria-selected', String(b === btn));
        });
        updateResult();
      });
    }
    ['abl-agents', 'abl-credits', 'abl-runs'].forEach(function (id) {
      const el = document.getElementById(id);
      if (el) el.addEventListener('input', updateResult);
    });
    updateResult();
  }

  function renderMap() {
    const el = document.getElementById('abl-map');
    if (!el) return;

    el.innerHTML = `
<section class="relative overflow-hidden py-16 sm:py-24">
  <div class="pointer-events-none absolute inset-0 abl-map-grid" aria-hidden="true"></div>
  <div class="${SECTION} relative z-10 text-center">
    <h2 class="${H2}">AICONOMY System Map</h2>
    <p class="mx-auto mt-4 max-w-[660px] ${LEDE}">
      One connected economy: agents are built, remixed and run - and every run automatically splits revenue
      between builders, the remix chain and creators. This map shows how value flows through it all.
    </p>
    <img class="mx-auto mt-14 block h-auto w-full"
         data-abl-dark="${DESIGN}/system-map-dark.webp" data-abl-light="${DESIGN}/system-map-light.webp"
         data-abl-dark-w="2190" data-abl-dark-h="961"
         data-abl-light-w="2190" data-abl-light-h="959"
         src="${DESIGN}/system-map-dark.webp" width="2190" height="961" loading="lazy"
         alt="System map: created agents split every run 70% to the creator and 30% to the platform; a remixed run pays 50% to the creator and 20% to the remixer">
  </div>
</section>`;
  }

  function faqItemMarkup(faq, index) {
    const isFirst = index === 0;
    return `
<div class="abl-faq-item rounded-[24px] transition-colors duration-200 ${SURFACE}">
  <button type="button" class="abl-faq-toggle w-full flex items-start justify-between gap-4 sm:gap-8 p-6 sm:p-8 text-left cursor-pointer" aria-expanded="${isFirst}">
    <span class="text-gray-900 dark:text-white text-[17px] leading-[26px] sm:text-[20px] sm:leading-8 font-medium">${faq.question}</span>
    <span class="abl-faq-icon relative shrink-0 h-10 w-10 sm:h-12 sm:w-12 rounded-full"></span>
  </button>
  <div class="abl-faq-body overflow-hidden transition-all duration-200 ${isFirst ? 'max-h-80' : 'max-h-0'}">
    <p class="px-6 pb-6 sm:pl-8 sm:pr-24 sm:pb-8 max-w-[878px] text-[#5B6472] dark:text-white/60 text-[16px] leading-[22px]">${faq.answer}</p>
  </div>
</div>`;
  }

  function renderFaq() {
    const el = document.getElementById('abl-faq');
    if (!el) return;

    el.innerHTML = `
<section class="py-16 sm:py-24">
  <div class="${SECTION}">
    <h2 class="${H2} text-center">Frequently Asked Questions</h2>
    <div class="mt-12 flex flex-col gap-6">
      ${FAQS.map(faqItemMarkup).join('')}
    </div>
  </div>
</section>`;

    bindFaqToggles();
  }

  function bindFaqToggles() {
    document.querySelectorAll('.abl-faq-toggle').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const item = btn.closest('.abl-faq-item');
        const body = item.querySelector('.abl-faq-body');
        const wasOpen = body.classList.contains('max-h-80');

        document.querySelectorAll('.abl-faq-item').forEach(function (el) {
          el.querySelector('.abl-faq-body').classList.remove('max-h-80');
          el.querySelector('.abl-faq-body').classList.add('max-h-0');
          el.querySelector('.abl-faq-toggle').setAttribute('aria-expanded', 'false');
        });

        if (!wasOpen) {
          body.classList.add('max-h-80');
          body.classList.remove('max-h-0');
          btn.setAttribute('aria-expanded', 'true');
        }
      });
    });
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function creditsLabel(cost) {
    if (!cost) return 'credits vary';
    let min = Number(cost.minCost), max = Number(cost.maxCost);
    if (!isFinite(min) || !isFinite(max) || max <= 0) return 'credits vary';
    if (String(cost.currency || '').toUpperCase() === 'USD') {
      min /= USD_PER_CREDIT;
      max /= USD_PER_CREDIT;
    }
    const lo = Math.max(1, Math.round(min)), hi = Math.max(1, Math.round(max));
    return lo === hi ? `${lo} credits` : `${lo}\u2013${hi} credits`;
  }

  function toDiscoverCard(a) {
    const cat = String(a.category || '').toLowerCase();
    const media = cat.includes('video')
      ? (a.featured_video || a.showcase_videos?.[0] || a.videos?.[0] || a.showcase_images?.[0] || a.icon || a.screenshots?.[0])
      : (a.showcase_images?.[0] || a.featured_video || a.showcase_videos?.[0] || a.icon || a.videos?.[0] || a.screenshots?.[0]);
    const url = media || '';
    const isVideo = /\.(mp4|webm)(\?|#|$)/i.test(url);
    return {
      href: '/agents/' + encodeURIComponent(a.id),
      img: isVideo ? '' : escapeHtml(url),
      video: isVideo ? escapeHtml(url) : '',
      title: escapeHtml(a.name || a.id),
      copy: escapeHtml(a.description || ''),
      credits: escapeHtml(creditsLabel(a.costEstimate)),
    };
  }

  function seeAllCardMarkup() {
    return `
<a href="/marketplace/agents.html" class="agent-card group bg-card rounded-ios-2xl border border-border/40 border-dashed overflow-hidden card-hover cursor-pointer flex flex-col items-center justify-center gap-4 no-underline text-inherit shrink-0 w-[280px] sm:w-[300px] snap-start">
  <span class="w-14 h-14 rounded-full border border-border bg-secondary/60 flex items-center justify-center transition-transform group-hover:translate-x-0.5">
    <svg class="w-6 h-6 text-muted-foreground" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" aria-hidden="true">
      <path stroke-linecap="round" stroke-linejoin="round" d="M9 18l6-6-6-6"/>
    </svg>
  </span>
  <span class="text-[16px] font-semibold text-foreground">See All Agents</span>
  <span class="text-[12px] text-muted-foreground">Browse the full marketplace</span>
</a>`;
  }

  function agentCardMarkup(agent) {
    const media = agent.video
      ? `<div data-video-src="${agent.video}" class="w-full h-full rounded-b-[20px] relative overflow-hidden"></div>`
      : agent.img
      ? `<img src="${agent.img}" alt="" class="w-full h-full object-cover img-zoom rounded-b-[20px] pointer-events-none" loading="lazy" decoding="async">`
      : `<img src="/marketplace/Logo.svg" alt="" class="w-12 h-12 opacity-40 pointer-events-none" width="40" height="40" loading="lazy">`;
    return `
<a href="${agent.href}" class="agent-card group bg-card rounded-ios-2xl border border-border/40 overflow-hidden card-hover cursor-pointer flex flex-col no-underline text-inherit shrink-0 w-[280px] sm:w-[300px] snap-start">
  <div class="card-media relative aspect-square bg-secondary/50 overflow-hidden flex items-center justify-center rounded-b-[20px]">
    ${media}
  </div>
  <div class="card-info p-4 flex flex-col flex-1">
    <h3 class="mt-1 text-[16px] leading-snug font-semibold text-foreground truncate">${agent.title}</h3>
    <p class="mt-2 text-[12px] font-normal text-muted-foreground line-clamp-2 leading-snug">${agent.copy}</p>
    <div class="mt-auto pt-4 flex items-center justify-between gap-3">
      <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary text-secondary-foreground text-[12px] font-medium max-w-[140px] text-center whitespace-normal leading-tight">
        ${CREDITS_ICON}<span>${agent.credits}</span>
      </div>
      <button type="button" tabindex="-1" class="w-10 h-10 rounded-full border border-border bg-card hover:bg-secondary transition-all btn-press flex items-center justify-center opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto" aria-hidden="true">
        <svg class="w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" aria-hidden="true">
          <path stroke-linecap="round" stroke-linejoin="round" d="M9 18l6-6-6-6"/>
        </svg>
      </button>
    </div>
  </div>
</a>`;
  }

  async function renderDiscover() {
    const el = document.getElementById('abl-discover');
    if (!el) return;

    let agents = [];
    try {
      const [body, showcase] = await Promise.all([
        fetch('https://aitopia.ai/api/store', { credentials: 'include' }).then(r => r.json()),
        fetch('https://aitopia.ai/agent-showcase-data.json').then(r => r.ok ? r.json() : []).catch(() => []),
      ]);
      const list = Array.isArray(body) ? body : (body.agents || body.items || body.data || []);
      const visuals = new Map(showcase.map(s => [s.id, s]));
      agents = list.filter(a => a && a.isBuilder).slice(0, 8).map((a) => {
        const v = visuals.get(a.id) || {};
        return toDiscoverCard({
          ...a,
          icon: v.icon || a.icon,
          showcase_images: v.showcase_images || a.showcase_images,
          showcase_videos: v.showcase_videos || a.showcase_videos,
          featured_video: v.featured_video || a.featured_video,
        });
      });
    } catch (err) {
      agents = [];
    }

    const heading = agents.length ? `
  <div class="${SECTION} text-center">
    <h2 class="${H2}">Discover Other Creators&rsquo; Agents</h2>
  </div>

  <div class="abl-rail abl-rail-inset mt-10 flex gap-7 overflow-x-auto snap-x snap-mandatory pr-3 sm:pr-4 lg:pr-6 pt-1 pb-7">
    ${agents.map(agentCardMarkup).join('')}
    ${seeAllCardMarkup()}
  </div>` : '';

    el.innerHTML = `
<section class="pt-16 sm:pt-24 pb-24">
  ${heading}
  <div class="text-center ${agents.length ? 'mt-3' : ''}">
    <a class="inline-flex items-center justify-center h-[47px] px-11 rounded-[16px] bg-primary hover:bg-primary/90 text-white text-[16px] leading-none font-medium transition-colors"
       href="${BUILDER_URL}">Start Building For Free</a>
  </div>
</section>`;
    if (agents.length) window.AitopiaLazyMedia?.observe(el);
  }

  const MOBILE_MQ = window.matchMedia('(max-width: 639px)');

  function syncThemeImages() {
    const dark = document.documentElement.classList.contains('dark');
    const mobile = MOBILE_MQ.matches;
    document.querySelectorAll('img[data-abl-dark]').forEach(function (img) {
      const mobileSrc = dark ? img.dataset.ablDarkMobile : img.dataset.ablLightMobile;
      const useMobile = mobile && !!mobileSrc;
      const next = useMobile ? mobileSrc : (dark ? img.dataset.ablDark : img.dataset.ablLight);
      if (!next) return;
      const w = useMobile ? img.dataset.ablMobileW : (dark ? img.dataset.ablDarkW : img.dataset.ablLightW);
      const h = useMobile ? img.dataset.ablMobileH : (dark ? img.dataset.ablDarkH : img.dataset.ablLightH);
      if (w) img.width = Number(w);
      if (h) img.height = Number(h);
      if (!img.src.endsWith(next)) img.src = next;
    });
  }

  function init() {
    renderHeader();
    renderHero();
    renderSteps();
    renderCalculator();
    renderMap();
    renderFaq();
    renderDiscover();
    syncThemeImages();

    new MutationObserver(syncThemeImages)
      .observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    MOBILE_MQ.addEventListener('change', syncThemeImages);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
