/**
 * Standard Button component.
 */

const VARIANT_CLASSES = {
  primary:
    'bg-primary/90 hover:bg-primary/90 text-primary-foreground shadow-sm',
  secondary:
    'bg-panel-input hover:bg-panel-hover ' +
    'text-gray-900 dark:text-white border border-panel-border',
  ghost:
    'bg-transparent hover:bg-neutral-100 dark:hover:bg-neutral-800 text-gray-700 dark:text-gray-300',
  destructive:
    'bg-red-600 hover:bg-red-700 text-white shadow-sm',
};

const SIZE_CLASSES = {
  sm: 'px-3 py-1.5 text-xs rounded-lg',
  md: 'px-4 py-2.5 text-sm rounded-xl',
  lg: 'px-6 py-3 text-base rounded-2xl',
};

/**
 * @param {object} options
 * @param {string} options.label - Button text
 * @param {'primary'|'secondary'|'ghost'|'destructive'} [options.variant='primary']
 * @param {'sm'|'md'|'lg'} [options.size='md']
 * @param {string} [options.icon] - SVG string for icon (must be trusted content)
 * @param {'left'|'right'} [options.iconPosition='left']
 * @param {boolean} [options.loading=false]
 * @param {boolean} [options.disabled=false]
 * @param {boolean} [options.fullWidth=false]
 * @param {function} [options.onClick]
 * @returns {{ button: HTMLButtonElement, setLoading: (v: boolean) => void, setDisabled: (v: boolean) => void, setLabel: (v: string) => void }}
 */
export function createButton({
  label = '',
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'left',
  loading = false,
  disabled = false,
  fullWidth = false,
  onClick,
} = {}) {
  const button = document.createElement('button');
  button.type = 'button';

  const variantCls = VARIANT_CLASSES[variant] || VARIANT_CLASSES.primary;
  const sizeCls = SIZE_CLASSES[size] || SIZE_CLASSES.md;

  button.className = [
    'inline-flex items-center justify-center gap-2 font-semibold transition-colors',
    'focus:outline-none focus:ring-2 focus:ring-primary/30',
    'disabled:opacity-50 disabled:cursor-not-allowed',
    variantCls,
    sizeCls,
    fullWidth ? 'w-full' : '',
  ].filter(Boolean).join(' ');

  // Spinner SVG for loading state
  const spinnerSvg = `<svg class="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
  </svg>`;

  const iconEl = document.createElement('span');
  iconEl.className = 'inline-flex items-center shrink-0';

  const labelEl = document.createElement('span');
  labelEl.textContent = label;

  function render() {
    button.innerHTML = '';
    if (loading) {
      const spinner = document.createElement('span');
      spinner.className = 'inline-flex items-center shrink-0';
      spinner.innerHTML = spinnerSvg;
      button.appendChild(spinner);
      button.appendChild(labelEl);
      button.disabled = true;
      button.setAttribute('aria-busy', 'true');
      return;
    }
    button.disabled = disabled;
    button.removeAttribute('aria-busy');
    if (icon && iconPosition === 'left') {
      iconEl.innerHTML = icon;
      button.appendChild(iconEl);
    }
    button.appendChild(labelEl);
    if (icon && iconPosition === 'right') {
      iconEl.innerHTML = icon;
      button.appendChild(iconEl);
    }
  }

  render();

  if (typeof onClick === 'function') {
    button.addEventListener('click', onClick);
  }

  return {
    button,
    setLoading(v) {
      loading = Boolean(v);
      render();
    },
    setDisabled(v) {
      disabled = Boolean(v);
      if (!loading) button.disabled = disabled;
    },
    setLabel(v) {
      labelEl.textContent = String(v ?? '');
    },
  };
}
