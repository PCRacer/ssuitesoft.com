/**
 * Image pair field component.
 */
import {
  updateFormData, createFieldLabel, createHelpToggle, fileToBase64DataUrl, registerPendingSync,
} from '../../runner/overrides/ui.js';
import { createMediaField } from './media-upload.js';

export function createImagePairField({
  label,
  id,
  required = false,
  help,
  defaultValue,
  aLabel = 'Start image',
  bLabel = 'End image',
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'imagePair';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'image-pair');
  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-3';
    const row = document.createElement('div');
    row.className = 'flex items-center';
    const title = String(label);
    const labelEl = createFieldLabel(title, { required });
    labelEl.className = 'block text-sm font-medium mx-2';
    row.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: title, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      row.appendChild(trigger);
    }
    header.appendChild(row);
    wrap.appendChild(header);
  }

  const grid = document.createElement('div');
  grid.className = 'grid grid-cols-2 gap-3';

  const aFieldId = fieldKey ? `${fieldKey}[0]` : undefined;
  const bFieldId = fieldKey ? `${fieldKey}[1]` : undefined;
  const aField = createMediaField({ label: aLabel, id: aFieldId, required, kind: 'image' });
  const bField = createMediaField({ label: bLabel, id: bFieldId, required, kind: 'image' });

  grid.appendChild(aField.wrap);
  grid.appendChild(bField.wrap);
  wrap.appendChild(grid);

  // Sync the pair as an array to global form data (base64 for files).
  // seq guard: the awaits below mean an earlier slow conversion could finish
  // after a later call and write a stale pair; only the latest call writes.
  // The run is registered so the run gate can await in-flight conversions.
  let syncSeq = 0;
  const syncToGlobal = () => registerPendingSync((async () => {
    const seq = ++syncSeq;
    const aUrl = aField.urlInput.value.trim();
    const bUrl = bField.urlInput.value.trim();
    // createMediaField stages picks in a closure and clears fileInput.value,
    // so read the staged file — fileInput.files is always empty by now.
    const aFile = aField.getStagedFile?.() || null;
    const bFile = bField.getStagedFile?.() || null;

    let aVal = aUrl || undefined;
    let bVal = bUrl || undefined;
    try { if (!aVal && aFile) aVal = await fileToBase64DataUrl(aFile); } catch { /* skip */ }
    try { if (!bVal && bFile) bVal = await fileToBase64DataUrl(bFile); } catch { /* skip */ }
    if (seq !== syncSeq) return;

    if (aVal || bVal) {
      updateFormData(fieldKey, [aVal, bVal]);
    } else {
      updateFormData(fieldKey, undefined);
    }
  })());

  // Listen for changes on both child fields
  aField.urlInput.addEventListener('input', syncToGlobal);
  aField.urlInput.addEventListener('change', syncToGlobal);
  aField.fileInput.addEventListener('change', syncToGlobal);
  bField.urlInput.addEventListener('input', syncToGlobal);
  bField.urlInput.addEventListener('change', syncToGlobal);
  bField.fileInput.addEventListener('change', syncToGlobal);

  function setValue(v) {
    const arr = Array.isArray(v) ? v : [];
    aField.setValue?.(arr[0]);
    bField.setValue?.(arr[1]);
    syncToGlobal();
  }

  if (Array.isArray(defaultValue)) setValue(defaultValue);
  syncToGlobal(); // Initial sync

  return {
    wrap,
    getValue: async () => {
      // Start both uploads, then await in order; the early catch keeps B's
      // rejection from going unhandled when A throws first.
      const aPromise = aField.getValue();
      const bPromise = bField.getValue();
      bPromise.catch(() => {});
      const a = await aPromise;
      const b = await bPromise;
      if (a === undefined && b === undefined) return undefined;
      if (required && (!a || !b)) {
        const msg = `Please upload both images for ${label ? label.toLowerCase() : 'this field'}`;
        throw new Error(msg);
      }
      return [a ?? '', b ?? ''];
    },
    setValue: (v) => { setValue(v); syncToGlobal(); },
    setReadOnly: (readOnly) => {
      aField.fileInput.disabled = Boolean(readOnly);
      aField.urlInput.readOnly = Boolean(readOnly);
      bField.fileInput.disabled = Boolean(readOnly);
      bField.urlInput.readOnly = Boolean(readOnly);
      wrap.classList.toggle('opacity-75', Boolean(readOnly));
      wrap.querySelectorAll('button, input, textarea, select').forEach((el) => {
        if (el.tagName.toLowerCase() === 'button') (el).disabled = Boolean(readOnly);
      });
    },
  };
}
