/**
 * Pill toggle component (single-select pill button group).
 * Renders a row of mutually exclusive toggle buttons styled as rounded pills.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createPillToggle({ label, id, options = [], defaultValue, required = false, help } = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'pillToggle';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'pill-toggle');

  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-3';
    const row = document.createElement('div');
    row.className = 'flex items-center';

    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-sm font-semibold';
    row.appendChild(labelEl);

    const { trigger, panel } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger && panel) {
      wrap.setAttribute('data-help-scope', '');
      row.appendChild(trigger);
      header.appendChild(row);
      header.appendChild(panel);
    } else {
      header.appendChild(row);
    }
    wrap.appendChild(header);
  }

  const group = document.createElement('div');
  group.className = 'inline-flex p-1 rounded-full bg-gray-100 dark:bg-[#1a1a1a] border border-gray-200 dark:border-[#333]';
  wrap.appendChild(group);

  let selected = defaultValue;
  const buttons = [];

  // Sync to global form data
  const syncToGlobal = () => updateFormData(fieldKey, selected);

  function apply() {
    for (const { btn, value } of buttons) {
      const active = value === selected;
      btn.className =
        'px-5 py-2 rounded-full text-sm font-medium transition-all ' +
        (active
          ? 'bg-primary/90 text-primary-foreground shadow-md'
          : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white');
    }
  }

  const normalizedOptions = (Array.isArray(options) ? options : [])
    .map((opt) => {
      if (opt && typeof opt === 'object') {
        return { value: String(opt.value), label: String(opt.label ?? opt.value) };
      }
      return { value: String(opt), label: String(opt) };
    });

  for (const opt of normalizedOptions) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = opt.label;
    btn.addEventListener('click', () => {
      selected = opt.value;
      apply();
      syncToGlobal();
    });
    group.appendChild(btn);
    buttons.push({ btn, value: opt.value });
  }

  apply();
  syncToGlobal(); // Initial sync

  return {
    wrap,
    getValue: () => selected,
    setValue: (v) => { selected = v; apply(); syncToGlobal(); },
  };
}
