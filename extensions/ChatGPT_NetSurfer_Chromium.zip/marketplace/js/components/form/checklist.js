/**
 * Checklist field component.
 * Renders a multi-checkbox grid with custom visual checkboxes and form data sync.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createChecklistField({
  label,
  id,
  required = false,
  help,
  options = [],
  defaultChecked = [],
  columns = 2,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'checklist';
  if (id) wrap.setAttribute('data-id', id);

  // --- Header ---
  const header = document.createElement('div');
  header.className = 'mb-2';
  const row = document.createElement('div');
  row.className = 'flex items-center';
  const labelEl = createFieldLabel(label, { required });
  labelEl.className = 'block text-sm font-medium mx-2';
  row.appendChild(labelEl);
  const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
  if (trigger) {
    wrap.setAttribute('data-help-scope', '');
    row.appendChild(trigger);
  }
  header.appendChild(row);
  wrap.appendChild(header);

  // --- Checkbox grid ---
  const checks = new Map();

  const syncToGlobal = () => {
    const out = [];
    for (const [key, cb] of checks.entries()) {
      if (cb.checked) out.push(key);
    }
    updateFormData(fieldKey, out.length > 0 ? out : undefined);
  };

  const cols = Math.max(1, Math.min(4, columns));
  const grid = document.createElement('div');
  grid.className = `grid grid-cols-${cols} gap-x-4 gap-y-2`;

  for (const opt of options) {
    const rowEl = document.createElement('label');
    rowEl.className = 'flex items-center gap-2 select-none cursor-pointer py-1.5';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'sr-only';
    cb.checked = defaultChecked.includes(opt.key);

    const visual = document.createElement('div');
    visual.className =
      'w-4 h-4 rounded border-2 flex items-center justify-center transition-colors shrink-0';

    const checkIcon = document.createElement('span');
    checkIcon.innerHTML =
      '<svg class="w-2.5 h-2.5 text-white" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>';

    function syncVisual() {
      if (cb.checked) {
        visual.className =
          'w-4 h-4 rounded border-2 border-primary/90 bg-primary/90 flex items-center justify-center transition-colors shrink-0';
        checkIcon.style.display = '';
      } else {
        visual.className =
          'w-4 h-4 rounded border-2 border-gray-300 dark:border-gray-600 bg-white dark:bg-[#141414] flex items-center justify-center transition-colors shrink-0';
        checkIcon.style.display = 'none';
      }
    }

    visual.appendChild(checkIcon);
    syncVisual();

    cb.addEventListener('change', () => {
      syncVisual();
      syncToGlobal();
    });

    rowEl.appendChild(cb);
    rowEl.appendChild(visual);

    const span = document.createElement('span');
    span.className = 'text-[13px] text-gray-700 dark:text-gray-300';
    span.textContent = opt.label;
    rowEl.appendChild(span);

    grid.appendChild(rowEl);
    checks.set(opt.key, cb);
  }

  wrap.appendChild(grid);
  syncToGlobal();

  // --- Error ---
  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function setError(message) {
    if (!message) { errorEl.textContent = ''; errorEl.classList.add('hidden'); return; }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
  }
  function clearError() { setError(''); }

  return {
    wrap,
    getValues: () => {
      const out = [];
      for (const [key, cb] of checks.entries()) {
        if (cb.checked) out.push(key);
      }
      return out;
    },
    setValue: (keys) => {
      const set = new Set(Array.isArray(keys) ? keys : []);
      for (const [key, cb] of checks.entries()) {
        cb.checked = set.has(key);
      }
      // Sync visuals
      for (const rowEl of grid.querySelectorAll('label')) {
        const cb = rowEl.querySelector('input');
        if (cb) cb.dispatchEvent(new Event('change'));
      }
    },
    setError,
    clearError,
  };
}
