/**
 * Editable select component: preset dropdown + inline custom input.
 * Works like createSelectField but adds a text input at the bottom of the
 * dropdown so users can type a custom value, press Enter, and have it
 * added & selected.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createEditableSelect({
  label,
  id,
  options = [],
  defaultValue,
  required = false,
  help,
  placeholder = 'Search or type custom value',
  autoSelectFirst = true,
  onChange,
  triggerLabel,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'editableSelect';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'editable-select');

  /* ── header (label + help) ── */
  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const headerRow = document.createElement('div');
    headerRow.className = 'flex items-center';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-[13px] font-medium mx-2';
    headerRow.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      headerRow.appendChild(trigger);
    }
    header.appendChild(headerRow);
    wrap.appendChild(header);
  }

  /* ── normalise options ── */
  const capitalize = s => s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
  const normalizedOptions = (Array.isArray(options) ? options : []).map(opt => ({
    value: String(opt?.value ?? ''),
    label: capitalize(String(opt?.label ?? opt?.value ?? '')),
  }));

  /* ── state ── */
  let selected = (() => {
    const desired = defaultValue != null ? String(defaultValue) : null;
    if (desired != null && normalizedOptions.some(o => o.value === desired)) return desired;
    if (autoSelectFirst) return normalizedOptions.length > 0 ? normalizedOptions[0].value : '';
    return '';
  })();

  const placeholderLabel = typeof triggerLabel === 'string' && triggerLabel
    ? triggerLabel
    : 'Select...';

  const selectedLabel = () => {
    if (!selected) return placeholderLabel;
    const opt = normalizedOptions.find(o => o.value === selected);
    return opt ? opt.label : selected;
  };

  /* ── trigger button ── */
  const dropdownBtn = document.createElement('button');
  dropdownBtn.type = 'button';
  dropdownBtn.className =
    'w-full flex items-center justify-between rounded-[16px] bg-panel-input ' +
    'border border-panel-border ' +
    'px-4 h-12 cursor-pointer hover:bg-panel-hover transition-colors ' +
    'focus:outline-none focus:border-[#D9D9D9]/40 dark:focus:border-[#D9D9D9]/20';

  const btnContent = document.createElement('div');
  btnContent.className = 'text-left min-w-0 flex-1';

  const btnValue = document.createElement('div');
  btnValue.className = 'text-[13px] font-semibold text-gray-900 dark:text-white truncate';
  btnValue.textContent = selectedLabel();

  btnContent.appendChild(btnValue);

  const chevron = document.createElement('div');
  chevron.className = 'text-gray-500 dark:text-gray-400 shrink-0 ml-2';
  chevron.innerHTML =
    '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">' +
    '<path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>';

  dropdownBtn.appendChild(btnContent);
  dropdownBtn.appendChild(chevron);

  /* ── dropdown menu ── */
  const dropdownMenu = document.createElement('div');
  dropdownMenu.className =
    'hidden fixed z-[9999] rounded-[16px] bg-panel-input ' +
    'border border-[#D9D9D9]/20 dark:border-[#333] shadow-2xl overflow-y-auto max-h-[280px]';

  /* ── options list container ── */
  const optionsList = document.createElement('div');

  const checkSvg =
    '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">' +
    '<path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>';

  function createOptionButton(opt) {
    const item = document.createElement('button');
    item.type = 'button';
    item.className =
      'w-full flex items-center justify-between px-4 py-3 text-left text-[13px] ' +
      'text-gray-900 dark:text-white hover:bg-panel-hover transition-colors';
    item.dataset.value = opt.value;

    const itemLabel = document.createElement('span');
    itemLabel.textContent = opt.label;

    const itemCheck = document.createElement('span');
    itemCheck.className = opt.value === selected ? 'text-primary/90' : 'invisible';
    itemCheck.innerHTML = checkSvg;

    item.appendChild(itemLabel);
    item.appendChild(itemCheck);

    item.addEventListener('click', () => {
      applySelection(opt);
    });

    return item;
  }

  normalizedOptions.forEach(opt => {
    optionsList.appendChild(createOptionButton(opt));
  });

  function updateChecks() {
    optionsList.querySelectorAll('button').forEach(btn => {
      const check = btn.querySelector('span:last-child');
      if (check) {
        check.className = btn.dataset.value === selected ? 'text-primary/90' : 'invisible';
      }
    });
  }

  /* ── inline search / custom input ── */
  const inputWrap = document.createElement('div');
  inputWrap.className =
    'sticky top-0 z-10 bg-panel-input border-b border-black/5 dark:border-white/[0.06]';

  const customInput = document.createElement('input');
  customInput.type = 'text';
  customInput.placeholder = placeholder;
  customInput.className =
    'px-4 py-2.5 text-[13px] bg-transparent w-full outline-none ' +
    'text-gray-900 dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-500';

  inputWrap.appendChild(customInput);

  const emptyState = document.createElement('div');
  emptyState.className =
    'hidden px-4 py-3 text-[12px] text-gray-400 dark:text-gray-500 italic';

  dropdownMenu.appendChild(inputWrap);
  dropdownMenu.appendChild(optionsList);
  dropdownMenu.appendChild(emptyState);

  function filterOptions(term) {
    const q = String(term || '').trim().toLowerCase();
    let visible = 0;
    optionsList.querySelectorAll('button').forEach(btn => {
      const label = (btn.textContent || '').toLowerCase();
      const value = String(btn.dataset.value || '').toLowerCase();
      const match = !q || label.includes(q) || value.includes(q);
      btn.classList.toggle('hidden', !match);
      if (match) visible += 1;
    });

    if (q && visible === 0) {
      emptyState.textContent = `Press Enter to add “${term.trim()}”`;
      emptyState.classList.remove('hidden');
    } else {
      emptyState.classList.add('hidden');
    }
    return visible;
  }

  /* ── apply a selection ── */
  function applySelection(opt) {
    selected = opt.value;
    btnValue.textContent = opt.label;
    customInput.value = '';
    filterOptions('');
    closeMenu();
    updateChecks();
    syncToGlobal();
    if (typeof onChange === 'function') {
      try { onChange(opt.value, opt); } catch { /* swallow */ }
    }
  }

  // Filter the list as the user types.
  customInput.addEventListener('input', () => {
    filterOptions(customInput.value);
    if (!dropdownMenu.classList.contains('hidden')) positionDropdown();
  });

  customInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeMenu();
      return;
    }
    if (e.key !== 'Enter') return;
    e.preventDefault();
    const val = customInput.value.trim();
    if (!val) return;

    //  Exact match on value or label
    const exact = normalizedOptions.find(
      o => o.value.toLowerCase() === val.toLowerCase() ||
           o.label.toLowerCase() === val.toLowerCase()
    );
    if (exact) { applySelection(exact); return; }

    // Otherwise pick the first option still visible after filtering
    const firstVisible = optionsList.querySelector('button:not(.hidden)');
    if (firstVisible) {
      const v = firstVisible.dataset.value;
      const opt = normalizedOptions.find(o => o.value === v);
      if (opt) { applySelection(opt); return; }
    }

    // No match anywhere, add as a new custom option and select it.
    const newOpt = { value: val, label: capitalize(val) };
    normalizedOptions.push(newOpt);
    optionsList.appendChild(createOptionButton(newOpt));
    applySelection(newOpt);
  });

  // Prevent click on input from closing dropdown
  customInput.addEventListener('click', (e) => {
    e.stopPropagation();
  });

  /* ── positioning ── */
  function positionDropdown() {
    const btnRect = dropdownBtn.getBoundingClientRect();
    const spaceBelow = window.innerHeight - btnRect.bottom;
    const spaceAbove = btnRect.top;
    const menuHeight = Math.min(280, (normalizedOptions.length + 1) * 48);

    const minWidth = 200;
    const dropdownWidth = Math.max(minWidth, btnRect.width);
    dropdownMenu.style.width = `${dropdownWidth}px`;
    let leftPos = btnRect.left;
    leftPos = Math.min(leftPos, window.innerWidth - dropdownWidth - 8);
    leftPos = Math.max(8, leftPos);
    dropdownMenu.style.left = `${leftPos}px`;

    if (spaceBelow < menuHeight && spaceAbove > spaceBelow) {
      dropdownMenu.style.bottom = `${window.innerHeight - btnRect.top + 4}px`;
      dropdownMenu.style.top = 'auto';
    } else {
      dropdownMenu.style.top = `${btnRect.bottom + 4}px`;
      dropdownMenu.style.bottom = 'auto';
    }
  }

  /* ── open / close ── */
  function openMenu() {
    customInput.value = '';
    filterOptions('');
    positionDropdown();
    dropdownMenu.classList.remove('hidden');
  }
  function closeMenu() {
    dropdownMenu.classList.add('hidden');
  }

  dropdownBtn.addEventListener('click', () => {
    if (dropdownMenu.classList.contains('hidden')) openMenu();
    else closeMenu();
  });

  document.addEventListener('click', (e) => {
    if (!wrap.contains(e.target) && !dropdownMenu.contains(e.target)) {
      dropdownMenu.classList.add('hidden');
    }
  });

  window.addEventListener('scroll', () => {
    if (!dropdownMenu.classList.contains('hidden')) positionDropdown();
  }, true);

  const row = document.createElement('div');
  row.className = 'relative';
  row.appendChild(dropdownBtn);
  document.body.appendChild(dropdownMenu);
  wrap.appendChild(row);

  /* ── form data sync ── */
  const syncToGlobal = () => updateFormData(fieldKey, selected);
  syncToGlobal();

  /* ── error display ── */
  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      dropdownBtn.style.outline = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    dropdownBtn.style.outline = '1.5px solid #f87171';
  }

  function clearError() {
    setError('');
  }

  return {
    wrap,
    getValue: () => selected,
    setValue: (v) => {
      const next = v == null ? '' : String(v);
      if (normalizedOptions.some(o => o.value === next)) {
        selected = next;
        btnValue.textContent = selectedLabel();
        updateChecks();
        syncToGlobal();
      }
    },
    reset: () => {
      selected = '';
      btnValue.textContent = selectedLabel();
      updateChecks();
      syncToGlobal();
    },
    setError,
    clearError,
  };
}
