/**
 * Multi-select dropdown component.
 * Renders a select-box style button that opens a dropdown with checkboxes.
 * Multiple options can be toggled on/off.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createMultiSelect({
  label,
  id,
  options = [],
  defaultValue,
  required = false,
  help,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'multiSelect';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'multi-select');

  const hasLabel = label && String(label).trim();
  if (hasLabel) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const headerRow = document.createElement('div');
    headerRow.className = 'flex items-center';
    const labelEl = createFieldLabel(String(label), { required });
    labelEl.className = 'block text-[13px] font-medium mx-2';
    headerRow.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      headerRow.appendChild(trigger);
    }
    header.appendChild(headerRow);
    wrap.appendChild(header);
  }

  const capitalize = s => s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
  const normalizedOptions = (Array.isArray(options) ? options : []).map(opt => {
    if (opt && typeof opt === 'object') {
      return { value: String(opt.value), label: capitalize(String(opt.label ?? opt.value)) };
    }
    return { value: String(opt), label: capitalize(String(opt)) };
  });

  const selected = new Set();
  if (defaultValue != null) {
    String(defaultValue).split(',').map(s => s.trim()).filter(Boolean).forEach(v => selected.add(v));
  }

  const getValueString = () => [...selected].join(',');
  const syncToGlobal = () => updateFormData(fieldKey, getValueString());

  function renderPills() {
    pillWrap.innerHTML = '';
    if (selected.size === 0) {
      const placeholder = document.createElement('span');
      placeholder.className = 'text-[13px] text-gray-400 dark:text-gray-500';
      placeholder.textContent = 'Select...';
      pillWrap.appendChild(placeholder);
      return;
    }
    for (const opt of normalizedOptions) {
      if (!selected.has(opt.value)) continue;
      const pill = document.createElement('span');
      pill.className =
        'inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[12px] font-medium ' +
        'bg-primary/15 text-primary dark:bg-primary/20';
      pill.textContent = opt.label;

      const x = document.createElement('button');
      x.type = 'button';
      x.className = 'ml-0.5 hover:text-red-400 transition-colors leading-none text-[14px]';
      x.innerHTML = '&times;';
      x.setAttribute('aria-label', `Remove ${opt.label}`);
      x.addEventListener('click', (e) => {
        e.stopPropagation();
        selected.delete(opt.value);
        renderPills();
        updateChecks();
        syncToGlobal();
      });
      pill.appendChild(x);
      pillWrap.appendChild(pill);
    }
  }

  const dropdownBtn = document.createElement('button');
  dropdownBtn.type = 'button';
  dropdownBtn.className =
    'w-full flex items-center justify-between rounded-[0.75rem] bg-panel-input ' +
    'border border-panel-border ' +
    'px-3 py-2 cursor-pointer hover:bg-panel-hover transition-colors ' +
    'focus:outline-none focus:border-[#D9D9D9]/40 dark:focus:border-[#D9D9D9]/20';
  dropdownBtn.style.minHeight = '3rem';

  const btnContent = document.createElement('div');
  btnContent.className = 'text-left min-w-0 flex-1';

  const pillWrap = document.createElement('div');
  pillWrap.className = 'flex flex-wrap gap-1.5';
  renderPills();
  btnContent.appendChild(pillWrap);

  const clearBtn = document.createElement('button');
  clearBtn.type = 'button';
  clearBtn.className = 'shrink-0 ml-1 p-0.5 rounded-full text-gray-400 hover:text-red-400 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors';
  clearBtn.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>`;
  clearBtn.setAttribute('aria-label', 'Clear all');
  clearBtn.style.display = selected.size > 0 ? '' : 'none';
  clearBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    selected.clear();
    updateChecks();
    syncToGlobal();
    clearBtn.style.display = 'none';
  });

  const chevron = document.createElement('div');
  chevron.className = 'text-gray-500 dark:text-gray-400 shrink-0 ml-1 transition-transform';
  chevron.innerHTML = `
    <svg class="w-4 h-4" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M2.21999 5.93998C2.21999 5.81332 2.26665 5.68665 2.36665 5.58665C2.55999 5.39332 2.87999 5.39332 3.07332 5.58665L7.41999 9.93332C7.73999 10.2533 8.25999 10.2533 8.57999 9.93332L12.9267 5.58665C13.12 5.39332 13.44 5.39332 13.6333 5.58665C13.8267 5.77998 13.8267 6.09998 13.6333 6.29332L9.28665 10.64C8.94665 10.98 8.48665 11.1733 7.99999 11.1733C7.51332 11.1733 7.05332 10.9867 6.71332 10.64L2.36665 6.29332C2.27332 6.19332 2.21999 6.06665 2.21999 5.93998Z"/>
    </svg>
  `;

  dropdownBtn.appendChild(btnContent);
  dropdownBtn.appendChild(clearBtn);
  dropdownBtn.appendChild(chevron);

  const dropdownMenu = document.createElement('div');
  dropdownMenu.className =
    'hidden fixed z-[9999] rounded-[16px] bg-panel-input ' +
    'border border-[#D9D9D9]/20 dark:border-[#333] shadow-2xl overflow-y-auto max-h-[280px]';

  function positionDropdown() {
    const btnRect = dropdownBtn.getBoundingClientRect();
    const spaceBelow = window.innerHeight - btnRect.bottom;
    const spaceAbove = btnRect.top;
    const menuHeight = Math.min(280, normalizedOptions.length * 48);

    const minWidth = 200;
    const dropdownWidth = Math.max(minWidth, btnRect.width);
    dropdownMenu.style.width = `${dropdownWidth}px`;
    let leftPos = btnRect.left;
    leftPos = Math.min(leftPos, window.innerWidth - dropdownWidth - 8);
    leftPos = Math.max(8, leftPos);
    dropdownMenu.style.left = `${leftPos}px`;

    if (spaceBelow < menuHeight && spaceAbove > spaceBelow) {
      dropdownMenu.style.bottom = `${window.innerHeight - btnRect.top + 4}px`;
      dropdownMenu.style.top = 'auto';
    } else {
      dropdownMenu.style.top = `${btnRect.bottom + 4}px`;
      dropdownMenu.style.bottom = 'auto';
    }
  }

  function updateChecks() {
    dropdownMenu.querySelectorAll('button[data-value]').forEach(btn => {
      const check = btn.querySelector('.ms-check');
      if (check) {
        const isSelected = selected.has(btn.dataset.value);
        check.className = 'ms-check ' + (isSelected ? 'text-primary/90' : 'invisible');
      }
    });
    renderPills();
    clearBtn.style.display = selected.size > 0 ? '' : 'none';
  }

  normalizedOptions.forEach((opt) => {
    const item = document.createElement('button');
    item.type = 'button';
    item.className =
      'w-full flex items-center justify-between px-4 py-3 text-left text-[13px] ' +
      'text-gray-900 dark:text-white hover:bg-panel-hover transition-colors';
    item.dataset.value = opt.value;

    const itemLabel = document.createElement('span');
    itemLabel.textContent = opt.label;

    const itemCheck = document.createElement('span');
    itemCheck.className = 'ms-check ' + (selected.has(opt.value) ? 'text-primary/90' : 'invisible');
    itemCheck.innerHTML = `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>`;

    item.appendChild(itemLabel);
    item.appendChild(itemCheck);
    dropdownMenu.appendChild(item);

    item.addEventListener('click', (e) => {
      e.stopPropagation();
      if (selected.has(opt.value)) {
        selected.delete(opt.value);
      } else {
        selected.add(opt.value);
      }
      updateChecks();
      syncToGlobal();
    });
  });

  dropdownBtn.addEventListener('click', () => {
    const wasHidden = dropdownMenu.classList.contains('hidden');
    if (wasHidden) positionDropdown();
    dropdownMenu.classList.toggle('hidden');
  });

  document.addEventListener('click', (e) => {
    if (!wrap.contains(e.target) && !dropdownMenu.contains(e.target)) {
      dropdownMenu.classList.add('hidden');
    }
  });

  window.addEventListener('scroll', () => {
    if (!dropdownMenu.classList.contains('hidden')) positionDropdown();
  }, true);

  const row = document.createElement('div');
  row.className = 'relative';
  row.appendChild(dropdownBtn);
  document.body.appendChild(dropdownMenu);
  wrap.appendChild(row);

  syncToGlobal();

  return {
    wrap,
    getValue: getValueString,
    setValue: (v) => {
      selected.clear();
      if (v != null) {
        String(v).split(',').map(s => s.trim()).filter(Boolean).forEach(val => selected.add(val));
      }
      updateChecks();
      syncToGlobal();
    },
  };
}
