/**
 * Chip group component (single-select pill/button group).
 * Renders a row of mutually exclusive buttons styled as chips.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createChipGroup({
  label,
  id,
  options = [],
  defaultValue,
  required = false,
  help,
  layout = 'row', // 'row' | 'wrap'
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'chipGroup';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'chip-group');

  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-3';
    const row = document.createElement('div');
    row.className = 'flex items-center';
    const labelEl = createFieldLabel(String(label), { required });
    labelEl.className = 'block text-sm font-semibold mx-2';
    row.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      row.appendChild(trigger);
    }
    header.appendChild(row);
    wrap.appendChild(header);
  }

  const group = document.createElement('div');
  group.className = layout === 'wrap'
    ? 'flex flex-wrap gap-1.5'
    : 'flex flex-wrap gap-1.5 p-1 rounded-2xl bg-neutral-100 dark:bg-neutral-900';
  group.setAttribute('role', 'radiogroup');
  wrap.appendChild(group);

  const normalizedOptions = (Array.isArray(options) ? options : [])
    .map((opt) => {
      if (opt && typeof opt === 'object') {
        return { value: String(opt.value), label: String(opt.label ?? opt.value) };
      }
      return { value: String(opt), label: String(opt) };
    });

  // No silent auto-select when there's no default. Leaving `selected` empty
  // makes every chip render unselected (aria-checked="false"), so a required
  // enum field correctly fails validation with "Please fill out this field"
  // until the user actually picks one. Auto-selecting the first chip masked
  // the required check entirely.
  let selected = defaultValue != null && normalizedOptions.some((opt) => opt.value === String(defaultValue))
    ? String(defaultValue)
    : '';
  const buttons = [];

  function apply() {
    for (const { btn, value } of buttons) {
      const active = value === selected;
      btn.setAttribute('aria-checked', active ? 'true' : 'false');
      btn.className =
        'px-3 py-1.5 rounded-lg text-sm font-medium transition-all ' +
        (active
          ? 'bg-primary/90 text-primary-foreground shadow-md'
          : 'bg-neutral-100 dark:bg-neutral-800 text-gray-700 dark:text-gray-300 hover:bg-neutral-200 dark:hover:bg-neutral-700');
    }
  }

  // Sync to global form data
  const syncToGlobal = () => updateFormData(fieldKey, selected);

  for (const opt of normalizedOptions) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.setAttribute('role', 'radio');
    btn.textContent = opt.label;
    btn.addEventListener('click', () => {
      selected = opt.value;
      apply();
      syncToGlobal();
    });
    group.appendChild(btn);
    buttons.push({ btn, value: opt.value });
  }

  apply();
  syncToGlobal(); // Initial sync

  return {
    wrap,
    getValue: () => selected,
    setValue: (v) => {
      selected = v == null ? '' : String(v);
      apply();
      syncToGlobal();
    },
  };
}

