/**
 * Voice picker: the single voice control for the voice-cloner agent, replacing a
 * free-text "Voice ID" box. Three sections — the voices the user has cloned, the
 * selected model's built-in presets, and a paste-an-ID escape hatch (typed ids
 * stay legal; the model gating layer warns and confirms instead of blocking).
 *
 * Selections travel both ways over the shared voice-selection bus: this widget
 * publishes what the user picks so the model dropdown can react, and reflects
 * what other surfaces publish ("Generate with this voice", creation history) so
 * the visible label and the submitted value can never disagree.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';
import {
  setVoiceSelection,
  getVoiceSelection,
  onVoiceSelectionChange,
  canonicalVoiceFamily,
} from '../../runner/voice-selection-state.js';

const AGENT_ID = 'voice-cloner';
const DEFAULT_VOICE_LABEL = 'Model default voice';
const NO_PRESETS_TEXT = 'This model has no built-in voices — pick one of yours, clone a new one, or paste an ID.';
const NOTICE_TIMEOUT_MS = 8000;
// Mirrors the max-h-[320px] utility below; Tailwind ships precompiled here, so
// the class has to be a literal the stylesheet already contains.
const MENU_MAX_HEIGHT_PX = 320;

const FAMILY_LABELS = {
  elevenlabs: 'ElevenLabs',
  minimax: 'MiniMax',
  qwen: 'Qwen3',
  'reference-audio': 'Reference audio',
};

const CHEVRON_SVG =
  '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">' +
  '<path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>';
const CHECK_SVG =
  '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">' +
  '<path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>';
const PLAY_SVG =
  '<svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>';
const PAUSE_SVG =
  '<svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>';

/** Preset lists never change within a session, so one fetch per model is enough. */
const presetCache = new Map();

/** @returns {Promise<string[]|null>} preset names, [] when the model has none, null when unknown */
function fetchPresetVoices(modelId) {
  if (!modelId) return Promise.resolve([]);
  const cached = presetCache.get(modelId);
  if (cached) return cached;

  const promise = (async () => {
    try {
      const res = await fetch(
        `https://aitopia.ai/api/models/schema?modelId=${encodeURIComponent(modelId)}&agentId=${AGENT_ID}`,
        { credentials: 'include', headers: { Accept: 'application/json' } },
      );
      if (!res.ok) return null;
      const json = await res.json();
      // Some callers get the schema at the top level, others nested under `schema`.
      const properties = json?.properties || json?.schema?.properties || {};
      const values = properties?.voice?.enum;
      return Array.isArray(values) ? values.map(String) : [];
    } catch {
      return null;
    }
  })();

  presetCache.set(modelId, promise);
  // A failed fetch must not freeze the model into "no built-in voices".
  promise.then((list) => { if (list === null) presetCache.delete(modelId); });
  return promise;
}

/** Same signal the runner uses elsewhere: a cached profile means signed in. */
function isSignedIn() {
  const profile = window.AitopiaCache?.getUserProfile?.();
  return Boolean(profile && typeof profile === 'object' && !Array.isArray(profile)
    && (profile.email || profile.key));
}

/** @returns {Promise<{voices: Array<object>, message: string}>} */
async function fetchClonedVoices() {
  // A signed-out visitor gets 200 with an empty list, not a 401 — and their
  // clones are never persisted, so the empty state has to say that.
  const emptyMessage = isSignedIn()
    ? 'No cloned voices yet — clone one and it appears here.'
    : 'Sign in to build a voice library — voices cloned while signed out are not saved.';
  try {
    const res = await fetch('https://aitopia.ai/api/voices', { credentials: 'include', headers: { Accept: 'application/json' } });
    if (!res.ok) return { voices: [], message: 'Could not load your voices right now.' };
    const json = await res.json();
    const voices = Array.isArray(json?.voices) ? json.voices : [];
    return { voices, message: voices.length ? '' : emptyMessage };
  } catch {
    return { voices: [], message: 'Could not load your voices right now.' };
  }
}

function readSelectedModelId() {
  const modelSelect = document.querySelector('select[id^="modelSelect"]');
  return typeof modelSelect?.value === 'string' ? modelSelect.value : '';
}

export function createVoicePicker({ label, id, required = false, help, defaultValue } = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'voicePicker';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'voice-picker');

  /* ── header (label + help) ── */
  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const headerRow = document.createElement('div');
    headerRow.className = 'flex items-center';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-[13px] font-medium mx-2';
    headerRow.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      headerRow.appendChild(trigger);
    }
    header.appendChild(headerRow);
    wrap.appendChild(header);
  }

  /* ── state ── */
  let selection = { kind: 'none', family: null, voiceId: '', name: '' };
  let clonedVoices = [];
  let presetNames = [];
  let currentModelId = null;
  let noticeTimer = null;
  let unsubscribeVoiceSelection = () => {};

  /* ── trigger button ── */
  const dropdownBtn = document.createElement('button');
  dropdownBtn.type = 'button';
  dropdownBtn.className =
    'w-full flex items-center justify-between rounded-[16px] bg-panel-input ' +
    'border border-panel-border ' +
    'px-4 h-12 cursor-pointer hover:bg-panel-hover transition-colors ' +
    'focus:outline-none focus:border-[#D9D9D9]/40 dark:focus:border-[#D9D9D9]/20';

  const btnContent = document.createElement('div');
  btnContent.className = 'text-left min-w-0 flex-1';
  const btnValue = document.createElement('div');
  btnValue.className = 'text-[13px] font-semibold text-gray-900 dark:text-white truncate';
  const btnMeta = document.createElement('div');
  btnMeta.className = 'text-[11px] text-gray-500 dark:text-gray-400 truncate';
  btnContent.appendChild(btnValue);
  btnContent.appendChild(btnMeta);

  const chevron = document.createElement('div');
  chevron.className = 'text-gray-500 dark:text-gray-400 shrink-0 ml-2';
  chevron.innerHTML = CHEVRON_SVG;

  dropdownBtn.appendChild(btnContent);
  dropdownBtn.appendChild(chevron);

  const row = document.createElement('div');
  row.className = 'relative';
  row.appendChild(dropdownBtn);
  wrap.appendChild(row);

  const noticeEl = document.createElement('p');
  noticeEl.className = 'mt-1 text-[11px] leading-normal text-amber-600 dark:text-amber-400 hidden';
  noticeEl.setAttribute('role', 'status');
  wrap.appendChild(noticeEl);

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  /* ── dropdown menu ── */
  const dropdownMenu = document.createElement('div');
  dropdownMenu.className =
    'hidden fixed z-[9999] rounded-[16px] bg-panel-input ' +
    'border border-[#D9D9D9]/20 dark:border-[#333] shadow-2xl overflow-y-auto max-h-[320px]';
  // Never carries data-id: the form's visibleWhen and submit-time strip both
  // resolve fields by [data-id] and must find the wrap, not this body-level menu.
  dropdownMenu.setAttribute('data-component', 'voice-picker-menu');
  document.body.appendChild(dropdownMenu);

  const previewAudio = typeof Audio === 'function' ? new Audio() : null;
  let activePlayBtn = null;

  function stopPreview() {
    if (previewAudio) {
      previewAudio.pause();
      previewAudio.currentTime = 0;
    }
    if (activePlayBtn) {
      activePlayBtn.innerHTML = PLAY_SVG;
      activePlayBtn = null;
    }
  }
  if (previewAudio) previewAudio.addEventListener('ended', stopPreview);

  function createPlayButton(previewUrl) {
    const playBtn = document.createElement('span');
    playBtn.setAttribute('role', 'button');
    playBtn.setAttribute('tabindex', '0');
    playBtn.setAttribute('aria-label', 'Play voice preview');
    playBtn.className =
      'inline-flex items-center justify-center w-6 h-6 rounded-full shrink-0 ' +
      'bg-black/5 dark:bg-white/10 text-gray-700 dark:text-gray-200 hover:bg-black/10 dark:hover:bg-white/20';
    playBtn.innerHTML = PLAY_SVG;
    const togglePreview = (e) => {
      // The row itself is a button, so a bubbling click would select the voice.
      e.stopPropagation();
      if (!previewAudio) return;
      const wasActive = activePlayBtn === playBtn;
      stopPreview();
      if (wasActive) return;
      previewAudio.src = previewUrl;
      activePlayBtn = playBtn;
      playBtn.innerHTML = PAUSE_SVG;
      previewAudio.play().catch(() => stopPreview());
    };
    playBtn.addEventListener('click', togglePreview);
    playBtn.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      e.preventDefault();
      togglePreview(e);
    });
    return playBtn;
  }

  function createSection(title) {
    const section = document.createElement('div');
    section.className = 'border-t border-black/5 dark:border-white/[0.06] first:border-t-0';
    const heading = document.createElement('div');
    heading.className =
      'px-4 pt-3 pb-1 text-[10px] font-semibold uppercase tracking-wide text-gray-400 dark:text-gray-500';
    heading.textContent = title;
    const body = document.createElement('div');
    section.appendChild(heading);
    section.appendChild(body);
    return { section, body };
  }

  function createOptionRow({ title, subtitle, badge, previewUrl, value }) {
    const item = document.createElement('button');
    item.type = 'button';
    item.className =
      'w-full flex items-center gap-2 px-4 py-2.5 text-left text-[13px] ' +
      'text-gray-900 dark:text-white hover:bg-panel-hover transition-colors';
    item.dataset.value = value;

    const text = document.createElement('div');
    text.className = 'min-w-0 flex-1';
    const titleEl = document.createElement('div');
    titleEl.className = 'truncate';
    titleEl.textContent = title;
    text.appendChild(titleEl);
    if (subtitle) {
      const subtitleEl = document.createElement('div');
      subtitleEl.className = 'text-[11px] text-gray-500 dark:text-gray-400 truncate';
      subtitleEl.textContent = subtitle;
      text.appendChild(subtitleEl);
    }
    item.appendChild(text);

    if (badge) {
      const badgeEl = document.createElement('span');
      badgeEl.className =
        'shrink-0 px-2 py-0.5 rounded-full text-[10px] font-medium ' +
        'bg-black/5 dark:bg-white/10 text-gray-600 dark:text-gray-300';
      badgeEl.textContent = badge;
      item.appendChild(badgeEl);
    }

    if (previewUrl && previewAudio) item.appendChild(createPlayButton(previewUrl));

    const check = document.createElement('span');
    check.className = value === selection.voiceId ? 'text-primary/90 shrink-0' : 'invisible shrink-0';
    check.innerHTML = CHECK_SVG;
    item.appendChild(check);

    return item;
  }

  function createEmptyRow(text) {
    const el = document.createElement('div');
    el.className = 'px-4 py-2.5 text-[12px] leading-relaxed text-gray-400 dark:text-gray-500';
    el.textContent = text;
    return el;
  }

  /* ── "Model default voice" ── */
  const defaultRow = createOptionRow({
    title: DEFAULT_VOICE_LABEL,
    subtitle: 'Let the model use its own voice',
    value: '',
  });
  defaultRow.addEventListener('click', () => applySelection({ kind: 'none' }));
  const defaultSection = document.createElement('div');
  defaultSection.appendChild(defaultRow);
  dropdownMenu.appendChild(defaultSection);

  /* ── "Your voices" ── */
  const yourVoices = createSection('Your voices');
  dropdownMenu.appendChild(yourVoices.section);

  function renderClonedVoices(voices, message) {
    yourVoices.body.innerHTML = '';
    if (!voices.length) {
      yourVoices.body.appendChild(createEmptyRow(message));
      return;
    }
    for (const voice of voices) {
      const voiceId = String(voice?.providerVoiceId || '');
      if (!voiceId) continue;
      const name = String(voice?.name || voiceId);
      const family = canonicalVoiceFamily(voice?.family);
      const item = createOptionRow({
        title: name,
        badge: FAMILY_LABELS[family] || 'Cloned',
        previewUrl: typeof voice?.previewUrl === 'string' ? voice.previewUrl : '',
        value: voiceId,
      });
      item.addEventListener('click', () => applySelection({ kind: 'cloned', family, voiceId, name }));
      yourVoices.body.appendChild(item);
    }
  }
  renderClonedVoices([], 'Loading your voices…');

  /* ── "Built-in voices" ── */
  const builtInVoices = createSection('Built-in voices');
  dropdownMenu.appendChild(builtInVoices.section);

  function renderPresets(names, message) {
    builtInVoices.body.innerHTML = '';
    if (!names.length) {
      builtInVoices.body.appendChild(createEmptyRow(message));
      return;
    }
    for (const name of names) {
      const item = createOptionRow({ title: name, value: name });
      item.addEventListener('click', () => applySelection({ kind: 'preset', voiceId: name, name }));
      builtInVoices.body.appendChild(item);
    }
  }
  renderPresets([], 'Loading this model’s voices…');

  /* ── "Paste a voice ID" ── */
  const pasteSection = createSection('Paste a voice ID');
  dropdownMenu.appendChild(pasteSection.section);

  const pasteToggle = document.createElement('button');
  pasteToggle.type = 'button';
  pasteToggle.className =
    'w-full flex items-center justify-between px-4 py-2.5 text-left text-[13px] ' +
    'text-gray-900 dark:text-white hover:bg-panel-hover transition-colors';
  pasteToggle.textContent = 'Enter a voice ID manually';

  const pasteRow = document.createElement('div');
  pasteRow.className = 'hidden px-4 pb-3 pt-1 flex items-center gap-2';
  const pasteInput = document.createElement('input');
  pasteInput.type = 'text';
  pasteInput.placeholder = 'Paste a voice ID';
  pasteInput.className =
    'flex-1 min-w-0 px-3 py-2 text-[13px] rounded-[12px] bg-transparent outline-none ' +
    'border border-[#D9D9D9]/30 dark:border-[#333] ' +
    'text-gray-900 dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-500';
  const pasteApply = document.createElement('button');
  pasteApply.type = 'button';
  pasteApply.textContent = 'Use';
  pasteApply.className =
    'shrink-0 px-3 py-2 rounded-[12px] text-[12px] font-medium ' +
    'bg-black/5 dark:bg-white/10 text-gray-800 dark:text-gray-100 hover:bg-black/10 dark:hover:bg-white/20';

  pasteRow.appendChild(pasteInput);
  pasteRow.appendChild(pasteApply);
  pasteSection.body.appendChild(pasteToggle);
  pasteSection.body.appendChild(pasteRow);

  function applyPastedValue() {
    const voiceId = pasteInput.value.trim();
    if (!voiceId) return;
    applySelection({ kind: 'pasted', voiceId });
  }

  pasteToggle.addEventListener('click', () => {
    pasteRow.classList.toggle('hidden');
    if (!pasteRow.classList.contains('hidden')) {
      positionDropdown();
      pasteInput.focus();
    }
  });
  pasteApply.addEventListener('click', applyPastedValue);
  pasteInput.addEventListener('click', (e) => e.stopPropagation());
  pasteInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { closeMenu(); return; }
    if (e.key !== 'Enter') return;
    e.preventDefault();
    applyPastedValue();
  });

  /* ── selection ── */
  function refreshTrigger() {
    if (!selection.voiceId) {
      btnValue.textContent = DEFAULT_VOICE_LABEL;
      btnMeta.textContent = 'No specific voice selected';
      return;
    }
    btnValue.textContent = selection.name || selection.voiceId;
    if (selection.kind === 'cloned') {
      btnMeta.textContent = `Your voice · ${FAMILY_LABELS[selection.family] || 'Cloned'}`;
    } else if (selection.kind === 'preset') {
      btnMeta.textContent = 'Built-in voice';
    } else {
      btnMeta.textContent = 'Pasted voice ID';
    }
  }

  function refreshChecks() {
    dropdownMenu.querySelectorAll('button[data-value]').forEach((item) => {
      const check = item.querySelector('span:last-child');
      if (!check) return;
      check.className = item.dataset.value === selection.voiceId ? 'text-primary/90 shrink-0' : 'invisible shrink-0';
    });
  }

  function commitSelection({ kind, family, voiceId, name }) {
    selection = {
      kind: kind || 'none',
      family: family || null,
      voiceId: voiceId || '',
      name: name || '',
    };
    refreshTrigger();
    refreshChecks();
    showNotice('');
    clearError();
    updateFormData(fieldKey, selection.voiceId);
    closeMenu();
  }

  function applySelection(next) {
    commitSelection(next);
    setVoiceSelection({ ...selection });
  }

  function showNotice(message) {
    if (noticeTimer) { clearTimeout(noticeTimer); noticeTimer = null; }
    if (!message) {
      noticeEl.textContent = '';
      noticeEl.classList.add('hidden');
      return;
    }
    noticeEl.textContent = message;
    noticeEl.classList.remove('hidden');
    noticeTimer = setTimeout(() => showNotice(''), NOTICE_TIMEOUT_MS);
  }

  /* ── loading ── */
  async function loadClonedVoices() {
    const { voices, message } = await fetchClonedVoices();
    if (!wrap.isConnected) return;
    clonedVoices = voices;
    renderClonedVoices(voices, message);
    if (!dropdownMenu.classList.contains('hidden')) positionDropdown();
  }

  async function loadPresets(modelId) {
    if (!modelId) {
      renderPresets([], 'Select a model to see its built-in voices.');
      return;
    }
    const list = await fetchPresetVoices(modelId);
    if (!wrap.isConnected || modelId !== currentModelId) return;
    presetNames = Array.isArray(list) ? list : [];
    renderPresets(presetNames, list === null ? 'Could not load this model’s voices.' : NO_PRESETS_TEXT);
    if (!dropdownMenu.classList.contains('hidden')) positionDropdown();
    // Only a known preset list can prove the selection is stale — a failed
    // fetch must not throw away the user's voice.
    if (list && selection.kind === 'preset' && !presetNames.includes(selection.voiceId)) {
      const droppedName = selection.name || selection.voiceId;
      applySelection({ kind: 'none' });
      showNotice(`“${droppedName}” isn’t available on this model — using the model default voice.`);
    }
  }

  function syncModel() {
    const modelId = readSelectedModelId();
    if (modelId === currentModelId) return;
    currentModelId = modelId;
    renderPresets([], 'Loading this model’s voices…');
    loadPresets(modelId);
  }

  /* ── positioning ── */
  function positionDropdown() {
    const btnRect = dropdownBtn.getBoundingClientRect();
    const spaceBelow = window.innerHeight - btnRect.bottom;
    const spaceAbove = btnRect.top;
    const menuHeight = Math.min(MENU_MAX_HEIGHT_PX, dropdownMenu.scrollHeight || MENU_MAX_HEIGHT_PX);

    const minWidth = 240;
    const dropdownWidth = Math.max(minWidth, btnRect.width);
    dropdownMenu.style.width = `${dropdownWidth}px`;
    let leftPos = Math.min(btnRect.left, window.innerWidth - dropdownWidth - 8);
    leftPos = Math.max(8, leftPos);
    dropdownMenu.style.left = `${leftPos}px`;

    if (spaceBelow < menuHeight && spaceAbove > spaceBelow) {
      dropdownMenu.style.bottom = `${window.innerHeight - btnRect.top + 4}px`;
      dropdownMenu.style.top = 'auto';
    } else {
      dropdownMenu.style.top = `${btnRect.bottom + 4}px`;
      dropdownMenu.style.bottom = 'auto';
    }
  }

  /* ── open / close ── */
  function openMenu() {
    syncModel();
    loadClonedVoices();
    positionDropdown();
    dropdownMenu.classList.remove('hidden');
  }

  function closeMenu() {
    stopPreview();
    dropdownMenu.classList.add('hidden');
  }

  /**
   * The form is re-rendered on the fly, so an instance can outlive its DOM.
   * Every document/window listener checks first and tears the stale instance
   * down — otherwise it would keep publishing selections over the live one.
   */
  function detachedFromDom() {
    if (wrap.isConnected) return false;
    document.removeEventListener('click', onDocumentClick);
    document.removeEventListener('change', onDocumentChange);
    window.removeEventListener('scroll', onWindowScroll, true);
    unsubscribeVoiceSelection();
    stopPreview();
    dropdownMenu.remove();
    return true;
  }

  function onDocumentClick(e) {
    if (detachedFromDom()) return;
    if (!wrap.contains(e.target) && !dropdownMenu.contains(e.target)) closeMenu();
  }

  function onDocumentChange(e) {
    if (detachedFromDom()) return;
    if (typeof e.target?.id === 'string' && e.target.id.startsWith('modelSelect')) syncModel();
  }

  function onWindowScroll() {
    if (detachedFromDom()) return;
    if (!dropdownMenu.classList.contains('hidden')) positionDropdown();
  }

  dropdownBtn.addEventListener('click', () => {
    if (dropdownMenu.classList.contains('hidden')) openMenu();
    else closeMenu();
  });
  document.addEventListener('click', onDocumentClick);
  document.addEventListener('change', onDocumentChange);
  window.addEventListener('scroll', onWindowScroll, true);

  // "Generate with this voice →" and the creation history publish a selection
  // without touching this widget, so the read direction is required: reflect
  // what they published instead of leaving the label and the submitted value
  // disagreeing. Only the shared state is trusted here — no re-classifying.
  unsubscribeVoiceSelection = onVoiceSelectionChange((next) => {
    if (detachedFromDom()) return;
    if (!next) return;
    // Our own publish comes straight back through here.
    if (next.voiceId === selection.voiceId && next.kind === selection.kind) return;
    commitSelection(next);
  });

  /* ── error display ── */
  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      dropdownBtn.style.outline = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    dropdownBtn.style.outline = '1.5px solid #f87171';
  }

  function clearError() {
    setError('');
  }

  function setValue(v) {
    const next = v == null ? '' : String(v);
    if (!next) { applySelection({ kind: 'none' }); return; }
    const cloned = clonedVoices.find(voice => String(voice?.providerVoiceId || '') === next);
    if (cloned) {
      applySelection({
        kind: 'cloned',
        family: canonicalVoiceFamily(cloned.family),
        voiceId: next,
        name: String(cloned.name || next),
      });
      return;
    }
    if (presetNames.includes(next)) {
      applySelection({ kind: 'preset', voiceId: next, name: next });
      return;
    }
    applySelection({ kind: 'pasted', voiceId: next });
  }

  refreshTrigger();
  updateFormData(fieldKey, selection.voiceId);
  syncModel();
  // An external surface can publish a voice before this widget exists — start
  // from the shared state so a late-built form never contradicts it. A live
  // selection outranks the schema default, which is static.
  const published = getVoiceSelection();
  if (published.voiceId) commitSelection(published);
  else if (defaultValue != null && String(defaultValue).trim()) setValue(String(defaultValue).trim());

  return {
    wrap,
    getValue: () => selection.voiceId,
    setValue,
    setError,
    clearError,
  };
}
