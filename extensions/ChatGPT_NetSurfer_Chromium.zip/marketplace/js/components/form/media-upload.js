/**
 * Media upload field component.
 * Supports file upload (drag-drop, picker, paste), URL input,
 * audio recording, preview (image/video/audio), and server upload.
 */
import {
  updateFormData, createFieldLabel, createHelpToggle,
  fileToBase64DataUrl, IMAGE_UPLOAD_ICON_LIGHT, IMAGE_UPLOAD_ICON_DARK,
} from '../../runner/overrides/ui.js';
import {
  acceptForKind, isFileTypeAccepted, maxBytesForKind, maxInlineBytesForKind, formatBytes, uploadFileToServer,
} from '../../shared/media.js';

export function createMediaField({
  label,
  id,
  required = false,
  kind = 'image', // 'image' | 'video' | 'audio' | 'imageOrVideo' | 'audioOrVideo'
  help,
  defaultValue,
  recording,
  dropzoneTitle,
  multiple = false,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'media';
  if (id) wrap.setAttribute('data-id', id);

  const hintId = `hint-${Math.random().toString(16).slice(2)}`;
  const errorId = `error-${Math.random().toString(16).slice(2)}`;
  const statusId = `status-${Math.random().toString(16).slice(2)}`;
  const fileInputId = `file-${Math.random().toString(16).slice(2)}`;

  const header = document.createElement('div');
  header.className = 'mb-3 media-field-header';
  const headerRow = document.createElement('div');
  headerRow.className = 'flex items-center';
  const titleText = String(label || 'Upload');
  const labelEl = createFieldLabel(titleText, { required });
  labelEl.className = 'agent-form-upload-title block mb-2 mt-2 mx-2';
  headerRow.appendChild(labelEl);
  const { trigger } = createHelpToggle({ idSeed: titleText, labelText: titleText, helpText: help });
  if (trigger) {
    wrap.setAttribute('data-help-scope', '');
    headerRow.appendChild(trigger);
  }
  header.appendChild(headerRow);
  wrap.appendChild(header);

  const isVideo = kind === 'video' || kind === 'imageOrVideo' || kind === 'audioOrVideo';
  const isAudio = kind === 'audio' || kind === 'audioOrVideo';

  let emptyIcon, emptyTitle, emptySubtitle;
  if (isVideo && !isAudio) {
    emptyIcon = `<svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 10.5l4.72-4.72a.75.75 0 011.28.53v11.38a.75.75 0 01-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 002.25-2.25v-9a2.25 2.25 0 00-2.25-2.25h-9A2.25 2.25 0 002.25 7.5v9a2.25 2.25 0 002.25 2.25z"/>
    </svg>`;
    emptyTitle = 'Upload Video';
    emptySubtitle = 'Video duration: 3-30 seconds';
  } else if (isAudio) {
    emptyIcon = `<svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M19.114 5.636a9 9 0 010 12.728M16.463 8.288a5.25 5.25 0 010 7.424M6.75 8.25l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z"/>
    </svg>`;
    emptyTitle = 'Upload Audio';
    emptySubtitle = 'MP3, WAV, OGG up to 20MB';
  } else {
    emptyIcon =
      '<span class="dark:hidden inline-block w-8 h-8">' + IMAGE_UPLOAD_ICON_LIGHT + '</span>' +
      '<span class="hidden dark:inline-block w-8 h-8">' + IMAGE_UPLOAD_ICON_DARK + '</span>';
    emptyTitle = dropzoneTitle || 'Upload Image';
    emptySubtitle = 'PNG, JPG, WEBP up to 10MB';
  }

  const acceptStr = acceptForKind(kind);
  const allowedDesc =
    kind === 'video' ? 'video files'
    : kind === 'audio' ? 'MP3, WAV, or OGG audio'
    : kind === 'audioOrVideo' ? 'audio or video files'
    : kind === 'imageOrVideo' ? 'images or videos'
    : 'PNG, JPG, or WEBP images';

  const card = document.createElement('div');
  card.className = 'rounded-2xl overflow-hidden';

  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = acceptStr;
  if (multiple) fileInput.multiple = true;
  fileInput.className = 'hidden';
  fileInput.id = fileInputId;

  const dropzone = document.createElement('button');
  dropzone.type = 'button';
  dropzone.className =
    'dropzone-empty relative w-full h-[115px] rounded-[16px] border border-dashed border-[#D9D9D9] dark:border-[#272727] ' +
    'bg-panel-input ' +
    'hover:border-[#ccc] dark:hover:border-[#3a3a3a] hover:bg-panel-hover transition-colors ' +
    'focus:outline-none focus:border-[#bbb] dark:focus:border-[#3a3a3a] ' +
    'px-4 py-5 flex flex-col items-center justify-center text-center gap-2';
  dropzone.setAttribute('aria-label', `Upload ${String(kind || 'media')} for ${String(label || 'field')}`);
  dropzone.setAttribute('aria-describedby', [hintId, errorId, statusId].filter(Boolean).join(' '));
  dropzone.setAttribute('aria-controls', fileInputId);
  dropzone.setAttribute('aria-roledescription', 'file dropzone');

  const dzInner = document.createElement('div');
  dzInner.className = 'flex flex-col items-center gap-2';

  const dzIcon = document.createElement('div');
  dzIcon.className = 'w-8 h-8 flex items-center justify-center';
  dzIcon.innerHTML = emptyIcon;

  const dzText = document.createElement('div');
  dzText.className = 'min-w-0 space-y-1';
  const dzTitle = document.createElement('div');
  dzTitle.className = 'agent-form-upload-title';
  dzTitle.textContent = emptyTitle;
  const dzSubtitle = document.createElement('div');
  dzSubtitle.className = 'agent-form-hint';
  dzSubtitle.textContent = emptySubtitle;
  dzText.appendChild(dzTitle);
  dzText.appendChild(dzSubtitle);

  dzInner.appendChild(dzIcon);
  dzInner.appendChild(dzText);
  dropzone.appendChild(dzInner);

  const urlInput = document.createElement('input');
  urlInput.type = 'url';
  urlInput.placeholder = 'Paste URL';
  urlInput.className =
    'mt-1.5 block w-full h-11 text-[13px] bg-panel-input ' +
    'border border-panel-border rounded-2xl px-5 ' +
    'text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-500 ' +
    'focus:outline-none focus:border-[#D9D9D9]/40 dark:focus:border-[#D9D9D9]/20 transition-colors hidden';
  urlInput.setAttribute('data-media-url', '');

  const hint = document.createElement('p');
  hint.id = hintId;
  hint.className = 'mt-2 px-1 text-xs text-gray-500 dark:text-gray-400 hidden';

  const errorEl = document.createElement('p');
  errorEl.id = errorId;
  errorEl.className = 'mt-1 px-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  errorEl.setAttribute('aria-live', 'polite');

  const busyEl = document.createElement('div');
  busyEl.className = 'mt-3 hidden items-center justify-center gap-2 text-xs text-gray-600 dark:text-gray-300';
  busyEl.innerHTML = `
    <svg class="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
      <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
    </svg>
    <span>Uploading…</span>
  `;

  const live = document.createElement('p');
  live.id = statusId;
  live.className = 'sr-only';
  live.setAttribute('aria-live', 'polite');

  const canRecordAudio = kind === 'audio' || kind === 'audioOrVideo';
  const recordingCfg = recording && typeof recording === 'object' ? recording : {};
  const recordingNoteText = String(
    recordingCfg.note ??
    'Tip: Recording uses your microphone. For best results, use a quiet environment. Mobile recording is best-effort in v1.'
  ).trim();
  const recordingAudioConstraints = recordingCfg.audioConstraints ?? { echoCancellation: true, noiseSuppression: true };
  const recordingMediaRecorderOptions = recordingCfg.mediaRecorderOptions ?? {};
  const recordingTimeSliceMs = Number.isFinite(recordingCfg.timeSliceMs)
    ? Math.max(0, Number(recordingCfg.timeSliceMs))
    : 500;

  const recordDetails = document.createElement('details');
  recordDetails.className = 'mt-2 rounded-[16px] border border-white dark:border-[#3a3a3a]';
  const recordSummary = document.createElement('summary');
  recordSummary.className = 'cursor-pointer select-none text-xs font-semibold text-gray-700 dark:text-gray-200 px-4 py-3';
  recordSummary.textContent = 'Record';
  recordDetails.appendChild(recordSummary);

  const recordPanel = document.createElement('div');
  recordPanel.className = 'px-4 pb-3';

  const recordRow = document.createElement('div');
  recordRow.className = 'flex items-center gap-2 flex-nowrap';

  const recordBtn = document.createElement('button');
  recordBtn.type = 'button';
  recordBtn.className = 'px-3 py-2 rounded-full bg-primary/90 hover:bg-primary/90 text-primary-foreground text-xs font-semibold whitespace-nowrap shrink-0 transition-colors disabled:opacity-60 disabled:cursor-not-allowed';
  recordBtn.textContent = 'Record';

  const stopBtn = document.createElement('button');
  stopBtn.type = 'button';
  stopBtn.className = 'px-3 py-2 rounded-full bg-secondary hover:bg-secondary/80 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors disabled:opacity-60 disabled:cursor-not-allowed';
  stopBtn.textContent = 'Stop';
  stopBtn.disabled = true;

  const cancelBtn = document.createElement('button');
  cancelBtn.type = 'button';
  cancelBtn.className = 'px-3 py-2 rounded-full bg-secondary hover:bg-secondary/80 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors disabled:opacity-60 disabled:cursor-not-allowed';
  cancelBtn.textContent = 'Cancel';
  cancelBtn.disabled = true;

  const timerEl = document.createElement('span');
  timerEl.className = 'ml-auto text-xs text-gray-600 dark:text-gray-300 tabular-nums';
  timerEl.textContent = '00:00';

  recordRow.appendChild(recordBtn);
  recordRow.appendChild(stopBtn);
  recordRow.appendChild(cancelBtn);
  recordRow.appendChild(timerEl);

  const recordNote = document.createElement('p');
  recordNote.className = 'mt-2 text-[11px] text-gray-500 dark:text-gray-400 leading-snug';
  recordNote.textContent = recordingNoteText;

  const recordError = document.createElement('p');
  recordError.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  recordError.setAttribute('role', 'alert');
  recordError.setAttribute('aria-live', 'polite');

  recordPanel.appendChild(recordRow);
  recordPanel.appendChild(recordNote);
  recordPanel.appendChild(recordError);
  recordDetails.appendChild(recordPanel);

  const previewWrap = document.createElement('div');
  previewWrap.className =
    'hidden w-full h-[115px] rounded-[16px] border border-dashed border-[#D9D9D9] dark:border-[#272727] ' +
    'bg-panel-input flex items-center justify-center px-4 py-5';

  const previewContainer = document.createElement('div');
  previewContainer.className = 'relative inline-block';

  const img = document.createElement('img');
  img.alt = 'Preview';
  img.className = 'hidden w-[180px] h-[100px] rounded-2xl object-contain bg-neutral-200 dark:bg-neutral-800';

  const video = document.createElement('video');
  video.controls = false;
  video.muted = true;
  video.loop = true;
  video.autoplay = true;
  video.playsInline = true;
  video.className = 'hidden w-[180px] h-[100px] rounded-2xl object-contain bg-neutral-200 dark:bg-neutral-800';

  const audio = document.createElement('audio');
  audio.controls = true;
  audio.className = 'hidden flex-1 min-w-0';

  const removeBtn = document.createElement('button');
  removeBtn.type = 'button';
  removeBtn.className =
    'absolute top-2 right-2 w-7 h-7 rounded-full bg-neutral-800/70 hover:bg-neutral-800/90 ' +
    'backdrop-blur flex items-center justify-center transition-colors z-10';
  removeBtn.innerHTML = `<svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>`;
  removeBtn.setAttribute('aria-label', 'Remove file');

  const typeLabel = document.createElement('div');
  typeLabel.className =
    'absolute bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full ' +
    'bg-neutral-800/70 text-xs font-medium text-white backdrop-blur';
  typeLabel.textContent = isVideo ? 'Video' : isAudio ? 'Audio' : 'Image';

  previewContainer.appendChild(img);
  previewContainer.appendChild(video);
  previewContainer.appendChild(audio);
  previewContainer.appendChild(removeBtn);
  previewContainer.appendChild(typeLabel);
  previewWrap.appendChild(previewContainer);

  const changeBtn = document.createElement('button');
  changeBtn.type = 'button';
  changeBtn.className = 'hidden';

  card.appendChild(fileInput);
  card.appendChild(dropzone);
  card.appendChild(previewWrap);
  card.appendChild(urlInput);
  if (canRecordAudio) {
    card.appendChild(recordDetails);
  }

  card.appendChild(hint);
  card.appendChild(busyEl);
  card.appendChild(live);
  wrap.appendChild(card);
  wrap.appendChild(errorEl);

  let objectUrl = null;
  let stagedFile = null;
  let stagedFiles = [];   // for multiple mode
  let inFlight = null;

  let recordStream = null;
  let recordRecorder = null;
  let recordChunks = [];
  let recordTimer = null;
  let recordStart = 0;

  function isProbablyVideoUrl(url) {
    if (!url || typeof url !== 'string') return false;
    const s = url.trim().toLowerCase();
    if (s.startsWith('data:video/')) return true;
    return /\.(mp4|mov|webm|m4v)(\?|#|$)/.test(s) || s.includes('/video/');
  }

  function isProbablyAudioUrl(url) {
    if (!url || typeof url !== 'string') return false;
    const s = url.trim().toLowerCase();
    if (s.startsWith('data:audio/')) return true;
    return /\.(mp3|wav|ogg|m4a|aac)(\?|#|$)/.test(s) || s.includes('/audio/');
  }

  function inferPreviewKind({ url, file }) {
    if (file?.type?.startsWith?.('video/')) return 'video';
    if (file?.type?.startsWith?.('audio/')) return 'audio';
    if (file?.type?.startsWith?.('image/')) return 'image';
    if (typeof url === 'string') {
      if (isProbablyVideoUrl(url)) return 'video';
      if (isProbablyAudioUrl(url)) return 'audio';
      return 'image';
    }
    return 'image';
  }

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      dropzone.removeAttribute('aria-invalid');
      dropzone.style.borderColor = '';
      dropzone.style.borderStyle = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    dropzone.setAttribute('aria-invalid', 'true');
    dropzone.style.borderColor = '#f87171';
    dropzone.style.borderStyle = 'solid';
  }

  function setRecordError(message) {
    if (!recordError) return;
    if (!message) {
      recordError.textContent = '';
      recordError.classList.add('hidden');
      return;
    }
    recordError.textContent = String(message);
    recordError.classList.remove('hidden');
  }

  function formatMmSs(ms) {
    const total = Math.max(0, Math.floor(ms / 1000));
    const mins = Math.floor(total / 60).toString().padStart(2, '0');
    const secs = (total % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  }

  function updateTimer() {
    timerEl.textContent = formatMmSs(Date.now() - recordStart);
  }

  function stopRecordTimer() {
    if (recordTimer) {
      clearInterval(recordTimer);
      recordTimer = null;
    }
  }

  function cleanupRecordStream() {
    if (recordStream) {
      try {
        recordStream.getTracks().forEach((t) => t.stop());
      } catch { /* ignore */ }
      recordStream = null;
    }
  }

  function resetRecordUi() {
    stopRecordTimer();
    recordStart = 0;
    timerEl.textContent = '00:00';
    recordBtn.disabled = false;
    stopBtn.disabled = true;
    cancelBtn.disabled = true;
    recordBtn.textContent = 'Record';
  }

  function isRecordingSupported() {
    return Boolean(
      canRecordAudio &&
      typeof navigator !== 'undefined' &&
      navigator.mediaDevices &&
      typeof navigator.mediaDevices.getUserMedia === 'function' &&
      typeof MediaRecorder !== 'undefined' &&
      typeof File !== 'undefined'
    );
  }

  function pickRecordingMimeType() {
    const candidates = [
      'audio/webm;codecs=opus',
      'audio/webm',
      'audio/mp4',
      'audio/ogg;codecs=opus',
      'audio/ogg',
    ];
    try {
      if (typeof MediaRecorder !== 'undefined' && typeof MediaRecorder.isTypeSupported === 'function') {
        for (const c of candidates) {
          if (MediaRecorder.isTypeSupported(c)) return c;
        }
      }
    } catch { /* ignore */ }
    return '';
  }

  function extensionForMimeType(mimeType) {
    const mt = String(mimeType || '').toLowerCase();
    if (mt.includes('webm')) return 'webm';
    if (mt.includes('ogg')) return 'ogg';
    if (mt.includes('mp4') || mt.includes('m4a')) return 'm4a';
    if (mt.includes('mpeg') || mt.includes('mp3')) return 'mp3';
    if (mt.includes('wav')) return 'wav';
    return 'webm';
  }

  async function startRecording() {
    if (!isRecordingSupported()) {
      setRecordError('Recording is not supported in this browser.');
      return;
    }
    if (recordRecorder) return;

    setRecordError('');
    try {
      const tryGetUserMedia = async (audio) => await navigator.mediaDevices.getUserMedia({ audio });
      try {
        recordStream = await tryGetUserMedia(recordingAudioConstraints);
      } catch (err) {
        const name = err && typeof err === 'object' ? err.name : '';
        if (name === 'OverconstrainedError') {
          // Best-effort fallback when the requested constraints can't be satisfied.
          recordStream = await tryGetUserMedia(true);
        } else {
          throw err;
        }
      }
      const mimeType = pickRecordingMimeType();
      recordChunks = [];
      const baseOptions =
        recordingMediaRecorderOptions && typeof recordingMediaRecorderOptions === 'object'
          ? recordingMediaRecorderOptions
          : {};

      const tryCreateRecorder = (opts) => {
        if (!opts) return new MediaRecorder(recordStream);
        return new MediaRecorder(recordStream, opts);
      };

      const hasBaseOptions = Object.keys(baseOptions).length > 0;
      const candidates = [];
      if (mimeType && hasBaseOptions) candidates.push({ ...baseOptions, mimeType });
      if (mimeType) candidates.push({ mimeType });
      if (hasBaseOptions) candidates.push(baseOptions);
      candidates.push(null);

      let lastCreateErr = null;
      for (const opts of candidates) {
        try {
          recordRecorder = tryCreateRecorder(opts);
          lastCreateErr = null;
          break;
        } catch (e) {
          lastCreateErr = e;
          recordRecorder = null;
        }
      }
      if (!recordRecorder) throw lastCreateErr || new Error('Failed to initialize MediaRecorder.');

      recordRecorder.ondataavailable = (e) => {
        if (e?.data && e.data.size > 0) recordChunks.push(e.data);
      };

      recordRecorder.onerror = (e) => {
        const msg = e?.error?.message || 'Recording failed.';
        setRecordError(msg);
      };

      recordRecorder.onstop = () => {
        try {
          const blobType = recordRecorder?.mimeType || mimeType || 'audio/webm';
          const blob = new Blob(recordChunks, { type: blobType });
          if (!blob.size) {
            setRecordError('No audio was captured. Try recording for a few seconds and ensure your microphone is working.');
            live.textContent = 'Recording captured no data.';
            return;
          }
          const ext = extensionForMimeType(blob.type || blobType);
          const filename = `recording-${Date.now()}.${ext}`;
          const file = new File([blob], filename, { type: blob.type || blobType });
          setFromFile(file);
          live.textContent = 'Recording captured.';
        } finally {
          recordChunks = [];
          recordRecorder = null;
          cleanupRecordStream();
          resetRecordUi();
        }
      };

      if (recordingTimeSliceMs > 0) recordRecorder.start(recordingTimeSliceMs);
      else recordRecorder.start();

      recordStart = Date.now();
      timerEl.textContent = '00:00';
      recordTimer = setInterval(updateTimer, 250);
      recordBtn.disabled = true;
      stopBtn.disabled = false;
      cancelBtn.disabled = false;
      recordBtn.textContent = 'Recording…';
      live.textContent = 'Recording started.';
    } catch (err) {
      const name = err && typeof err === 'object' ? err.name : '';
      if (name === 'NotAllowedError') setRecordError('Microphone access denied. Please allow microphone access to record.');
      else if (name === 'NotFoundError') setRecordError('No microphone found.');
      else setRecordError(err instanceof Error ? err.message : String(err || 'Failed to start recording.'));
      cleanupRecordStream();
      recordRecorder = null;
      resetRecordUi();
    }
  }

  function stopRecording() {
    if (!recordRecorder) return;
    try {
      stopBtn.disabled = true;
      cancelBtn.disabled = true;
      recordRecorder.stop();
      live.textContent = 'Stopping recording…';
    } catch (err) {
      setRecordError(err instanceof Error ? err.message : String(err || 'Failed to stop recording.'));
      recordRecorder = null;
      cleanupRecordStream();
      resetRecordUi();
    }
  }

  function cancelRecording() {
    if (!recordRecorder) {
      resetRecordUi();
      cleanupRecordStream();
      return;
    }
    try {
      recordChunks = [];
      recordRecorder.onstop = null;
      recordRecorder.stop();
    } catch { /* ignore */ }
    recordRecorder = null;
    cleanupRecordStream();
    resetRecordUi();
    live.textContent = 'Recording cancelled.';
  }

  function revokeObjectUrl() {
    if (objectUrl) {
      try { URL.revokeObjectURL(objectUrl); } catch { /* ignore */ }
      objectUrl = null;
    }
  }

  function clearPreview() {
    img.src = '';
    video.src = '';
    audio.src = '';
    img.classList.add('hidden');
    video.classList.add('hidden');
    audio.classList.add('hidden');
    previewWrap.classList.add('hidden');
    dropzone.classList.remove('hidden');
    // Reset audio-specific inline styles
    previewContainer.style.display = '';
    previewContainer.style.alignItems = '';
    previewContainer.style.gap = '';
    previewContainer.style.width = '';
    removeBtn.style.position = '';
    removeBtn.style.flexShrink = '';
    typeLabel.style.position = '';
    typeLabel.style.transform = '';
    typeLabel.style.flexShrink = '';
  }

  function setPreview(src, { file } = {}) {
    if (!src) {
      clearPreview();
      return;
    }

    const kindToShow = kind === 'imageOrVideo' || kind === 'audioOrVideo'
      ? inferPreviewKind({ url: src, file })
      : kind;

    // Hide dropzone, show preview
    dropzone.classList.add('hidden');
    previewWrap.classList.remove('hidden');
    img.classList.add('hidden');
    video.classList.add('hidden');
    audio.classList.add('hidden');

    // Reset audio-specific layout adjustments
    previewContainer.style.width = '';
    removeBtn.style.position = '';
    removeBtn.style.top = '';
    removeBtn.style.right = '';
    removeBtn.style.marginLeft = '';
    removeBtn.style.flexShrink = '';
    typeLabel.style.position = '';
    typeLabel.style.bottom = '';
    typeLabel.style.left = '';
    typeLabel.style.transform = '';
    typeLabel.style.marginLeft = '';
    typeLabel.style.flexShrink = '';
    previewContainer.style.display = '';
    previewContainer.style.alignItems = '';
    previewContainer.style.gap = '';

    // Update type label
    if (kindToShow === 'video') {
      typeLabel.textContent = 'Video';
      video.classList.remove('hidden');
      video.src = src;
      return;
    }
    if (kindToShow === 'audio') {
      typeLabel.textContent = 'Audio';
      audio.classList.remove('hidden');
      audio.src = src;
      // Audio preview: full-width player with remove button, no type label clutter
      previewContainer.style.display = 'flex';
      previewContainer.style.alignItems = 'center';
      previewContainer.style.gap = '12px';
      previewContainer.style.width = '100%';
      previewContainer.style.padding = '0 4px';
      audio.style.flex = '1';
      audio.style.minWidth = '0';
      audio.style.borderRadius = '12px';
      removeBtn.style.position = 'static';
      removeBtn.style.flexShrink = '0';
      typeLabel.style.display = 'none'; // Hide redundant "Audio" label — the player is self-evident
      return;
    }
    typeLabel.textContent = 'Image';
    img.classList.remove('hidden');
    img.src = src;
  }

  function setBusy(isBusy) {
    dropzone.disabled = Boolean(isBusy);
    urlInput.disabled = Boolean(isBusy);
    changeBtn.disabled = Boolean(isBusy);
    removeBtn.disabled = Boolean(isBusy);
    if (canRecordAudio) {
      recordBtn.disabled = Boolean(isBusy) || Boolean(recordRecorder);
      stopBtn.disabled = Boolean(isBusy) || !recordRecorder;
      cancelBtn.disabled = Boolean(isBusy) || !recordRecorder;
    }
    dropzone.setAttribute('aria-busy', isBusy ? 'true' : 'false');
  }

  function setFromFile(file) {
    if (!file) return;
    if (!isFileTypeAccepted(file, acceptStr)) {
      fileInput.value = '';
      setError(`Unsupported file type. Please use ${allowedDesc}.`);
      return;
    }
    if (recordRecorder && recordRecorder.state === 'recording') cancelRecording();
    stagedFile = file;
    urlInput.value = '';
    fileInput.value = '';
    revokeObjectUrl();
    objectUrl = URL.createObjectURL(file);
    setPreview(objectUrl, { file });
  }

  function setFromUrl(url) {
    const next = String(url || '').trim();
    urlInput.value = next;
    stagedFile = null;
    stagedFiles = [];
    fileInput.value = '';
    if (recordRecorder && recordRecorder.state === 'recording') cancelRecording();
    revokeObjectUrl();
    setPreview(next);
  }

  function canInteract() {
    return !(fileInput.disabled || urlInput.readOnly || urlInput.disabled || dropzone.disabled);
  }

  function openFilePicker() {
    if (!canInteract()) return;
    fileInput.click();
  }

  function normalizeDroppedText(text) {
    const t = String(text || '').trim();
    if (!t) return '';
    if (t.startsWith('http://') || t.startsWith('https://') || t.startsWith('data:') || t.startsWith('blob:') || t.startsWith('/')) return t;
    return '';
  }

  function maybeUpdateHint() {
    const kindForHint = kind || 'image';
    const maxUpload = maxBytesForKind(kindForHint);
    const maxInline = maxInlineBytesForKind(kindForHint);
    hint.textContent = `Max upload: ${formatBytes(maxUpload)}. Files over ${formatBytes(maxInline)} are uploaded automatically.`;
  }

  maybeUpdateHint();

  if (canRecordAudio) {
    if (!isRecordingSupported()) {
      recordBtn.disabled = true;
      recordSummary.textContent = 'Record (unsupported)';
      setRecordError('Recording is not supported in this browser. You can still upload an audio/video file or paste a URL.');
    } else {
      recordBtn.disabled = false;
    }

    recordBtn.addEventListener('click', startRecording);
    stopBtn.addEventListener('click', stopRecording);
    cancelBtn.addEventListener('click', cancelRecording);
  }

  dropzone.addEventListener('click', openFilePicker);
  dropzone.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    e.preventDefault();
    openFilePicker();
  });

  dropzone.addEventListener('dragenter', (e) => {
    if (!canInteract()) return;
    e.preventDefault();
    dropzone.classList.add('border-primary/40', 'bg-primary/5');
  });
  dropzone.addEventListener('dragover', (e) => {
    if (!canInteract()) return;
    e.preventDefault();
  });
  dropzone.addEventListener('dragleave', () => {
    dropzone.classList.remove('border-primary/40', 'bg-primary/5');
  });
  dropzone.addEventListener('drop', (e) => {
    if (!canInteract()) return;
    e.preventDefault();
    dropzone.classList.remove('border-primary/40', 'bg-primary/5');
    const dt = e.dataTransfer;
    const droppedFile = dt?.files && dt.files.length > 0 ? dt.files[0] : null;
    if (droppedFile) {
      setError('');
      setFromFile(droppedFile);
      return;
    }
    const text = normalizeDroppedText(dt?.getData?.('text/plain') || '');
    if (text) {
      setError('');
      setFromUrl(text);
    }
  });

  dropzone.addEventListener('paste', (e) => {
    if (!canInteract()) return;
    const items = e.clipboardData?.items || [];
    for (const item of items) {
      if (item.kind === 'file') {
        const file = item.getAsFile();
        if (file) {
          e.preventDefault();
          setError('');
          setFromFile(file);
          return;
        }
      }
    }
    const text = normalizeDroppedText(e.clipboardData?.getData?.('text/plain') || '');
    if (text) {
      e.preventDefault();
      setError('');
      setFromUrl(text);
    }
  });

  fileInput.addEventListener('change', () => {
    if (!fileInput.files || fileInput.files.length === 0) return;
    setError('');
    if (multiple) {
      stagedFiles = Array.from(fileInput.files);
      stagedFile = stagedFiles[0];
      urlInput.value = '';
      revokeObjectUrl();
      objectUrl = URL.createObjectURL(stagedFiles[0]);
      setPreview(objectUrl, { file: stagedFiles[0] });
      live.textContent = stagedFiles.length > 1
        ? `${stagedFiles.length} files selected` : '';
    } else {
      stagedFiles = [];
      setFromFile(fileInput.files[0]);
    }
  });

  urlInput.addEventListener('input', () => {
    const url = urlInput.value.trim();
    setError('');
    if (url.length > 0) {
      stagedFile = null;
      stagedFiles = [];
      fileInput.value = '';
      revokeObjectUrl();
      setPreview(url);
    } else {
      clearPreview();
    }
  });

  changeBtn.addEventListener('click', openFilePicker);

  img.addEventListener('click', openFilePicker);
  video.addEventListener('click', openFilePicker);
  img.style.cursor = 'pointer';
  video.style.cursor = 'pointer';

  removeBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    setError('');
    stagedFile = null;
    stagedFiles = [];
    fileInput.value = '';
    urlInput.value = '';
    if (recordRecorder && recordRecorder.state === 'recording') cancelRecording();
    revokeObjectUrl();
    clearPreview();
  });

  if (typeof defaultValue === 'string' && defaultValue.trim()) {
    setFromUrl(defaultValue);
  }

  // Sync to global form data (reads file as base64 data URL for recall/persistence)
  const syncToGlobal = () => {
    const url = urlInput.value.trim();

    if (multiple) {
      if (url) {
        updateFormData(fieldKey, [url]);
      } else if (stagedFiles.length > 0) {
        Promise.all(stagedFiles.map(f => fileToBase64DataUrl(f)))
          .then(dataUrls => updateFormData(fieldKey, dataUrls))
          .catch(() => { updateFormData(fieldKey, undefined); });
      } else {
        const singleFile = stagedFile || (fileInput.files && fileInput.files.length > 0 ? fileInput.files[0] : null);
        if (singleFile) {
          fileToBase64DataUrl(singleFile)
            .then(dataUrl => { updateFormData(fieldKey, [dataUrl]); })
            .catch(() => { updateFormData(fieldKey, undefined); });
        } else {
          updateFormData(fieldKey, undefined);
        }
      }
      return;
    }

    const file = stagedFile || (fileInput.files && fileInput.files.length > 0 ? fileInput.files[0] : null);
    if (url) {
      updateFormData(fieldKey, url);
    } else if (file) {
      // Convert to base64 data URL so the value is restorable
      fileToBase64DataUrl(file)
        .then(dataUrl => { updateFormData(fieldKey, dataUrl); })
        .catch(() => { updateFormData(fieldKey, undefined); });
    } else {
      updateFormData(fieldKey, undefined);
    }
  };
  urlInput.addEventListener('input', syncToGlobal);
  urlInput.addEventListener('change', syncToGlobal);
  fileInput.addEventListener('change', syncToGlobal);
  syncToGlobal(); // Initial sync

  function clearError() {
    setError('');
  }

  // Listen for programmatic remix value injection via custom event
  wrap.addEventListener('remix-set-value', (e) => {
    const url = e.detail?.value;
    if (typeof url === 'string' && url.trim()) {
      setFromUrl(url.trim());
      syncToGlobal();
    }
  });

  return {
    wrap,
    fileInput,
    urlInput,
    setValue: (v) => { setFromUrl(v); syncToGlobal(); },
    setError,
    clearError,
    getValue: async () => {
      // --- Multiple files path ---
      if (multiple) {
        const url = urlInput.value.trim();
        if (url) {
          const normalized = normalizeDroppedText(url);
          if (normalized) return [normalized];
          const msg = 'Invalid URL. Use https://… / data:… / blob:… / or a /uploads path.';
          setError(msg);
          throw new Error(msg);
        }

        const files = stagedFiles.length > 0
          ? stagedFiles
          : (fileInput.files && fileInput.files.length > 0 ? Array.from(fileInput.files) : []);

        if (files.length === 0) {
          if (required) {
            const msg = `Please upload ${label ? label.toLowerCase() : 'file(s)'}`;
            setError(msg);
            throw new Error(msg);
          }
          return undefined;
        }

        for (const f of files) {
          const kindForLimits = f.type?.startsWith?.('video/') ? 'video'
            : f.type?.startsWith?.('audio/') ? 'audio'
              : f.type?.startsWith?.('image/') ? 'image' : kind;
          const maxUploadBytes = maxBytesForKind(kindForLimits);
          if (f.size > maxUploadBytes) {
            const msg = `${f.name} is too large (${formatBytes(f.size)}). Max is ${formatBytes(maxUploadBytes)}.`;
            setError(msg);
            throw new Error(msg);
          }
        }

        setBusy(true);
        setError('');
        try {
          const urls = [];
          for (const f of files) {
            const uploadedUrl = await uploadFileToServer(f, { filename: f.name });
            urls.push(uploadedUrl);
          }
          live.textContent = `${urls.length} file(s) uploaded.`;
          return urls;
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err || 'Upload failed');
          setError(msg);
          live.textContent = `Upload failed: ${msg}`;
          throw new Error(msg);
        } finally {
          setBusy(false);
        }
      }

      // --- Single file path ---
      const url = urlInput.value.trim();
      if (url) {
        const normalized = normalizeDroppedText(url);
        if (normalized) return normalized;
        const msg = 'Invalid URL. Use https://… / data:… / blob:… / or a /uploads path.';
        setError(msg);
        throw new Error(msg);
      }

      const file = stagedFile || (fileInput.files && fileInput.files[0] ? fileInput.files[0] : null);
      if (!file) {
        if (required) {
          const msg = `Please upload ${label ? label.toLowerCase() : 'a file'}`;
          setError(msg);
          throw new Error(msg);
        }
        return undefined;
      }

      if (inFlight) return await inFlight;

      const kindForLimits =
        file.type?.startsWith?.('video/') ? 'video'
          : file.type?.startsWith?.('audio/') ? 'audio'
            : file.type?.startsWith?.('image/') ? 'image'
              : kind;

      const maxUploadBytes = maxBytesForKind(kindForLimits);
      if (file.size > maxUploadBytes) {
        const msg = `${label} is too large (${formatBytes(file.size)}). Max upload is ${formatBytes(maxUploadBytes)}.`;
        setError(msg);
        throw new Error(msg);
      }

      setBusy(true);
      setError('');
      inFlight = (async () => {
        try {
          const uploadedUrl = await uploadFileToServer(file, { filename: file.name });
          setFromUrl(uploadedUrl);
          live.textContent = 'Upload complete.';
          return uploadedUrl;
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err || 'Upload failed');
          setError(msg);
          live.textContent = `Upload failed: ${msg}`;
          throw new Error(msg);
        }
      })();

      try {
        return await inFlight;
      } finally {
        inFlight = null;
        setBusy(false);
      }
    },
  };
}
