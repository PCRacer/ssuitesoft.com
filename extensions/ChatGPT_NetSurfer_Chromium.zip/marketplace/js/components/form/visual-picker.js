/**
 * Visual picker component.
 *
 * Renders a small trigger card; clicking it opens a full-screen modal with a
 * thumbnail grid (optionally filtered by category chips). Used for "Choose
 * Video Type" / style picker style fields in the agent-v2 template.
 *
 * Schema shape it consumes (passed through schema-form.js):
 *   x-uap.ui_component: "visual-picker"
 *   x-uap.triggerLabel: "Choose Video Type"   // shown on the empty trigger
 *   x-uap.optionImages: { [enumValue]: imageUrl }
 *   x-uap.optionLabels: { [enumValue]: "Motion Type 1" }
 *   x-uap.optionCategories: { [enumValue]: "Motion" }   // optional
 *   enum: [...]
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

const VIDEO_EXT = /\.(mp4|webm|mov|m4v|ogv)(\?.*)?$/i;

function isVideoUrl(url) {
  return typeof url === 'string' && VIDEO_EXT.test(url);
}

function makeThumb(imageUrl, alt, extraClass = '') {
  if (!imageUrl) {
    const ph = document.createElement('div');
    ph.className = 'absolute inset-0 flex items-center justify-center text-xs text-gray-400 dark:text-gray-500';
    ph.textContent = alt || '';
    return ph;
  }
  if (isVideoUrl(imageUrl)) {
    const v = document.createElement('video');
    v.src = imageUrl;
    v.muted = true;
    v.loop = true;
    v.playsInline = true;
    v.autoplay = true;
    v.preload = 'metadata';
    v.className = 'absolute inset-0 w-full h-full object-cover ' + extraClass;
    v.onerror = () => { v.remove(); };
    return v;
  }
  const img = document.createElement('img');
  img.src = imageUrl;
  img.alt = alt || '';
  img.loading = 'lazy';
  img.className = 'absolute inset-0 w-full h-full object-cover ' + extraClass;
  img.onerror = () => { img.remove(); };
  return img;
}

export function createVisualPickerField({
  label,
  id,
  required = false,
  help,
  options = [],
  defaultValue,
  triggerLabel = 'Choose Option',
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'visualPicker';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'visual-picker');

  /* ── optional header (label + help) ── */
  if (label) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const headerRow = document.createElement('div');
    headerRow.className = 'flex items-center';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-[13px] font-medium';
    headerRow.appendChild(labelEl);
    const { trigger: helpTrigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (helpTrigger) {
      wrap.setAttribute('data-help-scope', '');
      headerRow.appendChild(helpTrigger);
    }
    header.appendChild(headerRow);
    wrap.appendChild(header);
  }

  /* ── state ── */
  const normalizedOptions = options.map((o) => ({
    value: String(o.value ?? ''),
    label: String(o.label ?? o.value ?? ''),
    image: typeof o.image === 'string' ? o.image : '',
    category: typeof o.category === 'string' ? o.category : '',
  }));
  let selectedValue = defaultValue != null && normalizedOptions.some((o) => o.value === String(defaultValue))
    ? String(defaultValue)
    : '';

  /* ── trigger card ── */
  const trigger = document.createElement('button');
  trigger.type = 'button';
  trigger.className = [
    'group relative inline-flex items-center gap-3',
    'rounded-2xl border border-black/10 dark:border-white/[0.08]',
    'bg-white dark:bg-neutral-900',
    'p-1.5 pr-3 text-left',
    'hover:border-purple-300 dark:hover:border-purple-700/60',
    'transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60',
  ].join(' ');
  trigger.setAttribute('aria-haspopup', 'dialog');
  trigger.setAttribute('aria-expanded', 'false');
  trigger.setAttribute('data-trigger', '');

  const triggerThumb = document.createElement('div');
  triggerThumb.className = 'relative w-12 h-12 rounded-xl overflow-hidden bg-black/5 dark:bg-white/5 flex-shrink-0 flex items-center justify-center';
  const triggerIcon = document.createElement('span');
  triggerIcon.innerHTML = '<svg class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V6a2 2 0 012-2h2M4 16v2a2 2 0 002 2h2m8-16h2a2 2 0 012 2v2m-4 12h2a2 2 0 002-2v-2M12 8v8m-4-4h8"/></svg>';
  triggerThumb.appendChild(triggerIcon);

  const triggerLabelEl = document.createElement('span');
  triggerLabelEl.className = 'text-[13px] font-medium text-gray-800 dark:text-gray-200 whitespace-nowrap';
  triggerLabelEl.textContent = triggerLabel;

  trigger.appendChild(triggerThumb);
  trigger.appendChild(triggerLabelEl);
  wrap.appendChild(trigger);

  /* ── error message ── */
  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function refreshTrigger() {
    if (!selectedValue) {
      triggerThumb.innerHTML = '';
      triggerThumb.appendChild(triggerIcon);
      triggerLabelEl.textContent = triggerLabel;
      return;
    }
    const opt = normalizedOptions.find((o) => o.value === selectedValue);
    if (!opt) return;
    triggerThumb.innerHTML = '';
    const t = makeThumb(opt.image, opt.label);
    triggerThumb.appendChild(t);
    triggerLabelEl.textContent = opt.label;
  }
  refreshTrigger();

  /* ── modal ── */
  const overlay = document.createElement('div');
  overlay.className = [
    'fixed inset-0 z-[9998] bg-black/60 backdrop-blur-sm',
    'hidden items-center justify-center p-3 sm:p-6',
  ].join(' ');
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  if (label) overlay.setAttribute('aria-label', label);

  const dialog = document.createElement('div');
  dialog.className = [
    'relative w-full max-w-5xl max-h-[90vh]',
    'rounded-2xl border border-black/10 dark:border-white/[0.08]',
    'bg-white dark:bg-neutral-950 shadow-2xl overflow-hidden flex flex-col',
  ].join(' ');

  const dialogHeader = document.createElement('div');
  dialogHeader.className = 'flex items-center justify-between gap-3 px-5 py-4 border-b border-black/5 dark:border-white/[0.06]';

  const dialogTitle = document.createElement('h3');
  dialogTitle.className = 'text-base font-semibold text-gray-900 dark:text-white';
  dialogTitle.textContent = label || triggerLabel || 'Choose Option';

  const dialogClose = document.createElement('button');
  dialogClose.type = 'button';
  dialogClose.setAttribute('aria-label', 'Close');
  dialogClose.className = [
    'flex items-center justify-center w-8 h-8 rounded-full',
    'text-gray-500 dark:text-gray-400',
    'hover:bg-black/5 dark:hover:bg-white/5 transition-colors',
  ].join(' ');
  dialogClose.innerHTML = '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>';

  dialogHeader.appendChild(dialogTitle);
  dialogHeader.appendChild(dialogClose);
  dialog.appendChild(dialogHeader);

  /* ── category chips ── */
  const categoryCounts = new Map();
  for (const opt of normalizedOptions) {
    if (!opt.category) continue;
    categoryCounts.set(opt.category, (categoryCounts.get(opt.category) || 0) + 1);
  }
  const categories = ['All', ...Array.from(categoryCounts.keys())];
  let activeCategory = 'All';

  const chipsRow = document.createElement('div');
  chipsRow.className = 'flex flex-wrap items-center gap-2 px-5 pt-4';
  const chipButtons = [];

  function chipClass(active) {
    return [
      'inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[12px] font-medium transition-colors',
      active
        ? 'bg-purple-100 text-purple-700 border border-purple-200 dark:bg-purple-900/40 dark:text-purple-300 dark:border-purple-800/50'
        : 'bg-black/5 text-gray-700 border border-transparent hover:bg-black/10 dark:bg-white/5 dark:text-gray-300 dark:hover:bg-white/10',
    ].join(' ');
  }

  for (const cat of categories) {
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = chipClass(cat === activeCategory);
    const count = cat === 'All' ? normalizedOptions.length : (categoryCounts.get(cat) || 0);
    chip.innerHTML = `<span>${cat}</span><span class="opacity-60">·</span><span>${count}</span>`;
    chip.addEventListener('click', () => {
      activeCategory = cat;
      for (const c of chipButtons) {
        c.btn.className = chipClass(c.cat === activeCategory);
      }
      renderGrid();
    });
    chipButtons.push({ cat, btn: chip });
    chipsRow.appendChild(chip);
  }
  if (categories.length > 1) {
    dialog.appendChild(chipsRow);
  }

  /* ── grid ── */
  const gridScroll = document.createElement('div');
  gridScroll.className = 'flex-1 overflow-y-auto px-5 py-4';

  const grid = document.createElement('div');
  grid.className = 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3';
  gridScroll.appendChild(grid);
  dialog.appendChild(gridScroll);

  function makeCard(opt) {
    const card = document.createElement('button');
    card.type = 'button';
    card.dataset.value = opt.value;
    card.setAttribute('role', 'option');
    card.setAttribute('aria-selected', opt.value === selectedValue ? 'true' : 'false');
    const selected = opt.value === selectedValue;
    card.className = [
      'group relative flex flex-col items-stretch text-left rounded-xl overflow-hidden',
      'border transition focus:outline-none',
      selected
        ? 'border-purple-500 ring-2 ring-purple-400/60'
        : 'border-black/10 dark:border-white/[0.08] hover:border-purple-400/70',
      'bg-white dark:bg-neutral-900',
    ].join(' ');

    const thumbWrap = document.createElement('div');
    thumbWrap.className = 'relative w-full aspect-[3/4] bg-black/5 dark:bg-white/5';
    thumbWrap.appendChild(makeThumb(opt.image, opt.label));
    card.appendChild(thumbWrap);

    const caption = document.createElement('div');
    caption.className = 'px-2.5 py-2 text-[12px] font-medium text-gray-900 dark:text-gray-100 truncate';
    caption.textContent = opt.label;
    card.appendChild(caption);

    card.addEventListener('click', () => {
      selectedValue = opt.value;
      updateFormData(fieldKey, selectedValue);
      refreshTrigger();
      closeModal();
    });
    return card;
  }

  function renderGrid() {
    grid.innerHTML = '';
    const filtered = activeCategory === 'All'
      ? normalizedOptions
      : normalizedOptions.filter((o) => o.category === activeCategory);
    for (const opt of filtered) {
      grid.appendChild(makeCard(opt));
    }
  }

  overlay.appendChild(dialog);

  /* ── open/close ── */
  let lastFocus = null;

  function openModal() {
    if (!overlay.isConnected) {
      document.body.appendChild(overlay);
    }
    lastFocus = document.activeElement;
    overlay.classList.remove('hidden');
    overlay.classList.add('flex');
    document.body.style.overflow = 'hidden';
    trigger.setAttribute('aria-expanded', 'true');
    renderGrid();
    dialogClose.focus();
  }

  function closeModal() {
    overlay.classList.add('hidden');
    overlay.classList.remove('flex');
    document.body.style.overflow = '';
    trigger.setAttribute('aria-expanded', 'false');
    if (lastFocus && typeof lastFocus.focus === 'function') {
      lastFocus.focus();
    }
  }

  trigger.addEventListener('click', openModal);
  dialogClose.addEventListener('click', closeModal);
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !overlay.classList.contains('hidden')) {
      closeModal();
    }
  });

  /* ── form data sync ── */
  if (selectedValue) updateFormData(fieldKey, selectedValue);

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      trigger.classList.remove('border-red-400', 'dark:border-red-500');
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    trigger.classList.add('border-red-400', 'dark:border-red-500');
  }

  function clearError() { setError(''); }

  return {
    wrap,
    getValue: () => selectedValue,
    setValue: (v) => {
      const next = v == null ? '' : String(v);
      if (next && !normalizedOptions.some((o) => o.value === next)) return;
      selectedValue = next;
      refreshTrigger();
      updateFormData(fieldKey, selectedValue);
    },
    setError,
    clearError,
  };
}
