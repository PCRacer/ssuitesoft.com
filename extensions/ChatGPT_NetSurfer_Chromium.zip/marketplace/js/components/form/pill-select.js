/**
 * Compact pill select component.
 * Renders a small dark pill with icon + value text. Clicking opens a minimal
 * dropdown with checkmarks for the selected item.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createPillSelect({
  label,
  pillLabel,
  pillIcon,
  id,
  options = [],
  defaultValue,
  required = false,
  help,
} = {}) {
  const wrap = document.createElement('div');
  wrap.className = 'inline-flex flex-col';
  const fieldKey = id || label || 'pillSelect';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'pill-select');

  /* ── optional header (label + help) ── */
  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const headerRow = document.createElement('div');
    headerRow.className = 'flex items-center';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-[13px] font-medium mx-2';
    headerRow.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      headerRow.appendChild(trigger);
    }
    header.appendChild(headerRow);
    wrap.appendChild(header);
  }

  /* ── normalise options ── */
  const normalizedOptions = (Array.isArray(options) ? options : []).map(opt => ({
    value: String(opt?.value ?? ''),
    label: String(opt?.label ?? opt?.value ?? ''),
    icon: opt?.icon || null,
  }));

  /* ── state ── */
  let selected = (() => {
    const desired = defaultValue != null ? String(defaultValue) : null;
    if (desired != null && normalizedOptions.some(o => o.value === desired)) return desired;
    return normalizedOptions.length > 0 ? normalizedOptions[0].value : '';
  })();

  const selectedOption = () => normalizedOptions.find(o => o.value === selected);

  /* ── trigger pill ── */
  const hasPillLabel = !!pillLabel;
  const pill = document.createElement('button');
  pill.type = 'button';
  pill.className =
    'w-full inline-flex items-center gap-2 px-3 rounded-[12px] ' +
    'bg-panel-input ' +
    'border border-panel-border ' +
    'text-gray-800 dark:text-white ' +
    'hover:bg-panel-hover transition-colors ' +
    'cursor-pointer focus:outline-none ' +
    (hasPillLabel ? 'h-11 py-1' : 'h-10 text-[13px] font-medium');

  const iconSpan = document.createElement('span');
  iconSpan.className = 'inline-flex items-center w-4 h-4 shrink-0 [&>svg]:w-full [&>svg]:h-full opacity-60';

  const textCol = document.createElement('span');
  textCol.className = 'flex flex-col min-w-0 flex-1 items-start';

  let pillLabelSpan = null;
  if (hasPillLabel) {
    pillLabelSpan = document.createElement('span');
    pillLabelSpan.className = 'text-[11px] font-normal text-gray-400 dark:text-gray-500 leading-none whitespace-nowrap mb-1';
    pillLabelSpan.textContent = pillLabel;
    textCol.appendChild(pillLabelSpan);
  }

  const valueRow = document.createElement('span');
  valueRow.className = 'inline-flex items-center gap-1.5 mt-0.5';
  const labelSpan = document.createElement('span');
  labelSpan.className = 'truncate whitespace-nowrap ' +
    (hasPillLabel ? 'text-[13px] font-semibold leading-none' : 'leading-tight');
  valueRow.appendChild(iconSpan);
  valueRow.appendChild(labelSpan);
  textCol.appendChild(valueRow);

  pill.appendChild(textCol);

  function updatePill() {
    const opt = selectedOption();
    const icon = opt?.icon || pillIcon || '';
    if (icon) {
      iconSpan.innerHTML = icon;
      iconSpan.style.display = '';
    } else {
      iconSpan.innerHTML = '';
      iconSpan.style.display = 'none';
    }
    labelSpan.textContent = opt?.label || '';
  }
  updatePill();

  wrap.appendChild(pill);

  /* ── dropdown menu ── */
  const menu = document.createElement('div');
  menu.className =
    'hidden fixed z-[9999] rounded-[12px] ' +
    'bg-panel-input ' +
    'border border-black/10 dark:border-white/[0.08] ' +
    'shadow-2xl overflow-y-auto max-h-[280px]';

  const checkSvg =
    '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">' +
    '<path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>';

  normalizedOptions.forEach(opt => {
    const item = document.createElement('button');
    item.type = 'button';
    item.className =
      'w-full flex items-center gap-2 px-4 py-2.5 text-left text-[13px] ' +
      'text-gray-900 dark:text-white hover:bg-panel-hover transition-colors';
    item.dataset.value = opt.value;

    const itemLabel = document.createElement('span');
    itemLabel.className = 'flex-1 truncate';
    itemLabel.textContent = opt.label;

    const itemCheck = document.createElement('span');
    itemCheck.className = (opt.value === selected ? 'text-gray-800 dark:text-white' : 'invisible') + ' shrink-0';
    itemCheck.innerHTML = checkSvg;

    item.appendChild(itemLabel);
    item.appendChild(itemCheck);
    menu.appendChild(item);

    item.addEventListener('click', () => {
      selected = opt.value;
      updatePill();
      menu.classList.add('hidden');
      updateChecks();
      syncToGlobal();
    });
  });

  function updateChecks() {
    menu.querySelectorAll('button').forEach(btn => {
      const check = btn.querySelector('span:last-child');
      if (check) {
        check.className = (btn.dataset.value === selected
          ? 'text-gray-800 dark:text-white'
          : 'invisible') + ' shrink-0';
      }
    });
  }

  /* ── positioning (reused pattern from select.js) ── */
  function positionMenu() {
    const rect = pill.getBoundingClientRect();
    const spaceBelow = window.innerHeight - rect.bottom;
    const spaceAbove = rect.top;
    const menuHeight = Math.min(280, normalizedOptions.length * 40);
    const minWidth = 140;
    const menuWidth = Math.max(minWidth, rect.width);

    menu.style.width = `${menuWidth}px`;

    let leftPos = rect.left;
    leftPos = Math.min(leftPos, window.innerWidth - menuWidth - 8);
    leftPos = Math.max(8, leftPos);
    menu.style.left = `${leftPos}px`;

    if (spaceBelow < menuHeight && spaceAbove > spaceBelow) {
      menu.style.bottom = `${window.innerHeight - rect.top + 4}px`;
      menu.style.top = 'auto';
    } else {
      menu.style.top = `${rect.bottom + 4}px`;
      menu.style.bottom = 'auto';
    }
  }

  /* ── open / close ── */
  pill.addEventListener('click', () => {
    const wasHidden = menu.classList.contains('hidden');
    if (wasHidden) positionMenu();
    menu.classList.toggle('hidden');
  });

  document.addEventListener('click', e => {
    if (!pill.contains(e.target) && !menu.contains(e.target)) {
      menu.classList.add('hidden');
    }
  });

  window.addEventListener('scroll', () => {
    if (!menu.classList.contains('hidden')) positionMenu();
  }, true);

  document.body.appendChild(menu);

  /* ── form data sync ── */
  const syncToGlobal = () => updateFormData(fieldKey, selected);
  syncToGlobal();

  /* ── error display ── */
  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      pill.style.outline = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    pill.style.outline = '1.5px solid #f87171';
  }

  function clearError() {
    setError('');
  }

  return {
    wrap,
    getValue: () => selected,
    setValue: (v) => {
      const next = v == null ? '' : String(v);
      if (normalizedOptions.some(o => o.value === next)) {
        selected = next;
        updatePill();
        updateChecks();
        syncToGlobal();
      }
    },
    setError,
    clearError,
  };
}
