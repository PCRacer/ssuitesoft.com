/**
 * Number input field component.
 * Compact stepper: [ − ]  value  [ + ] with optional label + help.
 * Returns getNumber/setNumber with parsed Number values (not strings).
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createNumberField({
  label,
  compactLabel,
  id,
  required = false,
  min,
  max,
  step = 1,
  help,
  defaultValue,
  compact = false,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'number';
  if (id) wrap.setAttribute('data-id', id);

  if (!compact) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const row = document.createElement('div');
    row.className = 'flex items-center';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-sm font-medium mx-2';
    row.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      row.appendChild(trigger);
    }
    header.appendChild(row);
    wrap.appendChild(header);
  }

  /* ── state ── */
  const stepNum = Number(step) || 1;
  const minNum = min != null ? Number(min) : -Infinity;
  const maxNum = max != null ? Number(max) : Infinity;
  let current = defaultValue != null ? Number(defaultValue) : (min != null ? Number(min) : 0);

  function clamp(v) {
    if (!Number.isFinite(v)) return current;
    if (v < minNum) return minNum;
    if (v > maxNum) return maxNum;
    return v;
  }

  /* ── hidden input for form compat ── */
  const input = document.createElement('input');
  input.type = 'hidden';
  input.name = fieldKey;
  if (min != null) input.min = String(min);
  if (max != null) input.max = String(max);
  input.step = String(step);
  input.value = String(current);

  /* ── stepper row ── */
  const hasCompactLabel = compact && compactLabel;
  const radius = compact ? 'rounded-[12px]' : 'rounded-2xl';
  const stepper = document.createElement('div');
  stepper.className =
    'w-full inline-flex flex-col justify-center ' + radius + ' ' +
    'bg-panel-input ' +
    'border border-panel-border ' +
    (hasCompactLabel ? 'h-12 py-1' : '');

  if (hasCompactLabel) {
    const labelRow = document.createElement('span');
    labelRow.className = 'text-[11px] font-normal text-gray-400 dark:text-gray-500 leading-none px-3 pt-1';
    labelRow.textContent = compactLabel;
    stepper.appendChild(labelRow);
  }

  const stepperRow = document.createElement('div');
  stepperRow.className = 'flex items-center justify-between';

  const btnH = hasCompactLabel ? 'h-6' : 'h-10';
  const btnSize = compact ? ('w-8 ' + btnH + ' text-[13px]') : 'w-10 h-12 text-lg';
  const btnClass =
    'flex items-center justify-center ' + btnSize + ' font-medium ' +
    'text-gray-600 dark:text-gray-300 ' +
    'hover:text-gray-900 dark:hover:text-white ' +
    'transition-colors cursor-pointer select-none ' +
    'focus:outline-none disabled:opacity-30 disabled:cursor-not-allowed';

  const minusBtn = document.createElement('button');
  minusBtn.type = 'button';
  minusBtn.className = btnClass + (hasCompactLabel ? ' rounded-bl-[12px]' : ' rounded-l-' + (compact ? '[12px]' : '2xl'));
  minusBtn.textContent = '−';
  minusBtn.setAttribute('aria-label', 'Decrease');

  const valWidth = compact ? 'min-w-[1.5rem]' : 'min-w-[2.5rem]';
  const valueDisplay = document.createElement('span');
  valueDisplay.className =
    valWidth + ' text-center font-semibold ' +
    'text-gray-900 dark:text-white select-none tabular-nums ' +
    (hasCompactLabel ? 'text-[13px]' : 'text-[13px]');
  valueDisplay.textContent = String(current);

  const plusBtn = document.createElement('button');
  plusBtn.type = 'button';
  plusBtn.className = btnClass + (hasCompactLabel ? ' rounded-br-[12px]' : ' rounded-r-' + (compact ? '[12px]' : '2xl'));
  plusBtn.textContent = '+';
  plusBtn.setAttribute('aria-label', 'Increase');

  stepperRow.appendChild(minusBtn);
  stepperRow.appendChild(valueDisplay);
  stepperRow.appendChild(plusBtn);
  stepper.appendChild(stepperRow);

  /* ── sync ── */
  function updateUI() {
    valueDisplay.textContent = Number.isInteger(current) ? String(current) : current.toFixed(2);
    input.value = String(current);
    minusBtn.disabled = current <= minNum;
    plusBtn.disabled = current >= maxNum;
  }

  const syncToGlobal = () => {
    updateFormData(fieldKey, Number.isFinite(current) ? current : undefined);
  };

  function setValue(v) {
    current = clamp(v);
    updateUI();
    syncToGlobal();
  }

  minusBtn.addEventListener('click', () => setValue(current - stepNum));
  plusBtn.addEventListener('click', () => setValue(current + stepNum));

  updateUI();
  syncToGlobal();

  wrap.appendChild(stepper);
  wrap.appendChild(input);

  /* ── error display ── */
  let errorEl = null;
  if (!compact) {
    errorEl = document.createElement('p');
    errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
    errorEl.setAttribute('role', 'alert');
    wrap.appendChild(errorEl);
  }

  function setError(message) {
    if (!errorEl) return;
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      stepper.style.outline = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    stepper.style.outline = '1.5px solid #f87171';
  }

  function clearError() {
    setError('');
  }

  return {
    wrap,
    input,
    getNumber: () => Number.isFinite(current) ? current : undefined,
    setNumber: (n) => { setValue(n == null ? (min != null ? Number(min) : 0) : Number(n)); },
    getValue: () => String(current),
    setError,
    clearError,
  };
}
