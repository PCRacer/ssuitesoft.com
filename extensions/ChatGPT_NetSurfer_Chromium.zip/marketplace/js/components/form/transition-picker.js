/**
 * Transition picker component.
 * Preview card + duration toggle + full-screen modal with searchable video grid.
 */

export function createTransitionPicker({
  transitions = [],
  defaultValue,
  defaultDuration = '5s',
  modalTitle = 'Transitions',
} = {}) {
  const wrap = document.createElement('div');
  wrap.className = 'flex flex-col items-center';

  let selectedTransition = transitions.find(t => t.value === defaultValue) || transitions[0] || { value: '', label: '', preview: '' };
  let selectedDuration = defaultDuration;

  // --- Preview card ---
  const previewCard = document.createElement('button');
  previewCard.type = 'button';
  previewCard.className = 'relative w-[140px] h-[80px] rounded-[16px] overflow-hidden cursor-pointer group';

  const thumbVideo = document.createElement('video');
  thumbVideo.className = 'w-full h-full object-cover';
  thumbVideo.muted = true;
  thumbVideo.loop = true;
  thumbVideo.playsInline = true;
  if (selectedTransition.preview) {
    thumbVideo.src = selectedTransition.preview;
    thumbVideo.play().catch(() => {});
  }
  previewCard.appendChild(thumbVideo);

  const overlay = document.createElement('div');
  overlay.className = 'absolute inset-0 flex flex-col items-center justify-center bg-black/20 group-hover:bg-black/30 transition-colors';

  const icon = document.createElement('div');
  icon.className = 'mb-0.5';
  icon.innerHTML = `<svg width="24" height="24" viewBox="0 0 24 23" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12.3845 1.88928H7.38837C2.56018 1.88928 0.628906 3.56865 0.628906 7.76708V12.8052C0.628906 17.0036 2.56018 18.683 7.38837 18.683H12.3845" stroke="white" stroke-width="1.25953" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M17.4664 1.97325C19.5356 1.97325 20.3633 3.64423 20.3633 7.82166V12.8346C20.3633 17.012 19.5356 18.683 17.4664 18.683" stroke="white" stroke-width="1.25953" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M5.75391 10.2857V9.04293C5.75391 7.43913 6.88748 6.79257 8.27296 7.59027L9.34776 8.21164L10.4226 8.833C11.808 9.63071 11.808 10.9406 10.4226 11.7383L9.34776 12.3597L8.27296 12.981C6.88748 13.7787 5.75391 13.1238 5.75391 11.5284V10.2857Z" stroke="white" stroke-width="1.25953" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M14.9023 0.629761L14.9023 19.9425" stroke="white" stroke-width="1.25953" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;

  const selectedName = document.createElement('div');
  selectedName.className = 'text-white text-xs font-semibold';
  selectedName.textContent = selectedTransition.label;

  overlay.appendChild(icon);
  overlay.appendChild(selectedName);
  previewCard.appendChild(overlay);
  wrap.appendChild(previewCard);

  // --- Duration toggle ---
  const toggleWrap = document.createElement('div');
  toggleWrap.className = 'mt-3 flex p-1 bg-[#F2F5F9] dark:bg-[#1a1a1a] rounded-full w-[140px] h-[32px]';

  const activeClass = 'flex-1 rounded-full text-[11px] font-semibold bg-white dark:bg-[#333] text-foreground shadow-sm transition-all';
  const inactiveClass = 'flex-1 rounded-full text-[11px] font-semibold text-muted-foreground hover:text-foreground transition-all';

  const btn5s = document.createElement('button');
  btn5s.type = 'button';
  btn5s.className = selectedDuration === '5s' ? activeClass : inactiveClass;
  btn5s.textContent = '5s';

  const btn10s = document.createElement('button');
  btn10s.type = 'button';
  btn10s.className = selectedDuration === '10s' ? activeClass : inactiveClass;
  btn10s.textContent = '10s';

  toggleWrap.appendChild(btn5s);
  toggleWrap.appendChild(btn10s);
  wrap.appendChild(toggleWrap);

  btn5s.addEventListener('click', (e) => {
    e.stopPropagation();
    selectedDuration = '5s';
    btn5s.className = activeClass;
    btn10s.className = inactiveClass;
  });

  btn10s.addEventListener('click', (e) => {
    e.stopPropagation();
    selectedDuration = '10s';
    btn10s.className = activeClass;
    btn5s.className = inactiveClass;
  });

  // --- Modal ---
  const modal = document.createElement('div');
  modal.className = 'fixed inset-0 z-50 hidden items-center justify-center p-4 bg-black/60 backdrop-blur-sm';
  modal.innerHTML = `
    <div class="bg-white dark:bg-[#0A0A0A] rounded-2xl w-full max-w-lg sm:max-w-2xl lg:max-w-3xl max-h-[85vh] overflow-hidden flex flex-col shadow-xl">
      <div class="flex items-center justify-between px-4 pt-4 pb-2">
        <h3 class="text-[16px] font-bold text-foreground">${modalTitle}</h3>
        <button type="button" class="modal-close w-8 h-8 rounded-full hover:bg-gray-100 dark:hover:bg-[#333] flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="px-4 pb-2">
        <div class="relative">
          <svg class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
          <input type="text" class="search-input w-full h-10 sm:h-12 pl-12 pr-4 rounded-[16px] bg-[#F2F5F9] dark:bg-[#262626]/80 text-foreground placeholder-muted-foreground focus:outline-none text-sm" placeholder="Search transitions">
        </div>
      </div>
      <div class="flex-1 overflow-y-auto p-3 sm:p-4">
        <div class="transitions-grid grid grid-cols-3 sm:grid-cols-3 gap-2 sm:gap-4"></div>
      </div>
    </div>
  `;
  document.body.appendChild(modal);

  const grid = modal.querySelector('.transitions-grid');
  const searchInput = modal.querySelector('.search-input');
  const closeBtn = modal.querySelector('.modal-close');

  function renderGrid(filter = '') {
    grid.innerHTML = '';
    const filtered = transitions.filter(t =>
      t.label.toLowerCase().includes(filter.toLowerCase())
    );

    filtered.forEach(transition => {
      const isSelected = selectedTransition.value === transition.value;

      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'text-left transition-all';

      const videoWrap = document.createElement('div');
      videoWrap.className = `w-full aspect-square rounded-[14.2px] bg-[#e5e5e5] dark:bg-[#0f0f0f] overflow-hidden mb-1 sm:mb-2 relative ${isSelected ? 'ring-2 ring-primary/90' : ''}`;

      const video = document.createElement('video');
      video.className = 'w-full h-full object-cover';
      video.muted = true;
      video.loop = true;
      video.playsInline = true;
      video.src = transition.preview;

      videoWrap.appendChild(video);

      if (isSelected) {
        const checkmark = document.createElement('div');
        checkmark.className = 'absolute top-1 right-1 sm:top-2 sm:right-2 w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-primary/90 flex items-center justify-center';
        checkmark.innerHTML = '<svg class="w-3 h-3 sm:w-4 sm:h-4 text-white" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>';
        videoWrap.appendChild(checkmark);
      }

      video.play().catch(() => {});

      const name = document.createElement('div');
      name.className = `text-[12px] sm:text-[15px] font-medium ${isSelected ? 'text-primary/90' : 'text-foreground'}`;
      name.textContent = transition.label;

      item.appendChild(videoWrap);
      item.appendChild(name);

      item.addEventListener('click', () => {
        selectedTransition = transition;
        selectedName.textContent = transition.label;
        thumbVideo.src = transition.preview;
        thumbVideo.play().catch(() => {});
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        renderGrid(searchInput.value);
      });

      grid.appendChild(item);
    });
  }

  previewCard.addEventListener('click', () => {
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    renderGrid();
    searchInput.value = '';
    searchInput.focus();
  });

  closeBtn.addEventListener('click', () => {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  });

  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  });

  searchInput.addEventListener('input', () => {
    renderGrid(searchInput.value);
  });

  return {
    wrap,
    getTransition: () => selectedTransition.value,
    getDuration: () => selectedDuration === '5s' ? 5 : 10,
    setTransition(value) {
      if (!value) return;
      const v = String(value);
      const match = transitions.find(t => t.value === v || t.value.toLowerCase() === v.toLowerCase());
      if (!match) return;
      selectedTransition = match;
      selectedName.textContent = match.label;
      thumbVideo.src = match.preview;
      thumbVideo.play().catch(() => {});
    },
    setDuration(value) {
      if (!value) return;
      const v = String(value).toLowerCase();
      const numeric = Number.parseFloat(v.replace(/[^\d.]/g, ''));
      const useFive = Number.isFinite(numeric)
        ? numeric < 8
        : (v.includes('normal') || v.includes('slow') || v.includes('1') || v.includes('2') || v.includes('3') || v.includes('4'));
      if (useFive) {
        selectedDuration = '5s';
        btn5s.className = activeClass;
        btn10s.className = inactiveClass;
      } else {
        selectedDuration = '10s';
        btn10s.className = activeClass;
        btn5s.className = inactiveClass;
      }
    },
  };
}
