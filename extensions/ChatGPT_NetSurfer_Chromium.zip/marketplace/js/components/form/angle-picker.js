/**
 * Angle Picker component
 * Manages three form-data fields: horizontalAngle, verticalAngle, zoom.
 */
import { updateFormData, createFieldLabel, createHelpToggle, onAgentFormDataChange, createSliderField } from '../../runner/overrides/ui.js';

const DEG = Math.PI / 180;
const TWO_PI = Math.PI * 2;


export function createAnglePicker({
  label,
  id,
  required = false,
  help,
  defaultH = 0,
  defaultV = 0,
  defaultZ = 5,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || 'anglePicker';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'angle-picker');

  if (!document.getElementById('aitopia-angle-picker-style')) {
    const style = document.createElement('style');
    style.id = 'aitopia-angle-picker-style';
    style.textContent = `

    `;
    document.head.appendChild(style);
  }

  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-3';
    const row = document.createElement('div');
    row.className = 'flex items-center';
    const labelEl = createFieldLabel(String(label), { required });
    labelEl.className = 'block text-[13px] font-semibold mx-2';
    row.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) { wrap.setAttribute('data-help-scope', ''); row.appendChild(trigger); }
    header.appendChild(row);
    wrap.appendChild(header);
  }

  // ── State ──
  const num = (v, fb) => { const n = Number(v); return Number.isFinite(n) ? n : fb; };
  let rotation = num(defaultH, 0);   // 0-360
  let tilt = num(defaultV, 0);       // -30 to 90
  let zoom = num(defaultZ, 5);       // 0-10
  const syncToGlobal = () => {
    updateFormData('horizontalAngle', rotation);
    updateFormData('verticalAngle', tilt);
    updateFormData('zoom', zoom);
  };

  // ── Canvas: wireframe sphere ──
  const canvasWrap = document.createElement('div');
  canvasWrap.className = 'relative rounded-[16px] overflow-hidden select-none border border-white/[0.06] dark:border-white/[0.06] bg-[#1a1c1f]';
  canvasWrap.style.cssText = 'aspect-ratio:1/1;max-width:280px;margin:0 auto;';
  // Light mode
  if (!document.documentElement.classList.contains('dark') && !window.matchMedia?.('(prefers-color-scheme: dark)')?.matches) {
    canvasWrap.style.background = '#EAEFF6';
    canvasWrap.style.borderColor = 'rgba(0,0,0,0.06)';
  }

  const canvas = document.createElement('canvas');
  canvas.width = 400;
  canvas.height = 400;
  canvas.style.cssText = 'width:100%;height:100%;cursor:grab;touch-action:none;';
  canvasWrap.appendChild(canvas);

  const hintEl = document.createElement('p');
  hintEl.className = 'absolute top-3 left-0 right-0 text-center text-[11px] pointer-events-none';
  hintEl.style.color = 'rgba(255,255,255,0.35)';
  hintEl.textContent = 'Hold and drag to change camera angle';
  canvasWrap.appendChild(hintEl);

  function makeChevron(dir) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'absolute flex items-center justify-center w-8 h-8 rounded-full transition-colors';
    btn.style.cssText = 'color:rgba(255,255,255,0.35);background:transparent;';

    const paths = {
      up: 'M7 13l5-5 5 5',
      down: 'M7 11l5 5 5-5',
      left: 'M13 17l-5-5 5-5',
      right: 'M11 7l5 5-5 5',
    };
    btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="${paths[dir]}"/></svg>`;

    const pos = {
      up:    'top:28px;left:50%;transform:translateX(-50%);',
      down:  'bottom:8px;left:50%;transform:translateX(-50%);',
      left:  'left:8px;top:50%;transform:translateY(-50%);',
      right: 'right:8px;top:50%;transform:translateY(-50%);',
    };
    btn.style.cssText += pos[dir];

    btn.addEventListener('mouseenter', () => { btn.style.color = 'rgba(255,255,255,0.65)'; });
    btn.addEventListener('mouseleave', () => { btn.style.color = 'rgba(255,255,255,0.35)'; });

    return btn;
  }

  const chevUp = makeChevron('up');
  const chevDown = makeChevron('down');
  const chevLeft = makeChevron('left');
  const chevRight = makeChevron('right');
  canvasWrap.appendChild(chevUp);
  canvasWrap.appendChild(chevDown);
  canvasWrap.appendChild(chevLeft);
  canvasWrap.appendChild(chevRight);

  chevUp.addEventListener('click', () => { tilt = Math.min(90, tilt + 15); afterChange(); });
  chevDown.addEventListener('click', () => { tilt = Math.max(-30, tilt - 15); afterChange(); });
  chevLeft.addEventListener('click', () => { rotation = (rotation - 15 + 360) % 360; afterChange(); });
  chevRight.addEventListener('click', () => { rotation = (rotation + 15) % 360; afterChange(); });

  wrap.appendChild(canvasWrap);

  let userImg = null;
  let userImgSrc = '';

  function loadUserImage() {
    const fd = window.agent_form_data;
    if (!fd) return;
    let raw = fd.imageUrl || fd.image_url || fd.image || fd.url;
    if (typeof raw === 'string') { try { raw = JSON.parse(raw); } catch { /* keep */ } }
    if (!raw) {
      const imgField = wrap.closest?.('form')?.querySelector?.('[data-component="file-upload"] img[src], [data-id="imageUrl"] img, [data-id="image"] img');
      if (imgField?.src) raw = imgField.src;
    }
    const isUrl = typeof raw === 'string' && (raw.startsWith('http') || raw.startsWith('blob:') || raw.startsWith('data:'));
    if (isUrl && raw !== userImgSrc) {
      userImgSrc = raw;
      const img = new Image();
      if (!raw.startsWith('data:')) img.crossOrigin = 'anonymous';
      img.onload = () => { userImg = img; draw(); };
      // Keep the memo on failure so a broken URL isn't refetched on every form change.
      img.onerror = () => { userImg = null; draw(); };
      img.src = raw;
    } else if (!raw) {
      userImg = null; userImgSrc = ''; draw();
    }
  }

  onAgentFormDataChange(() => loadUserImage());
  requestAnimationFrame(() => {
    loadUserImage();
    const form = wrap.closest?.('form') || wrap.parentElement;
    if (form) new MutationObserver(() => loadUserImage()).observe(form, { subtree: true, childList: true, attributes: true, attributeFilter: ['src', 'value'] });
  });

  function isDark() {
    return window.matchMedia?.('(prefers-color-scheme: dark)')?.matches || document.documentElement.classList.contains('dark');
  }

  function draw() {
    const ctx = canvas.getContext('2d');
    const W = canvas.width;
    const H = canvas.height;
    const cx = W / 2;
    const cy = H / 2;
    const R = W * 0.34;
    const dk = isDark();

    ctx.clearRect(0, 0, W, H);

    ctx.fillStyle = dk ? '#1a1c1f' : '#EAEFF6';
    ctx.fillRect(0, 0, W, H);

    const lineColor = dk ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
    ctx.strokeStyle = lineColor;
    ctx.lineWidth = 0.7;

    const rotRad = rotation * DEG;
    const tiltRad = tilt * DEG;
    const NUM_MERIDIANS = 12;
    for (let i = 0; i < NUM_MERIDIANS; i++) {
      const angle = (i / NUM_MERIDIANS) * Math.PI;
      drawGreatCircle(ctx, cx, cy, R, angle + rotRad, 'vertical');
    }

    const NUM_PARALLELS = 7;
    for (let i = 1; i < NUM_PARALLELS; i++) {
      const lat = -70 + (i / NUM_PARALLELS) * 140; // -70 to +70 degrees
      const latRad = lat * DEG;
      const r = R * Math.cos(latRad);
      const y = cy - R * Math.sin(latRad) * Math.cos(tiltRad * 0.3);
      ctx.beginPath();
      ctx.ellipse(cx, y, r, r * 0.3, 0, 0, TWO_PI);
      ctx.stroke();
    }

    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI;
      drawGreatCircle(ctx, cx, cy, R, angle + rotRad + Math.PI / 4, 'diagonal');
    }

    // Outer circle
    ctx.strokeStyle = dk ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, TWO_PI);
    ctx.stroke();

    // ── User image (centered rounded rect, scales with zoom) ──
    // zoom 0 = wide (small image), zoom 5 = medium, zoom 10 = close-up (large)
    const zoomScale = 0.55 + (zoom / 10) * 0.45; // 0.55 at zoom=0, 1.0 at zoom=10
    const imgSize = R * 0.8 * zoomScale;
    const imgX = cx - imgSize / 2;
    const imgY = cy - imgSize / 2;
    const imgR = 12;

    if (userImg) {
      ctx.save();
      ctx.beginPath();
      ctx.roundRect(imgX, imgY, imgSize, imgSize, imgR);
      ctx.clip();
      const iw = userImg.naturalWidth;
      const ih = userImg.naturalHeight;
      const scale = Math.max(imgSize / iw, imgSize / ih);
      const dw = iw * scale;
      const dh = ih * scale;
      ctx.drawImage(userImg, cx - dw / 2, cy - dh / 2, dw, dh);
      ctx.restore();
      // Border
      ctx.strokeStyle = dk ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.1)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(imgX, imgY, imgSize, imgSize, imgR);
      ctx.stroke();
    } else {
      // Placeholder
      ctx.fillStyle = dk ? '#252729' : '#dde3ed';
      ctx.beginPath();
      ctx.roundRect(imgX, imgY, imgSize, imgSize, imgR);
      ctx.fill();
      ctx.strokeStyle = dk ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    // ── Camera indicator on sphere surface ──
    const camAngleRad = rotation * DEG;
    const camTiltRad = tilt * DEG;
    const camX = cx + R * Math.sin(camAngleRad) * Math.cos(camTiltRad);
    const camY = cy - R * Math.sin(camTiltRad);

    ctx.strokeStyle = dk ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.15)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(camX, camY);
    ctx.lineTo(cx, cy);
    ctx.stroke();

    // Camera icon
    const camW = 14;
    const camH = 10;
    ctx.save();
    ctx.translate(camX, camY);
    const angleToCenter = Math.atan2(cy - camY, cx - camX);
    ctx.rotate(angleToCenter);

    ctx.fillStyle = dk ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.5)';
    ctx.beginPath();
    ctx.roundRect(-camW / 2, -camH / 2, camW, camH, 2.5);
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(camW / 2, -camH / 2 + 1);
    ctx.lineTo(camW / 2 + 5, -camH / 2 + 2.5);
    ctx.lineTo(camW / 2 + 5, camH / 2 - 2.5);
    ctx.lineTo(camW / 2, camH / 2 - 1);
    ctx.closePath();
    ctx.fill();
    // Lens circle
    ctx.fillStyle = dk ? 'rgba(255,255,255,0.9)' : 'rgba(0,0,0,0.7)';
    ctx.beginPath();
    ctx.arc(0, 0, 2.5, 0, TWO_PI);
    ctx.fill();
    ctx.restore();

    ctx.fillStyle = dk ? 'rgba(255,255,255,0.25)' : 'rgba(0,0,0,0.25)';
    ctx.font = '500 10px system-ui, sans-serif';
    ctx.textAlign = 'center';
    const sign = tilt >= 0 ? '+' : '';
    ctx.fillText(`${Math.round(rotation)}\u00B0 rot \u00B7 ${sign}${Math.round(tilt)}\u00B0 tilt \u00B7 zoom ${Math.round(zoom)}/10`, cx, cy + R + 22);
  }


  function drawGreatCircle(ctx, cx, cy, R, angle, type) {
    ctx.beginPath();
    if (type === 'vertical') {
      const squeeze = Math.abs(Math.cos(angle));
      const rx = R * squeeze;
      ctx.ellipse(cx, cy, Math.max(rx, 0.5), R, 0, 0, TWO_PI);
    } else {
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(angle);
      ctx.beginPath();
      ctx.ellipse(0, 0, R, R * 0.35, 0, 0, TWO_PI);
      ctx.restore();
    }
    ctx.stroke();
  }

  let dragging = false;
  let dragStartX = 0;
  let dragStartY = 0;
  let dragStartRot = 0;
  let dragStartTilt = 0;

  canvas.addEventListener('pointerdown', (e) => {
    dragging = true;
    canvas.style.cursor = 'grabbing';
    canvas.setPointerCapture(e.pointerId);
    const rect = canvas.getBoundingClientRect();
    dragStartX = e.clientX - rect.left;
    dragStartY = e.clientY - rect.top;
    dragStartRot = rotation;
    dragStartTilt = tilt;
  });

  canvas.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    const rect = canvas.getBoundingClientRect();
    const dx = (e.clientX - rect.left) - dragStartX;
    const dy = (e.clientY - rect.top) - dragStartY;
    const scale = canvas.width / rect.width;
    rotation = (dragStartRot + (dx / rect.width) * 360 + 360) % 360;
    tilt = Math.max(-30, Math.min(90, dragStartTilt - (dy / rect.height) * 120));
    rotation = Math.round(rotation);
    tilt = Math.round(tilt);
    syncToGlobal();
    draw();
  });

  canvas.addEventListener('pointerup', () => { dragging = false; canvas.style.cursor = 'grab'; updateSliders(); });
  canvas.addEventListener('pointercancel', () => { dragging = false; canvas.style.cursor = 'grab'; updateSliders(); });


  const slidersWrap = document.createElement('div');
  slidersWrap.className = 'mt-4 space-y-2';

  const rotSlider = createSliderField({
    label: 'Rotation', id: 'horizontalAngle',
    min: 0, max: 360, step: 1, defaultValue: rotation, unit: '\u00B0',
  });
  const tiltSlider = createSliderField({
    label: 'Tilt', id: 'verticalAngle',
    min: -30, max: 90, step: 1, defaultValue: tilt, unit: '\u00B0',
  });
  const zoomSlider = createSliderField({
    label: 'Zoom', id: 'zoom',
    min: 0, max: 10, step: 1, defaultValue: zoom,
  });

  rotSlider.input.addEventListener('input', () => {
    rotation = Number(rotSlider.input.value);
    afterChange(true);
  });
  tiltSlider.input.addEventListener('input', () => {
    tilt = Number(tiltSlider.input.value);
    afterChange(true);
  });
  zoomSlider.input.addEventListener('input', () => {
    zoom = Number(zoomSlider.input.value);
    afterChange(true);
  });

  slidersWrap.appendChild(rotSlider.wrap);
  slidersWrap.appendChild(tiltSlider.wrap);
  slidersWrap.appendChild(zoomSlider.wrap);
  wrap.appendChild(slidersWrap);

  function updateSliders() {
    rotSlider.setNumber(rotation);
    tiltSlider.setNumber(tilt);
    zoomSlider.setNumber(zoom);
  }

  function afterChange(fromSlider = false) {
    if (!fromSlider) updateSliders();
    syncToGlobal();
    draw();
  }

  syncToGlobal();
  requestAnimationFrame(() => draw());

  window.matchMedia?.('(prefers-color-scheme: dark)')?.addEventListener('change', () => {
    const dk = isDark();
    canvasWrap.style.background = dk ? '#1a1c1f' : '#EAEFF6';
    canvasWrap.style.borderColor = dk ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
    hintEl.style.color = dk ? 'rgba(255,255,255,0.35)' : 'rgba(0,0,0,0.35)';
    draw();
  });
  new MutationObserver(() => draw()).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function setError(msg) {
    if (!msg) { errorEl.textContent = ''; errorEl.classList.add('hidden'); return; }
    errorEl.textContent = String(msg);
    errorEl.classList.remove('hidden');
  }

  function clearError() { setError(''); }

  return {
    wrap,
    getValues: () => ({ horizontalAngle: rotation, verticalAngle: tilt, zoom }),
    setValues: ({ horizontalAngle, verticalAngle, zoom: z } = {}) => {
      if (horizontalAngle != null) rotation = num(horizontalAngle, rotation);
      if (verticalAngle != null) tilt = num(verticalAngle, tilt);
      if (z != null) zoom = num(z, zoom);
      afterChange();
    },
    setError,
    clearError,
  };
}
