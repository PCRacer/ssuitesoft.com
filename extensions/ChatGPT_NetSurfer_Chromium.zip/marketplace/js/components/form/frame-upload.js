/**
 * Frame upload component.
 * Video/image upload with dashed border, file preview, remove button
 */
import { uploadFileToServer, uploadUrlToServer } from '../../shared/media.js';

const ICON_DARK = `
<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect width="32" height="32" rx="16" fill="#272727"/>
  <rect x="0.3" y="0.3" width="31.4" height="31.4" rx="15.7" stroke="#B6B6B6" stroke-opacity="0.3" stroke-width="0.6"/>
  <path d="M6.92578 15.9959C6.92578 18.8919 8.16311 20.1293 11.0591 20.1293V19.3293C8.60045 19.3293 7.72578 18.4546 7.72578 15.9959V12.7959C7.72578 10.3373 8.60045 9.4626 11.0591 9.4626H14.2591C16.7178 9.4626 17.5924 10.3373 17.5924 12.7959L18.3924 12.7959C18.3924 9.89993 17.1551 8.6626 14.2591 8.6626H11.0591C8.16311 8.6626 6.92578 9.89993 6.92578 12.7959V15.9959Z" fill="#B6B6B6"/>
  <path d="M11.0604 13.7295C10.2497 13.7295 9.59375 13.0735 9.59375 12.2628C9.59375 11.4521 10.2497 10.7961 11.0604 10.7961C11.8711 10.7961 12.5271 11.4521 12.5271 12.2628C12.5271 13.0735 11.8711 13.7295 11.0604 13.7295ZM11.0604 11.5961C10.6924 11.5961 10.3937 11.8948 10.3937 12.2628C10.3937 12.6308 10.6924 12.9295 11.0604 12.9295C11.4284 12.9295 11.7271 12.6308 11.7271 12.2628C11.7271 11.8948 11.4284 11.5961 11.0604 11.5961Z" fill="#B6B6B6"/>
  <path d="M16.6591 25.3293H19.8591C22.5258 25.3293 23.5924 24.2626 23.5924 21.5959V18.3959C23.5924 15.7293 22.5258 14.6626 19.8591 14.6626H16.6591C13.9924 14.6626 12.9258 15.7293 12.9258 18.3959V21.5959C12.9258 24.2626 13.9924 25.3293 16.6591 25.3293Z" stroke="#B6B6B6" stroke-width="0.833333" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M16.7148 19.9963V19.207C16.7148 18.1883 17.4348 17.7776 18.3148 18.2843L18.9975 18.679L19.6802 19.0736C20.5602 19.5803 20.5602 20.4123 19.6802 20.919L18.9975 21.3136L18.3148 21.7083C17.4348 22.215 16.7148 21.799 16.7148 20.7856V19.9963Z" stroke="#B6B6B6" stroke-width="0.833333" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`;

const ICON_LIGHT = `
<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect width="32" height="32" rx="16" fill="#E5E5E5"/>
  <rect x="0.3" y="0.3" width="31.4" height="31.4" rx="15.7" stroke="#999" stroke-opacity="0.3" stroke-width="0.6"/>
  <path d="M6.92578 15.9959C6.92578 18.8919 8.16311 20.1293 11.0591 20.1293V19.3293C8.60045 19.3293 7.72578 18.4546 7.72578 15.9959V12.7959C7.72578 10.3373 8.60045 9.4626 11.0591 9.4626H14.2591C16.7178 9.4626 17.5924 10.3373 17.5924 12.7959L18.3924 12.7959C18.3924 9.89993 17.1551 8.6626 14.2591 8.6626H11.0591C8.16311 8.6626 6.92578 9.89993 6.92578 12.7959V15.9959Z" fill="#666"/>
  <path d="M11.0604 13.7295C10.2497 13.7295 9.59375 13.0735 9.59375 12.2628C9.59375 11.4521 10.2497 10.7961 11.0604 10.7961C11.8711 10.7961 12.5271 11.4521 12.5271 12.2628C12.5271 13.0735 11.8711 13.7295 11.0604 13.7295ZM11.0604 11.5961C10.6924 11.5961 10.3937 11.8948 10.3937 12.2628C10.3937 12.6308 10.6924 12.9295 11.0604 12.9295C11.4284 12.9295 11.7271 12.6308 11.7271 12.2628C11.7271 11.8948 11.4284 11.5961 11.0604 11.5961Z" fill="#666"/>
  <path d="M16.6591 25.3293H19.8591C22.5258 25.3293 23.5924 24.2626 23.5924 21.5959V18.3959C23.5924 15.7293 22.5258 14.6626 19.8591 14.6626H16.6591C13.9924 14.6626 12.9258 15.7293 12.9258 18.3959V21.5959C12.9258 24.2626 13.9924 25.3293 16.6591 25.3293Z" stroke="#666" stroke-width="0.833333" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M16.7148 19.9963V19.207C16.7148 18.1883 17.4348 17.7776 18.3148 18.2843L18.9975 18.679L19.6802 19.0736C20.5602 19.5803 20.5602 20.4123 19.6802 20.919L18.9975 21.3136L18.3148 21.7083C17.4348 22.215 16.7148 21.799 16.7148 20.7856V19.9963Z" stroke="#666" stroke-width="0.833333" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`;

function getFrameIcon() {
  const isDark = document.documentElement.classList.contains('dark');
  return isDark ? ICON_DARK : ICON_LIGHT;
}

/**
 * @param {object} opts
 * @param {string}  opts.label    - Main label (e.g. "Start Video")
 * @param {string}  [opts.sublabel] - Subtitle text
 * @param {string}  [opts.accept='video/*'] - File input accept attribute
 */
export function createFrameUpload({ label, sublabel, accept = 'video/*' } = {}) {
  const wrap = document.createElement('div');

  // Upload area
  const uploadArea = document.createElement('div');
  uploadArea.className =
    'rounded-[16px] border border-dashed border-[#D9D9D9] dark:border-[#272727] bg-panel-input p-4 flex flex-col items-center justify-center gap-2 cursor-pointer hover:border-[#ccc] dark:hover:border-[#3a3a3a] transition-colors h-[115px]';

  const iconWrap = document.createElement('div');
  iconWrap.innerHTML = getFrameIcon();

  const titleEl = document.createElement('div');
  titleEl.className = 'text-sm font-medium text-foreground';
  titleEl.textContent = label || '';

  const subtitleEl = document.createElement('div');
  subtitleEl.className = 'text-xs text-muted-foreground';
  subtitleEl.textContent = sublabel || '';

  uploadArea.appendChild(iconWrap);
  uploadArea.appendChild(titleEl);
  uploadArea.appendChild(subtitleEl);

  // Hidden file input
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = accept;
  fileInput.className = 'hidden';
  uploadArea.appendChild(fileInput);

  // Preview elements
  const previewImg = document.createElement('img');
  previewImg.className = 'hidden w-full h-full object-cover rounded-xl absolute inset-0';

  const previewVideo = document.createElement('video');
  previewVideo.className = 'hidden w-full h-full object-cover rounded-xl absolute inset-0';
  previewVideo.muted = true;
  previewVideo.loop = true;
  previewVideo.playsInline = true;

  const removeBtn = document.createElement('button');
  removeBtn.type = 'button';
  removeBtn.className =
    'hidden absolute top-2 right-2 w-6 h-6 rounded-full bg-black/70 text-white flex items-center justify-center hover:bg-black transition-colors z-10';
  removeBtn.innerHTML =
    '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>';

  uploadArea.appendChild(previewImg);
  uploadArea.appendChild(previewVideo);
  uploadArea.appendChild(removeBtn);
  wrap.appendChild(uploadArea);

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  let currentFile = null;
  let remixDataUrl = null;

  function showPreview(src) {
    uploadArea.classList.add('relative', 'p-0', 'overflow-hidden');
    uploadArea.classList.remove('p-6');
    iconWrap.classList.add('hidden');
    titleEl.classList.add('hidden');
    subtitleEl.classList.add('hidden');
    previewVideo.src = src;
    previewVideo.classList.remove('hidden');
    previewImg.classList.add('hidden');
    previewVideo.play().catch(() => {});
    removeBtn.classList.remove('hidden');
  }

  function clearPreview() {
    currentFile = null;
    remixDataUrl = null;
    fileInput.value = '';
    previewImg.classList.add('hidden');
    previewVideo.classList.add('hidden');
    removeBtn.classList.add('hidden');
    uploadArea.classList.remove('relative', 'p-0', 'overflow-hidden');
    uploadArea.classList.add('p-6');
    iconWrap.classList.remove('hidden');
    titleEl.classList.remove('hidden');
    subtitleEl.classList.remove('hidden');
  }

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      uploadArea.style.borderColor = '';
      uploadArea.style.borderStyle = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    uploadArea.style.borderColor = '#f87171';
    uploadArea.style.borderStyle = 'solid';
  }

  function clearError() {
    setError('');
  }

  uploadArea.addEventListener('click', (e) => {
    if (e.target === removeBtn || removeBtn.contains(e.target)) return;
    fileInput.click();
  });

  fileInput.addEventListener('change', async () => {
    const file = fileInput.files?.[0];
    if (!file) return;

    currentFile = file;
    remixDataUrl = null;
    const url = URL.createObjectURL(file);

    uploadArea.classList.add('relative', 'p-0', 'overflow-hidden');
    uploadArea.classList.remove('p-6');
    iconWrap.classList.add('hidden');
    titleEl.classList.add('hidden');
    subtitleEl.classList.add('hidden');

    if (file.type.startsWith('video/')) {
      previewVideo.src = url;
      previewVideo.classList.remove('hidden');
      previewImg.classList.add('hidden');
      previewVideo.play();
    } else {
      previewImg.src = url;
      previewImg.classList.remove('hidden');
      previewVideo.classList.add('hidden');
    }
    removeBtn.classList.remove('hidden');
  });

  removeBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    clearPreview();
  });

  fileInput.addEventListener('change', clearError);

  return {
    wrap,
    setValue(dataUrl) {
      if (!dataUrl || typeof dataUrl !== 'string') return;
      remixDataUrl = dataUrl;
      currentFile = null;
      showPreview(dataUrl);
    },
    getValue: async () => {
      if (currentFile) {
        return await uploadFileToServer(currentFile, { filename: currentFile.name });
      }
      if (remixDataUrl) {
        if (remixDataUrl.startsWith('http')) return remixDataUrl;
        if (remixDataUrl.startsWith('data:')) {
          return await uploadUrlToServer(remixDataUrl);
        }
        return remixDataUrl;
      }
      return null;
    },
    setError,
    clearError,
  };
}
