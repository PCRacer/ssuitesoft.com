/**
 * Color picker field component.
 * Inline hex input, preview dot toggle, SV canvas picker, responsive hue bar.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createColorPickerField({
  label,
  id,
  required = false,
  help,
  defaultValue = '#FFFFFF',
  presets = {},
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'colorPicker';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'color-picker');

  // --- HSV ↔ RGB ↔ Hex ---
  function hsvToRgb(h, s, v) {
    const i = Math.floor(h / 60) % 6, f = h / 60 - Math.floor(h / 60);
    const p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
    let r, g, b;
    switch (i) {
      case 0: r = v; g = t; b = p; break; case 1: r = q; g = v; b = p; break;
      case 2: r = p; g = v; b = t; break; case 3: r = p; g = q; b = v; break;
      case 4: r = t; g = p; b = v; break; default: r = v; g = p; b = q; break;
    }
    return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
  }
  function rgbToHex(r, g, b) { return '#' + [r, g, b].map(c => c.toString(16).padStart(2, '0')).join('').toUpperCase(); }
  function hexToRgb(hex) { const m = hex.match(/^#?([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})$/); return m ? [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)] : [255, 255, 255]; }
  function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
    let h = 0; const s = max === 0 ? 0 : d / max, v = max;
    if (d !== 0) { if (max === r) h = ((g - b) / d + 6) % 6 * 60; else if (max === g) h = ((b - r) / d + 2) * 60; else h = ((r - g) / d + 4) * 60; }
    return [h, s, v];
  }
  function hexToHsv(hex) { return rgbToHsv(...hexToRgb(hex)); }
  function hsvToHex(h, s, v) { return rgbToHex(...hsvToRgb(h, s, v)); }

  // --- State ---
  const initHsv = hexToHsv(defaultValue || '#FFFFFF');
  let hue = initHsv[0], sat = initHsv[1], val = initHsv[2];
  let selected = (defaultValue || '#FFFFFF').toUpperCase();
  const SV_W = 280, SV_H = 160, HUE_H = 12;
  const HEX_RE = /^#[0-9A-Fa-f]{6}$/;
  const presetEntries = Object.entries(presets).filter(([, hex]) => /^#[0-9A-Fa-f]{6}$/.test(hex));
  const hasPresets = presetEntries.length > 0;
  let pickerOpen = !hasPresets;

  // --- Scoped CSS (one-time) ---
  if (!document.getElementById('aitopia-color-picker-style')) {
    const style = document.createElement('style');
    style.id = 'aitopia-color-picker-style';
    style.textContent = `
      .acp-swatch{position:relative;border-radius:10px;border:2.5px solid transparent;cursor:pointer;transition:transform .12s ease,border-color .12s ease;padding:0;outline:none;overflow:hidden;flex:1 1 0;aspect-ratio:1}
      .acp-swatch:hover{transform:scale(1.06)}
      .acp-swatch:focus-visible{border-color: hsl(var(--ait-m-primary))}
      .acp-swatch .acp-check{display:none}
      .acp-swatch[aria-checked="true"]{border-color: hsl(var(--ait-m-primary))}
      .acp-sv{border-radius:14px;cursor:crosshair;display:block;width:100%;touch-action:none}
      .acp-hue{border-radius:999px;cursor:crosshair;display:block;width:100%;touch-action:none;height:${HUE_H}px}
      .acp-picker{overflow:hidden;transition:max-height .3s cubic-bezier(.4,0,.2,1),opacity .2s ease,margin .3s ease}
      .acp-hex-input{width:70px;padding:4px 6px;border-radius:8px;font-size:11px;font-family:ui-monospace,monospace;text-align:center;border:1px solid rgba(217,217,217,.08);background:transparent;color:#666;outline:none;transition:border-color .15s,box-shadow .15s}
      .dark .acp-hex-input{color:#888;border-color:rgba(255,255,255,.06)}
      .acp-hex-input:focus{border-color: hsl(var(--ait-m-primary));box-shadow:0 0 0 1.5px hsl(var(--ait-m-primary) / .12);background:#EAEFF6}
      .dark .acp-hex-input:focus{background:#141414}
    `;
    document.head.appendChild(style);
  }

  // --- Header ---
  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'flex items-center justify-between mb-2';
    const leftRow = document.createElement('div');
    leftRow.className = 'flex items-center gap-1';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-[13px] font-medium mx-2';
    leftRow.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) { wrap.setAttribute('data-help-scope', ''); leftRow.appendChild(trigger); }
    header.appendChild(leftRow);
    wrap.appendChild(header);
  }

  const swatchButtons = [];

  // --- Inline custom color row: [dot] [hex] [────hue bar────] ---
  const customRow = document.createElement('div');
  customRow.className = 'flex items-center gap-2.5 px-2.5';
  wrap.appendChild(customRow);

  // Color preview dot
  const previewDot = document.createElement('span');
  previewDot.style.cssText = 'display:block;width:28px;height:28px;border-radius:8px;flex-shrink:0;transition:background-color .15s;cursor:pointer;border:1.5px solid rgba(128,128,128,.12)';
  previewDot.style.backgroundColor = selected;
  customRow.appendChild(previewDot);

  // Hex input
  const hexInput = document.createElement('input');
  hexInput.type = 'text';
  hexInput.className = 'acp-hex-input';
  hexInput.value = selected;
  hexInput.maxLength = 7;
  hexInput.spellcheck = false;
  hexInput.autocomplete = 'off';
  hexInput.addEventListener('input', () => {
    let v = hexInput.value.trim().toUpperCase();
    if (!v.startsWith('#')) v = '#' + v;
    if (HEX_RE.test(v)) {
      syncAll(v);
    }
  });
  hexInput.addEventListener('blur', () => {
    hexInput.value = selected;
  });
  customRow.appendChild(hexInput);
  const pickerWrap = document.createElement('div');
  pickerWrap.className = 'acp-picker flex flex-col gap-2.5 mt-2';
  pickerWrap.style.maxHeight = pickerOpen ? '260px' : '0';
  pickerWrap.style.opacity = pickerOpen ? '1' : '0';
  pickerWrap.style.paddingBottom = pickerOpen ? '8px' : '0';

  previewDot.addEventListener('click', () => {
    pickerOpen = !pickerOpen;
    pickerWrap.style.maxHeight = pickerOpen ? '260px' : '0';
    pickerWrap.style.opacity = pickerOpen ? '1' : '0';
    pickerWrap.style.paddingBottom = pickerOpen ? '8px' : '0';
    if (pickerOpen) requestAnimationFrame(redraw);
  });

  // SV canvas
  const svCanvas = document.createElement('canvas');
  svCanvas.className = 'acp-sv';
  svCanvas.width = SV_W;
  svCanvas.height = SV_H;
  const svCtx = svCanvas.getContext('2d');

  function drawSV() {
    const w = svCanvas.width, h = svCanvas.height;
    // SV gradient with rounded clip
    svCtx.save();
    svCtx.beginPath(); svCtx.roundRect(0, 0, w, h, 14); svCtx.clip();
    const [hr, hg, hb] = hsvToRgb(hue, 1, 1);
    const gH = svCtx.createLinearGradient(0, 0, w, 0);
    gH.addColorStop(0, '#fff'); gH.addColorStop(1, `rgb(${hr},${hg},${hb})`);
    svCtx.fillStyle = gH; svCtx.fillRect(0, 0, w, h);
    const gV = svCtx.createLinearGradient(0, 0, 0, h);
    gV.addColorStop(0, 'rgba(0,0,0,0)'); gV.addColorStop(1, '#000');
    svCtx.fillStyle = gV; svCtx.fillRect(0, 0, w, h);
    svCtx.restore();
    // Cursor
    const cx = sat * w, cy = (1 - val) * h;
    svCtx.save();
    svCtx.shadowColor = 'rgba(0,0,0,.35)';
    svCtx.shadowBlur = 6;
    svCtx.beginPath(); svCtx.arc(cx, cy, 8, 0, Math.PI * 2);
    svCtx.fillStyle = hsvToHex(hue, sat, val);
    svCtx.fill();
    svCtx.restore();
    svCtx.beginPath(); svCtx.arc(cx, cy, 8, 0, Math.PI * 2);
    svCtx.strokeStyle = '#fff'; svCtx.lineWidth = 2.5; svCtx.stroke();
  }

  // Hue bar
  const hueWrap = document.createElement('div');
  hueWrap.style.cssText = 'flex:1;min-width:0;height:20px;position:relative;cursor:crosshair;touch-action:none';
  customRow.appendChild(hueWrap);

  const hueCanvas = document.createElement('canvas');
  hueCanvas.className = 'acp-hue';
  hueCanvas.height = 20;
  hueCanvas.style.cssText = 'width:100%;height:100%;display:block';
  const hueCtx = hueCanvas.getContext('2d');
  hueWrap.appendChild(hueCanvas);

  // Size hue canvas to container
  const hueRo = new ResizeObserver((entries) => {
    for (const e of entries) {
      const w = Math.round(e.contentRect.width);
      if (w > 0 && w !== hueCanvas.width) { hueCanvas.width = w; drawHue(); }
    }
  });
  hueRo.observe(hueWrap);

  function drawHue() {
    const w = hueCanvas.width, h = hueCanvas.height;
    if (w <= 0) return;
    hueCtx.clearRect(0, 0, w, h);
    const grad = hueCtx.createLinearGradient(0, 0, w, 0);
    for (let i = 0; i <= 6; i++) { const [r, g, b] = hsvToRgb(i * 60, 1, 1); grad.addColorStop(i / 6, `rgb(${r},${g},${b})`); }
    hueCtx.fillStyle = grad;
    hueCtx.save();
    hueCtx.beginPath(); hueCtx.roundRect(0, 0, w, h, h / 2); hueCtx.clip();
    hueCtx.fillRect(0, 0, w, h);
    hueCtx.restore();
    const mx = Math.max(h / 2, Math.min(w - h / 2, (hue / 360) * w));
    hueCtx.save();
    hueCtx.shadowColor = 'rgba(0,0,0,.3)';
    hueCtx.shadowBlur = 4;
    hueCtx.beginPath(); hueCtx.arc(mx, h / 2, h / 2, 0, Math.PI * 2);
    hueCtx.fillStyle = hsvToHex(hue, 1, 1);
    hueCtx.fill();
    hueCtx.restore();
    hueCtx.beginPath(); hueCtx.arc(mx, h / 2, h / 2, 0, Math.PI * 2);
    hueCtx.strokeStyle = '#fff'; hueCtx.lineWidth = 2; hueCtx.stroke();
  }

  pickerWrap.appendChild(svCanvas);
  wrap.appendChild(pickerWrap);

  // --- Error ---
  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  // --- Helpers ---
  function applySwatches() {
    for (const { btn, hex } of swatchButtons) btn.setAttribute('aria-checked', hex === selected ? 'true' : 'false');
  }
  function redraw() {
    svCanvas.width = svCanvas.width;
    drawSV(); drawHue();
  }
  function commitColor() {
    selected = hsvToHex(hue, sat, val);
    hexInput.value = selected;
    previewDot.style.backgroundColor = selected;
    applySwatches();
    updateFormData(fieldKey, selected);
  }
  function syncAll(hex) {
    [hue, sat, val] = hexToHsv(hex);
    selected = hex.toUpperCase();
    hexInput.value = selected;
    previewDot.style.backgroundColor = selected;
    applySwatches();
    redraw();
    updateFormData(fieldKey, selected);
  }
  function setError(msg) {
    if (!msg) { errorEl.textContent = ''; errorEl.classList.add('hidden'); return; }
    errorEl.textContent = String(msg); errorEl.classList.remove('hidden');
  }
  function clearError() { setError(''); }

  // --- Canvas events ---
  function handleSV(e) {
    const r = svCanvas.getBoundingClientRect();
    sat = Math.max(0, Math.min(1, ((e.touches ? e.touches[0].clientX : e.clientX) - r.left) / r.width));
    val = Math.max(0, Math.min(1, 1 - ((e.touches ? e.touches[0].clientY : e.clientY) - r.top) / r.height));
    redraw(); commitColor();
  }
  let svDrag = false;
  svCanvas.addEventListener('pointerdown', (e) => { svDrag = true; svCanvas.setPointerCapture(e.pointerId); handleSV(e); });
  svCanvas.addEventListener('pointermove', (e) => { if (svDrag) handleSV(e); });
  svCanvas.addEventListener('pointerup', (e) => { svDrag = false; svCanvas.releasePointerCapture(e.pointerId); });

  function handleHue(e) {
    const r = hueWrap.getBoundingClientRect();
    hue = Math.max(0, Math.min(359.99, (((e.touches ? e.touches[0].clientX : e.clientX) - r.left) / r.width) * 360));
    // If saturation is 0 (e.g. white), bump it so hue change is visible
    if (sat < 0.05) sat = 1;
    if (val < 0.05) val = 1;
    drawHue(); drawSV(); commitColor();
  }
  let hueDrag = false;
  hueWrap.addEventListener('pointerdown', (e) => { hueDrag = true; hueWrap.setPointerCapture(e.pointerId); handleHue(e); });
  hueWrap.addEventListener('pointermove', (e) => { if (hueDrag) handleHue(e); });
  hueWrap.addEventListener('pointerup', (e) => { hueDrag = false; hueWrap.releasePointerCapture(e.pointerId); });

  for (const { btn, hex } of swatchButtons) {
    btn.addEventListener('click', () => { clearError(); syncAll(hex); });
  }

  // --- Responsive resize ---
  const ro = new ResizeObserver((entries) => {
    for (const entry of entries) {
      const w = Math.round(entry.contentRect.width);
      if (w > 0 && w !== svCanvas.width) { svCanvas.width = w; drawSV(); }
    }
  });
  ro.observe(pickerWrap);

  if (pickerOpen) drawSV();
  // Hue bar draws on its own ResizeObserver
  requestAnimationFrame(drawHue);
  updateFormData(fieldKey, selected);

  return {
    wrap,
    getValue: () => selected,
    setValue: (v) => { if (v && HEX_RE.test(v)) syncAll(v); },
    setError,
    clearError,
  };
}
