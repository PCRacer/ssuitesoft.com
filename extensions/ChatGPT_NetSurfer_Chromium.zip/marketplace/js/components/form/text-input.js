/**
 * Text input field component.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createTextInputField({
  label,
  id,
  required = false,
  type = 'text',
  placeholder = '',
  help,
  defaultValue = '',
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'textInput';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'input');

  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const row = document.createElement('div');
    row.className = 'flex items-center';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-sm font-medium mx-2';
    row.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      row.appendChild(trigger);
    }
    header.appendChild(row);
    wrap.appendChild(header);
  }

  const input = document.createElement('input');
  input.type = type;
  input.placeholder = placeholder || 'Type anything...';
  input.className =
    'block w-full text-[13px] bg-panel-input border border-panel-border rounded-2xl px-4 py-3 ' +
    'text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 ' +
    'focus:outline-none focus:border-[#D9D9D9]/40 dark:focus:border-[#D9D9D9]/20 transition-colors';
  if (required) input.required = true;
  if (defaultValue != null && defaultValue !== '') input.value = String(defaultValue);

  // Sync to global form data (keep empty string as-is for consistency)
  const syncToGlobal = () => updateFormData(fieldKey, input.value.trim());
  input.addEventListener('input', syncToGlobal);
  input.addEventListener('change', syncToGlobal);
  syncToGlobal(); // Initial sync

  wrap.appendChild(input);

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      input.style.outline = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    input.style.outline = '1.5px solid #f87171';
  }

  function clearError() {
    setError('');
  }

  input.addEventListener('input', clearError);

  return {
    wrap,
    input,
    getValue: () => input.value,
    getTrimmed: () => input.value.trim(),
    setValue: (v) => { input.value = v == null ? '' : String(v); syncToGlobal(); },
    setError,
    clearError,
  };
}
