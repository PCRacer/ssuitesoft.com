/**
 * Toggle switch field component.
 * Renders a boolean on/off toggle switch (styled checkbox).
 */
import { updateFormData, createHelpToggle } from '../../runner/overrides/ui.js';

export function createCheckboxField({
  label,
  id,
  help,
  summary,
  defaultChecked = false,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'checkbox';
  if (id) wrap.setAttribute('data-id', id);
  const row = document.createElement('label');
  row.className =
    'flex items-center justify-between gap-4 select-none cursor-pointer ' +
    'transition-colors px-2 py-2 ' +
    'focus-within:ring-0';

  const textWrap = document.createElement('div');
  textWrap.className = 'min-w-0 flex-1';
  const titleRow = document.createElement('div');
  titleRow.className = 'flex items-center gap-1';
  const title = document.createElement('div');
  title.className = 'agent-form-value text-sm leading-snug';
  title.textContent = String(label || '');
  titleRow.appendChild(title);
  const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
  if (trigger) {
    wrap.setAttribute('data-help-scope', '');
    titleRow.appendChild(trigger);
  }
  textWrap.appendChild(titleRow);

  const toggleWrap = document.createElement('div');
  toggleWrap.className = 'shrink-0 relative';

  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.className = 'sr-only';
  checkbox.checked = Boolean(defaultChecked);
  checkbox.setAttribute('role', 'switch');
  checkbox.setAttribute('aria-checked', checkbox.checked ? 'true' : 'false');

  const track = document.createElement('div');
  track.className =
    'w-9 h-5 rounded-full transition-colors cursor-pointer ' +
    'bg-neutral-300 dark:bg-neutral-700';

  const knob = document.createElement('div');
  knob.className =
    'absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow-md transition-transform';

  let summaryEl = null;

  function syncVisual() {
    checkbox.setAttribute('aria-checked', checkbox.checked ? 'true' : 'false');
    track.classList.toggle('bg-primary/90', checkbox.checked);
    track.classList.toggle('bg-neutral-300', !checkbox.checked);
    track.classList.toggle('dark:bg-neutral-700', !checkbox.checked);
    knob.style.transform = checkbox.checked ? 'translateX(16px)' : 'translateX(0px)';
    if (summaryEl) {
      summaryEl.classList.toggle('text-foreground', checkbox.checked);
      summaryEl.classList.toggle('text-muted-foreground', !checkbox.checked);
      summaryEl.classList.toggle('opacity-70', !checkbox.checked);
    }
  }

  checkbox.addEventListener('change', syncVisual);

  function handleToggleClick(e) {
    e.preventDefault();
    e.stopPropagation();
    checkbox.checked = !checkbox.checked;
    syncVisual();
    checkbox.dispatchEvent(new Event('change', { bubbles: true }));
  }
  track.addEventListener('click', handleToggleClick);
  knob.addEventListener('click', handleToggleClick);

  toggleWrap.appendChild(checkbox);
  toggleWrap.appendChild(track);
  toggleWrap.appendChild(knob);

  row.appendChild(textWrap);
  row.appendChild(toggleWrap);
  wrap.appendChild(row);

  if (summary) {
    summaryEl = document.createElement('p');
    summaryEl.className = 'mt-1 px-2 text-[12px] leading-snug transition-colors';
    summaryEl.textContent = String(summary);
    wrap.appendChild(summaryEl);
  }

  syncVisual();

  // Sync to global form data
  const syncToGlobal = () => updateFormData(fieldKey, Boolean(checkbox.checked));
  checkbox.addEventListener('change', syncToGlobal);
  syncToGlobal(); // Initial sync

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      row.style.outline = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    row.style.outline = '1.5px solid #f87171';
    row.style.borderRadius = '12px';
  }

  function clearError() {
    setError('');
  }

  checkbox.addEventListener('change', clearError);

  return {
    wrap,
    checkbox,
    getValue: () => Boolean(checkbox.checked),
    setValue: (v) => {
      checkbox.checked = Boolean(v);
      syncVisual();
      syncToGlobal();
      checkbox.dispatchEvent(new Event('input', { bubbles: true }));
      checkbox.dispatchEvent(new Event('change', { bubbles: true }));
    },
    setError,
    clearError,
  };
}

