/**
 * Slider field component.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createSliderField({
  label,
  id,
  required = false,
  min = 0,
  max = 100,
  step = 1,
  help,
  defaultValue,
  unit = '',
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'slider';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'slider');

  if (label && String(label).trim()) {
    const labelRow = document.createElement('div');
    labelRow.className = 'flex items-center gap-1 mb-2.5';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-sm font-medium mx-2';
    labelRow.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      labelRow.appendChild(trigger);
    }
    wrap.appendChild(labelRow);
  }

  const initVal = defaultValue != null ? defaultValue : min;

  if (!document.getElementById('aitopia-slider-style')) {
    const style = document.createElement('style');
    style.id = 'aitopia-slider-style';
    style.textContent = `
      .aitopia-slider { -webkit-appearance: none; appearance: none; width: 100%; height: 3px; border-radius: 999px; outline: none; cursor: pointer; background: rgba(255,255,255,0.10); }
      .aitopia-slider::-webkit-slider-runnable-track { height: 3px; border-radius: 999px; background: rgba(255,255,255,0.10); }
      .aitopia-slider::-webkit-slider-thumb { -webkit-appearance: none; appearance: none; width: 12px; height: 12px; border-radius: 50%; background: hsl(var(--ait-m-primary)); margin-top: -5px; cursor: pointer; box-shadow: 0 0 0 3px hsl(var(--ait-m-primary) / 0.15); transition: box-shadow 0.15s, transform 0.15s; }
      .aitopia-slider:hover::-webkit-slider-thumb { box-shadow: 0 0 0 5px hsl(var(--ait-m-primary) / 0.2); }
      .aitopia-slider:active::-webkit-slider-thumb { transform: scale(0.95); box-shadow: 0 0 0 3px hsl(var(--ait-m-primary) / 0.25); }
      .aitopia-slider::-moz-range-track { height: 3px; border-radius: 999px; background: rgba(255,255,255,0.10); border: none; }
      .aitopia-slider::-moz-range-thumb { width: 12px; height: 12px; border-radius: 50%; background: hsl(var(--ait-m-primary)); border: none; cursor: pointer; box-shadow: 0 0 0 3px hsl(var(--ait-m-primary) / 0.15); }
      .aitopia-slider::-moz-range-progress { height: 3px; border-radius: 999px; background: hsl(var(--ait-m-primary) / 0.4); }
    `;
    document.head.appendChild(style);
  }

  const sliderRow = document.createElement('div');
  sliderRow.className = 'flex items-center gap-3';

  const input = document.createElement('input');
  input.type = 'range';
  input.min = String(min);
  input.max = String(max);
  input.step = String(step);
  input.value = String(initVal);
  input.className = 'aitopia-slider flex-1';

  const valueText = document.createElement('span');
  valueText.className = 'text-sm text-gray-400 tabular-nums min-w-[2ch] text-right';
  valueText.textContent = `${initVal}${unit}`;

  sliderRow.appendChild(input);
  sliderRow.appendChild(valueText);
  wrap.appendChild(sliderRow);

  const syncToGlobal = () => {
    const n = Number(input.value);
    const display = Number.isInteger(step) ? Math.round(n) : parseFloat(n.toFixed(1));
    valueText.textContent = `${display}${unit}`;
    updateFormData(fieldKey, Number.isFinite(n) ? n : undefined);
  };
  input.addEventListener('input', syncToGlobal);
  input.addEventListener('change', syncToGlobal);
  syncToGlobal();

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
  }

  function clearError() {
    setError('');
  }

  input.addEventListener('input', clearError);

  return {
    wrap,
    input,
    getNumber: () => {
      const n = Number(input.value);
      return Number.isFinite(n) ? n : undefined;
    },
    setNumber: (n) => { input.value = n == null ? String(min) : String(n); syncToGlobal(); },
    setError,
    clearError,
  };
}
