/**
 * Multi-media upload field component.
 * Self-contained port of model.html's buildMultiFileUploadElement: dropzone with
 * file count, "Clear all", preview grid, drag-drop, and paste-URL+Add row.
 * Base64 mode — files become data URLs; pasted URLs are kept as-is.
 */
import {
  updateFormData, createFieldLabel, createHelpToggle,
} from '../../runner/overrides/ui.js';
import { acceptForKind, isFileTypeAccepted, maxInlineBytesForKind, formatBytes } from '../../shared/media.js';

export function createMultiMediaUploadField({
  label,
  id,
  help,
  kind = 'image',
  maxFiles = 8,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'multiMedia';
  if (id) wrap.setAttribute('data-id', id);

  const suffix = Math.random().toString(16).slice(2);
  const accept = acceptForKind(kind);
  const allowedDesc =
    kind === 'video' ? 'video files'
    : kind === 'audio' ? 'MP3, WAV, or OGG audio'
    : kind === 'audioOrVideo' ? 'audio or video files'
    : kind === 'imageOrVideo' ? 'images or videos'
    : 'PNG, JPG, or WEBP images';

  // Header with label + help toggle (sibling components render their own).
  const header = document.createElement('div');
  header.className = 'mb-3';
  const headerRow = document.createElement('div');
  headerRow.className = 'flex items-center';
  const title = label ? String(label) : 'Upload';
  const labelEl = createFieldLabel(title, { required: false });
  labelEl.className = 'block text-sm font-medium mx-2';
  headerRow.appendChild(labelEl);
  const { trigger } = createHelpToggle({ idSeed: `multi_${suffix}`, labelText: title, helpText: help });
  if (trigger) {
    wrap.setAttribute('data-help-scope', '');
    headerRow.appendChild(trigger);
  }
  header.appendChild(headerRow);
  wrap.appendChild(header);

  const container = document.createElement('div');
  container.className = 'space-y-3';

  // Count + clear-all row
  const countRow = document.createElement('div');
  countRow.className = 'flex items-center justify-between';
  const countText = document.createElement('span');
  countText.className = 'text-sm text-muted-foreground';
  const countEl = document.createElement('span');
  countEl.textContent = '0';
  countText.appendChild(countEl);
  countText.appendChild(document.createTextNode(`/${maxFiles} files`));
  const clearAllBtn = document.createElement('button');
  clearAllBtn.type = 'button';
  clearAllBtn.className = 'text-xs text-red-400 hover:text-red-300 transition-colors hidden';
  clearAllBtn.textContent = 'Clear all';
  countRow.appendChild(countText);
  countRow.appendChild(clearAllBtn);
  container.appendChild(countRow);

  // Drop zone
  const uploadLabel = accept.includes('video') ? 'Upload Videos'
    : accept.includes('audio') ? 'Upload Audio'
      : accept.includes('image') ? 'Upload Images' : 'Upload Files';
  const dropZone = document.createElement('div');
  dropZone.className = 'file-drop-zone rounded-[16px] h-[115px] px-4 py-5 text-center cursor-pointer flex flex-col items-center justify-center';
  dropZone.innerHTML = `
    <div class="flex flex-col items-center gap-2">
      <div class="w-8 h-8 flex items-center justify-center">
        <svg class="w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.338-2.32 3.75 3.75 0 013.57 4.26A4.5 4.5 0 0118 19.5H6.75z"/></svg>
      </div>
      <div class="space-y-1">
        <div class="agent-form-upload-title">${uploadLabel}</div>
        <div class="agent-form-hint" style="color: #9335EC !important">Multiple files supported</div>
      </div>
    </div>
  `;

  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = accept;
  fileInput.multiple = true;
  fileInput.className = 'hidden';
  fileInput.id = `multi_file_${suffix}`;

  // Preview grid
  const previewGrid = document.createElement('div');
  previewGrid.className = 'grid grid-cols-2 sm:grid-cols-3 gap-2 mt-3 hidden';

  // URL + Add row
  const urlWrapper = document.createElement('div');
  urlWrapper.className = 'flex gap-2';
  const urlInput = document.createElement('input');
  urlInput.type = 'text';
  urlInput.className = 'flex-1 text-[13px] bg-panel-input border border-panel-border rounded-2xl px-4 py-2 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-[#D9D9D9]/40 dark:focus:border-[#D9D9D9]/20 transition-colors';
  urlInput.placeholder = 'Or paste URL and press Enter...';
  const addUrlBtn = document.createElement('button');
  addUrlBtn.type = 'button';
  addUrlBtn.className = 'px-3 py-2 text-[13px] bg-panel-input border border-panel-border hover:bg-panel-hover rounded-2xl text-gray-900 dark:text-white transition-colors';
  addUrlBtn.textContent = 'Add';
  urlWrapper.appendChild(urlInput);
  urlWrapper.appendChild(addUrlBtn);

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 px-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  errorEl.setAttribute('aria-live', 'polite');

  container.appendChild(fileInput);
  container.appendChild(dropZone);
  container.appendChild(previewGrid);
  container.appendChild(urlWrapper);
  wrap.appendChild(container);
  wrap.appendChild(errorEl);

  let items = [];

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
  }

  function clearError() {
    setError('');
  }

  function syncToGlobal() {
    updateFormData(fieldKey, items.length > 0 ? items.slice() : undefined);
  }

  function renderPreview() {
    countEl.textContent = String(items.length);
    if (items.length > 0) {
      previewGrid.classList.remove('hidden');
      clearAllBtn.classList.remove('hidden');
    } else {
      previewGrid.classList.add('hidden');
      clearAllBtn.classList.add('hidden');
    }

    previewGrid.innerHTML = '';
    items.forEach((src, idx) => {
      const cell = document.createElement('div');
      cell.className = 'relative group';

      if (accept.includes('image')) {
        const img = document.createElement('img');
        img.src = src;
        img.className = 'w-full h-20 object-cover rounded-xl';
        cell.appendChild(img);
      } else if (accept.includes('video')) {
        const video = document.createElement('video');
        video.src = src;
        video.muted = true;
        video.className = 'w-full h-20 object-cover rounded-xl';
        cell.appendChild(video);
      } else {
        const ph = document.createElement('div');
        ph.className = 'w-full h-20 bg-panel-input rounded-xl flex items-center justify-center text-2xl';
        ph.textContent = accept.includes('audio') ? '🎵' : '📁';
        cell.appendChild(ph);
      }

      const removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.className = 'absolute top-1 right-1 w-5 h-5 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity';
      removeBtn.innerHTML = `<svg class="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>`;
      removeBtn.addEventListener('click', () => removeAt(idx));
      cell.appendChild(removeBtn);

      const badge = document.createElement('div');
      badge.className = 'absolute bottom-1 left-1 px-1 bg-black/60 rounded text-[10px] text-white';
      badge.textContent = String(idx + 1);
      cell.appendChild(badge);

      previewGrid.appendChild(cell);
    });
  }

  function addFiles(fileList) {
    const remaining = maxFiles - items.length;
    if (remaining <= 0) {
      setError(`Maximum ${maxFiles} files allowed`);
      return;
    }
    const all = Array.from(fileList);
    const typeValid = all.filter((f) => isFileTypeAccepted(f, accept));
    // Files are inlined as base64 into the run payload (no server upload), so
    // cap at the inline limit — not the larger upload limit.
    const inlineMaxFor = (f) => maxInlineBytesForKind(
      f.type?.startsWith?.('video/') ? 'video'
        : f.type?.startsWith?.('audio/') ? 'audio'
          : f.type?.startsWith?.('image/') ? 'image' : kind,
    );
    const oversized = typeValid.find((f) => f.size > inlineMaxFor(f));
    const valid = typeValid.filter((f) => f.size <= inlineMaxFor(f));
    const toAdd = valid.slice(0, remaining);
    for (const file of toAdd) {
      const reader = new FileReader();
      reader.onload = () => {
        items.push(reader.result);
        renderPreview();
        syncToGlobal();
      };
      reader.readAsDataURL(file);
    }
    if (oversized) {
      setError(`${oversized.name} is too large (${formatBytes(oversized.size)}). Max is ${formatBytes(inlineMaxFor(oversized))}.`);
    } else if (typeValid.length < all.length) {
      setError(`Unsupported file type. Please use ${allowedDesc}.`);
    } else {
      clearError();
    }
  }

  function addUrl(url) {
    const trimmed = String(url || '').trim();
    if (!trimmed) return;
    if (items.length >= maxFiles) {
      setError(`Maximum ${maxFiles} files allowed`);
      return;
    }
    items.push(trimmed);
    urlInput.value = '';
    clearError();
    renderPreview();
    syncToGlobal();
  }

  function removeAt(index) {
    items.splice(index, 1);
    renderPreview();
    syncToGlobal();
  }

  function clearAll() {
    items = [];
    fileInput.value = '';
    renderPreview();
    syncToGlobal();
  }

  dropZone.addEventListener('click', () => fileInput.click());
  dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('dragover'); });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    if (e.dataTransfer?.files?.length) addFiles(e.dataTransfer.files);
  });
  fileInput.addEventListener('change', () => {
    if (fileInput.files?.length) addFiles(fileInput.files);
  });
  addUrlBtn.addEventListener('click', () => addUrl(urlInput.value));
  urlInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addUrl(urlInput.value);
    }
  });

  clearAllBtn.addEventListener('click', clearAll);

  syncToGlobal();

  return {
    wrap,
    getValue: async () => (items.length > 0 ? items.slice() : undefined),
    setError,
    clearError,
  };
}
