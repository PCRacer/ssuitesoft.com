import { createFieldLabel, createHelpToggle, updateFormData, onAgentFormDataChange } from '../../runner/overrides/ui.js';
import { fileToDataUrl, uploadFileToServer } from '../../shared/media.js';

/**
 * Creates an interactive light-direction picker with a canvas-based control pad.
 *
 * @param {Object}  opts
 * @param {string}  [opts.label]        - Field label text.
 * @param {string}  [opts.id]           - Field key used for form-data storage.
 * @param {Array}   [opts.options]      - (unused, kept for schema compat).
 * @param {string}  [opts.defaultValue] - Initial direction value (JSON-stringified).
 * @param {boolean} [opts.required]     - Whether the field is required.
 * @param {string}  [opts.help]         - Help / tooltip text.
 * @returns {{ wrap: HTMLElement, hasInlineUpload: boolean, getValue: () => string, getAngles: () => {azimuth: number, elevation: number}, setValue: (v: any) => void }}
 */
export function createLightDirectionPicker({
  label,
  id,
  options = [],
  defaultValue,
  required = false,
  help,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'lightDirection';
  if (id) wrap.setAttribute('data-id', id);

  // --- Header / label ---
  if (label) {
    const header = document.createElement('div');
    header.className = 'mb-3';
    const row = document.createElement('div');
    row.className = 'flex items-center';
    const labelEl = createFieldLabel(String(label), { required });
    labelEl.className = 'block text-[13px] font-semibold mx-2';
    row.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      row.appendChild(trigger);
    }
    header.appendChild(row);
    wrap.appendChild(header);
  }

  // Directions
  const DIRECTIONS = ['top', 'front', 'right', 'left', 'back', 'bottom'];
  const normalizedOptions = DIRECTIONS.map(d => ({
    value: JSON.stringify(d),
    label: d.charAt(0).toUpperCase() + d.slice(1),
  }));

  let selected = defaultValue != null ? String(defaultValue) : JSON.stringify('front');

  // --- Quick select buttons (hidden, kept for internal state) ---
  const btnGrid = document.createElement('div');
  btnGrid.style.display = 'none';

  const buttons = [];

  function applyButtons() {
    for (const { btn, value } of buttons) {
      const active = value === selected;
      btn.setAttribute('aria-checked', active ? 'true' : 'false');
      btn.className =
        'px-3 py-2 rounded-lg text-[13px] font-medium transition-all text-center ' +
        (active
          ? 'bg-primary text-primary-foreground shadow-md'
          : 'bg-panel-input text-gray-700 dark:text-gray-300 hover:bg-panel-hover border border-black/5 dark:border-[#232527]');
    }
  }

  // Convert sphere position (lx, ly) + depthY to azimuth/elevation angles
  // depthY: 0 = steep front (+90°), 0.5 = flat (0°), 1 = full back (-90°)
  function anglesToGlobal(lx, ly) {
    const dist = Math.sqrt(lx * lx + ly * ly);
    const azimuth = dist > 0.05
      ? ((Math.atan2(lx, -ly) * 180 / Math.PI) + 360) % 360
      : 0;
    const elevation = 90 - depthY * 180; // +90 (front) → 0 (flat) → -90 (back)
    return {
      azimuth: Math.round(azimuth * 10) / 10,
      elevation: Math.round(elevation * 10) / 10,
    };
  }

  const syncToGlobal = () => {
    updateFormData(fieldKey, selected);
    const angles = anglesToGlobal(lightX, lightY);
    updateFormData('lightAzimuth', angles.azimuth);
    updateFormData('lightElevation', angles.elevation);
  };

  for (const opt of normalizedOptions) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.setAttribute('role', 'radio');
    btn.textContent = opt.label;
    btnGrid.appendChild(btn);
    buttons.push({ btn, value: opt.value });
  }

  // --- Canvas area (the dark control pad) ---
  const canvasWrap = document.createElement('div');
  canvasWrap.className = 'relative rounded-[16px] overflow-hidden select-none border border-dashed border-[#D9D9D9] dark:border-[#272727] bg-panel-input';
  wrap.appendChild(canvasWrap);

  const canvas = document.createElement('canvas');
  canvas.width = 440;
  canvas.height = 340;
  canvas.style.cssText = 'width:100%;height:auto;cursor:grab;touch-action:none;';
  canvasWrap.appendChild(canvas);

  const hintText = document.createElement('p');
  hintText.className = 'text-center text-[11px] text-gray-400 dark:text-gray-500 pointer-events-none';
  hintText.style.cssText = 'position:absolute;bottom:8px;left:0;right:0;';
  hintText.textContent = 'Drag to adjust light direction';
  canvasWrap.appendChild(hintText);

  // Inline image upload
  const _imgFileInput = document.createElement('input');
  _imgFileInput.type = 'file';
  _imgFileInput.accept = 'image/png,image/jpeg,image/webp';
  _imgFileInput.style.display = 'none';
  canvasWrap.appendChild(_imgFileInput);

  const _uploadBtn = document.createElement('button');
  _uploadBtn.type = 'button';
  _uploadBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`;
  _uploadBtn.title = 'Upload image';
  _uploadBtn.style.cssText = 'position:absolute;top:50%;left:calc((100% - 10%) / 2);z-index:2;width:36px;height:36px;display:flex;align-items:center;justify-content:center;transform:translate(-50%,-50%);';
  _uploadBtn.className = 'rounded-full transition-all bg-white/10 text-white/50 hover:bg-white/20 hover:text-white backdrop-blur-sm border border-white/15 hover:border-white/25';
  canvasWrap.appendChild(_uploadBtn);

  _uploadBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    _imgFileInput.click();
  });

  _imgFileInput.addEventListener('change', async () => {
    const file = _imgFileInput.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await fileToDataUrl(file);
      const img = new Image();
      img.onload = () => { userImg = img; userImgSrc = dataUrl; draw(); };
      img.src = dataUrl;
      updateFormData('imageUrl', dataUrl);
      const form = canvasWrap.closest('form');
      const mediaUrlInput = form?.querySelector('[data-id="imageUrl"] input[type="url"], [data-id="imageUrl"] input[type="text"], [data-id="imageUrl"] input:not([type="file"])');
      if (mediaUrlInput) mediaUrlInput.value = dataUrl;
      const uploaded = await uploadFileToServer(file, { kind: 'image' });
      if (uploaded && mediaUrlInput) mediaUrlInput.value = uploaded;
    } catch (err) {
      console.error('Image upload failed:', err);
    }
    _imgFileInput.value = '';
  });

  let _hasUploadedImg = false;
  function updateUploadBtnStyle() {
    const hasImg = !!window.agent_form_data?.imageUrl;
    if (hasImg === _hasUploadedImg) return;
    _hasUploadedImg = hasImg;
    if (hasImg) {
      _uploadBtn.style.cssText = 'position:absolute;top:50%;left:calc((100% - 10%) / 2);z-index:2;width:32px;height:32px;display:flex;align-items:center;justify-content:center;transform:translate(-50%,-50%);opacity:0;transition:opacity 0.2s;';
      _uploadBtn.className = 'rounded-lg bg-black/40 text-white/80 hover:bg-black/60 hover:text-white backdrop-blur-sm border border-white/15';
      _uploadBtn.innerHTML = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>`;
      _uploadBtn.title = 'Change image';
    } else {
      _uploadBtn.style.cssText = 'position:absolute;top:50%;left:calc((100% - 10%) / 2);z-index:2;width:36px;height:36px;display:flex;align-items:center;justify-content:center;transform:translate(-50%,-50%);';
      _uploadBtn.className = 'rounded-full transition-all bg-white/10 text-white/50 hover:bg-white/20 hover:text-white backdrop-blur-sm border border-white/15 hover:border-white/25';
      _uploadBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`;
      _uploadBtn.title = 'Upload image';
    }
  }
  canvasWrap.addEventListener('mouseenter', () => { if (_hasUploadedImg) _uploadBtn.style.opacity = '1'; });
  canvasWrap.addEventListener('mouseleave', () => { if (_hasUploadedImg) _uploadBtn.style.opacity = '0'; });

  // --- Light position as (lx, ly) on sphere surface ---
  // lx: -1=left, +1=right; ly: -1=top, +1=bottom
  // Center (0,0) = front light; edge (dist~1) = side light
  const DIR_POS = {
    '"top"':    { lx:  0,    ly: -0.85 },
    '"bottom"': { lx:  0,    ly:  0.85 },
    '"left"':   { lx: -0.85, ly:  0    },
    '"right"':  { lx:  0.85, ly:  0    },
    '"front"':  { lx:  0,    ly:  0    },
    '"back"':   { lx:  0,    ly:  0    },
  };
  const initP = DIR_POS[selected] || { lx: 0, ly: 0 };
  // Default: 45° az, 45° el
  let lightX = initP.lx || 0.35;
  let lightY = initP.ly || -0.35;
  let depthY = selected === '"back"' ? 0.85 : 0.25;

  // Beam color — synced from lightColor form field
  let beamHex = '#FFFFFF';
  function readBeamColor() {
    const fd = window.agent_form_data;
    if (!fd) return;
    let raw = fd.lightColor;
    if (typeof raw === 'string') {
      try { raw = JSON.parse(raw); } catch { /* keep */ }
      if (typeof raw === 'string' && /^#[0-9A-Fa-f]{6}$/.test(raw)) beamHex = raw;
    }
  }
  readBeamColor();

  // Brightness — synced from brightness form field (0-100, default 50)
  let beamBrightness = 50;
  function readBrightness() {
    const fd = window.agent_form_data;
    if (!fd) return;
    let raw = fd.brightness;
    if (typeof raw === 'string') {
      try { raw = JSON.parse(raw); } catch { /* keep */ }
    }
    if (typeof raw === 'number' && raw >= 0 && raw <= 100) beamBrightness = raw;
  }
  readBrightness();

  // User-uploaded image
  let userImg = null;
  let userImgSrc = '';
  function isImageUrl(s) {
    return typeof s === 'string' && (s.startsWith('http') || s.startsWith('blob:') || s.startsWith('data:'));
  }
  function loadUserImage() {
    const fd = window.agent_form_data;
    if (!fd) return;
    let raw = fd.imageUrl || fd.image_url || fd.image || fd.url;
    if (typeof raw === 'string') {
      try { raw = JSON.parse(raw); } catch { /* keep */ }
    }
    // Also check for thumbnail/preview elements in the image field
    if (!isImageUrl(raw)) {
      const imgField = wrap.closest?.('form')?.querySelector?.('[data-id="imageUrl"] img, [data-id="image"] img');
      if (imgField?.src) raw = imgField.src;
    }
    if (isImageUrl(raw) && raw !== userImgSrc) {
      userImgSrc = raw;
      const img = new Image();
      if (!raw.startsWith('data:')) img.crossOrigin = 'anonymous';
      img.onload = () => { userImg = img; draw(); };
      img.onerror = () => { userImgSrc = ''; }; // keep previous image, allow retry
      img.src = raw;
    } else if (!raw || raw === '') {
      userImg = null;
      userImgSrc = '';
    }
  }
  loadUserImage();
  const imgObserver = new MutationObserver(() => loadUserImage());
  requestAnimationFrame(() => {
    const form = wrap.closest?.('form') || wrap.parentElement;
    if (form) imgObserver.observe(form, { subtree: true, childList: true, attributes: true, attributeFilter: ['src', 'value'] });
  });

  onAgentFormDataChange(({ key }) => {
    if (key === 'lightColor' || key === '*') readBeamColor();
    if (key === 'brightness' || key === '*') readBrightness();
    if (key === 'imageUrl' || key === 'image_url' || key === 'image' || key === 'url' || key === '*') {
      loadUserImage();
      updateUploadBtnStyle();
    }
    draw();
  });

  function parseHex() {
    const h = beamHex;
    return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
  }
  function isDarkMode() {
    return window.matchMedia?.('(prefers-color-scheme: dark)')?.matches
      || document.documentElement.classList.contains('dark');
  }

  function dirFromPos(lx, ly) {
    const d = Math.sqrt(lx * lx + ly * ly);
    if (d < 0.25) return '"front"';
    // Back is now toggle-only — no auto-detection from sphere edge
    let best = '"top"', bestD = Infinity;
    for (const [dir, p] of Object.entries(DIR_POS)) {
      if (dir === '"front"' || dir === '"back"') continue;
      const dd = (lx - p.lx) ** 2 + (ly - p.ly) ** 2;
      if (dd < bestD) { bestD = dd; best = dir; }
    }
    return best;
  }

  const SR = 100; // sphere radius in canvas px
  const STRIP_W = 44;           // depth strip width
  const MAIN_W = canvas.width - STRIP_W; // main area width
  const STRIP_TRACK_PAD = 46;

  // Light source icon paths
  const _iconP1 = new Path2D('M18.4294 21.1001H14.5706C12.6411 21.1001 12 20.2272 12 19.3501V15.8501C12 14.5366 12.6411 14.1001 14.5706 14.1001H18.4294C20.3589 14.1001 21 14.5366 21 15.8501V19.3501C21 20.6636 20.3528 21.1001 18.4294 21.1001Z');
  const _iconP2 = new Path2D('M22.3825 22.7336L19 20.7713V14.4217L22.3825 12.4594C24.0373 11.5034 25.4 12.0871 25.4 13.7676V21.4355C25.4 23.116 24.0373 23.6996 22.3825 22.7336Z');
  const _iconCx = 18.7, _iconCy = 17.6;

  function draw() {
    const ctx = canvas.getContext('2d');
    const W = canvas.width;
    const H = canvas.height;
    const dk = isDarkMode();
    let [cr, cg, cb] = parseHex();
    // In light mode, if beam color is too bright it becomes invisible — darken it
    if (!dk && cr + cg + cb > 600) {
      cr = 80; cg = 80; cb = 80; // use dark gray for visibility
    }
    const cx = MAIN_W / 2;
    const cy = H / 2;
    const isBack = depthY > 0.5;

    // Brightness factor (0..1, maps 0-100% to 0.05..1.0)
    const bri = Math.max(0.05, beamBrightness / 100);

    // Light direction
    const dist = Math.sqrt(lightX * lightX + lightY * lightY);
    const cd = Math.min(dist, 1);
    const nx = dist > 0.01 ? lightX / dist : 0;
    const ny = dist > 0.01 ? lightY / dist : 0;

    // Mode flags
    const isFront = !isBack && cd < 0.15;
    const backHasDir = isBack && cd > 0.05;

    // External light source position (outside the sphere)
    const srcDist = SR * 2.5;
    let finalSrcX, finalSrcY;
    if (isBack) {
      if (backHasDir) {
        finalSrcX = cx + nx * srcDist * Math.max(cd, 0.5);
        finalSrcY = cy + ny * srcDist * Math.max(cd, 0.5);
      } else {
        finalSrcX = cx;
        finalSrcY = cy - srcDist * 0.6;
      }
    } else if (isFront) {
      // Front
      finalSrcX = cx;
      finalSrcY = cy;
    } else {
      // Directional: source orbits outside
      const srcCd = Math.sqrt(cd) * 0.75;
      finalSrcX = cx + nx * srcDist * srcCd;
      finalSrcY = cy + ny * srcDist * srcCd;
    }

    // Background
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = dk ? '#141414' : '#EAEFF6';
    ctx.fillRect(0, 0, W, H);

    // --- Environment light on background ---
    if (isBack) {
      // Back
      ctx.save();
      const backGlowX = backHasDir ? finalSrcX : cx;
      const backGlowY = backHasDir ? finalSrcY : cy;
      const backEnv = ctx.createRadialGradient(backGlowX, backGlowY, 0, backGlowX, backGlowY, SR * 2.2);
      backEnv.addColorStop(0, `rgba(${cr},${cg},${cb},${(dk ? 0.50 : 0.30) * bri})`);
      backEnv.addColorStop(0.2, `rgba(${cr},${cg},${cb},${(dk ? 0.30 : 0.18) * bri})`);
      backEnv.addColorStop(0.5, `rgba(${cr},${cg},${cb},${(dk ? 0.10 : 0.06) * bri})`);
      backEnv.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
      ctx.fillStyle = backEnv;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    } else if (isFront) {
      // Front
      ctx.save();
      const frontEnv = ctx.createRadialGradient(cx, cy, 0, cx, cy, SR * 2.2);
      frontEnv.addColorStop(0, `rgba(${cr},${cg},${cb},${(dk ? 0.28 : 0.20) * bri})`);
      frontEnv.addColorStop(0.3, `rgba(${cr},${cg},${cb},${(dk ? 0.15 : 0.10) * bri})`);
      frontEnv.addColorStop(0.6, `rgba(${cr},${cg},${cb},${(dk ? 0.06 : 0.04) * bri})`);
      frontEnv.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
      ctx.fillStyle = frontEnv;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    } else {
      ctx.save();
      const envGlow = ctx.createRadialGradient(finalSrcX, finalSrcY, 0, finalSrcX, finalSrcY, SR * 1.4);
      envGlow.addColorStop(0, `rgba(${cr},${cg},${cb},${0.20 * bri})`);
      envGlow.addColorStop(0.4, `rgba(${cr},${cg},${cb},${0.06 * bri})`);
      envGlow.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
      ctx.fillStyle = envGlow;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }

    // --- Spotlight cone from source toward sphere (directional only, not back) ---
    if (!isFront && !isBack) {
      ctx.save();
      // Angle from source toward sphere center
      const coneAngle = Math.atan2(cy - finalSrcY, cx - finalSrcX);
      // Narrower spread (~22° each side)
      const coneSpread = Math.PI * 0.12;
      const coneDist = SR * 1.6;
      const farX1 = finalSrcX + Math.cos(coneAngle + coneSpread) * coneDist;
      const farY1 = finalSrcY + Math.sin(coneAngle + coneSpread) * coneDist;
      const farX2 = finalSrcX + Math.cos(coneAngle - coneSpread) * coneDist;
      const farY2 = finalSrcY + Math.sin(coneAngle - coneSpread) * coneDist;

      // Draw the cone triangle
      ctx.beginPath();
      ctx.moveTo(finalSrcX, finalSrcY);
      ctx.lineTo(farX1, farY1);
      ctx.lineTo(farX2, farY2);
      ctx.closePath();

      // Gradient: brighter near source, fading outward
      const coneGrad = ctx.createLinearGradient(
        finalSrcX, finalSrcY,
        finalSrcX + Math.cos(coneAngle) * coneDist, finalSrcY + Math.sin(coneAngle) * coneDist
      );
      coneGrad.addColorStop(0, `rgba(${cr},${cg},${cb},${0.35 * bri})`);
      coneGrad.addColorStop(0.3, `rgba(${cr},${cg},${cb},${0.20 * bri})`);
      coneGrad.addColorStop(0.7, `rgba(${cr},${cg},${cb},${0.08 * bri})`);
      coneGrad.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
      ctx.fillStyle = coneGrad;
      ctx.fill();
      ctx.restore();
    }

    // --- Drop shadow (under sphere) ---
    ctx.save();
    const dsx = isBack ? cx : cx - nx * cd * 15;
    const dsy = cy + SR + 10;
    const dsw = SR * 0.7;
    const ds = ctx.createRadialGradient(dsx, dsy, 0, dsx, dsy, dsw);
    ds.addColorStop(0, dk ? 'rgba(0,0,0,0.4)' : 'rgba(0,0,0,0.12)');
    ds.addColorStop(0.6, dk ? 'rgba(0,0,0,0.1)' : 'rgba(0,0,0,0.03)');
    ds.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = ds;
    ctx.beginPath();
    ctx.ellipse(dsx, dsy, dsw, 8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // --- Subject: user image (rounded rect)---
    const hasImg = !!userImg;
    const imgSide = SR * 1.6; // image square size
    const imgR = 16; // corner radius
    const imgX = cx - imgSide / 2;
    const imgY = cy - imgSide / 2;

    // === BACK LIGHT ===
    if (isBack && backHasDir) {
      const backIconX = finalSrcX;
      const backIconY = finalSrcY;

      // Glow halo
      ctx.save();
      const bkGlowR = 38;
      const bkGlow = ctx.createRadialGradient(backIconX, backIconY, 4, backIconX, backIconY, bkGlowR);
      bkGlow.addColorStop(0, `rgba(${cr},${cg},${cb},${0.55 * bri})`);
      bkGlow.addColorStop(0.3, `rgba(${cr},${cg},${cb},${0.20 * bri})`);
      bkGlow.addColorStop(0.7, `rgba(${cr},${cg},${cb},${0.05 * bri})`);
      bkGlow.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
      ctx.fillStyle = bkGlow;
      ctx.beginPath();
      ctx.arc(backIconX, backIconY, bkGlowR, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Camera icon
      ctx.save();
      const bkScale = 1.6;
      ctx.translate(backIconX, backIconY);
      const bkToCenter = Math.atan2(cy - backIconY, cx - backIconX);
      ctx.rotate(bkToCenter);
      ctx.scale(bkScale, bkScale);
      ctx.translate(-_iconCx, -_iconCy);
      ctx.shadowColor = `rgba(${cr},${cg},${cb},${0.6 * bri})`;
      ctx.shadowBlur = 12 * bri;
      ctx.fillStyle = `rgba(${cr},${cg},${cb},${bri})`;
      ctx.fill(_iconP1);
      ctx.fill(_iconP2);
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      ctx.fillStyle = `rgba(${Math.min(cr + 60, 255)},${Math.min(cg + 60, 255)},${Math.min(cb + 60, 255)},0.5)`;
      ctx.fill(_iconP1);
      ctx.fill(_iconP2);
      ctx.restore();

      // Dashed beam
      ctx.save();
      const bkBeamAngle = Math.atan2(cy - backIconY, cx - backIconX);
      const bkEdgeX = cx - Math.cos(bkBeamAngle) * SR;
      const bkEdgeY = cy - Math.sin(bkBeamAngle) * SR;
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = `rgba(${cr},${cg},${cb},${(dk ? 0.18 : 0.12) * bri})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(backIconX, backIconY);
      ctx.lineTo(bkEdgeX, bkEdgeY);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    }

    if (hasImg) {
      // Rounded rectangle with user photo
      ctx.save();
      ctx.beginPath();
      ctx.roundRect(imgX, imgY, imgSide, imgSide, imgR);
      ctx.clip();
      const iw = userImg.naturalWidth;
      const ih = userImg.naturalHeight;
      const scale = Math.max(imgSide / iw, imgSide / ih);
      const dw = iw * scale;
      const dh = ih * scale;
      ctx.drawImage(userImg, cx - dw / 2, cy - dh / 2, dw, dh);
      ctx.restore();
      // Border
      ctx.save();
      ctx.strokeStyle = dk ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.08)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.roundRect(imgX, imgY, imgSide, imgSide, imgR);
      ctx.stroke();
      ctx.restore();
    } else {
      // Dark rounded rectangle placeholder (empty state)
      ctx.save();
      ctx.beginPath();
      ctx.roundRect(imgX, imgY, imgSide, imgSide, imgR);
      ctx.fillStyle = dk ? '#1e2023' : '#dde3ed';
      ctx.fill();
      // Subtle inner gradient for depth
      const innerGrad = ctx.createLinearGradient(imgX, imgY, imgX, imgY + imgSide);
      innerGrad.addColorStop(0, dk ? 'rgba(255,255,255,0.03)' : 'rgba(255,255,255,0.15)');
      innerGrad.addColorStop(1, dk ? 'rgba(0,0,0,0.10)' : 'rgba(0,0,0,0.04)');
      ctx.fillStyle = innerGrad;
      ctx.fill();
      ctx.restore();
    }

    // Helper
    function clipSubject() {
      ctx.beginPath();
      ctx.roundRect(imgX, imgY, imgSide, imgSide, imgR);
      ctx.clip();
    }

    // Apply lighting effects on the subject (both image and empty state)

    if (isBack) {
      // Back light — no effects INSIDE the square

    } else if (isFront) {
      // front light
      ctx.save();
      clipSubject();
      const frontFlood = ctx.createRadialGradient(cx, cy, 0, cx, cy, SR * 1.1);
      const flA = dk ? 0.55 : 0.40;
      frontFlood.addColorStop(0, `rgba(${cr},${cg},${cb},${flA * bri})`);
      frontFlood.addColorStop(0.35, `rgba(${cr},${cg},${cb},${flA * 0.65 * bri})`);
      frontFlood.addColorStop(0.65, `rgba(${cr},${cg},${cb},${flA * 0.30 * bri})`);
      frontFlood.addColorStop(0.85, `rgba(${cr},${cg},${cb},${flA * 0.10 * bri})`);
      frontFlood.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
      ctx.fillStyle = frontFlood;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();

      ctx.save();
      clipSubject();
      const frontSoft = ctx.createRadialGradient(cx, cy, SR * 0.2, cx, cy, SR * 0.85);
      const fsA = dk ? 0.25 : 0.18;
      frontSoft.addColorStop(0, `rgba(${cr},${cg},${cb},${fsA * bri})`);
      frontSoft.addColorStop(0.5, `rgba(${cr},${cg},${cb},${fsA * 0.5 * bri})`);
      frontSoft.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
      ctx.fillStyle = frontSoft;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();

      // Centered specular highlight
      ctx.save();
      clipSubject();
      const fspec = ctx.createRadialGradient(cx, cy - SR * 0.05, 0, cx, cy - SR * 0.05, SR * 0.30);
      fspec.addColorStop(0, `rgba(255,255,255,${(dk ? 0.65 : 0.50) * bri})`);
      fspec.addColorStop(0.3, `rgba(255,255,255,${(dk ? 0.25 : 0.18) * bri})`);
      fspec.addColorStop(0.6, `rgba(255,255,255,${(dk ? 0.08 : 0.05) * bri})`);
      fspec.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = fspec;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();

      // Subtle edge shadow for depth
      ctx.save();
      clipSubject();
      const fEdge = ctx.createRadialGradient(cx, cy, SR * 0.55, cx, cy, SR);
      fEdge.addColorStop(0, 'rgba(0,0,0,0)');
      fEdge.addColorStop(0.7, `rgba(0,0,0,${dk ? 0.08 : 0.03})`);
      fEdge.addColorStop(1, `rgba(0,0,0,${dk ? 0.22 : 0.10})`);
      ctx.fillStyle = fEdge;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();

    } else {
      // directional light

      // Light direction: lit edge at (cx + nx*half, cy + ny*half),
      //                  shadow edge at (cx - nx*half, cy - ny*half)
      const half = imgSide / 2;
      const litEdgeX = cx + nx * half;
      const litEdgeY = cy + ny * half;
      const darkEdgeX = cx - nx * half;
      const darkEdgeY = cy - ny * half;

      // Shadow: linear darkening from shadow side to lit side
      ctx.save();
      clipSubject();
      const sh = ctx.createLinearGradient(darkEdgeX, darkEdgeY, litEdgeX, litEdgeY);
      sh.addColorStop(0, `rgba(0,0,0,${dk ? 0.45 : 0.35})`);
      sh.addColorStop(0.4, `rgba(0,0,0,${dk ? 0.15 : 0.10})`);
      sh.addColorStop(0.7, 'rgba(0,0,0,0)');
      sh.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = sh;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();

      // Primary illumination: linear wash from lit edge fading inward
      ctx.save();
      clipSubject();
      const ill = ctx.createLinearGradient(litEdgeX, litEdgeY, darkEdgeX, darkEdgeY);
      const illA = 0.50;
      ill.addColorStop(0, `rgba(${cr},${cg},${cb},${illA * bri})`);
      ill.addColorStop(0.25, `rgba(${cr},${cg},${cb},${illA * 0.45 * bri})`);
      ill.addColorStop(0.55, `rgba(${cr},${cg},${cb},${illA * 0.12 * bri})`);
      ill.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
      ctx.fillStyle = ill;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();

      // Specular highlight near the lit edge
      const specX = cx + nx * half * 0.5;
      const specY = cy + ny * half * 0.5;
      ctx.save();
      clipSubject();
      const sp = ctx.createRadialGradient(specX, specY, 0, specX, specY, SR * 0.15);
      sp.addColorStop(0, `rgba(255,255,255,${0.40 * bri})`);
      sp.addColorStop(0.4, `rgba(255,255,255,${0.12 * bri})`);
      sp.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = sp;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();

    }

    // --- Colored border glow (empty state only) ---
    if (!hasImg && !isFront && !(isBack && !backHasDir)) {
      ctx.save();
      const clipCx = cx + nx * imgSide;
      const clipCy = cy + ny * imgSide;
      ctx.beginPath();
      ctx.arc(clipCx, clipCy, imgSide * 1.2, 0, Math.PI * 2);
      ctx.clip();
      ctx.shadowColor = `rgba(${cr},${cg},${cb},${0.5 * bri})`;
      ctx.shadowBlur = 12 * bri;
      ctx.shadowOffsetX = nx * 4;
      ctx.shadowOffsetY = ny * 4;
      ctx.strokeStyle = `rgba(${cr},${cg},${cb},${0.45 * bri})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(imgX, imgY, imgSide, imgSide, imgR);
      ctx.stroke();
      ctx.restore();
    }

    if (isBack) {
      // === BACK LIGHT===

      ctx.save();
      if (backHasDir) {
        const half = imgSide / 2;
        const litEdgeX = cx + nx * (half + 8);
        const litEdgeY = cy + ny * (half + 8);
        const darkEdgeX = cx - nx * (half + 8);
        const darkEdgeY = cy - ny * (half + 8);

        const rimGlow = ctx.createLinearGradient(finalSrcX, finalSrcY, darkEdgeX, darkEdgeY);
        rimGlow.addColorStop(0, `rgba(${cr},${cg},${cb},${0.10 * bri})`);
        rimGlow.addColorStop(0.2, `rgba(${cr},${cg},${cb},${0.03 * bri})`);
        rimGlow.addColorStop(0.35, `rgba(${cr},${cg},${cb},0)`);
        rimGlow.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
        ctx.fillStyle = rimGlow;
        ctx.fillRect(0, 0, W, H);

        ctx.save();
        const perpX = -ny;
        const perpY = nx;
        const far = W + H;
        ctx.beginPath();
        ctx.moveTo(cx + perpX * far, cy + perpY * far);
        ctx.lineTo(cx - perpX * far, cy - perpY * far);
        ctx.lineTo(cx - perpX * far + nx * far, cy - perpY * far + ny * far);
        ctx.lineTo(cx + perpX * far + nx * far, cy + perpY * far + ny * far);
        ctx.closePath();
        ctx.clip();
        ctx.shadowColor = `rgba(${cr},${cg},${cb},${0.15 * bri})`;
        ctx.shadowBlur = 6 * bri;
        ctx.shadowOffsetX = nx * 2;
        ctx.shadowOffsetY = ny * 2;
        ctx.strokeStyle = `rgba(${cr},${cg},${cb},${0.18 * bri})`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(imgX, imgY, imgSide, imgSide, imgR);
        ctx.stroke();
        ctx.restore();
      } else {
        // Centered back: strong uniform glow around all edges
        const uniGlow = ctx.createRadialGradient(cx, cy, imgSide / 2 - 4, cx, cy, imgSide / 2 + SR * 0.6);
        uniGlow.addColorStop(0, `rgba(${cr},${cg},${cb},0)`);
        uniGlow.addColorStop(0.2, `rgba(${cr},${cg},${cb},${0.45 * bri})`);
        uniGlow.addColorStop(0.5, `rgba(${cr},${cg},${cb},${0.18 * bri})`);
        uniGlow.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
        ctx.fillStyle = uniGlow;
        ctx.fillRect(0, 0, W, H);

        // Strong shadow glow all around
        ctx.save();
        ctx.shadowColor = `rgba(${cr},${cg},${cb},${0.55 * bri})`;
        ctx.shadowBlur = 22 * bri;
        ctx.strokeStyle = 'rgba(0,0,0,0)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.roundRect(imgX, imgY, imgSide, imgSide, imgR);
        ctx.stroke();
        ctx.restore();

        // Visible border line
        ctx.save();
        ctx.shadowColor = `rgba(${cr},${cg},${cb},${0.5 * bri})`;
        ctx.shadowBlur = 8 * bri;
        ctx.strokeStyle = `rgba(${cr},${cg},${cb},${0.25 * bri})`;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.roundRect(imgX, imgY, imgSide, imgSide, imgR);
        ctx.stroke();
        ctx.restore();
      }
      ctx.restore();

    } else if (!isBack) {
      // === FRONT / DIRECTIONAL: light source icon + cone + beam ===
      const iconX = isFront ? cx : finalSrcX;
      const iconY = isFront ? cy : finalSrcY;

      // --- Soft glow halo ---
      ctx.save();
      if (isFront) {
        const fGlowR = SR * 0.7;
        const fGlow = ctx.createRadialGradient(iconX, iconY, 2, iconX, iconY, fGlowR);
        fGlow.addColorStop(0, `rgba(${cr},${cg},${cb},${0.50 * bri})`);
        fGlow.addColorStop(0.2, `rgba(${cr},${cg},${cb},${0.25 * bri})`);
        fGlow.addColorStop(0.5, `rgba(${cr},${cg},${cb},${0.08 * bri})`);
        fGlow.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
        ctx.fillStyle = fGlow;
        ctx.beginPath();
        ctx.arc(iconX, iconY, fGlowR, 0, Math.PI * 2);
        ctx.fill();
      } else {
        const glowR = 38;
        const glow = ctx.createRadialGradient(iconX, iconY, 4, iconX, iconY, glowR);
        glow.addColorStop(0, `rgba(${cr},${cg},${cb},${0.55 * bri})`);
        glow.addColorStop(0.3, `rgba(${cr},${cg},${cb},${0.20 * bri})`);
        glow.addColorStop(0.7, `rgba(${cr},${cg},${cb},${0.05 * bri})`);
        glow.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(iconX, iconY, glowR, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // --- SVG light icon ---
      ctx.save();
      if (isFront) {
        const circR = 8;
        ctx.shadowColor = `rgba(${cr},${cg},${cb},${0.6 * bri})`;
        ctx.shadowBlur = 16 * bri;
        ctx.fillStyle = `rgba(${cr},${cg},${cb},${0.7 * bri})`;
        ctx.beginPath();
        ctx.arc(iconX, iconY, circR, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowColor = 'transparent';
        ctx.shadowBlur = 0;
        ctx.fillStyle = `rgba(${Math.min(cr + 80, 255)},${Math.min(cg + 80, 255)},${Math.min(cb + 80, 255)},${0.4 * bri})`;
        ctx.beginPath();
        ctx.arc(iconX, iconY, circR * 0.6, 0, Math.PI * 2);
        ctx.fill();
      } else {
        const iconScale = 1.6;
        ctx.translate(iconX, iconY);
        const toCenter = Math.atan2(cy - iconY, cx - iconX);
        ctx.rotate(toCenter);
        ctx.scale(iconScale, iconScale);
        ctx.translate(-_iconCx, -_iconCy);
        ctx.shadowColor = `rgba(${cr},${cg},${cb},${0.6 * bri})`;
        ctx.shadowBlur = 12 * bri;
        ctx.fillStyle = `rgba(${cr},${cg},${cb},${bri})`;
        ctx.fill(_iconP1);
        ctx.fill(_iconP2);
        ctx.shadowColor = 'transparent';
        ctx.shadowBlur = 0;
        ctx.fillStyle = `rgba(${Math.min(cr + 60, 255)},${Math.min(cg + 60, 255)},${Math.min(cb + 60, 255)},0.5)`;
        ctx.fill(_iconP1);
        ctx.fill(_iconP2);
      }
      ctx.restore();

      // --- Dashed beam line ---
      if (!isFront) {
        ctx.save();
        const beamAngle = Math.atan2(cy - iconY, cx - iconX);
        const edgeX = cx - Math.cos(beamAngle) * SR;
        const edgeY = cy - Math.sin(beamAngle) * SR;
        ctx.setLineDash([4, 4]);
        ctx.strokeStyle = `rgba(${cr},${cg},${cb},${(dk ? 0.18 : 0.12) * bri})`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(iconX, iconY);
        ctx.lineTo(edgeX, edgeY);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();
      }
    }

    // --- Back mode: draggable position dot on the canvas surface ---
    if (isBack) {
      const dotX = cx + lightX * SR;
      const dotY = cy + lightY * SR;
      // Outer glow
      ctx.save();
      const dotGlow = ctx.createRadialGradient(dotX, dotY, 0, dotX, dotY, 14);
      dotGlow.addColorStop(0, `rgba(${cr},${cg},${cb},${0.35 * bri})`);
      dotGlow.addColorStop(0.5, `rgba(${cr},${cg},${cb},${0.10 * bri})`);
      dotGlow.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
      ctx.fillStyle = dotGlow;
      ctx.beginPath();
      ctx.arc(dotX, dotY, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      // Inner dot
      ctx.save();
      ctx.fillStyle = `rgba(${cr},${cg},${cb},${0.6 * bri})`;
      ctx.beginPath();
      ctx.arc(dotX, dotY, 5, 0, Math.PI * 2);
      ctx.fill();
      // Bright center
      ctx.fillStyle = `rgba(${Math.min(cr + 80, 255)},${Math.min(cg + 80, 255)},${Math.min(cb + 80, 255)},${0.5 * bri})`;
      ctx.beginPath();
      ctx.arc(dotX, dotY, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // --- Direction label (azimuth + elevation) ---
    const angles = anglesToGlobal(lightX, lightY);
    const az = Math.round(angles.azimuth);
    const el = Math.round(angles.elevation);
    const elSign = el >= 0 ? '+' : '';
    const dirLabel = `${az}\u00B0 az \u00B7 ${elSign}${el}\u00B0 el`;
    ctx.save();
    ctx.fillStyle = dk ? 'rgba(255,255,255,0.22)' : 'rgba(0,0,0,0.18)';
    ctx.font = '600 10px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(dirLabel, cx, cy + imgSide / 2 + 22);
    ctx.restore();

    // side-view front - back control
    ctx.save();

    const stripBg = ctx.createLinearGradient(MAIN_W, 0, W, 0);
    stripBg.addColorStop(0, dk ? '#151719' : '#dfe5ee');
    stripBg.addColorStop(1, dk ? '#1a1c1f' : '#e4eaf2');
    ctx.fillStyle = stripBg;
    ctx.fillRect(MAIN_W, 0, STRIP_W, H);

    const sepGrad = ctx.createLinearGradient(MAIN_W - 2, 0, MAIN_W + 3, 0);
    sepGrad.addColorStop(0, 'rgba(0,0,0,0)');
    sepGrad.addColorStop(0.5, dk ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.07)');
    sepGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = sepGrad;
    ctx.fillRect(MAIN_W - 2, 0, 5, H);

    const stripCx = MAIN_W + STRIP_W / 2;
    const trackTop = STRIP_TRACK_PAD;
    const trackBot = H - STRIP_TRACK_PAD;
    const trackH = trackBot - trackTop;

    // front label — bold when active
    const frontActive = depthY <= 0.5;
    ctx.fillStyle = frontActive
      ? (dk ? 'rgba(255,255,255,0.85)' : 'rgba(0,0,0,0.75)')
      : (dk ? 'rgba(255,255,255,0.25)' : 'rgba(0,0,0,0.22)');
    ctx.font = frontActive ? '700 8px system-ui, sans-serif' : '500 7px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('FRONT', stripCx, 18);
    // camera icon
    const camY = 32;
    const camAlpha = frontActive ? 1 : 0.5;
    ctx.fillStyle = dk ? `rgba(255,255,255,${0.25 * camAlpha})` : `rgba(0,0,0,${0.20 * camAlpha})`;
    ctx.beginPath();
    ctx.roundRect(stripCx - 6, camY - 3, 9, 6, 1.5);
    ctx.fill();
    ctx.beginPath();
    ctx.roundRect(stripCx + 3, camY - 2, 3, 4, 1);
    ctx.fill();
    ctx.fillStyle = dk ? `rgba(255,255,255,${0.45 * camAlpha})` : `rgba(0,0,0,${0.30 * camAlpha})`;
    ctx.beginPath();
    ctx.arc(stripCx - 1.5, camY, 2, 0, Math.PI * 2);
    ctx.fill();

    // back label — bold when active
    const backActive = depthY > 0.5;
    ctx.fillStyle = backActive
      ? (dk ? 'rgba(255,255,255,0.85)' : 'rgba(0,0,0,0.75)')
      : (dk ? 'rgba(255,255,255,0.25)' : 'rgba(0,0,0,0.22)');
    ctx.font = backActive ? '700 8px system-ui, sans-serif' : '500 7px system-ui, sans-serif';
    ctx.fillText('BACK', stripCx, H - 16);

    // center
    const subjectY = trackTop + trackH * 0.5;
    ctx.fillStyle = dk ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.14)';

    ctx.beginPath();
    ctx.arc(stripCx, subjectY - 7, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(stripCx - 6, subjectY + 9);
    ctx.lineTo(stripCx - 3, subjectY - 1);
    ctx.quadraticCurveTo(stripCx, subjectY - 3, stripCx + 3, subjectY - 1);
    ctx.lineTo(stripCx + 6, subjectY + 9);
    ctx.quadraticCurveTo(stripCx, subjectY + 11, stripCx - 6, subjectY + 9);
    ctx.fill();

    // track
    const grooveW = 3;
    ctx.fillStyle = dk ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.04)';
    ctx.beginPath();
    ctx.roundRect(stripCx - grooveW / 2, trackTop, grooveW, subjectY - 14 - trackTop, grooveW / 2);
    ctx.fill();
    ctx.beginPath();
    ctx.roundRect(stripCx - grooveW / 2, subjectY + 14, grooveW, trackBot - subjectY - 14, grooveW / 2);
    ctx.fill();

    // light dot
    const dotStripY = trackTop + depthY * trackH;

    if (Math.abs(dotStripY - subjectY) > 12) {
      const lineFromY = Math.min(dotStripY, subjectY);
      const lineToY = Math.max(dotStripY, subjectY);
      ctx.save();
      ctx.setLineDash([2, 3]);
      ctx.strokeStyle = `rgba(${cr},${cg},${cb},${(dk ? 0.30 : 0.22) * bri})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(stripCx, lineFromY + 7);
      ctx.lineTo(stripCx, lineToY - 7);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    }

    // outer glow
    const stripDotGlow = ctx.createRadialGradient(stripCx, dotStripY, 0, stripCx, dotStripY, 14);
    stripDotGlow.addColorStop(0, `rgba(${cr},${cg},${cb},${0.45 * bri})`);
    stripDotGlow.addColorStop(0.4, `rgba(${cr},${cg},${cb},${0.10 * bri})`);
    stripDotGlow.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
    ctx.fillStyle = stripDotGlow;
    ctx.beginPath();
    ctx.arc(stripCx, dotStripY, 14, 0, Math.PI * 2);
    ctx.fill();

    // dot body
    ctx.fillStyle = `rgba(${cr},${cg},${cb},${0.90 * bri})`;
    ctx.beginPath();
    ctx.arc(stripCx, dotStripY, 5.5, 0, Math.PI * 2);
    ctx.fill();

    // bright center
    ctx.fillStyle = `rgba(${Math.min(cr + 80, 255)},${Math.min(cg + 80, 255)},${Math.min(cb + 80, 255)},${0.75 * bri})`;
    ctx.beginPath();
    ctx.arc(stripCx, dotStripY, 2.5, 0, Math.PI * 2);
    ctx.fill();

    // grab ring
    ctx.strokeStyle = `rgba(${cr},${cg},${cb},${0.25 * bri})`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(stripCx, dotStripY, 8, 0, Math.PI * 2);
    ctx.stroke();

    ctx.restore();
  }

  // --- Drag: main sphere (azimuth) or depth strip (elevation) ---
  let dragging = false;
  let dragZone = 'main'; // 'main' or 'strip'

  function posFromPointer(e) {
    const rect = canvas.getBoundingClientRect();
    const sx = canvas.width / rect.width;
    const sy = canvas.height / rect.height;
    const px = (e.clientX - rect.left) * sx - MAIN_W / 2;
    const py = (e.clientY - rect.top) * sy - canvas.height / 2;
    // Map to [-1, 1] relative to sphere
    let lx = px / SR;
    let ly = py / SR;
    const d = Math.sqrt(lx * lx + ly * ly);
    if (d > 1) { lx /= d; ly /= d; }
    return { lx, ly };
  }

  function updateFromPos(lx, ly) {
    lightX = lx;
    lightY = ly;
    const isBack = depthY > 0.5;
    if (!isBack) {
      const newDir = dirFromPos(lx, ly);
      if (newDir !== selected) {
        selected = newDir;
        applyButtons();
      }
    }
    syncToGlobal();
    draw();
  }

  function updateDepthFromPointer(e) {
    const rect = canvas.getBoundingClientRect();
    const sy = canvas.height / rect.height;
    const py = (e.clientY - rect.top) * sy;
    const trackTop = STRIP_TRACK_PAD;
    const trackBot = canvas.height - STRIP_TRACK_PAD;
    depthY = Math.max(0, Math.min(1, (py - trackTop) / (trackBot - trackTop)));
    if (depthY > 0.5) {
      selected = '"back"';
    } else {
      selected = dirFromPos(lightX, lightY);
    }
    applyButtons();
    syncToGlobal();
    draw();
  }

  canvas.addEventListener('pointerdown', (e) => {
    dragging = true;
    canvas.style.cursor = 'grabbing';
    canvas.setPointerCapture(e.pointerId);
    const rect = canvas.getBoundingClientRect();
    const sx = canvas.width / rect.width;
    const px = (e.clientX - rect.left) * sx;
    if (px > MAIN_W) {
      dragZone = 'strip';
      updateDepthFromPointer(e);
    } else {
      dragZone = 'main';
      const { lx, ly } = posFromPointer(e);
      updateFromPos(lx, ly);
    }
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    if (dragZone === 'strip') {
      updateDepthFromPointer(e);
    } else {
      const { lx, ly } = posFromPointer(e);
      updateFromPos(lx, ly);
    }
  });
  canvas.addEventListener('pointerup', () => { dragging = false; canvas.style.cursor = 'grab'; });
  canvas.addEventListener('pointercancel', () => { dragging = false; canvas.style.cursor = 'grab'; });

  // Button click handlers
  for (const { btn, value } of buttons) {
    btn.addEventListener('click', () => {
      selected = value;
      depthY = value === '"back"' ? 0.85 : 0.15;
      const p = DIR_POS[value] || { lx: 0, ly: 0 };
      lightX = p.lx;
      lightY = p.ly;
      applyButtons();
      draw();
      syncToGlobal();
    });
  }

  // Initial draw
  applyButtons();
  syncToGlobal();
  requestAnimationFrame(() => draw());

  // Theme change
  window.matchMedia?.('(prefers-color-scheme: dark)')?.addEventListener('change', () => draw());
  new MutationObserver(() => draw()).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });

  return {
    wrap,
    hasInlineUpload: true,
    getValue: () => selected,
    getAngles: () => anglesToGlobal(lightX, lightY),
    setValue: (v) => {
      selected = v == null ? '' : String(v);
      depthY = selected === '"back"' ? 0.85 : 0.15;
      const p = DIR_POS[selected] || { lx: 0, ly: 0 };
      lightX = p.lx;
      lightY = p.ly;
      applyButtons();
      draw();
      syncToGlobal();
    },
  };
}
