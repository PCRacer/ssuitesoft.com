/**
 * Interactive prompt component.
 * Renders a template string with clickable inline pills for slot values.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

/* ── module-level singleton: only one dropdown open at a time ── */
let activeDropdown = null;

export function createInteractivePrompt({
  label,
  id,
  required = false,
  help,
  template = '',
  slots = {},
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'interactivePrompt';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'interactive-prompt');

  /* ── optional header (label + help) ── */
  if (label) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const headerRow = document.createElement('div');
    headerRow.className = 'flex items-center';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-[13px] font-medium mx-2';
    headerRow.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      headerRow.appendChild(trigger);
    }
    header.appendChild(headerRow);
    wrap.appendChild(header);
  }

  /* ── parse template into segments ── */
  const slotPattern = /\{(\w+)\}/g;
  const segments = [];
  let lastIndex = 0;
  let match;
  while ((match = slotPattern.exec(template)) !== null) {
    if (match.index > lastIndex) {
      segments.push({ type: 'text', value: template.slice(lastIndex, match.index) });
    }
    const name = match[1];
    if (slots[name]) {
      segments.push({ type: 'slot', name });
    } else {
      // Unknown placeholder — render as literal text
      segments.push({ type: 'text', value: match[0] });
    }
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < template.length) {
    segments.push({ type: 'text', value: template.slice(lastIndex) });
  }

  /* ── normalise slot options & initialise state ── */
  const slotState = {}; // { name: currentValue }
  const slotOptions = {}; // { name: [{value,label}] }

  for (const [name, cfg] of Object.entries(slots)) {
    const opts = (Array.isArray(cfg.options) ? cfg.options : []).map(opt => ({
      value: String(opt?.value ?? ''),
      label: String(opt?.label ?? opt?.value ?? ''),
    }));
    slotOptions[name] = opts;
    const desired = cfg.defaultValue != null ? String(cfg.defaultValue) : null;
    if (desired != null && opts.some(o => o.value === desired)) {
      slotState[name] = desired;
    } else {
      slotState[name] = opts.length > 0 ? opts[0].value : '';
    }
  }

  /* ── assemble prompt string ── */
  function assemble() {
    let out = '';
    for (const node of card.childNodes) {
      if (node.nodeType === Node.TEXT_NODE) {
        out += node.textContent;
        continue;
      }
      if (node.nodeType !== Node.ELEMENT_NODE) continue;
      const slotName = node.getAttribute && node.getAttribute('data-slot');
      if (slotName) {
        out += slotState[slotName] ?? '';
      } else if (node.tagName === 'BR') {
        out += '\n';
      } else {
        out += node.textContent ?? '';
      }
    }
    return out;
  }

  /* ── chevron SVG (tiny) ── */
  const chevronSvg =
    '<svg class="w-2.5 h-2.5 opacity-60" fill="none" stroke="currentColor" ' +
    'viewBox="0 0 24 24" aria-hidden="true"><path stroke-width="2.5" stroke-linecap="round" ' +
    'stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>';

  /* ── checkmark SVG ── */
  const checkSvg =
    '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">' +
    '<path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>';

  /* ── card container ── */
  const card = document.createElement('div');
  card.setAttribute('contenteditable', 'true');
  card.setAttribute('spellcheck', 'false');
  card.setAttribute('role', 'textbox');
  card.setAttribute('aria-multiline', 'true');
  card.className =
    'rounded-xl bg-panel-input ' +
    'border border-black/5 dark:border-white/[0.08] px-2 py-1 ' +
    'text-[13px] leading-loose text-gray-800 dark:text-gray-200 ' +
    'focus:outline-none focus:ring-1 focus:ring-purple-300 dark:focus:ring-purple-700/50';

  /* ── pill references for setValue ── */
  const pillElements = {}; // { slotName: { labelSpan, button } }
  const dropdownMenus = {}; // { slotName: menuElement }

  /* ── build card contents ── */
  segments.forEach(seg => {
    if (seg.type === 'text') {
      const span = document.createElement('span');
      span.textContent = seg.value;
      card.appendChild(span);
    } else {
      // Slot pill
      const name = seg.name;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.setAttribute('contenteditable', 'false');
      btn.setAttribute('data-slot', name);
      btn.className =
        'inline-flex items-center gap-1 px-2 py-1 mx-1 my-0.5 rounded ' +
        'bg-purple-50 dark:bg-purple-950/40 ' +
        'bg-primary/10 ' +
        'text-primary ' +
        'border border-primary/30 ' +
        'text-[12px] font-medium whitespace-nowrap cursor-pointer ' +
        'hover:bg-primary/20 ' +
        'transition-colors focus:outline-none select-none';
      btn.classList.add('slot-pill');

      const labelStack = document.createElement('span');
      labelStack.style.display = 'inline-grid';
      labelStack.style.gridTemplateColumns = 'max-content';
      labelStack.style.justifyItems = 'center';

      const labelSpan = document.createElement('span');
      labelSpan.style.gridRow = '1';
      labelSpan.style.gridColumn = '1';
      const currentOpt = slotOptions[name]?.find(o => o.value === slotState[name]);
      labelSpan.textContent = currentOpt?.label || slotState[name] || '';
      labelStack.appendChild(labelSpan);

      (slotOptions[name] || []).forEach(opt => {
        const ghost = document.createElement('span');
        ghost.textContent = opt.label;
        ghost.setAttribute('aria-hidden', 'true');
        ghost.style.gridRow = '1';
        ghost.style.gridColumn = '1';
        ghost.style.visibility = 'hidden';
        ghost.style.pointerEvents = 'none';
        ghost.style.whiteSpace = 'nowrap';
        labelStack.appendChild(ghost);
      });

      const chevSpan = document.createElement('span');
      chevSpan.className = 'inline-flex items-center';
      chevSpan.innerHTML = chevronSvg;

      btn.appendChild(labelStack);
      btn.appendChild(chevSpan);
      card.appendChild(btn);

      pillElements[name] = { labelSpan, button: btn };

      /* ── dropdown menu for this slot ── */
      const menu = document.createElement('div');
      menu.className =
        'hidden fixed z-[9999] rounded-[12px] ' +
        'bg-panel-input ' +
        'border border-black/10 dark:border-white/[0.08] ' +
        'shadow-2xl overflow-y-auto max-h-[280px]';
      menu.classList.add('dropdown-menu');

      (slotOptions[name] || []).forEach(opt => {
        const item = document.createElement('button');
        item.type = 'button';
        item.className =
          'w-full flex items-center justify-between px-4 py-2.5 text-left text-[13px] ' +
          'text-gray-900 dark:text-white hover:bg-panel-hover transition-colors';
        item.dataset.value = opt.value;

        const itemLabel = document.createElement('span');
        itemLabel.textContent = opt.label;

        const itemCheck = document.createElement('span');
        itemCheck.className = opt.value === slotState[name] ? 'text-primary' : 'invisible';
        itemCheck.innerHTML = checkSvg;

        item.appendChild(itemLabel);
        item.appendChild(itemCheck);
        menu.appendChild(item);

        item.addEventListener('click', () => {
          slotState[name] = opt.value;
          labelSpan.textContent = opt.label;
          closeMenu(name);
          updateChecks(name);
          syncToGlobal();
        });
      });

      dropdownMenus[name] = menu;
      document.body.appendChild(menu);

      /* ── open / close pill dropdown ── */
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const wasHidden = menu.classList.contains('hidden');

        // Close any other open dropdown
        if (activeDropdown && activeDropdown !== name) {
          closeMenu(activeDropdown);
        }

        if (wasHidden) {
          positionMenu(name);
          menu.classList.remove('hidden');
          activeDropdown = name;
        } else {
          closeMenu(name);
        }
      });
    }
  });

  wrap.appendChild(card);

  /* ── positioning ── */
  function positionMenu(name) {
    const menu = dropdownMenus[name];
    const btn = pillElements[name]?.button;
    if (!menu || !btn) return;

    const rect = btn.getBoundingClientRect();
    const opts = slotOptions[name] || [];
    const spaceBelow = window.innerHeight - rect.bottom;
    const spaceAbove = rect.top;
    const menuHeight = Math.min(280, opts.length * 40);
    const minWidth = 140;
    const menuWidth = Math.max(minWidth, rect.width);

    menu.style.width = `${menuWidth}px`;

    let leftPos = rect.left;
    leftPos = Math.min(leftPos, window.innerWidth - menuWidth - 8);
    leftPos = Math.max(8, leftPos);
    menu.style.left = `${leftPos}px`;

    if (spaceBelow < menuHeight && spaceAbove > spaceBelow) {
      menu.style.bottom = `${window.innerHeight - rect.top + 4}px`;
      menu.style.top = 'auto';
    } else {
      menu.style.top = `${rect.bottom + 4}px`;
      menu.style.bottom = 'auto';
    }
  }

  function closeMenu(name) {
    const menu = dropdownMenus[name];
    if (menu) menu.classList.add('hidden');
    if (activeDropdown === name) activeDropdown = null;
  }

  function updateChecks(name) {
    const menu = dropdownMenus[name];
    if (!menu) return;
    menu.querySelectorAll('button').forEach(btn => {
      const check = btn.querySelector('span:last-child');
      if (check) {
        check.className = btn.dataset.value === slotState[name]
          ? 'text-primary'
          : 'invisible';
      }
    });
  }

  /* ── click-outside dismissal ── */
  document.addEventListener('click', (e) => {
    if (activeDropdown == null) return;
    const menu = dropdownMenus[activeDropdown];
    const btn = pillElements[activeDropdown]?.button;
    if (menu && btn && !btn.contains(e.target) && !menu.contains(e.target)) {
      closeMenu(activeDropdown);
    }
  });

  /* ── scroll repositioning ── */
  window.addEventListener('scroll', () => {
    if (activeDropdown != null && dropdownMenus[activeDropdown] && !dropdownMenus[activeDropdown].classList.contains('hidden')) {
      positionMenu(activeDropdown);
    }
  }, true);

  /* ── form data sync ── */
  const syncToGlobal = () => updateFormData(fieldKey, assemble());
  syncToGlobal();

  /* ── live sync as user edits the inline text ── */
  card.addEventListener('input', syncToGlobal);

  const pillObserver = new MutationObserver((mutations) => {
    let changed = false;
    for (const m of mutations) {
      m.removedNodes.forEach((node) => {
        if (node.nodeType !== Node.ELEMENT_NODE) return;
        const slotName = node.getAttribute && node.getAttribute('data-slot');
        if (!slotName) return;
        if (slotName in slotState) {
          delete slotState[slotName];
          changed = true;
        }
        const menu = dropdownMenus[slotName];
        if (menu && menu.parentNode) menu.parentNode.removeChild(menu);
        delete dropdownMenus[slotName];
        delete pillElements[slotName];
        if (activeDropdown === slotName) activeDropdown = null;
      });
    }
    if (changed) syncToGlobal();
  });
  pillObserver.observe(card, { childList: true });

  /* ── error display ── */
  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      card.style.outline = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    card.style.outline = '1.5px solid #f87171';
  }

  function clearError() {
    setError('');
  }

  return {
    wrap,
    getValue: () => assemble(),
    setValue: (slotName, value) => {
      if (!slots[slotName]) return; // unknown slot — ignore
      const opts = slotOptions[slotName] || [];
      const next = value == null ? '' : String(value);
      if (opts.some(o => o.value === next)) {
        slotState[slotName] = next;
        const pill = pillElements[slotName];
        if (pill) {
          const opt = opts.find(o => o.value === next);
          pill.labelSpan.textContent = opt?.label || next;
        }
        updateChecks(slotName);
        syncToGlobal();
      }
    },
    getSlotValues: () => ({ ...slotState }),
    setError,
    clearError,
  };
}
