/**
 * Consent section component for face swap agents.
 * Renders consent checkboxes for biometric processing confirmation.
 */
import { createCheckboxField } from '../../runner/overrides/ui.js';

export function createConsentSection({ mediaType = 'photo' } = {}) {
  const wrap = document.createElement('div');
  wrap.className = 'rounded-ios-xl border border-panel-border bg-panel-input p-4 mt-4 space-y-3';

  const title = document.createElement('div');
  title.className = 'text-sm font-semibold';
  title.textContent = 'Consent';
  wrap.appendChild(title);

  const note = document.createElement('p');
  note.className = 'text-xs text-gray-500 dark:text-gray-400';
  note.textContent = 'Face swap uses biometric processing. Please confirm the following to proceed.';
  wrap.appendChild(note);

  const subjectConsent = createCheckboxField({
    label: 'I have consent from the person whose face is being used.',
    id: 'subjectConsent',
    defaultChecked: false,
  });
  const targetConsent = createCheckboxField({
    label: `I have consent from the person in the target ${mediaType}.`,
    id: 'targetConsent',
    defaultChecked: false,
  });
  const ageVerified = createCheckboxField({
    label: 'All persons are 18+ years old.',
    id: 'ageVerified',
    defaultChecked: false,
  });

  wrap.appendChild(subjectConsent.wrap);
  wrap.appendChild(targetConsent.wrap);
  wrap.appendChild(ageVerified.wrap);

  const setError = () => { wrap.style.borderColor = '#ef4444'; };
  const clearError = () => { wrap.style.borderColor = ''; };
  [subjectConsent, targetConsent, ageVerified].forEach(f => {
    f.checkbox.addEventListener('change', clearError);
  });

  return {
    wrap,
    getConsent: () => {
      if (!subjectConsent.getValue() || !targetConsent.getValue() || !ageVerified.getValue()) {
        setError();
        if (!subjectConsent.getValue()) throw new Error('Please confirm consent from the source person.');
        if (!targetConsent.getValue()) throw new Error('Please confirm consent from the target person.');
        throw new Error('Please confirm age verification (18+).');
      }
      clearError();

      return {
        subjectConsent: true,
        targetConsent: true,
        samePersonSwap: false,
        ageVerified: true,
        intendedUse: 'personal',
        timestamp: new Date().toISOString(),
        method: 'checkbox',
      };
    },
  };
}
