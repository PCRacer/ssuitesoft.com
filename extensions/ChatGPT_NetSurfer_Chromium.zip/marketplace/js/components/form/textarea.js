/**
 * Textarea field component.
 * Renders a multi-line text input with label.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createTextAreaField({
  label,
  id,
  required = false,
  placeholder = '',
  rows = 6,
  help,
  defaultValue = '',
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'textarea';
  if (id) wrap.setAttribute('data-id', id);
  wrap.setAttribute('data-component', 'textarea');

  if (label && String(label).trim()) {
    const header = document.createElement('div');
    header.className = 'mb-2';
    const row = document.createElement('div');
    row.className = 'flex items-center';
    const labelEl = createFieldLabel(label, { required });
    labelEl.className = 'block text-sm font-medium mx-2';
    row.appendChild(labelEl);
    const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
    if (trigger) {
      wrap.setAttribute('data-help-scope', '');
      row.appendChild(trigger);
    }
    header.appendChild(row);
    wrap.appendChild(header);
  }

  const card = document.createElement('div');
  card.className = 'rounded-xl bg-panel-input border border-panel-border p-4 transition-colors';

  const textarea = document.createElement('textarea');
  textarea.rows = rows;
  textarea.placeholder = placeholder || 'Type your prompt here...';
  textarea.className =
    'block w-full text-[13px] bg-transparent border-0 p-0 resize-none text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500';
  textarea.style.outline = 'none';
  textarea.style.boxShadow = 'none';
  if (required) textarea.required = true;
  if (defaultValue) textarea.value = String(defaultValue);

  // Sync to global form data (keep empty string as-is for consistency)
  const syncToGlobal = () => updateFormData(fieldKey, textarea.value.trim());
  textarea.addEventListener('input', syncToGlobal);
  textarea.addEventListener('change', syncToGlobal);
  syncToGlobal(); // Initial sync

  card.appendChild(textarea);
  wrap.appendChild(card);

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      card.style.outline = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    card.style.outline = '1.5px solid #f87171';
    card.style.outlineOffset = '-1px';
  }

  function clearError() {
    setError('');
  }

  textarea.addEventListener('input', clearError);

  return {
    wrap,
    textarea,
    getValue: () => textarea.value,
    getTrimmed: () => textarea.value.trim(),
    setValue: (v) => { textarea.value = v == null ? '' : String(v); syncToGlobal(); },
    setError,
    clearError,
  };
}
