/**
 * Custom select/dropdown field component.
 * Renders a styled dropdown with positioned menu, checkmarks, and click-outside dismissal.
 */
import { updateFormData, createFieldLabel, createHelpToggle } from '../../runner/overrides/ui.js';

export function createSelectField({
  label,
  id,
  required = false,
  help,
  options = [],
  defaultValue,
} = {}) {
  const wrap = document.createElement('div');
  const fieldKey = id || label || 'select';
  if (id) wrap.setAttribute('data-id', id);

  const header = document.createElement('div');
  header.className = 'mb-2';
  const headerRow = document.createElement('div');
  headerRow.className = 'flex items-center';
  const labelEl = createFieldLabel(label, { required });
  labelEl.className = 'block text-[13px] font-medium mx-2';
  headerRow.appendChild(labelEl);
  const { trigger } = createHelpToggle({ idSeed: label, labelText: label, helpText: help });
  if (trigger) {
    wrap.setAttribute('data-help-scope', '');
    headerRow.appendChild(trigger);
  }
  header.appendChild(headerRow);
  wrap.appendChild(header);

  const select = document.createElement('select');
  const selectId = `select-${Math.random().toString(16).slice(2)}`;
  select.id = selectId;
  select.className = 'sr-only';
  if (label) select.setAttribute('aria-label', String(label));
  if (required) select.required = true;

  const capitalize = s => s ? s.replace(/[_-]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) : '';
  const normalizedOptions = (Array.isArray(options) ? options : []).map(opt => ({
    value: String(opt?.value ?? ''),
    label: capitalize(String(opt?.label ?? opt?.value ?? '')),
  }));

  for (const opt of normalizedOptions) {
    const optionEl = document.createElement('option');
    optionEl.value = opt.value;
    optionEl.textContent = opt.label;
    select.appendChild(optionEl);
  }

  const desiredDefault = defaultValue != null ? String(defaultValue) : null;
  if (desiredDefault != null && normalizedOptions.some((opt) => opt.value === desiredDefault)) {
    select.value = desiredDefault;
  } else if (normalizedOptions.length > 0) {
    select.value = normalizedOptions[0].value;
  }

  const dropdownBtn = document.createElement('button');
  dropdownBtn.type = 'button';
  dropdownBtn.className =
    'w-full flex items-center justify-between rounded-[16px] bg-panel-input ' +
    'border border-panel-border ' +
    'px-4 h-12 cursor-pointer hover:bg-panel-hover transition-colors ' +
    'focus:outline-none focus:border-[#D9D9D9]/40 dark:focus:border-[#D9D9D9]/20';

  const btnContent = document.createElement('div');
  btnContent.className = 'text-left min-w-0 flex-1';

  const btnValue = document.createElement('div');
  btnValue.className = 'text-[13px] font-semibold text-gray-900 dark:text-white truncate';
  const selectedOpt = normalizedOptions.find(o => o.value === select.value);
  btnValue.textContent = selectedOpt?.label || 'Select...';

  btnContent.appendChild(btnValue);

  const chevron = document.createElement('div');
  chevron.className = 'text-gray-500 dark:text-gray-400 shrink-0 ml-2';
  chevron.innerHTML = `
    <svg class="w-4 h-4" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M2.21999 5.93998C2.21999 5.81332 2.26665 5.68665 2.36665 5.58665C2.55999 5.39332 2.87999 5.39332 3.07332 5.58665L7.41999 9.93332C7.73999 10.2533 8.25999 10.2533 8.57999 9.93332L12.9267 5.58665C13.12 5.39332 13.44 5.39332 13.6333 5.58665C13.8267 5.77998 13.8267 6.09998 13.6333 6.29332L9.28665 10.64C8.94665 10.98 8.48665 11.1733 7.99999 11.1733C7.51332 11.1733 7.05332 10.9867 6.71332 10.64L2.36665 6.29332C2.27332 6.19332 2.21999 6.06665 2.21999 5.93998Z"/>
    </svg>
  `;

  dropdownBtn.appendChild(btnContent);
  dropdownBtn.appendChild(chevron);

  const dropdownMenu = document.createElement('div');
  dropdownMenu.className =
    'hidden fixed z-[9999] rounded-[16px] bg-panel-input ' +
    'border border-[#D9D9D9]/20 dark:border-[#333] shadow-2xl overflow-y-auto max-h-[280px]';

  function positionDropdown() {
    const btnRect = dropdownBtn.getBoundingClientRect();
    const spaceBelow = window.innerHeight - btnRect.bottom;
    const spaceAbove = btnRect.top;
    const menuHeight = Math.min(280, normalizedOptions.length * 48);

    // Set width to match button
    const minWidth = 200;
    const dropdownWidth = Math.max(minWidth, btnRect.width);
    dropdownMenu.style.width = `${dropdownWidth}px`;
    let leftPos = btnRect.left;
    leftPos = Math.min(leftPos, window.innerWidth - dropdownWidth - 8);
    leftPos = Math.max(8, leftPos);
    dropdownMenu.style.left = `${leftPos}px`;

    if (spaceBelow < menuHeight && spaceAbove > spaceBelow) {
      // Open upward
      dropdownMenu.style.bottom = `${window.innerHeight - btnRect.top + 4}px`;
      dropdownMenu.style.top = 'auto';
    } else {
      // Open downward
      dropdownMenu.style.top = `${btnRect.bottom + 4}px`;
      dropdownMenu.style.bottom = 'auto';
    }
  }

  normalizedOptions.forEach((opt) => {
    const item = document.createElement('button');
    item.type = 'button';
    item.className =
      'w-full flex items-center justify-between px-4 py-3 text-left text-[13px] ' +
      'text-gray-900 dark:text-white hover:bg-panel-hover transition-colors';
    item.dataset.value = opt.value;

    const itemLabel = document.createElement('span');
    itemLabel.textContent = opt.label;

    const itemCheck = document.createElement('span');
    itemCheck.className = opt.value === select.value ? 'text-primary/90' : 'invisible';
    itemCheck.innerHTML = `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>`;

    item.appendChild(itemLabel);
    item.appendChild(itemCheck);
    dropdownMenu.appendChild(item);

    item.addEventListener('click', () => {
      select.value = opt.value;
      btnValue.textContent = opt.label;
      dropdownMenu.classList.add('hidden');
      dropdownMenu.querySelectorAll('button').forEach(btn => {
        const check = btn.querySelector('span:last-child');
        if (check) check.className = btn.dataset.value === opt.value ? 'text-primary/90' : 'invisible';
      });
      select.dispatchEvent(new Event('change', { bubbles: true }));
    });
  });

  dropdownBtn.addEventListener('click', () => {
    const wasHidden = dropdownMenu.classList.contains('hidden');
    if (wasHidden) {
      positionDropdown();
    }
    dropdownMenu.classList.toggle('hidden');
  });

  document.addEventListener('click', (e) => {
    if (!wrap.contains(e.target) && !dropdownMenu.contains(e.target)) {
      dropdownMenu.classList.add('hidden');
    }
  });

  window.addEventListener('scroll', () => {
    if (!dropdownMenu.classList.contains('hidden')) positionDropdown();
  }, true);

  const row = document.createElement('div');
  row.className = 'relative';
  row.appendChild(select);
  row.appendChild(dropdownBtn);
  document.body.appendChild(dropdownMenu);
  wrap.appendChild(row);

  // Sync to global form data (keep empty strings as-is, don't convert to undefined)
  const syncToGlobal = () => updateFormData(fieldKey, select.value);
  select.addEventListener('change', syncToGlobal);
  syncToGlobal(); // Initial sync

  const errorEl = document.createElement('p');
  errorEl.className = 'mt-1 text-[11px] leading-normal text-red-500 dark:text-red-400 hidden';
  errorEl.setAttribute('role', 'alert');
  wrap.appendChild(errorEl);

  function setError(message) {
    if (!message) {
      errorEl.textContent = '';
      errorEl.classList.add('hidden');
      dropdownBtn.style.outline = '';
      return;
    }
    errorEl.textContent = String(message);
    errorEl.classList.remove('hidden');
    dropdownBtn.style.outline = '1.5px solid #f87171';
  }

  function clearError() {
    setError('');
  }

  select.addEventListener('change', clearError);

  return {
    wrap,
    select,
    getValue: () => select.value,
    setValue: (v) => {
      const oldValue = select.value;
      const nextValue = v == null ? '' : String(v);
      select.value = nextValue;
      if (oldValue !== select.value) {
        select.dispatchEvent(new Event('change', { bubbles: true }));
      }
      syncToGlobal();
    },
    setError,
    clearError,
  };
}
