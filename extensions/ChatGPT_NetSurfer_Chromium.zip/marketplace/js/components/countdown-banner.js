(function() {
  const COUNTDOWN_VERSION = 'countdown-banner-v1';
  if (window.__AITOPIA_COUNTDOWN_BANNER__ === COUNTDOWN_VERSION) return;
  window.__AITOPIA_COUNTDOWN_BANNER__ = COUNTDOWN_VERSION;

  let offerStart = null;
  let offerEnd = null;
  const PROFILE_KEY = 'aitopia_user_profile';
  const PROFILE_WAIT_TIMEOUT_MS = 3000;
  const PROFILE_WAIT_INTERVAL_MS = 100;
  const USER_STATE = {
    GUEST: 'guest',
    ELIGIBLE: 'eligible',
    SUBSCRIBED: 'subscribed',
  };

  const CONFIG = {
    title: 'Try GPT Image 2 - Free for 4 Hours',
    description: 'Create stunning visuals with GPT Image 2 free for 4 hours with no limits. Limited time offer.',
    extraDescription: 'Create stunning visuals with GPT Image 2 free for 4 hours with no limits.',
    targetPath: '/openai/gpt-image-2',
  };

  const CTA = {
    [USER_STATE.GUEST]: { label: 'Try Now', href: '/marketplace/register.html' },
    [USER_STATE.ELIGIBLE]: { label: 'Subscribe', href: '/pricing#pricing' },
  };

  function getCampaignTargetPath(extra) {
    const campaignType = extra?.campaign_type;
    if (typeof campaignType === 'string') {
      const path = campaignType.split('#')[1]?.trim();
      if (path) return '/' + path.replace(/^\/+/, '');
    }
    return CONFIG.targetPath;
  }

  function buildSubscribedCta(extra) {
    return { label: 'Try Now', href: getCampaignTargetPath(extra) };
  }

  async function loadBannerConfig() {
    try {
      const response = await fetch('https://aitopia.ai/api/config/countdown-banner', { cache: 'no-store' });
      if (!response.ok) return;

      const config = await response.json();
      const nextOfferStart = Date.parse(config?.offerStartUtc);
      const nextOfferEnd = Date.parse(config?.offerEndUtc);
      if (Number.isFinite(nextOfferStart) && Number.isFinite(nextOfferEnd) && nextOfferEnd > nextOfferStart) {
        offerStart = nextOfferStart;
        offerEnd = nextOfferEnd;
      }
    } catch (e) {}
  }

  function tryInjectOnCampaignTarget() {
    const path = window.location.pathname.replace(/\/+$/, '').toLowerCase();
    if (path !== CONFIG.targetPath.toLowerCase()) return null;
    const host = document.getElementById('modelContent');
    if (!host) return null;
    const c = document.createElement('div');
    c.id = 'countdown-banner-container';
    c.className = 'max-w-[1600px] mx-auto px-3 sm:px-4 lg:px-6 mt-4';
    host.insertBefore(c, host.firstChild);
    return c;
  }

  function showSkeleton(container) {
    if (container.firstChild) return;
    container.innerHTML = `
      <div class="rounded-[32px] border border-[#EDC93C]/40 dark:border-[#312F2C] min-h-[232px] animate-pulse bg-gradient-to-r from-[#FFD93D]/30 to-[#F3D767]/30 dark:from-[#1A1A1A] dark:to-[#0F0F0F]"></div>
    `;
  }

  function isOfferActive() {
    if (offerStart == null || offerEnd == null) return false;
    const now = Date.now();
    return now >= offerStart && now < offerEnd;
  }

  function hideBanner() {
    const container = document.getElementById('countdown-banner-container');
    if (container) container.remove();
  }

  function readProfileData() {
    try {
      const raw = sessionStorage.getItem(PROFILE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      return parsed?.data || null;
    } catch (e) {
      return null;
    }
  }

  function getUserState() {
    const data = readProfileData();
    if (!data) return USER_STATE.GUEST;
    return data.extra == null ? USER_STATE.ELIGIBLE : USER_STATE.SUBSCRIBED;
  }

  function pad(n) { return n < 10 ? '0' + n : String(n); }

  function parseSqlUtc(value) {
    if (typeof value !== 'string') return NaN;
    const normalized = value.includes('T') ? value : value.replace(' ', 'T') + 'Z';
    return Date.parse(normalized);
  }

  function getExtraWindow(extra) {
    if (!extra || typeof extra !== 'object') return null;
    const start = parseSqlUtc(extra.start_date);
    const end = parseSqlUtc(extra.end_date);
    if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) return null;
    return { start, end };
  }

  function injectStyles() {
    if (document.getElementById('countdown-banner-styles')) return;
    const s = document.createElement('style');
    s.id = 'countdown-banner-styles';
    s.textContent = `
      .cd-banner-bg { background: linear-gradient(90deg, #FFD93D 0%, #F3D767 100%); }
      .dark .cd-banner-bg {
        background:
          radial-gradient(circle at 85% 50%, rgba(245,191,35,0.18) 0%, rgba(245,191,35,0.05) 35%, rgba(15,15,15,1) 70%),
          linear-gradient(135deg, #0F0F0F 0%, #1A1A1A 100%);
      }
      .cd-group-bg { background: #F1CC3E; }
      .dark .cd-group-bg {
        background: radial-gradient(circle at 100% 100%, #3D3724 0%, #2C281F 70%);
      }
      .cd-cell-bg {
        background: #F6D33E;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.3), inset 0 -4px 10px rgba(0, 0, 0, 0.04);
      }
      .dark .cd-cell-bg {
        background: linear-gradient(180deg, #4A4128 0%, #3F361F 100%);
        box-shadow: inset 0 1px 0 rgba(255, 204, 0, 0.05), inset 0 -4px 10px rgba(0, 0, 0, 0.12);
      }
    `;
    document.head.appendChild(s);
  }

  function cellMarkup(id, label) {
    return `
      <div class="flex flex-col items-center gap-2">
        <div class="cd-cell-bg w-[96px] h-[86px] flex items-center justify-center rounded-2xl border border-black/10 dark:border-[#6B5E2E]/60">
          <div id="${id}" class="text-[#1A1A1A] dark:text-[#FFCC00] font-extrabold text-[36px] leading-9">00</div>
        </div>
        <div class="text-[#3A3A3A] dark:text-[#898A8B] text-[11px] leading-[9px] font-extrabold tracking-[1.2px] uppercase mt-1">${label}</div>
      </div>
    `;
  }

  function ctaMarkup(extraClasses, cta) {
    return `
      <a href="${cta.href}" class="${extraClasses} items-center justify-center gap-2 min-w-[163px] px-5 h-12 bg-[#F9D300] dark:bg-[#2D291B] hover:bg-[#FFDD33] dark:hover:bg-[#38321F] text-[#1A1A1A] dark:text-[#FFCC00] font-semibold text-sm border border-[#EFCA02] dark:border-[#594E25] rounded-2xl transition-all hover:-translate-y-px no-underline">
        ${cta.label}
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
      </a>
    `;
  }

  function waitForProfile(timeoutMs, done) {
    const startedAt = Date.now();
    const id = setInterval(() => {
      if (readProfileData() || Date.now() - startedAt > timeoutMs) {
        clearInterval(id);
        done();
      }
    }, PROFILE_WAIT_INTERVAL_MS);
  }

  function render(state, extra) {
    const container = document.getElementById('countdown-banner-container');
    if (!container) return;
    const isSubscribed = state === USER_STATE.SUBSCRIBED;
    const cta = isSubscribed
      ? buildSubscribedCta(extra)
      : (CTA[state] || CTA[USER_STATE.GUEST]);
    const description = isSubscribed ? CONFIG.extraDescription : CONFIG.description;
    const countdownLabel = isSubscribed ? 'Free Credits For' : 'Offer Expires In';

    container.innerHTML = `
      <div class="cd-banner-bg relative overflow-hidden rounded-[32px] border border-[#EDC93C] dark:border-[#312F2C] min-h-[232px] px-5 py-[22px] md:px-8 md:py-7">
        <div class="flex flex-col md:flex-row items-center md:justify-between gap-5 md:gap-6 h-full">
          <div class="flex-1 min-w-0 text-center md:text-left flex flex-col items-center md:items-start">
            <h2 class="text-[#1A1A1A] dark:text-[#FFCC00] font-bold text-[22px] md:text-[26px] lg:text-[30px] xl:text-[36px] leading-[28px] md:leading-[34px] lg:leading-[40px] xl:leading-[48px] tracking-[-0.5px] uppercase">
              ${CONFIG.title}
            </h2>
            <p class="text-[#4A4A4A] dark:text-[#898A8B] text-[12px] md:text-[13px] lg:text-[14px] xl:text-base font-medium leading-[20px] md:leading-[22px] lg:leading-[26px] xl:leading-8 whitespace-normal xl:whitespace-nowrap mt-2 md:mb-5">
              ${description}
            </p>
            ${ctaMarkup('hidden md:inline-flex', cta)}
          </div>
          <div class="cd-group-bg shrink-0 border border-[#E7C543] dark:border-[#38362F] rounded-2xl px-4 py-3.5">
            <div class="flex items-center justify-center gap-1.5 text-[#1A1A1A] dark:text-[#FFCC00] text-[12px] md:text-[11px] leading-3 font-extrabold md:font-semibold tracking-[1.2px] uppercase mb-3">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
              <span>${countdownLabel}</span>
            </div>
            <div class="flex items-start gap-3">
              ${cellMarkup('countdown-hours', 'Hours')}
              ${cellMarkup('countdown-minutes', 'Minutes')}
              ${cellMarkup('countdown-seconds', 'Seconds')}
            </div>
          </div>
          ${ctaMarkup('inline-flex md:hidden', cta)}
        </div>
      </div>
    `;
  }

  function renderCountdown(totalMs) {
    const hoursEl = document.getElementById('countdown-hours');
    const minutesEl = document.getElementById('countdown-minutes');
    const secondsEl = document.getElementById('countdown-seconds');
    if (!hoursEl || !minutesEl || !secondsEl) return false;

    const totalSeconds = Math.max(0, Math.floor(totalMs / 1000));
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    hoursEl.textContent = pad(hours);
    minutesEl.textContent = pad(minutes);
    secondsEl.textContent = pad(seconds);
    return true;
  }

  function tick(endTime) {
    const remaining = endTime - Date.now();
    if (remaining <= 0) {
      hideBanner();
      return false;
    }
    return renderCountdown(remaining);
  }

  function tickSubscribed(extra) {
    const windowMs = getExtraWindow(extra);
    if (!windowMs) {
      hideBanner();
      return false;
    }

    const now = Date.now();
    const remaining = now < windowMs.start
      ? windowMs.end - windowMs.start
      : windowMs.end - now;

    if (remaining <= 0) {
      hideBanner();
      return false;
    }
    return renderCountdown(remaining);
  }

  async function init() {
    let container = document.getElementById('countdown-banner-container');
    if (!container) {
      container = tryInjectOnCampaignTarget();
      if (!container) return;
    }
    await loadBannerConfig();

    if (!isOfferActive()) {
      hideBanner();
      return;
    }

    showSkeleton(container);
    waitForProfile(PROFILE_WAIT_TIMEOUT_MS, () => {
      const profile = readProfileData();
      const state = getUserState();

      injectStyles();
      render(state, profile?.extra);

      if (state === USER_STATE.SUBSCRIBED) {
        if (!tickSubscribed(profile && profile.extra)) return;
        const timerId = setInterval(() => {
          if (!tickSubscribed(profile && profile.extra)) clearInterval(timerId);
        }, 1000);
        return;
      }

      if (!tick(offerEnd)) return;
      const timerId = setInterval(() => {
        if (!tick(offerEnd)) clearInterval(timerId);
      }, 1000);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
