/**
 * Toast Component
 * Usage:
 *   showToast({ title: 'Saved!', message: 'Your changes are live.' });
 *   showToast({ title: 'Error', type: 'error', message: 'Try again.' });
 */

const CONTAINER_ID = 'app-toast-container';
const DEFAULT_DURATION = 4000;

const ICONS = {
  success: `<img src="https://aitopia.ai/icons/toast-success.svg" alt="" class="w-7 h-7" />`,
  warning: `<img src="https://aitopia.ai/icons/toast-warning.svg" alt="" class="w-7 h-7" />`,
  error: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M6 18L18 6M6 6l12 12"/></svg>`,
  info: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`,
};

const ICON_BG = {
  success: 'bg-[#DCEBE7] dark:bg-[#162118]',
  warning: 'bg-[#EFEFE4] dark:bg-[#262111]',
  error: 'bg-[#FDE2E2] dark:bg-[#EF4444]/15 text-[#F87171]',
  info: 'bg-[#DDE9FA] dark:bg-[#3B82F6]/15 text-[#60A5FA]',
};

function ensureContainer() {
  let container = document.getElementById(CONTAINER_ID);
  if (container) return container;
  container = document.createElement('div');
  container.id = CONTAINER_ID;
  container.className = 'fixed top-3 right-3 left-3 md:top-6 md:right-6 md:left-auto z-[200] flex flex-col items-end gap-3 pointer-events-none';
  document.body.appendChild(container);
  return container;
}

export function showToast(options = {}) {
  const {
    title = '',
    message = '',
    type = 'success',
    duration = DEFAULT_DURATION,
  } = options;

  const container = ensureContainer();

  const toast = document.createElement('div');
  toast.className = [
    'pointer-events-auto',
    'w-full md:w-auto flex items-center gap-4 max-w-md md:min-w-[320px] min-h-[78px]',
    'rounded-2xl bg-white dark:bg-[#0F0F0F] shadow-2xl',
    'px-5 py-3',
    'opacity-0 translate-x-3 transition-all duration-200',
  ].join(' ');

  const iconKey = ICONS[type] ? type : 'success';

  toast.innerHTML = `
    <div class="w-12 h-12 flex-shrink-0 flex items-center justify-center rounded-xl ${ICON_BG[iconKey]}">
      ${ICONS[iconKey]}
    </div>
    <div class="flex-1 min-w-0">
      ${title ? `<div class="text-[15px] leading-[18px] font-semibold text-gray-900 dark:text-white">${escapeHtml(title)}</div>` : ''}
      ${message ? `<div class="text-[13px] leading-[18px] text-gray-600 dark:text-white/60 mt-1">${escapeHtml(message)}</div>` : ''}
    </div>
    <button type="button" data-toast-close class="flex-shrink-0 w-7 h-7 flex items-center justify-center rounded-full text-gray-500 hover:text-gray-900 hover:bg-black/5 dark:text-white/40 dark:hover:text-white dark:hover:bg-white/5 transition-colors" aria-label="Close">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
    </button>
  `;

  container.appendChild(toast);

  requestAnimationFrame(() => {
    toast.classList.remove('opacity-0', 'translate-x-3');
  });

  const timer = setTimeout(dismiss, duration);
  toast.querySelector('[data-toast-close]').addEventListener('click', (e) => {
    e.stopPropagation();
    dismiss();
  });

  function dismiss() {
    clearTimeout(timer);
    toast.classList.add('opacity-0', 'translate-x-3');
    setTimeout(() => toast.remove(), 200);
  }

  return { dismiss };
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

if (typeof window !== 'undefined') {
  window.showToast = showToast;
}
