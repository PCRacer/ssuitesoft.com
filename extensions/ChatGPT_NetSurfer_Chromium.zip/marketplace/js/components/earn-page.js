(function() {
  const EARN_VERSION = 'earn-page-v1';
  if (window.__AITOPIA_EARN_PAGE__ === EARN_VERSION) return;
  window.__AITOPIA_EARN_PAGE__ = EARN_VERSION;

  const FAQS = [
    {
      question: 'How do I apply for the Creator Program?',
      answer: 'The Creator Program is selective. We accept a limited number of creators each cycle. Each application is reviewed carefully and in detail by our team. We evaluate content quality, audience engagement, platform consistency, and long-term creator potential.',
    },
    {
      question: 'Are there any hidden fees or commissions?',
      answer: 'No. Joining is completely free. Accepted creators receive a full Creator Plan at no cost - no setup fee, no subscription, no commission taken from your earnings.',
    },
    {
      question: 'How does the referral link work?',
      answer: 'Once accepted, your personal referral link is available in your dashboard. Add it to your social media bios, content captions, or link-in-bio tools. You earn a commission for every user who signs up through your link.',
    },
    {
      question: 'What is the Creator Plan and what does it include?',
      answer: "The Creator Plan is AITOPIA's highest-tier plan provided free to active creators every month. It includes full access to many image, video, and audio generation tools plus monthly credits. See full plan details at aitopia.ai/pricing.",
    },
    {
      question: 'What do I need to do each month to keep my Creator Plan?',
      answer: 'Meet one of two conditions: (A) publish at least 10 AITOPIA-logo content pieces across your platforms, or (B) reach 30,000 total impressions / views on your submitted content. If neither is met, Creator Plan benefit renewal for the next month is subject to team review.',
    },
    {
      question: 'Does the AITOPIA logo have to be in every video?',
      answer: 'Yes. All submitted content must include a clearly visible AITOPIA logo. You can add it automatically using the AITOPIA Logo Agent. Upload your AI-generated image or video, the agent applies the logo in the correct format, and you download the final version ready to post.',
    },
    {
      question: 'Does my social media account need to be public?',
      answer: 'Yes. All linked accounts must be publicly accessible. Private or restricted accounts cannot be verified by our team and content from such accounts will not count toward your monthly total.',
    },
    {
      question: 'When do I receive my earnings?',
      answer: 'Earnings are calculated based on signups made through your referral link within the calendar month (1st through last day) who subscribe to an AITOPIA plan. Payouts are processed between the 5th and 10th of the following month. There is no minimum payout threshold.',
    },
  ];

  const BOOST_STATS = [
    { value: '12.4M', label: 'TOTAL PAID OUT', barColor: 'hsl(var(--ait-m-primary))' },
    { value: '12.4M', label: 'TOTAL PAID OUT', barColor: '#FFD91F' },
  ];

  const CHART_SLIDES = [
    { image: 'https://aitopia.ai/earn-images/chart1.webp', imageLight: 'https://aitopia.ai/earn-images/chart-light.webp' },
    { image: 'https://aitopia.ai/earn-images/chart1.webp', imageLight: 'https://aitopia.ai/earn-images/chart-light.webp' },
  ];

  const POPULAR_AGENTS = [
    {
      name: 'Background Remover',
      description: 'Remove backgrounds from an image.',
      credits: '5-25 Credits',
      image: 'https://aitopia.ai/agent-images/background-remover-1.webp',
      video: 'https://aitopia.ai/agent-images/background-remover.mp4',
      href: '/agents/background-remover',
    },
    {
      name: 'Face Swap',
      description: 'Swap faces between photos in seconds.',
      credits: '5-25 Credits',
      image: 'https://aitopia.ai/agent-images/face-swap-1.webp',
      video: 'https://aitopia.ai/agent-images/face-swap.mp4',
      href: '/agents/face-swap',
    },
    {
      name: 'Image Upscaler',
      description: '4k AI image upscaling and enhancement.',
      credits: 'Credits Vary',
      image: 'https://aitopia.ai/agent-images/upscaler-1.webp',
      href: '/agents/image-upscaler',
    },
    {
      name: 'Background Replacer',
      description: 'Remove backgrounds from an image.',
      credits: 'Credits Vary',
      image: 'https://aitopia.ai/agent-images/background-replacer-1.webp',
      video: 'https://aitopia.ai/agent-images/background-replacer.mp4',
      href: '/agents/background-replacer',
    },
    {
      name: 'Virtual Try-On',
      description: 'Try on outfits virtually with AI.',
      credits: 'Credits Vary',
      image: 'https://aitopia.ai/agent-images/virtual-try-on-1.webp',
      video: 'https://aitopia.ai/agent-images/virtual-try-on-workflow-pulse.mp4',
      href: '/agents/virtual-try-on',
    },
  ];

  const STEPS = [
    {
      title: 'Submit Form',
      description: 'Apply with your AITOPIA account and social profiles.',
      image: 'https://aitopia.ai/earn-images/submit-form.webp',
      imageLight: 'https://aitopia.ai/earn-images/submit-form-light.webp',
    },
    {
      title: 'Get Onboarded',
      description: 'Wait confirmation email to get your Creator Plan and personal referral link.',
      image: 'https://aitopia.ai/earn-images/get-onboarded.webp',
      imageLight: 'https://aitopia.ai/earn-images/get-onboarded-light.webp',
    },
    {
      title: 'Get Paid and Creator Plan Access',
      description: 'Add your referral link to your profiles. Earn 40% commission for every subscription to AITOPIA plans.',
      image: 'https://aitopia.ai/earn-images/get-paid.webp',
      imageLight: 'https://aitopia.ai/earn-images/get-paid-light.webp',
    },
  ];

  const COIN_ICON = '<svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M9.03342 11.2833H7.78341C6.82508 11.2833 6.05008 10.4833 6.05008 9.49167C6.05008 9.15 6.33341 8.86667 6.67508 8.86667C7.01675 8.86667 7.30008 9.15 7.30008 9.49167C7.30008 9.79167 7.51675 10.0333 7.78341 10.0333H9.03342C9.22508 10.0333 9.37508 9.85833 9.37508 9.64167C9.37508 9.35 9.32508 9.33333 9.13341 9.26667L7.12508 8.56667C6.40008 8.31667 6.04175 7.80833 6.04175 7.01667C6.04175 6.11667 6.75841 5.375 7.63341 5.375H8.88341C9.84175 5.375 10.6167 6.175 10.6167 7.16667C10.6167 7.50833 10.3334 7.79167 9.99175 7.79167C9.65008 7.79167 9.36675 7.50833 9.36675 7.16667C9.36675 6.86667 9.15008 6.625 8.88341 6.625H7.63341C7.44175 6.625 7.29175 6.8 7.29175 7.01667C7.29175 7.30833 7.34175 7.325 7.53341 7.39167L9.54175 8.09167C10.2667 8.35 10.6167 8.85833 10.6167 9.64167C10.6251 10.55 9.90842 11.2833 9.03342 11.2833Z"/><path d="M8.33325 11.95C7.99159 11.95 7.70825 11.6667 7.70825 11.325V10.7084C7.70825 10.3667 7.99159 10.0834 8.33325 10.0834C8.67492 10.0834 8.95825 10.3667 8.95825 10.7084V11.325C8.95825 11.675 8.67492 11.95 8.33325 11.95Z"/><path d="M8.33325 6.61668C7.99159 6.61668 7.70825 6.33334 7.70825 5.99168V5.34167C7.70825 5.00001 7.99159 4.71667 8.33325 4.71667C8.67492 4.71667 8.95825 5.00001 8.95825 5.34167V5.99168C8.95825 6.33334 8.67492 6.61668 8.33325 6.61668Z"/><path d="M8.32508 15.6C4.30841 15.6 1.04175 12.3333 1.04175 8.31666C1.04175 4.29999 4.30841 1.03333 8.32508 1.03333C12.3417 1.03333 15.6084 4.29999 15.6084 8.31666C15.6084 12.3333 12.3334 15.6 8.32508 15.6ZM8.32508 2.29166C5.00008 2.29166 2.29175 4.99999 2.29175 8.32499C2.29175 11.65 5.00008 14.35 8.32508 14.35C11.6501 14.35 14.3584 11.6417 14.3584 8.31666C14.3584 4.99166 11.6501 2.29166 8.32508 2.29166Z"/><path d="M14.1834 18.9333C12.6418 18.9333 11.1918 18.1833 10.3001 16.9167C10.1001 16.6333 10.1668 16.2417 10.4501 16.0417C10.7334 15.8417 11.1251 15.9083 11.3251 16.1917C11.9834 17.125 13.0501 17.675 14.1834 17.675C16.1168 17.675 17.6834 16.1083 17.6834 14.175C17.6834 13.05 17.1334 11.9833 16.2168 11.325C15.9334 11.125 15.8751 10.7333 16.0751 10.45C16.2751 10.1667 16.6668 10.1083 16.9501 10.3083C18.1918 11.2 18.9334 12.6417 18.9334 14.175C18.9334 16.8083 16.8084 18.9333 14.1834 18.9333Z"/></svg>';

  function themeImg(dark, light, alt, cls) {
    if (!light) return '<img src="' + dark + '" alt="' + alt + '" class="' + cls + '" loading="lazy">';
    return '<picture>' +
      '<source srcset="' + dark + '" media="(prefers-color-scheme: dark)">' +
      '<img src="' + light + '" alt="' + alt + '" class="' + cls + ' earn-theme-img" data-dark="' + dark + '" data-light="' + light + '" loading="lazy">' +
      '</picture>';
  }

  function syncThemeImages() {
    var isDark = document.documentElement.classList.contains('dark');
    document.querySelectorAll('.earn-theme-img').forEach(function(img) {
      img.src = isDark ? img.dataset.dark : img.dataset.light;
    });
  }

  function renderHero() {
    const el = document.getElementById('earn-hero');
    if (!el) return;

    el.innerHTML = `
<!-- Mobile layout -->
<section class="lg:hidden overflow-hidden bg-[#0F0F0F] rounded-none">
  <div class="relative w-full aspect-[4/3]">
    <img src="https://aitopia.ai/earn-images/creator-program-mobile.png" alt="Creator Program" class="w-full h-full object-cover" loading="eager">
    <div class="absolute inset-0 bg-gradient-to-t from-[#0F0F0F] via-transparent to-transparent"></div>
  </div>
  <div class="px-6 pb-10 -mt-8 relative z-10 text-center">
    <h1 class="text-white text-[28px] leading-[36px] sm:text-[36px] sm:leading-[44px] font-bold tracking-tight font-['Inter',sans-serif]">
      Join <span class="text-white dark:text-primary">AITOPIA</span><br>Creator Program
    </h1>
    <p class="mt-4 text-white/60 text-[14px] leading-[22px] font-medium max-w-md mx-auto">
      Create without limits. Video, code, images, audio - discover and deploy the world's most advanced AI agents with variety of models.
    </p>
    <div class="mt-7">
      <button type="button" data-scroll-to="earn-form" class="inline-flex items-center gap-2.5 h-12 px-7 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground transition-all shadow-lg shadow-primary/20 text-[16px] leading-[28px] font-medium">
        ${COIN_ICON}
        Start Earning Now
      </button>
    </div>
  </div>
</section>

<!-- Desktop layout -->
<section class="hidden lg:block relative overflow-hidden rounded-[32px] lg:mx-6 xl:mx-auto xl:max-w-[1370px] lg:mt-12 min-h-[480px]">
  <img src="https://aitopia.ai/agent-images/creator-program.webp" alt="Creator Program" class="absolute inset-0 w-full h-full object-cover" loading="eager">
  <div class="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent"></div>
  <div class="relative z-10 flex items-center px-16 py-24 min-h-[480px]">
    <div class="max-w-lg">
      <span class="inline-block text-white dark:text-primary italic uppercase mb-5 text-[12px] font-medium leading-[20px] tracking-[0.15em]">Monetize Your Creativity</span>
      <h1 class="text-white text-[54px] leading-[60px] font-bold tracking-tight font-['Inter',sans-serif]">
        Join <span class="text-white dark:text-primary">AITOPIA</span><br>Creator Program
      </h1>
      <p class="mt-5 text-white/70 max-w-lg text-[14px] leading-[22px] font-normal">
        Create with AITOPIA. Share your link. Earn for every subscription.
      </p>
      <div class="mt-8">
        <button type="button" data-scroll-to="earn-form" class="inline-flex items-center gap-2.5 h-12 px-7 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground transition-all shadow-lg shadow-primary/20 hover:shadow-primary/30 text-[16px] leading-[28px] font-medium">
          ${COIN_ICON}
          Start Earning Now
        </button>
      </div>
    </div>
  </div>
</section>`;
  }

  function renderStepCard(step) {
    const image = step.image
      ? themeImg(step.image, step.imageLight, step.title, 'w-full h-full object-cover')
      : '';

    return `
<div class="flex flex-col">
  <div class="aspect-[4/3] rounded-2xl bg-[#E8EBF0] dark:bg-[#141414] border border-black/[0.06] dark:border-white/[0.06] overflow-hidden flex items-center justify-center">
    ${image}
  </div>
  <h3 class="text-gray-900 dark:text-white text-[20px] leading-[22px] sm:text-[18px] sm:leading-[26px] font-bold mt-5 text-center">${step.title}</h3>
  <p class="text-gray-500 dark:text-gray-500 text-[14px] leading-[20px] font-medium mt-4 text-center max-w-[300px] mx-auto">${step.description}</p>
</div>`;
  }

  function renderSteps() {
    const el = document.getElementById('earn-steps');
    if (!el) return;

    el.innerHTML = `
<section class="relative bg-[#F3F5F9] dark:bg-[#0F0F0F] rounded-none lg:rounded-[32px] lg:mx-6 xl:mx-auto xl:max-w-[1370px] lg:mt-12 overflow-hidden">
  <!-- Corner glows -->
  <div class="absolute -top-20 -right-20 w-[250px] h-[250px] bg-primary/[0.08] blur-[100px] rounded-full pointer-events-none"></div>
  <div class="absolute -bottom-10 -left-10 w-[200px] h-[200px] bg-primary/5 blur-[80px] rounded-full pointer-events-none"></div>

  <div class="relative border border-black/[0.06] dark:border-white/[0.06] rounded-none lg:rounded-[32px] px-6 sm:px-10 lg:px-16 py-14 sm:py-20">
    <h2 class="text-gray-900 dark:text-white text-[24px] leading-[32px] sm:text-[36px] sm:leading-[42px] font-bold text-center tracking-tight mb-12 sm:mb-16 font-['Inter',sans-serif]">
      3 Simple Steps to <span class="text-primary">Make Money</span>
    </h2>

    <!-- Desktop grid -->
    <div class="hidden sm:grid sm:grid-cols-3 gap-8">
      ${STEPS.map(renderStepCard).join('')}
    </div>

    <!-- Mobile slider -->
    <div class="sm:hidden">
      <div class="steps-slider overflow-hidden">
        <div class="steps-slider-track flex transition-transform duration-500 ease-out">
          ${STEPS.map(function(step) { return '<div class="steps-slide shrink-0 w-full px-2">' + renderStepCard(step) + '</div>'; }).join('')}
        </div>
      </div>
      <div class="flex items-center justify-center gap-1.5 mt-4">
        ${STEPS.map(function(_, i) { return '<button type="button" class="steps-slide-dot w-2 h-2 rounded-full transition-all duration-300 ' + (i === 0 ? 'bg-primary w-5' : 'bg-black/20 dark:bg-white/20 hover:bg-black/40 dark:hover:bg-white/40') + '" data-slide="' + i + '"></button>'; }).join('')}
      </div>
    </div>

    <div class="flex justify-center mt-12">
      <button type="button" data-scroll-to="earn-form" class="inline-flex items-center gap-2.5 h-12 px-8 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground text-[16px] leading-[28px] font-medium transition-all shadow-lg shadow-primary/20 hover:shadow-primary/30">
        ${COIN_ICON}
        Start Creating Today
      </button>
    </div>
  </div>
</section>`;

    bindStepsSlider();
  }

  function bindStepsSlider() {
    var track = document.querySelector('.steps-slider-track');
    var dots = document.querySelectorAll('.steps-slide-dot');
    if (!track || !dots.length) return;

    var current = 0;
    var total = STEPS.length;

    function goTo(index) {
      current = index;
      track.style.transform = 'translateX(-' + (current * 100) + '%)';
      dots.forEach(function(dot, i) {
        if (i === current) {
          dot.classList.add('bg-primary', 'w-5');
          dot.classList.remove('bg-black/20', 'dark:bg-white/20');
        } else {
          dot.classList.remove('bg-primary', 'w-5');
          dot.classList.add('bg-black/20', 'dark:bg-white/20');
        }
      });
    }

    dots.forEach(function(dot) {
      dot.addEventListener('click', function() {
        goTo(parseInt(dot.dataset.slide));
      });
    });

    var slider = document.querySelector('.steps-slider');
    var startX = 0;
    var diffX = 0;

    slider.addEventListener('touchstart', function(e) {
      startX = e.touches[0].clientX;
    }, { passive: true });

    slider.addEventListener('touchmove', function(e) {
      diffX = e.touches[0].clientX - startX;
    }, { passive: true });

    slider.addEventListener('touchend', function() {
      if (Math.abs(diffX) > 50) {
        if (diffX < 0 && current < total - 1) goTo(current + 1);
        else if (diffX > 0 && current > 0) goTo(current - 1);
      }
      diffX = 0;
    });
  }

  function renderBoost() {
    const el = document.getElementById('earn-boost');
    if (!el) return;

    const dots = CHART_SLIDES.map(function(_, i) {
      return `<button type="button" class="earn-slide-dot w-2 h-2 rounded-full transition-all duration-300 ${i === 0 ? 'bg-primary w-5' : 'bg-black/20 dark:bg-white/20 hover:bg-black/40 dark:hover:bg-white/40'}" data-slide="${i}"></button>`;
    }).join('');

    const slides = CHART_SLIDES.map(function(slide, i) {
      return `<div class="earn-slide shrink-0 w-full">
        ${themeImg(slide.image, slide.imageLight, 'Earnings chart', 'w-full h-auto rounded-2xl')}
      </div>`;
    }).join('');

    const stats = BOOST_STATS.map(function(stat) {
      return `<div class="flex items-center gap-3">
        <div class="w-1 self-stretch rounded-full" style="background:${stat.barColor}"></div>
        <div>
          <div class="text-gray-900 dark:text-white text-[24px] leading-[28px] font-semibold">${stat.value}</div>
          <div class="text-gray-500 dark:text-gray-500 text-[12px] leading-[28px] font-normal tracking-[0.12em] uppercase">${stat.label}</div>
        </div>
      </div>`;
    }).join('');

    el.innerHTML = `
<section class="relative bg-[#F3F5F9] dark:bg-[#0F0F0F] rounded-none lg:rounded-[32px] lg:mx-6 xl:mx-auto xl:max-w-[1370px] lg:mt-12 overflow-hidden">
  <div class="relative border border-black/[0.06] dark:border-white/[0.06] rounded-none lg:rounded-[32px] px-6 sm:px-10 lg:px-16 py-14 sm:py-20">
    <div class="flex flex-col lg:grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">

      <!-- Chart image (top on mobile, right on desktop) -->
      <div class="relative order-1 lg:order-2">
        ${themeImg(CHART_SLIDES[0].image, CHART_SLIDES[0].imageLight, 'Earnings chart', 'w-full h-auto rounded-2xl')}
      </div>

      <!-- Content (bottom on mobile, left on desktop) -->
      <div class="order-2 lg:order-1 text-center lg:text-left">
        <h2 class="text-gray-900 dark:text-white text-[24px] leading-[32px] font-extrabold sm:text-3xl sm:font-bold lg:text-[44px] lg:leading-[54px] tracking-tight font-['Inter',sans-serif]">
          Create AI content. Share your link. Earn commission for every subscription.
        </h2>
        <p class="mt-5 text-gray-600 dark:text-[#9CA3AF] text-[14px] leading-[21px] lg:text-[16px] lg:leading-[28px] font-normal max-w-md mx-auto lg:mx-0">
          Create AI-powered images and videos with latest models and agents provided by AITOPIA. Place your referral link on your bio, and earn 40% commission every time someone subscribes to AITOPIA plans.
        </p>
      </div>

    </div>
  </div>
</section>`;

    bindSlider();
  }

  function bindSlider() {
    var track = document.querySelector('.earn-slider-track');
    var dots = document.querySelectorAll('.earn-slide-dot');
    if (!track || !dots.length) return;

    var current = 0;
    var total = CHART_SLIDES.length;

    function goTo(index) {
      current = index;
      track.style.transform = 'translateX(-' + (current * 100) + '%)';
      dots.forEach(function(dot, i) {
        if (i === current) {
          dot.classList.add('bg-primary', 'w-5');
          dot.classList.remove('bg-black/20', 'dark:bg-white/20');
        } else {
          dot.classList.remove('bg-primary', 'w-5');
          dot.classList.add('bg-black/20', 'dark:bg-white/20');
        }
      });
    }

    dots.forEach(function(dot) {
      dot.addEventListener('click', function() {
        goTo(parseInt(dot.dataset.slide));
      });
    });

    var slider = document.querySelector('.earn-slider');
    var startX = 0;
    var diffX = 0;

    slider.addEventListener('touchstart', function(e) {
      startX = e.touches[0].clientX;
    }, { passive: true });

    slider.addEventListener('touchmove', function(e) {
      diffX = e.touches[0].clientX - startX;
    }, { passive: true });

    slider.addEventListener('touchend', function() {
      if (Math.abs(diffX) > 50) {
        if (diffX < 0 && current < total - 1) goTo(current + 1);
        else if (diffX > 0 && current > 0) goTo(current - 1);
      }
      diffX = 0;
    });
  }

  function renderAgentCard(agent) {
    const media = agent.video
      ? `<video src="${agent.video}" class="w-full h-full object-cover" autoplay muted loop playsinline></video>`
      : `<img src="${agent.image}" alt="${agent.name}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy">`;
    return `
<a href="${agent.href}" class="shrink-0 w-[260px] sm:w-[280px] lg:w-[300px] flex flex-col group rounded-2xl border border-black/[0.06] dark:border-white/[0.06] bg-white dark:bg-[#141414] overflow-hidden">
  <div class="aspect-square overflow-hidden">
    ${media}
  </div>
  <div class="p-4">
    <h3 class="text-gray-900 dark:text-white text-[15px] leading-[20px] font-semibold">${agent.name}</h3>
    <p class="text-gray-600 dark:text-[#9CA3AF] text-[13px] leading-[18px] mt-0.5">${agent.description}</p>
    <div class="flex items-center justify-between mt-3">
      <span class="inline-flex items-center gap-1.5 text-gray-500 dark:text-[#9CA3AF] text-[12px] leading-[16px] border border-black/[0.08] dark:border-white/[0.08] rounded-full px-2.5 py-1">
        <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
        ${agent.credits}
      </span>
      <span class="w-7 h-7 rounded-full border border-black/10 dark:border-white/10 flex items-center justify-center text-gray-400 dark:text-white/40 group-hover:text-gray-900 dark:group-hover:text-white group-hover:border-black/30 dark:group-hover:border-white/30 transition-colors">
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
      </span>
    </div>
  </div>
</a>`;
  }

  function renderDiscover() {
    const el = document.getElementById('earn-discover');
    if (!el) return;

    el.innerHTML = `
<section class="relative bg-white dark:bg-[#0A0A0A] lg:mx-6 xl:mx-auto xl:max-w-[1370px] lg:mt-12">
  <div class="relative lg:rounded-[32px] py-14 sm:py-20">
    <h2 class="text-gray-900 dark:text-white text-[24px] leading-[64px] sm:text-[32px] sm:leading-[64px] font-bold text-center mb-8 sm:mb-12 px-6 sm:px-10 lg:px-16 font-['Inter',sans-serif]">
      <a href="/marketplace/agents.html" class="text-primary transition-colors">Create with Popular Agents</a>
    </h2>

    <div class="overflow-x-auto scrollbar-hide pb-4 pl-6 sm:pl-10 lg:pl-16">
      <div class="flex gap-5 sm:gap-6 pr-6 sm:pr-10 lg:pr-16">
        ${POPULAR_AGENTS.map(renderAgentCard).join('')}
      </div>
    </div>

    <style>.scrollbar-hide::-webkit-scrollbar{display:none}.scrollbar-hide{-ms-overflow-style:none;scrollbar-width:none}</style>

    <div class="flex justify-center mt-10 px-6">
      <a href="/marketplace/agents.html" class="inline-flex items-center justify-center h-12 px-8 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground text-[16px] leading-[28px] font-medium transition-all shadow-lg shadow-primary/20 hover:shadow-primary/30">
        Discover More
      </a>
    </div>
  </div>
</section>`;
  }

  function renderFaqItem(faq, index) {
    const isFirst = index === 0;
    return `
<div class="earn-faq-item rounded-2xl border transition-all duration-300 ${isFirst ? 'border-primary/60 bg-primary/10' : 'border-black/[0.08] dark:border-white/[0.08] bg-transparent hover:border-white/15'}">
  <button type="button" class="earn-faq-toggle w-full flex items-center justify-between gap-4 px-6 py-5 text-left cursor-pointer" data-index="${index}">
    <span class="text-gray-900 dark:text-white font-bold text-[16px] leading-[24px] sm:font-semibold sm:text-base">${faq.question}</span>
    <span class="shrink-0 w-9 h-9 rounded-full border border-black/15 dark:border-white/15 flex items-center justify-center text-gray-500 dark:text-white/60 transition-transform duration-300 ${isFirst ? 'earn-faq-icon-open' : ''}">
      <svg class="earn-faq-icon-plus w-4 h-4 ${isFirst ? 'hidden' : ''}" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 5v14m-7-7h14"/></svg>
      <svg class="earn-faq-icon-minus w-4 h-4 ${isFirst ? '' : 'hidden'}" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M5 12h14"/></svg>
    </span>
  </button>
  <div class="earn-faq-body overflow-hidden transition-all duration-300 ${isFirst ? 'max-h-40' : 'max-h-0'}">
    <p class="px-6 pb-5 text-gray-600 dark:text-gray-400 text-[12px] leading-[19px] font-medium sm:text-sm sm:leading-relaxed sm:font-normal">${faq.answer}</p>
  </div>
</div>`;
  }

  function renderFaq() {
    const el = document.getElementById('earn-faq');
    if (!el) return;

    el.innerHTML = `
<section class="relative bg-[#F3F5F9] dark:bg-[#0F0F0F] rounded-none lg:rounded-[32px] lg:mx-6 xl:mx-auto xl:max-w-[1370px] lg:mt-12 overflow-hidden">
  <div class="relative rounded-none lg:rounded-[24px] px-6 sm:px-10 lg:px-16 py-14 sm:py-20">
    <h2 class="text-gray-900 dark:text-white text-[24px] leading-[64px] sm:text-[42px] sm:leading-[62px] font-bold text-center mb-10">Any Questions Left?</h2>
    <div class="flex flex-col gap-3">
      ${FAQS.map(renderFaqItem).join('')}
    </div>
  </div>
</section>`;

    bindFaqToggles();
  }

  function bindFaqToggles() {
    document.querySelectorAll('.earn-faq-toggle').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var item = btn.closest('.earn-faq-item');
        var body = item.querySelector('.earn-faq-body');
        var iconPlus = item.querySelector('.earn-faq-icon-plus');
        var iconMinus = item.querySelector('.earn-faq-icon-minus');
        var isOpen = body.classList.contains('max-h-40');

        // Close all
        document.querySelectorAll('.earn-faq-item').forEach(function(el) {
          el.classList.remove('border-primary/60', 'bg-primary/10', 'dark:bg-primary/10');
          el.classList.add('border-black/[0.08]', 'dark:border-white/[0.08]', 'bg-transparent');
          el.querySelector('.earn-faq-body').classList.remove('max-h-40');
          el.querySelector('.earn-faq-body').classList.add('max-h-0');
          el.querySelector('.earn-faq-icon-plus').classList.remove('hidden');
          el.querySelector('.earn-faq-icon-minus').classList.add('hidden');
        });

        if (!isOpen) {
          item.classList.add('border-primary/60', 'bg-primary/10', 'dark:bg-primary/10');
          item.classList.remove('border-black/[0.08]', 'dark:border-white/[0.08]', 'bg-transparent');
          body.classList.add('max-h-40');
          body.classList.remove('max-h-0');
          iconPlus.classList.add('hidden');
          iconMinus.classList.remove('hidden');
        }
      });
    });
  }

  function renderForm() {
    const el = document.getElementById('earn-form');
    if (!el) return;

    el.innerHTML = `
<section class="relative bg-[#F3F5F9] dark:bg-[#0F0F0F] rounded-none lg:rounded-[32px] lg:mx-6 xl:mx-auto xl:max-w-[1370px] lg:mt-12">
  <img src="https://aitopia.ai/earn-images/coin-background.webp" alt="" class="hidden lg:block absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[140%] max-w-none h-auto pointer-events-none select-none dark:opacity-100 opacity-30" loading="lazy">
  <div class="relative border border-black/[0.06] dark:border-white/[0.06] rounded-none lg:rounded-[32px] px-6 sm:px-10 lg:px-16 py-14 sm:py-20">
    <div class="max-w-[560px] mx-auto text-center">

      <!-- Badge -->
      <div class="flex items-center justify-center mb-6">
        <span class="inline-flex items-center text-[#FFD91F] text-[12px] font-bold italic tracking-[0.1em] uppercase px-5 py-2 rounded-full border border-black/10 dark:border-white/10 bg-black/[0.03] dark:bg-white/[0.03]">1300+ Creators</span>
      </div>

      <div class="relative">
        <div class="hidden sm:block absolute -left-16 top-1/2 -translate-y-1/2 pointer-events-none">
          <span class="block w-2.5 h-2.5 rounded-full bg-[#FFD91F] mb-1.5 ml-3 opacity-60"></span>
          <span class="block w-1.5 h-1.5 rounded-full bg-[#FFD91F]"></span>
        </div>
        <div class="hidden sm:block absolute -right-16 top-1/2 -translate-y-1/2 pointer-events-none">
          <span class="block w-1.5 h-1.5 rounded-full bg-[#FFD91F] mb-2 ml-2 opacity-60"></span>
          <span class="block w-3 h-3 rounded-full bg-[#FFD91F]"></span>
        </div>
        <p class="text-gray-900 dark:text-white text-[24px] leading-[64px] font-bold sm:text-4xl sm:leading-[1.15] lg:text-[42px] sm:font-extrabold tracking-tight mb-10 font-['Inter',sans-serif]">
          Join the Creator Program
        </p>
      </div>

      <!-- Form -->
      <form id="earn-application-form" class="flex flex-col gap-4" novalidate>

        <!-- Step 1: Socials -->
        <div id="earn-form-step1" class="flex flex-col gap-4">
          <div class="rounded-2xl border border-[#D9D9D90A] bg-[#E8EBF0] dark:bg-[#121212] h-[56px] relative">
            <label class="absolute top-2 left-5 text-[11px] text-gray-500 dark:text-gray-500 pointer-events-none">Instagram URL</label>
            <input type="url" name="instagram_url"
              class="w-full h-full bg-transparent text-gray-900 dark:text-white text-[15px] pt-5 pb-1 px-5 outline-none rounded-2xl placeholder-gray-400 dark:placeholder-white/20"
              placeholder="username">
          </div>

          <div class="rounded-2xl border border-[#D9D9D90A] bg-[#E8EBF0] dark:bg-[#121212] h-[56px] relative">
            <label class="absolute top-2 left-5 text-[11px] text-gray-500 dark:text-gray-500 pointer-events-none">Youtube URL</label>
            <input type="url" name="youtube_url"
              class="w-full h-full bg-transparent text-gray-900 dark:text-white text-[15px] pt-5 pb-1 px-5 outline-none rounded-2xl placeholder-gray-400 dark:placeholder-white/20"
              placeholder="@channel">
          </div>

          <div class="rounded-2xl border border-[#D9D9D90A] bg-[#E8EBF0] dark:bg-[#121212] h-[56px] relative">
            <label class="absolute top-2 left-5 text-[11px] text-gray-500 dark:text-gray-500 pointer-events-none">X URL</label>
            <input type="url" name="x_url"
              class="w-full h-full bg-transparent text-gray-900 dark:text-white text-[15px] pt-5 pb-1 px-5 outline-none rounded-2xl placeholder-gray-400 dark:placeholder-white/20"
              placeholder="username">
          </div>

          <div class="rounded-2xl border border-[#D9D9D90A] bg-[#E8EBF0] dark:bg-[#121212] h-[56px] relative">
            <label class="absolute top-2 left-5 text-[11px] text-gray-500 dark:text-gray-500 pointer-events-none">Tiktok URL</label>
            <input type="url" name="tiktok_url"
              class="w-full h-full bg-transparent text-gray-900 dark:text-white text-[15px] pt-5 pb-1 px-5 outline-none rounded-2xl placeholder-gray-400 dark:placeholder-white/20"
              placeholder="username">
          </div>

          <p id="earn-form-error" class="hidden flex items-center gap-2 text-[#EF4444] text-[13px] leading-[20px] font-medium mt-1">
            <svg class="w-4 h-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            Fill one of the social media links that you own.
          </p>

          <button type="button" id="earn-form-next"
            class="w-full h-14 mt-1 rounded-2xl bg-primary hover:bg-primary/90 text-primary-foreground text-[18px] font-semibold transition-all shadow-lg shadow-primary/20 hover:shadow-primary/30">
            Continue (1/2)
          </button>
        </div>

        <!-- Step 2: Information -->
        <div id="earn-form-step2" class="hidden flex-col gap-4">
          <p class="text-gray-500 dark:text-gray-400 text-[14px] leading-[20px] -mt-2 mb-2">Please type the required fields below before earning.</p>

          <div>
            <div class="earn-field-wrap rounded-2xl border border-[#D9D9D90A] bg-[#E8EBF0] dark:bg-[#121212] h-[56px] relative transition-colors">
              <label class="absolute top-2 left-5 text-[11px] text-gray-500 dark:text-gray-500 pointer-events-none">Full Name*</label>
              <input type="text" name="full_name" required data-label="Name"
                class="w-full h-full bg-transparent text-gray-900 dark:text-white text-[15px] pt-5 pb-1 px-5 outline-none rounded-2xl placeholder-gray-400 dark:placeholder-white/20"
                placeholder="User Name">
            </div>
            <p class="earn-field-error hidden items-center gap-1.5 text-[#EF4444] text-[12px] leading-[16px] font-medium mt-1.5 ml-1">
              <svg class="w-3.5 h-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              <span></span>
            </p>
          </div>

          <div>
            <div class="earn-field-wrap rounded-2xl border border-[#D9D9D90A] bg-[#E8EBF0] dark:bg-[#121212] h-[56px] relative transition-colors">
              <label class="absolute top-2 left-5 text-[11px] text-gray-500 dark:text-gray-500 pointer-events-none">E-mail*</label>
              <input type="email" name="email" required data-label="E-mail"
                class="w-full h-full bg-transparent text-gray-900 dark:text-white text-[15px] pt-5 pb-1 px-5 outline-none rounded-2xl placeholder-gray-400 dark:placeholder-white/20"
                placeholder="you@example.com">
            </div>
            <p class="earn-field-error hidden items-center gap-1.5 text-[#EF4444] text-[12px] leading-[16px] font-medium mt-1.5 ml-1">
              <svg class="w-3.5 h-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              <span></span>
            </p>
          </div>

          <div class="rounded-2xl border border-[#D9D9D90A] bg-[#E8EBF0] dark:bg-[#121212] h-[56px] relative transition-colors">
            <label class="absolute top-2 left-5 text-[11px] text-gray-500 dark:text-gray-500 pointer-events-none">Phone Number</label>
            <input type="tel" name="phone"
              class="w-full h-full bg-transparent text-gray-900 dark:text-white text-[15px] pt-5 pb-1 px-5 outline-none rounded-2xl placeholder-gray-400 dark:placeholder-white/20"
              placeholder="+1 (555) 000-0000">
          </div>

          <div id="earn-turnstile" class="flex items-center justify-center mt-1"></div>
          <p id="earn-captcha-error" class="hidden items-center gap-1.5 text-[#EF4444] text-[12px] leading-[16px] font-medium ml-1">
            <svg class="w-3.5 h-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <span>Please complete the verification</span>
          </p>

          <div id="earn-submit-error" class="hidden p-3 bg-red-50 dark:bg-red-500/10 border border-red-100 dark:border-red-500/20 rounded-xl text-red-600 dark:text-red-400 text-sm"></div>
          <div class="flex gap-3 mt-1">
            <button type="button" id="earn-form-back"
              class="flex-1 h-14 rounded-2xl border border-black/10 dark:border-white/10 hover:border-black/20 dark:hover:border-white/20 bg-transparent text-gray-900 dark:text-white text-[18px] font-semibold transition-all">
              Back
            </button>
            <button type="submit"
              class="flex-[2] h-14 rounded-2xl bg-primary hover:bg-primary/90 text-primary-foreground text-[18px] font-semibold transition-all shadow-lg shadow-primary/20 hover:shadow-primary/30">
              Start Earning
            </button>
          </div>
        </div>

      </form>

    </div>
  </div>
</section>`;

    bindForm();
  }

  function bindForm() {
    var step1 = document.getElementById('earn-form-step1');
    var step2 = document.getElementById('earn-form-step2');
    var nextBtn = document.getElementById('earn-form-next');
    var backBtn = document.getElementById('earn-form-back');
    if (!step1 || !step2) return;

    // Require at least one social URL to continue
    var socialInputs = step1.querySelectorAll('input[type="url"]');
    var errorMsg = document.getElementById('earn-form-error');

    function hasSocial() {
      return Array.prototype.some.call(socialInputs, function(inp) { return inp.value.trim() !== ''; });
    }

    socialInputs.forEach(function(inp) {
      inp.addEventListener('input', function() {
        if (hasSocial() && errorMsg) errorMsg.classList.add('hidden');
      });
    });

    // Step 1 → Step 2
    nextBtn.addEventListener('click', function() {
      if (!hasSocial()) {
        if (errorMsg) { errorMsg.classList.remove('hidden'); errorMsg.classList.add('flex'); }
        return;
      }
      step1.classList.add('hidden');
      step1.classList.remove('flex');
      step2.classList.remove('hidden');
      step2.classList.add('flex');
    });

    // Step 2 → Step 1
    backBtn.addEventListener('click', function() {
      step2.classList.add('hidden');
      step2.classList.remove('flex');
      step1.classList.remove('hidden');
      step1.classList.add('flex');
    });

    // Turnstile captcha
    var turnstileToken = null;
    var captchaError = document.getElementById('earn-captcha-error');

    function renderTurnstile() {
      if (typeof turnstile === 'undefined') return;
      var container = document.getElementById('earn-turnstile');
      if (!container || container.children.length > 0) return;
      var isDark = document.documentElement.classList.contains('dark');
      turnstile.render('#earn-turnstile', {
        sitekey: '0x4AAAAAACyW3ulRepzEW6OE',
        theme: isDark ? 'dark' : 'light',
        callback: function(token) {
          turnstileToken = token;
          if (captchaError) { captchaError.classList.add('hidden'); captchaError.classList.remove('flex'); }
        },
        'expired-callback': function() { turnstileToken = null; },
        'error-callback': function() { turnstileToken = null; }
      });
    }

    // Render turnstile when step 2 becomes visible
    var origNextClick = nextBtn.onclick;
    nextBtn.addEventListener('click', function() { setTimeout(renderTurnstile, 100); });
    renderTurnstile();

    // Step 2 validation — per-field errors
    var requiredInputs = step2.querySelectorAll('input[required]');

    function clearFieldError(inp) {
      var wrap = inp.closest('.earn-field-wrap');
      var err = wrap && wrap.parentElement.querySelector('.earn-field-error');
      if (wrap) { wrap.classList.remove('border-[#EF4444]'); wrap.classList.add('border-[#D9D9D90A]'); }
      if (err) { err.classList.add('hidden'); err.classList.remove('flex'); }
    }

    function showFieldError(inp) {
      var wrap = inp.closest('.earn-field-wrap');
      var err = wrap && wrap.parentElement.querySelector('.earn-field-error');
      var label = inp.dataset.label || inp.name;
      if (wrap) { wrap.classList.remove('border-[#D9D9D90A]'); wrap.classList.add('border-[#EF4444]'); }
      if (err) {
        err.querySelector('span').textContent = label + ' is required';
        err.classList.remove('hidden');
        err.classList.add('flex');
      }
    }

    requiredInputs.forEach(function(inp) {
      inp.addEventListener('input', function() {
        if (inp.value.trim()) clearFieldError(inp);
      });
    });

    // Form submit
    var form = document.getElementById('earn-application-form');
    if (form) {
      form.addEventListener('submit', function(e) {
        e.preventDefault();

        var hasError = false;
        requiredInputs.forEach(function(inp) {
          if (!inp.value.trim()) {
            hasError = true;
            showFieldError(inp);
          } else {
            clearFieldError(inp);
          }
        });

        if (!turnstileToken) {
          hasError = true;
          if (captchaError) { captchaError.classList.remove('hidden'); captchaError.classList.add('flex'); }
        }

        if (hasError) return;

        var submitBtn = form.querySelector('button[type="submit"]');
        var errEl = document.getElementById('earn-submit-error');
        if (errEl) { errEl.classList.add('hidden'); errEl.textContent = ''; }
        if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Submitting...'; }

        var formData = new FormData(form);
        var payload = {
          email: formData.get('email'),
          detail: {
            fullName: formData.get('full_name'),
            phone: formData.get('phone') || undefined,
            instagramUrl: formData.get('instagram_url') || undefined,
            youtubeUrl: formData.get('youtube_url') || undefined,
            xUrl: formData.get('x_url') || undefined,
            tiktokUrl: formData.get('tiktok_url') || undefined,
          },
          'cf-turnstile-response': turnstileToken,
        };

        fetch('https://aitopia.ai/api/creator-program/apply', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
          .then(function(res) { return res.json().then(function(data) { return { status: res.status, data: data }; }); })
          .then(function(result) {
            var errEl = document.getElementById('earn-submit-error');
            if (result.status === 201) {
              // Success
              var formContainer = document.querySelector('#earn-form .max-w-\\[560px\\]');
              if (formContainer) {
                formContainer.innerHTML =
                  '<div class="text-center py-10">' +
                    '<div class="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5">' +
                      '<svg class="w-8 h-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>' +
                    '</div>' +
                    '<h3 class="text-gray-900 dark:text-white text-[24px] font-bold mb-3">Application Submitted!</h3>' +
                    '<p class="text-gray-600 dark:text-gray-400 text-[15px] leading-[24px]">Thank you for applying to the Creator Program.<br>We\'ll review your application and get back to you soon.</p>' +
                  '</div>';
              }
            } else if (result.status === 409) {
              if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Start Earning'; }
              if (errEl) { errEl.textContent = 'You have already applied with this email.'; errEl.classList.remove('hidden'); }
            } else {
              if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Start Earning'; }
              if (errEl) { errEl.textContent = result.data.error || 'Something went wrong. Please try again.'; errEl.classList.remove('hidden'); }
            }
          })
          .catch(function() {
            var errEl = document.getElementById('earn-submit-error');
            if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Start Earning'; }
            if (errEl) { errEl.textContent = 'Please try again.'; errEl.classList.remove('hidden'); }
          });
      });
    }
  }

  function init() {
    renderHero();
    renderSteps();
    renderBoost();
    renderForm();
    renderFaq();
    renderDiscover();
    syncThemeImages();

    // Re-sync images when theme toggles
    new MutationObserver(function() { syncThemeImages(); })
      .observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
