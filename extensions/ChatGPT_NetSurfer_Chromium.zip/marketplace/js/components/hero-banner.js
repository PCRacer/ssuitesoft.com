(function() {
  const HERO_VERSION = 'hero-v1';
  if (window.__AITOPIA_HERO__ === HERO_VERSION) return;
  window.__AITOPIA_HERO__ = HERO_VERSION;

  const WIDTHS = ['w-[340px]', 'w-[260px]', 'w-[300px]', 'w-[220px]', 'w-[360px]'];

  const ROW_1 = [
    { src: 'https://aitopia.ai/agent-images/cloud-surf-1.webp', label: 'Cloud Surf' },
    { src: 'https://aitopia.ai/agent-images/sims-style-1.webp', label: 'Sims Style' },
    { src: 'https://aitopia.ai/agent-images/pet-morph-wizard-1.webp', label: 'Pet Morph' },
    { src: 'https://aitopia.ai/agent-images/micro-beast-1.webp', label: 'Micro Beast' },
    { src: 'https://aitopia.ai/agent-images/paint-app-style-1.webp', label: 'Paint App' },
  ];

  const ROW_2 = [
    { src: 'https://aitopia.ai/agent-images/poster-generation-1.webp', label: 'Poster Generator' },
    { src: 'https://aitopia.ai/agent-images/image-breakdown-1.webp', label: 'Image Breakdown' },
    { src: 'https://aitopia.ai/agent-images/gta-style-1.webp', label: 'GTA Style' },
    { src: 'https://aitopia.ai/agent-images/game-dump-1.webp', label: 'Multi-Game Avatar' },
    { src: 'https://aitopia.ai/agent-images/cosplay-style-1.webp', label: 'Cosplay Style' },
  ];

  function injectStyles() {
    if (document.getElementById('hero-banner-styles')) return;
    const style = document.createElement('style');
    style.id = 'hero-banner-styles';
    style.textContent = `
    @keyframes heroScrollLeft {
      0% { transform: translateX(0); }
      100% { transform: translateX(-50%); }
    }
    @keyframes heroScrollRight {
      0% { transform: translateX(-50%); }
      100% { transform: translateX(0); }
    }
    .hero-row-left { animation: heroScrollLeft 30s linear infinite; }
    .hero-row-right { animation: heroScrollRight 30s linear infinite; }
    @media (prefers-reduced-motion: reduce) {
      .hero-row-left, .hero-row-right { animation: none; }
    }
    .hero-gradient {
      background: linear-gradient(180deg, rgba(250,245,255,0) -15%, rgba(250,245,255,0.75) 10%, rgba(255,255,255,0.92) 22%, #fff 40%, #fff 100%);
    }
    .dark .hero-gradient {
      background: linear-gradient(180deg, rgba(10,10,10,0) -15.56%, rgba(10,10,10,0.86) 23.69%, #0A0A0A 100%);
    }
    `;
    document.head.appendChild(style);
  }

  function renderCard(card, i, isDuplicate) {
    const w = WIDTHS[i % WIDTHS.length];
    const hideMobile = isDuplicate && i > 0;
    const cardCls = `${hideMobile ? 'hidden sm:block ' : ''}relative rounded-2xl overflow-hidden h-[200px] shrink-0 ${w}`;
    const labelCls = hideMobile
      ? 'absolute bottom-2 left-2 bg-black/60 backdrop-blur text-white text-[11px] font-semibold py-1 px-2.5 rounded-lg whitespace-nowrap'
      : 'hidden sm:block absolute bottom-2 left-2 bg-black/60 backdrop-blur text-white text-[11px] font-semibold py-1 px-2.5 rounded-lg whitespace-nowrap';
    return `<div class="${cardCls}"><img class="w-full h-full object-cover block" src="${card.src}" alt="${card.label}" loading="eager"><span class="${labelCls}">${card.label}</span></div>`;
  }

  function renderRow(cards, direction) {
    const originals = cards.map((c, i) => renderCard(c, i, false));
    const duplicates = cards.map((c, i) => renderCard(c, i, true));
    return `<div class="flex gap-3 w-max hero-row-${direction}">${originals.join('')}${duplicates.join('')}</div>`;
  }

  function render() {
    const container = document.getElementById('hero-banner-container');
    if (!container) return;
    // Skip if hero was already inlined in the HTML
    if (container.querySelector('#heroBanner')) return;

    container.innerHTML = `
  <section class="relative overflow-hidden bg-white dark:bg-[#0a0a0a]" id="heroBanner">
    <div class="absolute inset-0 flex flex-col justify-start gap-3 pt-8 overflow-hidden" aria-hidden="true">
      ${renderRow(ROW_1, 'left')}
      ${renderRow(ROW_2, 'right')}
    </div>
    <div class="absolute inset-0 z-[2] hero-gradient"></div>
    <div class="relative z-[3] flex flex-col items-center justify-center text-center pt-[24px] px-4 pb-10 min-h-[380px] sm:pt-8 sm:px-5 sm:pb-[60px] sm:min-h-[440px] lg:pt-4 lg:px-6 lg:pb-16 lg:min-h-[480px]">
      <div class="inline-flex items-center gap-2 text-primary text-[10px] sm:text-[12px] font-[600] uppercase tracking-[1.2px] leading-4 mb-6 px-3 py-2 sm:px-5 sm:py-2.5 rounded-full border border-primary/20 bg-primary/10">
        <span class="w-2 h-2 rounded-full bg-primary shrink-0"></span>
        TRUSTED BY +3 MILLION USERS
      </div>
      <h1 class="text-[24px] leading-[40px] tracking-[-1px] sm:text-[40px] sm:leading-[42px] sm:tracking-[-1.5px] lg:text-[50px] lg:leading-[52px] lg:tracking-[-2px] font-[700] text-gray-900 dark:text-white mb-5 max-w-[700px] xl:max-w-none xl:whitespace-nowrap">
        Top AI <span class="text-primary">Apps, Models, and Agents.</span> One Subscription.
      </h1>
      <p class="text-[14px] leading-[22px] font-[500] sm:text-[20px] sm:leading-[28px] lg:text-[20px] lg:leading-[28px] text-[#9CA3AF] max-w-[820px] mb-9">
        Generate AI images, videos, music, and code with the world's most advanced AI agents and models. All in one place.
      </p>
      <div class="flex flex-row items-center gap-3 sm:gap-4">
        <a href="/marketplace/agents.html" class="flex items-center justify-center h-[48px] sm:h-[60px] px-6 sm:px-10 text-[14px] leading-[28px] sm:text-[16px] font-[600] text-primary-foreground bg-primary border-2 border-primary hover:border hover:text-primary hover:bg-primary/10 active:bg-primary/10 rounded-[9999px] no-underline cursor-pointer transition-colors duration-200">Try Agents</a>
        <a href="/marketplace/models.html" class="flex items-center justify-center h-[48px] sm:h-[60px] px-6 sm:px-10 text-[14px] leading-[28px] sm:text-[16px] font-[600] text-foreground bg-transparent border-2 border-border hover:border hover:text-primary hover:border-primary hover:bg-primary/10 active:bg-primary/10 rounded-[9999px] no-underline cursor-pointer transition-colors duration-200">View All Models</a>
      </div>
    </div>
  </section>`;
  }

  function init() {
    injectStyles();
    render();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
