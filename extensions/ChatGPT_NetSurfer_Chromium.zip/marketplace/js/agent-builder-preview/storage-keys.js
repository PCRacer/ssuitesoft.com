/**
 * Shared localStorage key conventions for the Agent Builder preview bridge.
 *
 * The builder UI (public/js/agent-builder/*) and the preview page
 * (public/agent-builder/preview.html + this directory) communicate purely
 * through localStorage — there is no socket, no server-side draft, no
 * shared in-memory state.
 *
 * The agent JSON itself lives in the builder's own slot
 * (`aitopia.agent-builder.v4.draft.<id>`) — the preview page reads it from
 * there directly. The keys below are auxiliary signals that flow back from
 * the preview page to the builder.
 *
 * Keys are id-scoped so multiple drafts can have independent preview tabs
 * open at once without clobbering each other.
 *
 *   input-errors:<id>  — wizard validators' results, written when the
 *                        Preview button is clicked. If non-empty, the
 *                        builder shows them inline and the preview tab
 *                        is NOT opened. Lives here too so a refresh of
 *                        the builder reloads the same error set.
 *   output-errors:<id> — runtime errors surfaced by the preview run
 *                        (provider 422, unresolved placeholder, missing
 *                        required field at runtime). The builder polls
 *                        this on tab focus and via the `storage` event
 *                        to keep Publish disabled while runtime issues
 *                        remain.
 *   run-result:<id>    — last successful run record (step outputs + final
 *                        output). The preview page rehydrates from this
 *                        when the tab is reopened so a tab refresh
 *                        doesn't lose the work.
 *   preview-passed:<id> — '1' once an end-to-end run returned success.
 *                        Cleared whenever the draft is edited.
 *   passed-doc-hash:<id> — hash of the agent doc the passing run executed
 *                          against. Mismatch with the current draft hash
 *                          invalidates preview-passed.
 *
 * Strings only — every value is JSON-serialized at the boundary.
 */

import * as store from '/marketplace/js/services/browser-storage.js';

const PREFIX = 'aitopia.agent-builder.preview';

export function inputErrorsKey(id) {
  return `${PREFIX}.input-errors.${id}`;
}

export function outputErrorsKey(id) {
  return `${PREFIX}.output-errors.${id}`;
}

export function runResultKey(id) {
  return `${PREFIX}.run-result.${id}`;
}

export function previewPassedKey(id) {
  return `${PREFIX}.preview-passed.${id}`;
}

/**
 * Hash of the agent document the last successful preview run executed
 * against. The builder writes the current doc's hash here whenever the
 * draft changes; if it disagrees with the doc whose preview passed, the
 * Publish gate refuses to unlock until the user runs a fresh preview.
 */
export function passedDocHashKey(id) {
  return `${PREFIX}.passed-doc-hash.${id}`;
}

/**
 * Timestamp (ms since epoch) of the last successful preview run. Paired
 * with PREVIEW_VALIDITY_MS so the Publish gate also expires a passing
 * preview after 72 hours of inactivity — providers update model schemas
 * and prices, and a days-old "passed" record shouldn't quietly
 * authorize a publish against drifted infrastructure.
 */
export function passedAtKey(id) {
  return `${PREFIX}.passed-at.${id}`;
}

/** How long a passing preview stays valid before the gate asks for a re-run. */
export const PREVIEW_VALIDITY_MS = 72 * 60 * 60 * 1000;

/**
 * Project the agent document down to the fields that actually affect a
 * preview run — the model pipeline (steps) and the input contract (fields).
 * Only these two drive what the live pipeline does, so only a change to
 * them re-arms the preview gate. The template shell and listing copy
 * (name, description, media, tags) do NOT change pipeline behavior, so
 * editing those after a successful preview should NOT invalidate the gate
 * and the author can publish directly. Used by both the builder (computing
 * the current hash) and the preview tab (writing the passing hash), so the
 * two sides agree on what counts as a meaningful change.
 *
 * Builder feeds cleanAgentForExport(state.agent); preview tab feeds the raw
 * localStorage slot. To keep the two hashes equal we project each step/field
 * to a fixed allow-list of pipeline-affecting keys (mirrors stepDocHash) and
 * canonicalize nested objects, so transient UI keys (outputFormat, a model
 * alias), key-order shifts, and listing-copy edits never drift the hash.
 */

/** Deep-canonicalize: recursively sort object keys so JSON.stringify is
 * insertion-order-independent. Arrays keep order (meaningful for steps/enum). */
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value).sort()) out[k] = canonical(value[k]);
    return out;
  }
  return value;
}

/** Pipeline-affecting projection of one step. Mirrors stepDocHash() —
 * presentation/runtime-only keys (outputFormat UI choice, estimatedDurationMs,
 * a model alias duplicating model_id, __-prefixed flags) are intentionally
 * excluded so editing them never re-arms the preview gate. */
function stepForHash(step) {
  if (!step || typeof step !== 'object') return step;
  return canonical({
    kind: step.kind || 'model',
    model: step.model_id || step.model || null,
    output: step.output_id || null,
    soul: step.soul || '',
    schema: step.schema || null,
    tools: Array.isArray(step.tools) ? step.tools : null,
    outputSchema: step.outputSchema || null,
  });
}

/** Pipeline-affecting projection of one field. Only the input contract and
 * cost inputs matter to a run; listing/presentation keys (title, description,
 * ui_component, advanced, visible, default) are excluded so editing copy after
 * a passing preview does NOT lock Publish. */
function fieldForHash(field) {
  if (!field || typeof field !== 'object') return field;
  return canonical({
    id: field.id ?? null,
    type: field.type || null,
    required: field.required === true,
    costMultiplier: field.costMultiplier ?? null,
    enum: Array.isArray(field.enum) ? field.enum : null,
    range: field.range && typeof field.range === 'object' ? field.range : null,
  });
}

export function previewAffectingDoc(doc) {
  if (!doc || typeof doc !== 'object') return null;
  const fields = Array.isArray(doc.fields) ? doc.fields.map(fieldForHash) : [];
  const steps = Array.isArray(doc.steps) ? doc.steps.map(stepForHash) : [];
  return {
    fields,
    steps,
  };
}

/**
 * Tiny non-cryptographic string hash (FNV-1a 32-bit). Stable across tabs,
 * cheap, collision-resistant enough for "did the doc change since the
 * last preview run?" — we only need to distinguish *any* change, not
 * defend against malicious collisions.
 */
export function hashString(input) {
  let h = 0x811c9dc5;
  const s = typeof input === 'string' ? input : JSON.stringify(input ?? '');
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16);
}

/** Read + parse a stored JSON value; null on missing or malformed. */
export async function readJson(key) {
  try {
    const raw = await store.getItem(key);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/**
 * Write a JSON value, swallowing write failures. Preview state is advisory —
 * Publish is still gated server-side — so a lost write degrades to "no preview
 * state" rather than data loss.
 */
export async function writeJson(key, value) {
  try {
    return await store.setItem(key, JSON.stringify(value));
  } catch {
    return false;
  }
}

export async function remove(key) {
  try {
    await store.removeItem(key);
  } catch {
    // intentional no-op
  }
}
