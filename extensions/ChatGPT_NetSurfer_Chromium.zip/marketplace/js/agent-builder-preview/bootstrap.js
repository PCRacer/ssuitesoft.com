/**
 * Preview bootstrap.
 *
 * This file's job: prepare the page so embed-runner.js — the same runner
 * that drives every published agent page — can render the *draft* the
 * author is currently editing, without that runner having to know it's
 * in preview mode.
 *
 * Boot ordering (critical):
 *
 *   1. **Before any await**, at import-evaluation time:
 *        - parse agent id from URL,
 *        - install the fetch monkey-patch (so any `https://aitopia.ai/api/store/<id>*` call
 *          fired before preview-meta resolves is queued, not 404'd),
 *        - publish window.__AITOPIA_AGENT_RUN__ / window.__agent so
 *          embed-runner sees the id at its first read.
 *        The draft itself is read asynchronously from browser-storage, so the
 *        hook must be installed before that read, not after.
 *
 *   2. **Asynchronously**, in parallel with embed-runner's boot:
 *        - POST /api/agent-builder/preview-meta with the draft,
 *        - resolve the queued store-fetch promises with the synthesised
 *          agent + schema payloads,
 *        - paint the cloned template's hardcoded header copy with the
 *          draft's name/description (on DOMContentLoaded).
 *
 * Why the queue: embed-runner.js is imported as a module sibling to this
 * bootstrap. Both start evaluating immediately when the parser hits their
 * <script type="module"> tags. The runner's `Promise.all([getStoreAgent,
 * getAgentSchema, ...])` can fire BEFORE our `await fetch('https://aitopia.ai/preview-meta')`
 * completes — so the patch must answer those calls with promises that hold
 * the network in flight, not synchronous 404s.
 */

import {
  outputErrorsKey,
  runResultKey,
  previewPassedKey,
  passedDocHashKey,
  passedAtKey,
  previewAffectingDoc,
  hashString,
  readJson,
  writeJson,
  remove as removeKey,
} from './storage-keys.js';
// The same progress card the runner shows on the Studio stage / History list
// (percent circle + bar). Reused as-is for the V2/V3 hero stage during a
// resumed run — no duplicate markup.
import * as store from '/marketplace/js/services/browser-storage.js';
import { createProgressController, normalizeJobProgress } from '/marketplace/js/runner/progress.js';
// The runner's own result renderer — used to paint a resumed run's settled
// result onto the hero stage, identical to the foreground run.
import { renderOutput } from '/marketplace/js/runner/result-renderer.js';

// ----------------------------------------------------------------------------
// Settings
// ----------------------------------------------------------------------------
//
// Last-response preview: on boot, paint this draft's most recent creation onto
// the hero stage instead of the showcase, so result-UI work doesn't need a
// fresh (paid) run on every reload. Dev aid only — keep it OFF in production.
const LAST_RESPONSE_PREVIEW = false;

// ----------------------------------------------------------------------------
// URL → agent id + current shell
// ----------------------------------------------------------------------------
//
// Static shells live at:
//   /agent-builder/preview/:id     → public/agent-builder/preview.html       (default)
//   /agent-builder/preview-v2/:id  → public/agent-builder/preview-v2.html    (V2)
//   /agent-builder/preview-v3/:id  → public/agent-builder/preview-v3.html    (V3)
//
// `currentShell` is what's loaded right now. If the draft's `template` field
// disagrees we redirect to the matching URL before doing any work.

function parsePreviewLocation() {
  const m = window.location.pathname.match(/^\/agent-builder\/(preview|preview-v2|preview-v3)\/([^/]+)/);
  if (!m) return { agentId: null, currentShell: null };
  const shellByPath = { 'preview-v2': 'V2', 'preview-v3': 'V3' };
  return {
    agentId: decodeURIComponent(m[2]),
    currentShell: shellByPath[m[1]] || 'default',
  };
}

// Mirrors public/js/agent-builder/state.js's storage prefix. Kept as a literal
// here so this bootstrap stays free of the agent-builder module graph (it
// runs in the preview tab, not the builder). Declared at module top so the
// bootstrap call below — which fires before the rest of this file finishes
// evaluating — can reach it.
const BUILDER_DRAFT_PREFIX = 'aitopia.agent-builder.v4.draft.';

// Resolves with the agent doc once it is known. In moderation mode the fetch
// intercept is installed before the doc arrives, so it awaits this.
let docReadyResolve;
const docReady = new Promise((resolve) => { docReadyResolve = resolve; });

/** Publish the globals embed-runner reads at its first tick. */
function publishAgentGlobals(doc) {
  window.__AITOPIA_AGENT_RUN__ = { agentId, useModelSelector: false };
  window.__agent = {
    id: agentId,
    name: doc.name || agentId,
    category: doc.category || 'preview',
    credits: 0,
    previewMode: true,
  };
}

/** Preview URL for a template shell, keeping the query (?mod=1&version=). */
function shellPathFor(template, id) {
  const base = template === 'V2' ? 'preview-v2' : template === 'V3' ? 'preview-v3' : 'preview';
  return `/agent-builder/${base}/${encodeURIComponent(id)}${window.location.search}`;
}

// `metaReady` is a promise the fetch-intercept awaits before answering any
// /api/store/<id>* call. It resolves with `{ storeAgent, schema }` from the
// preview-meta endpoint, OR rejects if the draft is malformed / unavailable.
let metaReadyResolve;
let metaReadyReject;
const metaReady = new Promise((resolve, reject) => {
  metaReadyResolve = resolve;
  metaReadyReject = reject;
});

const { agentId, currentShell } = parsePreviewLocation();

if (!agentId) {
  showFatal('Preview URL is missing the agent id. Expected /agent-builder/preview/<id>.');
} else {
  // Claim the globals and the fetch hook before the first await: the shell
  // ships `agentId: '_preview'` in a classic script that has already run, and
  // embed-runner.js is a module sibling that starts as soon as parsing ends.
  // Anything deferred past an await loses that race and 404s on `_preview`.
  publishAgentGlobals({});
  installFetchIntercept(docReady);

  // Template-shell handoff: if the loaded shell disagrees with the draft's
  // template, redirect once. Moderation has no local draft — bootstrap()
  // fetches the doc and redirects once the template is known.
  (async () => {
    const earlyDraft = moderationParams() ? null : await readDraftEntry(agentId);
    const draftTemplate = earlyDraft?.agent?.template;
    const desiredTemplate = (draftTemplate === 'V2' || draftTemplate === 'V3') ? draftTemplate : 'default';
    if (earlyDraft && desiredTemplate !== currentShell) {
      window.location.replace(shellPathFor(desiredTemplate, agentId));
      return;   // the new page boots fresh
    }
    await bootstrap();
  })().catch(err => {
    console.error('[preview-bootstrap] init failed', err);
    showFatal(err instanceof Error ? err.message : String(err));
  });
}

/**
 * Read the full `{ pass, agent, creditsPerRun }` entry that the builder
 * persists on every notify(). Returns `null` when the slot is empty or
 * corrupt — callers fall back to a fatal error message.
 *
 * Single source of truth: this is the only localStorage read for draft data.
 * No separate snapshot key, no preview-time copy.
 */
async function readDraftEntry(id) {
  try {
    const raw = await store.getItem(`${BUILDER_DRAFT_PREFIX}${id}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && parsed.agent && typeof parsed.agent === 'object') {
      return parsed;
    }
  } catch {
    // Corrupt JSON / quota — caller renders the fatal state.
  }
  return null;
}

async function readActiveDraft(id) {
  const entry = await readDraftEntry(id);
  return entry ? entry.agent : null;
}

// Moderation preview (?mod=1&version=): there is no local slot by design, so
// read the reviewed version straight from the DB.
function moderationParams() {
  const qs = new URLSearchParams(window.location.search);
  if (qs.get('mod') !== '1') return null;
  return { version: qs.get('version') || '' };
}

async function fetchServerDoc(id, version, rawFetch) {
  const versionQs = version ? `&version=${encodeURIComponent(version)}` : '';
  const res = await rawFetch(
    `https://aitopia.ai/api/agent-builder/version/${encodeURIComponent(id)}?withData=1${versionQs}`,
    { credentials: 'include' },
  );
  if (!res.ok) return null;
  const json = await res.json().catch(() => null);
  return json?.currentData && typeof json.currentData === 'object' ? json.currentData : null;
}

async function bootstrap() {
  const mod = moderationParams();
  // Capture before installFetchIntercept swaps window.fetch out.
  const rawFetch = window.fetch.bind(window);
  // Globals + fetch hook were claimed at module scope, before any await.
  const doc = mod
    ? await fetchServerDoc(agentId, mod.version, rawFetch)
    : await readActiveDraft(agentId);
  // One-shot snapshot of every cost-affecting field as it sits in localStorage.
  // This is the source-of-truth for the multiplier hits below: if a number
  // here disagrees with what you set in the builder UI, the builder UI hasn't
  // pushed its latest edit to the preview tab yet — click Preview again.
  if (Array.isArray(doc?.fields)) {
    const priced = doc.fields
      .filter(f => f && f.costMultiplier != null)
      .map(f => ({ id: f.id, ui: f.ui_component, costMultiplier: f.costMultiplier, enum: f.enum, default: f.default }));
    if (priced.length > 0) {
      console.log('[preview-bootstrap] priced fields from storage', priced);
    }
  }
  if (!doc || typeof doc !== 'object') {
    // The runner has already started; reject the queued fetches so they
    // return a clean 404 instead of hanging forever.
    metaReadyReject(new Error(mod ? 'Agent version not found.' : 'Draft not found in localStorage.'));
    showFatal(
      mod
        ? 'This agent version could not be loaded from the server. It may have ' +
          'been deleted, or you may not have permission to review it.'
        : 'No draft was found for this id in your browser. Open the agent in the ' +
          'builder and click <strong>Preview</strong> again — the preview page ' +
          'reads the in-progress draft from localStorage.',
      { id: agentId }
    );
    return;
  }

  // Moderation: template only known after the fetch, so redirect the shell now.
  if (mod) {
    const want = (doc.template === 'V2' || doc.template === 'V3') ? doc.template : 'default';
    if (want !== currentShell) {
      window.location.replace(shellPathFor(want, agentId));
      return;
    }
  }

  // Re-publish with the loaded doc; the intercept is already active from the
  // pre-await install above.
  publishAgentGlobals(doc);
  docReadyResolve(doc);

  // Now resolve preview-meta. The patch is already active; queued requests
  // for /api/store/<id> and /api/store/<id>/schema/json are awaiting this
  // promise.
  let resolvedMeta;
  try {
    const res = await fetch('https://aitopia.ai/api/agent-builder/preview-meta', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agent: doc }),
    });
    const json = await res.json();
    if (!res.ok || !json?.ok) {
      const detail = json?.errors
        ? json.errors.map(e => e.message || JSON.stringify(e)).join('; ')
        : json?.message || `HTTP ${res.status}`;
      throw new Error(`preview-meta failed: ${detail}`);
    }
    resolvedMeta = { storeAgent: json.storeAgent, schema: json.schema };
    metaReadyResolve(resolvedMeta);
  } catch (err) {
    metaReadyReject(err);
    showFatal(
      'Preview metadata fetch failed. Check the builder validators — preview ' +
      'reuses the same rules as Publish.',
      { error: err instanceof Error ? err.message : String(err) }
    );
    return;
  }

  // Cosmetic header swap once the DOM is ready (the runner's own DOM writes
  // are scoped to runner containers, so we don't race with them). The
  // credits handler also receives the same storeAgent reference the fetch
  // intercept hands the runner — that lets it mutate costEstimate in place
  // so AitopiaCredits.getCreditsInfoForAgent recomputes the right total
  // when the runner re-reads it on model/form change.
  whenDomReady(() => {
    paintHeader(doc);
    installLiveCreditsBadge(doc, resolvedMeta.storeAgent);
    // Auto-resume of in-flight preview runs is DISABLED. The /api/queue scan
    // matched any pending/processing builder job for this draft id — including
    // stale/zombie ones left behind when a worker died mid-run — and attached
    // an overlay whose elapsed = Date.now() - createdAt read hours, pinning a
    // bogus "Running… 10808s" bar on a long-dead job. Progress/estimate now
    // lives only in the builder edit screen's Run All / per-step flow.
    // resumeInFlightPreviewRun is kept below; re-enabling needs an age guard.
    void 0;
    if (LAST_RESPONSE_PREVIEW) void loadLastCreationOntoStage(doc);
  });
}

/**
 * Paints the most recent creation for this draft onto the hero stage at boot.
 * Gated by LAST_RESPONSE_PREVIEW. Purely additive: it only fills the stage,
 * and any real run overwrites it.
 */
async function loadLastCreationOntoStage(doc) {
  if (currentShell !== 'V2' && currentShell !== 'V3') return;
  const stage = document.getElementById('hero-media-main');
  if (!stage) return;

  try {
    const res = await fetch(
      `https://aitopia.ai/api/me/creations?limit=1&agentId=${encodeURIComponent(doc.id)}`,
      { headers: { Accept: 'application/json' }, credentials: 'include' }
    );
    if (!res.ok) return;
    const data = await res.json();
    const output = Array.isArray(data?.creations) ? data.creations[0]?.output : null;
    if (output == null) return;

    // Let the template snapshot its showcase first, same as a real run does.
    try { document.dispatchEvent(new CustomEvent('aitopia:hero-stage-claim')); } catch { /* noop */ }
    stage.classList.remove('hidden');
    renderOutput(stage, output, { showPublish: true, fitContainer: true });
  } catch { /* best-effort: a failed preload just leaves the showcase up */ }
}

/**
 * DB-driven refresh resilience for /agent-builder/preview/:agentId.
 *
 * On every boot we ask the server "is there a preview run still going for
 * this builder draft?". The shared /api/queue endpoint already lists every
 * pending+processing job for the caller; we filter to ones whose agentId
 * matches `doc.id` AND whose input.kind === 'builder-preview' (per-step
 * Plays land in the same queue but render in the builder edit screen, not
 * here). When we find one we wire up a progress overlay + a poller that
 * settles the run exactly like handleRunForward would.
 *
 * Same idea as creation-history.js#resumePollingForInProgressItems, just
 * narrower (one job at a time, builder-preview kind only).
 */
async function resumeInFlightPreviewRun(doc) {
  let res;
  try {
    res = await fetch('https://aitopia.ai/api/queue?status=pending,processing&limit=20', {
      headers: { Accept: 'application/json' },
      credentials: 'include',
    });
  } catch {
    return;
  }
  if (!res.ok) return;
  let body;
  try { body = await res.json(); } catch { return; }
  const items = Array.isArray(body?.items) ? body.items : [];

  // Find the most recent builder-preview job for this draft. The queue
  // endpoint sorts newest-first; we keep the first match.
  const match = items.find(item => {
    if (!item || item.agentId !== doc.id) return false;
    const input = item.input && typeof item.input === 'object' ? item.input : {};
    return input.kind === 'builder-preview';
  });
  if (!match) return;

  console.log('[preview-bootstrap] resuming in-flight preview run', { jobId: match.refId, agentId: doc.id });

  // Paint the progress overlay immediately so the author sees "Resuming…"
  // before the first poll lands. The overlay updates every second from
  // its own ticker; the poll loop replaces the run result when settled.
  //
  // We do one extra fetch against /preview-job to get the server's own
  // elapsedMs + estimatedDurationMs (the /queue endpoint doesn't expose
  // estimatedDurationMs). Then we anchor the overlay's startedAt to
  // `Date.now() - elapsedMs` so the ticker (which reads client clock)
  // advances from the correct position regardless of any client/server
  // clock skew.
  // 0 = no estimate yet; the overlay treats it as indeterminate state.
  let estimatedDurationMs = 0;
  let startedAt = Date.now();
  try {
    const probeRes = await fetch(`https://aitopia.ai/api/agent-builder/preview-job/${encodeURIComponent(match.refId)}`, {
      headers: { Accept: 'application/json' },
      credentials: 'include',
    });
    if (probeRes.ok) {
      const probeJson = await probeRes.json();
      if (probeJson?.ok && probeJson.status === 'running') {
        const elapsedMs = Number(probeJson.elapsedMs) || 0;
        startedAt = Date.now() - Math.max(0, elapsedMs);
        if (Number(probeJson.estimatedDurationMs) > 0) {
          estimatedDurationMs = Number(probeJson.estimatedDurationMs);
        }
      }
    }
  } catch { /* fall back to defaults above */ }

  const overlay = ensurePreviewProgressOverlay();
  if (overlay) overlay.start({ startedAt, estimatedDurationMs, label: 'Resuming preview…', jobId: match.refId });
  // V2/V3: also show the run on the big right-hand stage with the runner's
  // own progress card, not just the floating overlay (no-op on default).
  const stageProgress = startHeroStageProgress();

  // Poll the same builder endpoint the foreground run uses. Each running
  // tick streams the server's progress + (live, adaptive) estimate into
  // the overlay so the bar updates from the real source.
  const final = await pollPreviewRunJob(match.refId, {
    onProgress: (running) => {
      const norm = normalizeJobProgress(running.progress);
      if (overlay) {
        overlay.update({
          progress: typeof running.progress === 'number' ? running.progress : null,
          estimatedDurationMs: typeof running.estimatedDurationMs === 'number' && running.estimatedDurationMs > 0
            ? running.estimatedDurationMs
            : undefined,
          estimateExceeded: running.estimateExceeded === true,
        });
      }
      if (stageProgress && norm != null) stageProgress.controller.update(stageProgress.stage, norm);
      // Mirror into the Creation History card, same as the foreground run.
      const pct = norm != null ? Math.round(norm) : null;
      window.dispatchEvent(new CustomEvent('aitopia-creation-progress', {
        detail: {
          jobId: match.refId,
          agentId: doc.id,
          status: pct != null ? `Running (${pct}%)` : 'Running',
        },
      }));
    },
  });
  if (overlay) overlay.stop();
  // The run has SETTLED — the poll loop only returns once status leaves
  // 'running'. Decide on that, not the `progress` number. On success, paint
  // the result onto the stage with the runner's own renderer (clears the
  // in-progress card); on failure, just drop the card. A text-format final
  // step is wrapped as { success, content } so renderOutput's Generated
  // Content card fires (a bare string would render nothing).
  if (stageProgress) {
    if (final && final.success) {
      const textContent = finalStepTextContent(doc, final);
      const value = textContent != null ? { success: true, content: textContent } : final;
      renderOutput(stageProgress.stage, value, { showPublish: false });
    } else {
      stageProgress.controller.clear();
    }
  }
  applyPreviewRunFinal(doc, final);
}

/**
 * Poll /api/agent-builder/preview-job/:jobId for a full preview run.
 * Returns the settled body or throws when the budget runs out.
 */
async function pollPreviewRunJob(jobId, opts = {}) {
  const INTERVAL_MS = 1500;
  const MAX_POLLS = 1000;
  for (let i = 0; i < MAX_POLLS; i++) {
    await new Promise(r => setTimeout(r, INTERVAL_MS));
    let res;
    try {
      res = await fetch(`https://aitopia.ai/api/agent-builder/preview-job/${encodeURIComponent(jobId)}`, {
        headers: { Accept: 'application/json' },
        credentials: 'include',
      });
    } catch { continue; }
    if (res.status === 404) continue;
    if (!res.ok) continue;
    let body;
    try { body = await res.json(); } catch { continue; }
    if (!body?.ok) continue;
    if (body.status === 'running') {
      // Stream the running snapshot up so the overlay can sync its bar to
      // whatever the server's adaptive estimator now says. Without this,
      // the overlay would just animate its elapsed-time text against a
      // stale percentage between settlements.
      if (typeof opts.onProgress === 'function') {
        try { opts.onProgress(body); } catch { /* listener errors don't kill the poll */ }
      }
      continue;
    }
    return body;
  }
  return { ok: false, status: 'failed', success: false, error: { message: 'Resume polling exceeded budget.' } };
}

/**
 * Mirror the bookkeeping handleRunForward does once a preview run settles:
 *   - success → write the run-result snapshot + preview-passed + doc hash
 *   - failure → write output-errors, clear preview-passed
 */
function applyPreviewRunFinal(doc, final) {
  if (!final || typeof final !== 'object') return;
  if (final.success) {
    writeJson(runResultKey(doc.id), {
      success: true,
      finalOutput: final.finalOutput,
      outputs: final.outputs,
      steps: final.steps,
      totalDurationMs: final.totalDurationMs,
      at: Date.now(),
    });
    // Adaptive estimate: write each finished step's real durationMs (+20%
    // headroom) onto the draft so the next run's progress bar uses the
    // learned value instead of the coarse default. Persisted to the same
    // draftKey the builder tab reads, so reopening the builder picks it up.
    recordPipelineEstimates(doc, final.steps);
    persistOutputErrors([]);
    writeJson(previewPassedKey(doc.id), '1');
    writeJson(passedDocHashKey(doc.id), hashString(previewAffectingDoc(doc)));
    writeJson(passedAtKey(doc.id), Date.now());
  } else {
    persistOutputErrors([{
      code: 'runtime_error',
      message: final.error?.message || 'A step failed during the preview run.',
      stepIndex: final.error?.stepIndex,
    }]);
    removeKey(previewPassedKey(doc.id));
  }
}

// Same rule as steps-pass.js#recordStepEstimate: only persist when the last
// step ran. Pipeline success always reaches the last step, so in practice
// this is a guard against partial-success shapes.
//
// Writes back into the builder's v4.draft.<id> entry so the next builder
// reload picks up the learned estimates. The entry shape is
// `{ pass, agent, creditsPerRun }` — we read it, mutate `agent`, write it.
async function recordPipelineEstimates(doc, stepResults) {
  if (!doc?.steps?.length || !Array.isArray(stepResults)) return;
  const lastIndex = doc.steps.length - 1;
  if (!stepResults.some(r => Number(r?.stepIndex) === lastIndex && Number(r?.durationMs) > 0)) return;
  for (const r of stepResults) {
    const idx = Number(r?.stepIndex);
    const ms = Number(r?.durationMs);
    if (idx >= 0 && idx < doc.steps.length && ms > 0) {
      doc.steps[idx].estimatedDurationMs = Math.ceil(ms * 1.2);
    }
  }
  const totalSec = Math.ceil(doc.steps.reduce((s, x) => s + (Number(x?.estimatedDurationMs) || 0), 0) / 1000);
  doc.estimatedDuration = { ...(doc.estimatedDuration || { min: 0 }), max: totalSec };

  const entry = await readDraftEntry(doc.id);
  if (!entry) return;
  entry.agent = doc;
  try {
    await store.setItem(`${BUILDER_DRAFT_PREFIX}${doc.id}`, JSON.stringify(entry));
  } catch {
    // Quota / private mode — adaptive estimate just doesn't persist this run.
  }
}

/**
 * Build (or return the already-mounted) progress overlay that sits over
 * the runner's Generate button while a preview run is in flight on the
 * server. Kept idle (display:none) until start() is called.
 *
 * Single-overlay-per-page contract — multiple calls return the same node
 * with its state reset.
 */
function ensurePreviewProgressOverlay() {
  if (typeof document === 'undefined') return null;
  let card = document.getElementById('ab-preview-progress-card');
  if (!card) {
    card = document.createElement('div');
    card.id = 'ab-preview-progress-card';
    card.style.cssText = [
      'position: fixed',
      'left: 50%',
      'bottom: 24px',
      'transform: translateX(-50%)',
      'z-index: 60',
      'min-width: 320px',
      'max-width: 90vw',
      'padding: 14px 18px',
      'border-radius: 14px',
      'background: hsl(var(--ait-m-background) / 0.96)',
      'border: 1px solid hsl(var(--ait-m-border))',
      'box-shadow: 0 18px 40px -16px rgba(0,0,0,0.45)',
      'font-family: Inter, system-ui, sans-serif',
      'display: none',
    ].join(';');
    card.innerHTML = `
      <div style="display:flex; align-items:center; justify-content:space-between; gap:0.75rem; font-size:0.78rem; color: hsl(var(--ait-m-muted-foreground)); margin-bottom: 6px;">
        <span data-progress-label>Running preview…</span>
        <span data-progress-pct style="font-variant-numeric: tabular-nums;">estimating…</span>
      </div>
      <div data-progress-track style="height: 6px; border-radius: 999px; background: hsl(var(--ait-m-secondary)); overflow: hidden; position: relative;">
        <div data-progress-bar style="width: 0%; height: 100%; background: hsl(var(--ait-m-primary)); transition: width 0.3s ease;"></div>
      </div>
      <div style="margin-top: 6px; display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;">
        <span data-progress-time style="font-size: 0.7rem; color: hsl(var(--ait-m-muted-foreground));">0s elapsed</span>
        <button data-progress-cancel type="button" style="display: none; font-size: 0.7rem; padding: 4px 10px; border-radius: 8px; border: 1px solid hsl(0 80% 60% / 0.5); background: hsl(0 80% 60% / 0.08); color: hsl(0 80% 65%); cursor: pointer;">✕ Cancel</button>
      </div>
    `;
    document.body.appendChild(card);
  }

  const labelEl = card.querySelector('[data-progress-label]');
  const pctEl = card.querySelector('[data-progress-pct]');
  const trackEl = card.querySelector('[data-progress-track]');
  const barEl = card.querySelector('[data-progress-bar]');
  const timeEl = card.querySelector('[data-progress-time]');
  const cancelEl = card.querySelector('[data-progress-cancel]');

  let tickerId = null;
  let context = null;

  // Cancel becomes available after 2 minutes of waiting — same threshold
  // the step row uses. The button POSTs /preview-job/:jobId/cancel; the
  // server flips the jobs row to `cancelled`, our poll loop sees the
  // failed status on the next tick and tears the overlay down naturally.
  const CANCEL_THRESHOLD_MS = 120000;
  if (cancelEl) {
    cancelEl.addEventListener('click', async () => {
      if (!context || !context.jobId || context.cancelling) return;
      context.cancelling = true;
      cancelEl.disabled = true;
      cancelEl.textContent = 'Cancelling…';
      try {
        await fetch(`https://aitopia.ai/api/agent-builder/preview-job/${encodeURIComponent(context.jobId)}/cancel`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
        });
      } catch (err) {
        // Network error — let the user click again. The poll loop will
        // still pick up an eventual settle.
        context.cancelling = false;
        cancelEl.disabled = false;
        cancelEl.textContent = '✕ Cancel';
        console.warn('[preview-bootstrap] cancel request failed', err);
      }
    });
  }

  // Server-fed values cached between poll ticks. The setInterval below only
  // advances the elapsed-time counter; the percentage updates only when
  // `update({progress})` is called from a poll callback. This is the same
  // honesty rule the Steps pass renderer uses — no local synthetic math.
  function renderIndeterminate(elapsedSec, estimatedSec, exceeded) {
    if (pctEl) {
      pctEl.textContent = exceeded ? 'still working…' : 'estimating…';
      pctEl.style.fontStyle = 'italic';
    }
    if (labelEl && context && context.label) {
      labelEl.textContent = exceeded
        ? `Taking longer than expected - ${context.label.toLowerCase()}`
        : context.label;
    }
    if (barEl) {
      barEl.style.transition = 'none';
      barEl.style.width = '30%';
      barEl.style.position = 'absolute';
      barEl.style.top = '0';
      barEl.style.animation = 'ab-progress-indeterminate 1.4s ease-in-out infinite';
    }
    if (timeEl) {
      timeEl.textContent = exceeded
        ? `${elapsedSec}s elapsed (estimated ~${estimatedSec}s)`
        : `${elapsedSec}s elapsed`;
    }
  }
  function renderDetermined(pct, elapsedSec, estimatedSec) {
    if (pctEl) {
      pctEl.textContent = pct + '%';
      pctEl.style.fontStyle = '';
    }
    if (labelEl && context && context.label) labelEl.textContent = context.label;
    if (barEl) {
      barEl.style.animation = '';
      barEl.style.position = '';
      barEl.style.top = '';
      barEl.style.transition = 'width 0.3s ease';
      barEl.style.width = pct + '%';
    }
    if (timeEl) timeEl.textContent = `${elapsedSec}s / ~${estimatedSec}s`;
  }

  function tick() {
    if (!context) return;
    const elapsed = Math.max(0, Date.now() - context.startedAt);
    const elapsedSec = Math.round(elapsed / 1000);
    const estimatedSec = context.estimatedDurationMs > 0 ? Math.round(context.estimatedDurationMs / 1000) : 0;
    if (context.progress !== null && context.estimatedDurationMs > 0) {
      renderDetermined(context.progress, elapsedSec, estimatedSec);
    } else {
      renderIndeterminate(elapsedSec, estimatedSec, !!context.estimateExceeded);
    }
    // Surface Cancel only after the 2-minute wall and only when we have a
    // jobId to address. Cancel is permanent — the button stays visible
    // until the run settles or the overlay stops; once shown it doesn't
    // hide if the elapsed counter somehow ticks backwards.
    if (cancelEl && context.jobId && !context.cancelling && elapsed >= CANCEL_THRESHOLD_MS) {
      cancelEl.style.display = '';
    }
  }

  // Ensure the keyframes the indeterminate state references exist — the
  // preview tab is a clone of the published agent page and doesn't load
  // the builder's stylesheet that defines `ab-progress-indeterminate`.
  if (!document.getElementById('ab-progress-indeterminate-style')) {
    const style = document.createElement('style');
    style.id = 'ab-progress-indeterminate-style';
    style.textContent = '@keyframes ab-progress-indeterminate { 0% { left:-30%; } 50% { left:50%; } 100% { left:110%; } }';
    document.head.appendChild(style);
  }

  return {
    start({ startedAt, estimatedDurationMs, label, jobId }) {
      context = {
        startedAt: Number(startedAt) || Date.now(),
        estimatedDurationMs: Number(estimatedDurationMs) || 0,
        progress: null,
        estimateExceeded: false,
        // Keep the label around so renderIndeterminate can prepend
        // "Taking longer than expected — " when the estimate is exceeded
        // without clobbering the caller's original label string.
        label: label || 'Running preview…',
        // jobId is what the cancel button POSTs against. Optional —
        // a caller without it (rare) just gets the overlay without
        // the cancel surface.
        jobId: typeof jobId === 'string' && jobId ? jobId : null,
        cancelling: false,
      };
      if (labelEl) labelEl.textContent = context.label;
      if (cancelEl) {
        cancelEl.style.display = 'none';
        cancelEl.disabled = false;
        cancelEl.textContent = '✕ Cancel';
      }
      card.style.display = 'block';
      tick();
      if (tickerId) clearInterval(tickerId);
      tickerId = setInterval(tick, 1000);
    },
    /**
     * Fed by the poll loop on every running tick: writes the server's
     * progress + (live, adaptive) estimatedDurationMs into the overlay
     * context. The bar's % only changes here — the setInterval above
     * just advances the elapsed-time text.
     */
    update({ progress, estimatedDurationMs, estimateExceeded }) {
      if (!context) return;
      if (typeof progress === 'number' && progress >= 0) {
        context.progress = Math.max(0, Math.min(99, progress));
      } else if (progress === null) {
        context.progress = null;
      }
      if (typeof estimatedDurationMs === 'number' && estimatedDurationMs > 0) {
        context.estimatedDurationMs = estimatedDurationMs;
      }
      context.estimateExceeded = estimateExceeded === true;
      tick();
    },
    stop() {
      if (tickerId) {
        clearInterval(tickerId);
        tickerId = null;
      }
      card.style.display = 'none';
      context = null;
    },
  };
}

// ----------------------------------------------------------------------------
// Hero-stage running indicator (V2/V3 only)
// ----------------------------------------------------------------------------
//
// V2/V3 surface their result on the big right-hand stage (#hero-media-main).
// When a preview run is resumed in-flight, the floating overlay alone leaves
// that stage showing stale showcase media. Drive the SAME progress card the
// runner uses on its stage (createProgressController — percent circle + bar)
// onto this stage, fed by the real poll percentage. The DEFAULT shell has no
// result stage, so this is a no-op there; settled results arrive via the
// normal runner flow.
function startHeroStageProgress() {
  if (currentShell !== 'V2' && currentShell !== 'V3') return null;
  const stage = document.getElementById('hero-media-main');
  if (!stage) return null;
  // Let the template snapshot its showcase BEFORE we overwrite the stage, so
  // the existing Remove/restore primitive (armHeroShowcase) can put it back.
  try { document.dispatchEvent(new CustomEvent('aitopia:hero-stage-claim')); } catch { /* noop */ }
  const controller = createProgressController();
  controller.start(stage, undefined, { status: 'running' });
  return { stage, controller };
}

// ----------------------------------------------------------------------------
// Cost-multiplier badge
// ----------------------------------------------------------------------------

/**
 * Wire up live credits on the Generate button.
 *
 * Replaces the embed-runner's default credit range ("38–263 credits") with a
 * single, concrete number that reflects the user's current field selections:
 *
 *   final_credits = base_credits × Π (field_multiplier for each user pick)
 *
 *   - base_credits   = doc.costEstimate.minCost converted via AitopiaCredits
 *     (the floor the publish pipeline enforces — never below this).
 *   - field_multiplier:
 *       * `costMultiplier` as number     → multiplier = m × user_value
 *       * `costMultiplier` as map        → multiplier = map[user_pick] (else 1)
 *       * field has no `costMultiplier`  → no contribution
 *
 * Side effects:
 *   - Overwrites runButton.innerHTML on every input/change so the displayed
 *     credits track form state. Both the desktop and mobile Generate buttons
 *     are updated in lockstep.
 *   - Mutates `storeAgent.costEstimate` in place so any other code that
 *     re-reads it (model selector change events, history rehydration) sees
 *     the same total. We collapse min/max to a single value because preview
 *     pricing is deterministic — there's no provider-variability range here.
 */
async function installLiveCreditsBadge(doc, storeAgent) {
  const fields = Array.isArray(doc?.fields) ? doc.fields : [];
  const multiplierFields = fields.filter(f => f && f.costMultiplier != null);

  // Base = the author's `credits_per_run` from the builder (state.creditsPerRun).
  // The builder persists it on every notify() as the top-level `creditsPerRun`
  // field of the v4.draft.<id> entry — same key the rest of this file reads
  // the draft from. No separate storage namespace.
  //
  // If absent (very old draft pre-creditsPerRun), fall back to the doc's
  // costEstimate.maxCost in credits — the runner's pre-existing behaviour —
  // so the form still renders a number.
  async function resolveBaseCredits() {
    const entry = await readDraftEntry(agentId);
    const stored = Number(entry?.creditsPerRun);
    if (Number.isFinite(stored) && stored > 0) {
      return Math.max(1, Math.round(stored));
    }
    const fallbackUsd = Number(doc?.costEstimate?.maxCost);
    if (!Number.isFinite(fallbackUsd) || fallbackUsd <= 0) return null;
    const credits = window.AitopiaCredits?.creditsFromUsd
      ? window.AitopiaCredits.creditsFromUsd(fallbackUsd)
      : Math.ceil(fallbackUsd / 0.02);
    return Math.max(1, Math.round(credits));
  }

  let baseCredits = await resolveBaseCredits();
  if (baseCredits == null) {
    // No cost info at all — leave the runner's default label alone.
    return;
  }

  // usdPerCredit drives the costEstimate mutation below. Prefer the live
  // billing config; otherwise back into it from base. AitopiaCredits is
  // populated by /js/runner/credits.js which the preview page loads via
  // the cloned image-generator template.
  const usdPerCredit =
    Number(window.AitopiaCredits?.getBillingConfig?.()?.usdPerCredit) || 0.02;

  // Wait for the Generate button to land in the DOM. The runner mounts the
  // right-hand panel after its async boot (getStoreAgent + getAgentSchema),
  // which is exactly the promise we just resolved — so the button will
  // appear within a tick or two of this call. We observe instead of polling
  // so the work cost is zero once the wiring is done.
  const root = document.body;
  const observer = new MutationObserver(() => {
    const runButtons = Array.from(document.querySelectorAll(
      '[data-agent-run-button], [data-agent-run-button-mobile]'
    ));
    const form = document.querySelector('[data-agent-run-form]');
    if (runButtons.length === 0 || !form) return;
    if (runButtons.every(b => b.dataset.previewCreditsWired === '1')) return;

    runButtons.forEach(b => { b.dataset.previewCreditsWired = '1'; });

    const refresh = () => {
      // Single source of truth: the shared input-aware pricer reads the same
      // server-embedded builderPricing descriptor the published store page uses,
      // so preview credits match the real charge (resolution/duration/quantity
      // + author multipliers + margin). Fall back to the author-multiplier-only
      // estimate when no descriptor is present (very old drafts).
      const formData = (typeof window !== 'undefined' && window.agent_form_data) || {};
      const shared = window.AitopiaCredits?.getDynamicCreditsForAgent?.(storeAgent, formData);
      const finalCredits = shared?.credits
        ? shared.credits
        : Math.max(1, Math.round(baseCredits * combinedMultiplier(multiplierFields)));

      // Mutate the shared agent reference so any other reader (model
      // selector change handler, history-list label refresh) sees the
      // same number when it next consults the agent. Collapsing min/max
      // to one value is what flips the runner's own label from "X–Y" to
      // a single "Z credits".
      if (storeAgent && typeof storeAgent === 'object') {
        const usd = finalCredits * usdPerCredit;
        storeAgent.costEstimate = {
          minCost: usd,
          maxCost: usd,
          currency: storeAgent.costEstimate?.currency || 'USD',
        };
      }

      // Write the same markup embed-runner's getRunButtonLabel produces, so
      // the button looks pixel-identical to the published surface.
      const html =
        '<span>Generate</span>' +
        '<span class="ml-2 inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-primary-foreground/20 text-xs font-medium">' +
        '<svg class="w-3 h-3" viewBox="0 0 24 24" fill="currentColor"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>' +
        String(finalCredits) +
        '</span>';

      for (const b of runButtons) {
        b.innerHTML = html;
      }

      // Mirrored on mobile credit hints if present.
      const mobileCredits = document.querySelector('[data-agent-run-credits-mobile]');
      const desktopCredits = document.querySelector('[data-agent-run-credits]');
      const text = `${finalCredits} credits`;
      if (desktopCredits) desktopCredits.textContent = text;
      if (mobileCredits) mobileCredits.textContent = text;
    };

    form.addEventListener('input', refresh);
    form.addEventListener('change', refresh);

    // Several custom controls (chip-group, pill-toggle, visual-picker,
    // color-picker, image-pair, multi-select, …) don't dispatch native
    // `input`/`change` events on their wrap — they only call updateFormData()
    // when their selection changes, which fires the global
    // `aitopia:form:data-changed` event on `window`. Subscribe to that too so
    // the credits badge updates regardless of which control the user touched.
    // De-dupe via a single-RAF coalescer so a burst of writes (e.g. an enum
    // field whose default pick triggers cascading updates) doesn't run the
    // multiplier math N times.
    let refreshScheduled = false;
    const scheduleRefresh = () => {
      if (refreshScheduled) return;
      refreshScheduled = true;
      requestAnimationFrame(() => {
        refreshScheduled = false;
        refresh();
      });
    };
    window.addEventListener('aitopia:form:data-changed', scheduleRefresh);

    // Cross-tab sync: if the author tweaks credits_per_run in the builder
    // while the preview tab is still open, the builder rewrites the same
    // v4.draft.<id> entry — pick it up and re-render so the displayed
    // total tracks the new base immediately.
    store.onExternalChange(async (e) => {
      if (e.key !== `${BUILDER_DRAFT_PREFIX}${agentId}`) return;
      const updated = await resolveBaseCredits();
      if (updated != null && updated !== baseCredits) {
        baseCredits = updated;
        refresh();
      }
    });

    refresh();

    observer.disconnect();
  });
  observer.observe(root, { childList: true, subtree: true });
}

/**
 * Read the user's current pick for `fieldId` from the rendered form.
 *
 * Schema-form wraps each control in `<div data-id="<fieldId>">`. We pull
 * the innermost interactive control and read its value. Enum option
 * values arrive JSON-encoded (schema-form does `JSON.stringify(option)`),
 * so we JSON.parse strings that look like literals — that brings
 * `"\"16:9\""` back to `"16:9"`, which is what the author keyed in
 * `costMultiplier`.
 *
 * Returns the raw pick (string / number / boolean) or undefined when no
 * pick exists.
 */
function readFieldPick(fieldId) {
  const wrapper = document.querySelector(`[data-id="${cssEscape(fieldId)}"]`);
  if (!wrapper) return undefined;

  let raw;
  const checkedRadio = wrapper.querySelector('input[type="radio"]:checked');
  if (checkedRadio) {
    raw = checkedRadio.value;
  } else {
    const cb = wrapper.querySelector('input[type="checkbox"]');
    if (cb) return cb.checked;
    const control = wrapper.querySelector('select, textarea, input');
    if (control && 'value' in control) raw = control.value;
  }
  if (raw === undefined || raw === null || raw === '') return undefined;

  if (typeof raw === 'string') {
    const trimmed = raw.trim();
    const looksJson =
      (trimmed.startsWith('"') && trimmed.endsWith('"'))
      || trimmed === 'true' || trimmed === 'false' || trimmed === 'null'
      || /^-?\d+(\.\d+)?$/.test(trimmed);
    if (looksJson) {
      try { return JSON.parse(trimmed); }
      catch { /* keep raw */ }
    }
  }
  return raw;
}

function cssEscape(s) {
  return String(s).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
}

// Extract the first number from a loose value, tolerating a leading/trailing
// unit letter and a comma decimal separator: "5s" / "5.5s" / "s5.5" / "s5,5"
// / "5,5s" → 5 / 5.5. Returns NaN when no number is present.
function parseLooseNumber(value) {
  if (typeof value === 'number') return value;
  if (typeof value !== 'string') return NaN;
  const match = value.replace(',', '.').match(/\d+(?:\.\d+)?/);
  return match ? Number(match[0]) : NaN;
}

/**
 * Combined cost multiplier.
 *
 * Walk every priced field, read the user's current DOM pick, multiply into
 * the running total based on costMultiplier shape:
 *   - number m              → numeric/slider control; floor scales as
 *                             user_value × m.
 *   - object { opt: m, … }  → enum/toggle control; lookup map[pick].
 * Unknown picks (option not in map, no value yet) contribute 1 (no change).
 */
function combinedMultiplier(multiplierFields) {
  let total = 1;
  for (const field of multiplierFields) {
    const cm = field.costMultiplier;
    if (cm == null) continue;
    const pick = readFieldPick(field.id);

    // Numeric multiplier — slider/number input. user_value × m.
    if (typeof cm === 'number' && Number.isFinite(cm)) {
      // Tolerate loose picks like "5s" / "5,5" — pull the first number out.
      const n = typeof pick === 'number' ? pick : parseLooseNumber(pick);
      if (Number.isFinite(n)) total *= n * cm;
      continue;
    }

    // Map multiplier — enum/toggle/visual-picker/etc.
    if (typeof cm === 'object') {
      if (pick == null || pick === '') continue;
      const m = cm[String(pick)];
      if (typeof m === 'number' && Number.isFinite(m)) total *= m;
    }
  }
  return total;
}

function formatMultiplier(m) {
  if (!Number.isFinite(m)) return '1';
  if (Math.abs(m - Math.round(m)) < 1e-9) return String(Math.round(m));
  return m.toFixed(2).replace(/\.?0+$/, '');
}

// ----------------------------------------------------------------------------
// Fetch intercept
// ----------------------------------------------------------------------------

/**
 * Wraps the global `fetch` so the runner's three boot-time agent calls and
 * its Generate-button POST are all rerouted to preview surfaces. Every other
 * URL falls through untouched.
 *
 * The patch is installed BEFORE preview-meta has resolved; any /api/store/<id>*
 * call that lands in the meantime awaits the `metaReady` promise, then sees
 * the cached payload. That keeps the fetch contract synchronous from the
 * runner's perspective: it gets a Promise<Response> like always, the only
 * difference being the resolution happens on the preview-meta round-trip.
 *
 * Why monkey-patch instead of a fetch-adapter module: embed-runner.js is a
 * shared file used by every agent page; patching the global keeps preview
 * support out of its module graph and avoids a "is this preview?" branch
 * deep in the runner.
 */
function installFetchIntercept(docPromise) {
  const originalFetch = window.fetch.bind(window);
  // We compare against the URL's *pathname* (e.g. "https://aitopia.ai/api/store/123123") rather
  // than the raw string passed to fetch. The runner goes through
  // public/js/shared/fetch-helper.js, which converts every relative URL into
  // an absolute one (`https://aitopia.com/api/store/...`) before calling
  // fetch — so a startsWith check against "https://aitopia.ai/api/store/..." misses every call.
  const STORE_PATH = `https://aitopia.ai/api/store/${encodeURIComponent(agentId)}`;
  const STORE_PATH_RAW = `https://aitopia.ai/api/store/${agentId}`;

  function pathnameOf(url) {
    if (!url) return '';
    // Relative ("https://aitopia.ai/api/...") — pathname is everything before '?' or '#'.
    if (url.startsWith('/')) {
      const qIdx = url.indexOf('?');
      const hIdx = url.indexOf('#');
      const cut = [qIdx, hIdx].filter(i => i >= 0).sort((a, b) => a - b)[0];
      return cut == null ? url : url.slice(0, cut);
    }
    // Absolute — let the URL parser do the work. Wrap in try in case fetch
    // is called with garbage (e.g. data: URIs); a parse failure means it's
    // not a store URL we care about.
    try {
      return new URL(url).pathname;
    } catch {
      return '';
    }
  }

  window.fetch = async function previewFetch(input, init) {
    const rawUrl = typeof input === 'string'
      ? input
      : (input && typeof input === 'object' && 'url' in input ? input.url : '');
    const pathname = pathnameOf(rawUrl);

    // /jobs/:id polls in preview mode go straight to the real endpoint — it
    // returns the flat builder shape for builder-step rows and scopes by the
    // caller's userId, which the preview session shares. We don't rewrite the
    // URL; we only peek the response to mirror `running` progress into the
    // Creation History card (the V3 stage clones the card; without this
    // dispatch it stays at its kick-off "Uploading"/"In Queue" label even
    // though the step is actually progressing).
    if (pathname && /^\/jobs\/[^/]+\/?$/.test(pathname)) {
      const jobId = pathname.replace(/^\/jobs\//, '').replace(/\/$/, '');
      const method2 = (init?.method || (typeof input === 'object' && input.method) || 'GET').toUpperCase();
      if (method2 === 'GET' && jobId) {
        const res = await originalFetch(input, init);
        try {
          const json = await res.clone().json();
          if (json && json.status === 'running') {
            const pct = typeof json.progress === 'number' ? Math.round(json.progress) : null;
            window.dispatchEvent(new CustomEvent('aitopia-creation-progress', {
              detail: {
                jobId,
                agentId,
                status: pct != null ? `Running (${pct}%)` : 'Running',
              },
            }));
          }
        } catch { /* peek is best-effort */ }
        return res;
      }
    }

    // Cheap early-out: anything that isn't a store-prefixed URL bypasses.
    if (!pathname || (!pathname.startsWith(STORE_PATH) && !pathname.startsWith(STORE_PATH_RAW))) {
      return originalFetch(input, init);
    }

    const matched = pathname.startsWith(STORE_PATH) ? STORE_PATH : STORE_PATH_RAW;
    const tail = pathname.slice(matched.length);
    const method = (init?.method || (typeof input === 'object' && input.method) || 'GET').toUpperCase();
    // Re-derive the search string so the schema endpoint still sees ?ui=uap.
    const qIdx = typeof rawUrl === 'string' ? rawUrl.indexOf('?') : -1;
    const search = qIdx >= 0 ? rawUrl.slice(qIdx) : '';

    // For metadata + schema, wait until preview-meta has resolved. If it
    // rejected (bad draft, network failure), surface a 502 so the runner
    // reports "Failed to load agent" rather than hanging the page.
    // (Note: `search` covers the ?ui=uap and similar query strings.)
    if (method === 'GET' && tail === '') {
      try {
        const { storeAgent } = await metaReady;
        return jsonResponse(200, storeAgent);
      } catch (err) {
        return jsonResponse(502, { error: errMessage(err) });
      }
    }

    if (method === 'GET' && tail.startsWith('/schema/json')) {
      try {
        const { schema } = await metaReady;
        return jsonResponse(200, schema);
      } catch (err) {
        return jsonResponse(502, { error: errMessage(err) });
      }
    }

    // POST /api/store/<id>/run-step → forward to /api/agent-builder/preview-step
    // with the draft inline (preview agents aren't published — server can't
    // read the doc from the DB). Identical request/response shape; the
    // runner can stay surface-agnostic.
    if (method === 'POST' && tail === '/run-step') {
      const denied = await requirePreviewSignIn();
      if (denied) return denied;
      try {
        let userBody = {};
        try {
          const raw = init?.body;
          if (typeof raw === 'string' && raw) userBody = JSON.parse(raw);
          else if (raw && typeof raw === 'object') userBody = raw;
        } catch { /* keep empty */ }
        return await originalFetch('https://aitopia.ai/api/agent-builder/preview-step', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...userBody, agent: await docPromise, atCost: true }),
          credentials: 'include',
        });
      } catch (err) {
        return jsonResponse(502, { error: errMessage(err) });
      }
    }

    // GET /api/store/<id>/jobs[?parentRunId=X] → pass through to the
    // real store endpoint. Preview-tab agents may not be published, but
    // their step job rows DO live in the shared jobs table under the
    // caller's userId — the public /:id/jobs query scopes by
    // (tenant_id, user_id, agent slug prefix) and returns only rows
    // owned by this viewer. The step-by-step driver uses this both
    // mid-run (resume an in-flight checkpoint) and at page-load
    // (auto-resume a paused run from a prior session).
    if (method === 'GET' && tail === '/jobs') {
      try {
        return await originalFetch(`${matched}/jobs${search}`, {
          method: 'GET',
          headers: init?.headers || { 'Accept': 'application/json' },
          credentials: 'include',
        });
      } catch (err) {
        return jsonResponse(502, { error: errMessage(err) });
      }
    }

    // DELETE /api/store/<id>/runs/<parentRunId> → pass through to the real
    // endpoint. Preview runs write real DB rows (jobs/runs/steps) under the
    // viewer's userId, so Cancel must reach the live delete — not the 404
    // catch-all below. The endpoint is viewer-scoped server-side.
    if (method === 'DELETE' && tail.startsWith('/runs/')) {
      try {
        return await originalFetch(`${matched}${tail}`, {
          method: 'DELETE',
          headers: init?.headers || { Accept: 'application/json' },
          credentials: 'include',
        });
      } catch (err) {
        return jsonResponse(502, { error: errMessage(err) });
      }
    }

    // POST /api/store/<id>/run → forward to /preview-run with the draft inline.
    // If the body carries a `stepIndex` (step-driver per-step call), forward
    // to /preview-step instead so only one step runs, not the full pipeline.
    if (method === 'POST' && tail.startsWith('/run')) {
      const denied = await requirePreviewSignIn();
      if (denied) return denied;
      let userBody = {};
      try {
        const raw = init?.body;
        if (typeof raw === 'string' && raw) userBody = JSON.parse(raw);
        else if (raw && typeof raw === 'object') userBody = raw;
      } catch { /* keep empty */ }
      if (Object.prototype.hasOwnProperty.call(userBody, 'stepIndex')) {
        try {
          return await originalFetch('https://aitopia.ai/api/agent-builder/preview-step', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...userBody, agent: await docPromise, atCost: true }),
            credentials: 'include',
          });
        } catch (err) {
          return jsonResponse(502, { error: errMessage(err) });
        }
      }
      return handleRunForward(originalFetch, input, init, await docPromise);
    }

    // Anything else under /api/store/<id> (jobs, rate, payout-breakdown, ...)
    // is not meaningful for a preview. Return a 404 so the caller sees a
    // clean missing-feature signal instead of a misleading success.
    // `search` deliberately unused for the catch-all — query strings on
    // jobs/rate URLs don't change the "not in preview" answer.
    void search;
    return jsonResponse(404, { error: 'Endpoint not available in preview mode.' });
  };
}

function errMessage(err) {
  return err instanceof Error ? err.message : String(err);
}

/**
 * Forwards the runner's Generate POST to /api/agent-builder/preview-run.
 *
 * The runner's request body is `{ input: <form values>, selectedModelId? }`.
 * Preview-run wants `{ agent: <doc>, input: <form values> }`. We translate,
 * call, then reshape the response back into the synchronous `https://aitopia.ai/api/store/.../run`
 * contract — `{ success, result, modelUsed, ... }` — so the runner's success
 * branch does not have to know it's in preview.
 *
 * Persistence side-effect: on a clean run we also write preview-passed +
 * the passed-doc hash so the builder tab unlocks Publish via the cross-tab
 * `storage` event. On failure we write output-errors and clear preview-passed.
 */
async function handleRunForward(originalFetch, originalInput, originalInit, doc) {
  let userBody = {};
  try {
    const rawBody = originalInit?.body;
    if (typeof rawBody === 'string' && rawBody) {
      userBody = JSON.parse(rawBody);
    } else if (rawBody && typeof rawBody === 'object') {
      userBody = rawBody;
    }
  } catch {
    userBody = {};
  }
  const userInput = userBody && typeof userBody === 'object' && userBody.input && typeof userBody.input === 'object'
    ? userBody.input
    : {};

  // 1. POST the run → expect 202 + { jobId }. The endpoint no longer blocks
  //    on the pipeline, so reverse-proxy 504s on multi-step runs are gone.
  let kickoff;
  try {
    kickoff = await originalFetch('https://aitopia.ai/api/agent-builder/preview-run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      // Preview is the author testing their own draft — charge provider cost,
      // not the retail price they set for customers. The live store path never
      // sends this flag.
      body: JSON.stringify({ agent: doc, input: userInput, atCost: true }),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    persistOutputErrors([{ code: 'network', message }]);
    removeKey(previewPassedKey(agentId));
    return jsonResponse(500, { success: false, error: { message } });
  }

  let kickoffJson;
  try { kickoffJson = await kickoff.json(); }
  catch { kickoffJson = null; }

  if (!kickoff.ok || !kickoffJson?.ok || !kickoffJson.jobId) {
    const message = kickoffJson?.message
      || (kickoffJson?.validationErrors && kickoffJson.validationErrors.map(e => e.message).join('; '))
      || `Preview run failed to start (HTTP ${kickoff.status})`;
    persistOutputErrors([{ code: kickoffJson?.code || 'http_error', message }]);
    removeKey(previewPassedKey(agentId));
    return jsonResponse(kickoff.status || 500, { success: false, error: { message } });
  }

  const jobId = kickoffJson.jobId;
  // Use the same wall clock the ticker reads (client Date.now()) for the
  // foreground run. Mixing the server-issued createdAt with client-side
  // tick timestamps causes the bar to read 0% forever whenever the two
  // clocks are skewed — `Date.now() - serverCreatedAt` goes negative,
  // gets clamped to 0, and the bar never advances. Same fix the per-step
  // path uses in runStepBuilder. The server's createdAt is still useful
  // for refresh resume below (where the elapsed jobs.row.createdAt is
  // already in server time and gets re-anchored).
  const startedAt = Date.now();
  // 0 is allowed — server returns null/0 for a draft that has never run.
  // The overlay treats 0 as "no estimate yet, show indeterminate state"
  // instead of pretending to have a percentage.
  const estimatedDurationMs = Number(kickoffJson.estimatedDurationMs) || 0;

  // Floating progress overlay — same UI a resumed run uses. Survives across
  // the poll loop iterations; we stop it on settle or timeout.
  const overlay = ensurePreviewProgressOverlay();
  if (overlay) overlay.start({ startedAt, estimatedDurationMs, label: 'Running preview…', jobId });

  // 2. Poll the job. The runner has its own loading UI up while we wait;
  //    we just need to keep the fetch promise unresolved until the job
  //    settles. 1.5s interval is enough — preview runs are minutes-scale.
  //    Each iteration logs to console so the author can watch progress in
  //    devtools.
  const POLL_INTERVAL_MS = 1500;
  const MAX_POLLS = 1000; // 1000 × 1.5s ≈ 25 minutes — must outlast the 20-minute FAL queue wait (fal-dynamic.ts)
  let final = null;
  for (let i = 0; i < MAX_POLLS; i++) {
    await new Promise(r => setTimeout(r, POLL_INTERVAL_MS));
    let pollRes;
    try {
      pollRes = await originalFetch(`https://aitopia.ai/api/agent-builder/preview-job/${encodeURIComponent(jobId)}`);
    } catch (err) {
      // Transient network blip — keep polling. Real timeouts are bounded by
      // the loop's max iteration count.
      console.warn('[preview-poll] network blip, retrying', err);
      continue;
    }
    let pollJson;
    try { pollJson = await pollRes.json(); }
    catch { pollJson = null; }

    if (!pollRes.ok || !pollJson?.ok) {
      const message = pollJson?.message || `Job poll failed (HTTP ${pollRes.status})`;
      persistOutputErrors([{ code: pollJson?.code || 'poll_error', message }]);
      removeKey(previewPassedKey(agentId));
      if (overlay) overlay.stop();
      return jsonResponse(500, { success: false, error: { message } });
    }

    if (pollJson.status === 'running') {
      // Sync the overlay to the server's current honest estimate. Each tick
      // can change both progress and estimatedDurationMs as the adaptive
      // estimator learns from finishing upstream steps.
      if (overlay) {
        overlay.update({
          progress: typeof pollJson.progress === 'number' ? pollJson.progress : null,
          estimatedDurationMs: typeof pollJson.estimatedDurationMs === 'number' && pollJson.estimatedDurationMs > 0
            ? pollJson.estimatedDurationMs
            : undefined,
        });
      }
      // Mirror the same progress into the Creation History card (sidebar).
      // The fetch-patched `https://aitopia.ai/api/store/.../run` path returns a synchronous
      // 200/422 after this loop, so embed-runner's own pollJob onTick never
      // runs — without this dispatch, the history card stays frozen at the
      // initial "In Queue" state we inserted before kick-off.
      const pct = typeof pollJson.progress === 'number' ? Math.round(pollJson.progress) : null;
      window.dispatchEvent(new CustomEvent('aitopia-creation-progress', {
        detail: {
          jobId,
          // Card was inserted with a `runner-…` key and never learned this
          // jobId; agentId lets the handler fall back to the agent's single
          // in-progress card.
          agentId,
          status: pct != null ? `Running (${pct}%)` : 'Running',
        },
      }));
      // Feed the real % into the V2/V3 hero-stage card embed-runner started at
      // kick-off — without this it shows only its optimistic simulation.
      if (pct != null) { try { window.__AITOPIA_HERO_PROGRESS__?.(pct); } catch { /* noop */ } }
      console.log(`[preview-poll] running (${Math.round((pollJson.elapsedMs || 0) / 1000)}s elapsed, progress=${pollJson.progress})`);
      continue;
    }

    // done or failed
    final = pollJson;
    break;
  }

  if (overlay) overlay.stop();

  // Settle the Creation History card. The poll loop above dispatched
  // `Running (XX%)` ticks while the run was in flight; without a final
  // dispatch the card stays frozen at the last-seen percentage even
  // after embed-runner moves on. The card's own `Completed`/`Failed`
  // status will land via embed-runner's sync branch (`addCreation`
  // with a fresh entry) — this dispatch just makes sure the spinner
  // disappears immediately, not after the sync branch races us.
  window.dispatchEvent(new CustomEvent('aitopia-creation-progress', {
    detail: {
      jobId,
      agentId,
      status: final && final.success ? 'Completed' : 'Failed',
    },
  }));

  if (!final) {
    const message = 'Preview run exceeded the client-side polling budget.';
    persistOutputErrors([{ code: 'poll_timeout', message }]);
    removeKey(previewPassedKey(agentId));
    return jsonResponse(504, { success: false, error: { message } });
  }

  // 3. Persist + reshape — same bookkeeping the synchronous version did.
  if (final.success) {
    writeJson(runResultKey(agentId), {
      success: true,
      finalOutput: final.finalOutput,
      outputs: final.outputs,
      steps: final.steps,
      totalDurationMs: final.totalDurationMs,
      at: Date.now(),
    });
    persistOutputErrors([]);
    writeJson(previewPassedKey(agentId), '1');
    writeJson(passedDocHashKey(agentId), hashString(previewAffectingDoc(doc)));
    writeJson(passedAtKey(agentId), Date.now());
  } else {
    persistOutputErrors([
      {
        code: 'runtime_error',
        message: final.error?.message || 'A step failed during the preview run.',
        stepIndex: final.error?.stepIndex,
      },
    ]);
    removeKey(previewPassedKey(agentId));
  }

  const status = final.success ? 200 : 422;
  // embed-runner renders `json.output ?? json.result` through renderOutput().
  // For a text-format content-research final step, the result is a markdown
  // STRING, and renderOutput's Generated Content card only fires on an OBJECT
  // with `{ success:true, content:<string> }` (result-renderer.js gate). So we
  // wrap the markdown in that shape — exactly what the published runtime hands
  // the runner via generic-wizard-agent. Media/structured steps keep the raw
  // checkpoint output / finalOutput, which renderOutput already understands.
  const textContent = finalStepTextContent(doc, final);
  const result = textContent != null
    ? { success: true, content: textContent }
    : (pickCheckpointOutput(final.steps) ?? final.finalOutput);
  const reshaped = {
    success: !!final.success,
    status: final.success ? 'success' : 'failed',
    result,
    modelUsed: lastModelOfDoc(doc),
    provider: 'preview',
    durationMs: final.totalDurationMs,
    previewMode: true,
    ...(final.success ? {} : { error: final.error?.message }),
  };
  return jsonResponse(status, reshaped);
}

/**
 * The markdown string a text-format content-research FINAL step produced, or
 * null when the final step isn't one. Used to surface `content` so the runner
 * renders a Generated Content card (same contract as the published runtime's
 * generic-wizard-agent `content: finalOutput`).
 */
function finalStepTextContent(doc, final) {
  if (!final?.success) return null;
  const steps = Array.isArray(doc?.steps) ? doc.steps : [];
  const last = steps[steps.length - 1];
  if (!last || last.kind !== 'content-research' || last.outputFormat === 'json') return null;
  return typeof final.finalOutput === 'string' && final.finalOutput.length > 0
    ? final.finalOutput
    : null;
}

function pickCheckpointOutput(steps) {
  if (!Array.isArray(steps) || steps.length === 0) return null;
  for (let i = steps.length - 1; i >= 0; i--) {
    const s = steps[i];
    if (s && s.checkpoint === true && s.output != null && s.output !== '') return s.output;
  }
  return null;
}

function lastModelOfDoc(doc) {
  const steps = Array.isArray(doc?.steps) ? doc.steps : [];
  if (steps.length === 0) return null;
  return steps[steps.length - 1]?.model_id || null;
}

async function requirePreviewSignIn() {
  let ok = false;
  try {
    const m = await import('/marketplace/js/shared/login-modal.js');
    ok = await m.ensureSignedIn({ message: 'Sign in to run a preview of this agent.' });
  } catch { ok = false; }
  if (ok) return null;
  return jsonResponse(401, { success: false, error: { message: 'Sign in to run a preview.' } });
}

function jsonResponse(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function persistOutputErrors(errors) {
  writeJson(outputErrorsKey(agentId), Array.isArray(errors) ? errors : []);
}

// ----------------------------------------------------------------------------
// DOM patches — swap the cloned template's hardcoded copy with the draft
// ----------------------------------------------------------------------------

function whenDomReady(fn) {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', fn, { once: true });
  } else {
    fn();
  }
}

/**
 * Hydrate the server-rendered placeholder copy/media with the draft.
 *
 * The preview page is rendered by generateAgentPreviewPage with a generic
 * placeholder agent (name "Agent Preview", no media), so the SSR output ships
 * with neutral copy. The actual draft only exists in this browser's
 * localStorage — we read it here and write it into the marked-up elements.
 *
 * Contract (set by templates/agent-page.html + slot helpers):
 *   - [data-agent-title]            → draft.name  (textContent)
 *   - [data-agent-description]      → draft.description  (textContent)
 *   - [data-agent-breadcrumb-current] → draft.name  (textContent)
 *   - [data-agent-cover-media]      → first showcase image/video (src + tag swap)
 *   - [data-agent-hero-media]       → first showcase image/video (src + tag swap)
 *
 * Anything missed here is cosmetic, not functional: the runner reads name/title
 * from the cached storeAgent response, not the DOM.
 */
function paintHeader(doc) {
  const name = String(doc.name || agentId);
  const description = String(doc.description || '');

  document.title = `${name} — Preview | AITOPIA`;

  document.querySelectorAll('[data-agent-title]').forEach(el => {
    el.textContent = name;
  });

  document.querySelectorAll('[data-agent-breadcrumb-current]').forEach(el => {
    el.textContent = name;
  });

  if (description) {
    document.querySelectorAll('[data-agent-description]').forEach(el => {
      el.textContent = description;
    });
  }

  hydrateMedia(doc);

  // Inject a discreet "Draft preview" banner so the author never confuses
  // a preview run with a real published page.
  if (!document.querySelector('[data-preview-banner]')) {
    const banner = document.createElement('div');
    banner.dataset.previewBanner = '1';
    banner.style.cssText = [
      'position:sticky', 'top:0', 'z-index:60',
      'padding:6px 12px', 'text-align:center', 'font-size:12px', 'font-weight:600',
      'background:linear-gradient(hsl(45 90% 55% / 0.18), hsl(45 90% 55% / 0.18)), hsl(var(--background, 0 0% 100%))',
      'color:hsl(45 90% 55%)',
      'border-bottom:1px solid hsl(45 90% 55% / 0.4)',
    ].join(';');
    banner.innerHTML =
      'Draft preview - this agent has not been published. Runs do not appear in the marketplace. ' +
      '<a href="https://aitopia.ai/agent-builder" style="text-decoration:underline">Back to builder</a>';
    document.body.prepend(banner);
  }
}

/**
 * Swap the server-rendered placeholder media (cover + hero) for the draft's
 * first showcase image or video.
 *
 * The element may have been rendered as either an <img> or a <video> depending
 * on what getBestMedia returned at SSR time. If the draft's media has a
 * different type (image vs video) we replace the whole element with the right
 * tag — just updating .src on a <video> placeholder would skip the <img> branch
 * the user actually wants to see, and vice versa.
 */
function hydrateMedia(doc) {
  const videos = Array.isArray(doc?.showcase_videos) ? doc.showcase_videos.filter(Boolean) : [];
  const images = Array.isArray(doc?.showcase_images) ? doc.showcase_images.filter(Boolean) : [];

  // URL → media type. Matches the inline sniff in scripts/lib/load-agents.mjs
  // `getBestMedia` (`endsWith('.mp4') || endsWith('.webm')`) plus the common
  // `.mov`/`.m4v` containers we encounter in showcase data.
  function urlIsVideo(url) {
    const s = String(url || '').toLowerCase();
    return /\.(mp4|mov|webm|m4v)(\?|#|$)/.test(s) || s.startsWith('data:video/') || s.includes('/video/');
  }

  // Cover (left panel, small): mirrors getBestMedia(agent, { preferImage: true })
  // in load-agents.mjs — the chain is:
  //   showcase_images[0] → icon → featured_video → showcase_videos[0]
  // Image-only field at the top: a left-panel image is what published agents
  // ship (e.g. image-generator-1.webp), not the hover clip.
  let cover = null;
  for (const candidate of [images[0], doc?.icon, doc?.featured_video, videos[0]]) {
    if (candidate && typeof candidate === 'string') {
      cover = { type: urlIsVideo(candidate) ? 'video' : 'image', url: candidate };
      break;
    }
  }

  // Hero (right side, large): mirrors getAgentMediaList in
  // scripts/generate-pages.v2.mjs — showcase_videos come first (typed video),
  // then showcase_images (typed image). `featured_video` is intentionally
  // excluded here: in the published catalog it's only used by the /agents
  // card hover, never by the detail-page hero.
  let hero = null;
  if (videos.length > 0) hero = { type: 'video', url: videos[0] };
  else if (images.length > 0) hero = { type: 'image', url: images[0] };
  else if (cover) hero = cover; // No showcase assets at all — reuse the cover so the hero isn't blank.

  if (!cover && !hero) return; // No media anywhere — leave SSR placeholder.

  // Apply: cover-media gets `cover`, hero-media gets `hero`.
  //
  // The SSR placeholder agent emits the correct outer/middle/media DOM shape
  // even when no media is configured (see generateMainMedia /
  // generateLeftPanelCoverMedia / generateHeroMobileMedia in
  // scripts/generate-pages.v2.mjs). So in the simple case we only need to
  // swap `src`. The element is replaced wholesale only when the type
  // disagrees (placeholder rendered `<img>` but the draft has a video, or
  // vice versa) — class names are preserved from the SSR element since
  // those already carry the right published-page dimensions.
  for (const [attr, pick] of [
    ['data-agent-cover-media', cover],
    ['data-agent-hero-media', hero],
  ]) {
    if (!pick) continue;
    document.querySelectorAll(`[${attr}]`).forEach(el => {
      const isVideoEl = el.tagName === 'VIDEO';
      const isImageEl = el.tagName === 'IMG';

      // Drop the empty-state opacity hint if it was rendered (placeholder).
      el.classList.remove('opacity-50');

      if (pick.type === 'video' && isVideoEl) {
        if (el.src !== pick.url) el.src = pick.url;
        return;
      }
      if (pick.type === 'image' && isImageEl) {
        if (el.getAttribute('src') !== pick.url) el.setAttribute('src', pick.url);
        return;
      }
      // Type mismatch — replace the element so the right tag is used.
      // Keep the SSR class names so dimensions match the published page.
      const replacement = document.createElement(pick.type === 'video' ? 'video' : 'img');
      replacement.src = pick.url;
      replacement.className = el.className;
      replacement.setAttribute(attr, '');
      if (pick.type === 'video') {
        replacement.autoplay = true;
        replacement.muted = true;
        replacement.loop = true;
        replacement.playsInline = true;
      } else {
        replacement.alt = String(doc.name || '');
      }
      el.replaceWith(replacement);
    });
  }

  // Multi-media gallery — build a thumbnail nav next to the hero slot when the
  // draft carries 2+ showcase items. The static preview shells (preview.html /
  // preview-v2.html) ship only a single <div id="hero-media-main"> slot; the
  // SSR `generateThumbnailNav` markup never lands here, so without this the
  // user sees only the first video/image even when several are uploaded.
  //
  // The two shells both define a global `selectHeroMedia(thumbEl, index)`
  // function that swaps the inner content of #hero-media-main based on the
  // thumb's data-type/data-url attributes — we mirror that contract and bind
  // click handlers directly (the script-level `heroThumbs` NodeList in those
  // shells is computed at load time and stays empty for our runtime thumbs).
  const allMedia = [
    ...videos.map(url => ({ type: 'video', url })),
    ...images.map(url => ({ type: 'image', url })),
  ];
  if (allMedia.length > 1) {
    buildHeroThumbnailNav(allMedia);
  }
}

/**
 * Build (or rebuild) the thumbnail nav for the hero gallery. Idempotent —
 * a previous nav is removed before painting the new one so re-hydrations
 * (cross-tab draft updates) don't stack rows.
 */
function buildHeroThumbnailNav(allMedia) {
  const heroSlot = document.getElementById('hero-media-main');
  if (!heroSlot) return;

  // Drop any prior runtime-built nav. The marker class is our own; SSR thumb
  // navs (when they ever exist) use plain `.hero-thumb` without it.
  const prior = document.querySelector('[data-preview-thumbnail-nav]');
  if (prior) prior.remove();

  const nav = document.createElement('div');
  nav.setAttribute('data-preview-thumbnail-nav', '');
  nav.className = 'flex items-center justify-center gap-3 mt-3';

  const arrowBtnClass =
    'flex-shrink-0 w-7 h-7 flex items-center justify-center rounded-full bg-gray-200 dark:bg-[#101010] '
    + 'border border-gray-300 dark:border-[#D9D9D9]/[0.08] hover:bg-gray-300 dark:hover:bg-[#1a1a1a] transition-colors';
  const arrowSvg = (path) =>
    `<svg class="w-2.5 h-2.5 text-gray-600 dark:text-[#D9D9D9]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">`
    + `<path stroke-linecap="round" stroke-linejoin="round" d="${path}"/></svg>`;

  const prevBtn = document.createElement('button');
  prevBtn.type = 'button';
  prevBtn.className = arrowBtnClass;
  prevBtn.innerHTML = arrowSvg('M15 19l-7-7 7-7');

  const nextBtn = document.createElement('button');
  nextBtn.type = 'button';
  nextBtn.className = arrowBtnClass;
  nextBtn.innerHTML = arrowSvg('M9 5l7 7-7 7');

  const thumbRow = document.createElement('div');
  thumbRow.className = 'flex items-center gap-3 overflow-x-auto hide-scrollbar';

  let activeIndex = 0;
  const thumbs = allMedia.map((m, i) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className =
      'hero-thumb flex-shrink-0 w-12 h-12 rounded-full overflow-hidden ring-2 '
      + (i === 0 ? 'ring-primary/90' : 'ring-transparent')
      + ' hover:ring-primary/90 transition-all';
    btn.dataset.type = m.type;
    btn.dataset.url = m.url;
    if (m.type === 'video') {
      const v = document.createElement('video');
      v.src = m.url;
      v.muted = true;
      v.className = 'w-full h-full object-cover';
      btn.appendChild(v);
    } else {
      const img = document.createElement('img');
      img.src = m.url;
      img.alt = '';
      img.className = 'w-full h-full object-cover';
      btn.appendChild(img);
    }
    btn.addEventListener('click', () => activate(i));
    thumbRow.appendChild(btn);
    return btn;
  });

  function activate(index) {
    if (index < 0 || index >= allMedia.length) return;
    activeIndex = index;
    const pick = allMedia[index];
    // Mirror the shells' selectHeroMedia(): rewrite the hero slot inner HTML
    // based on the picked media's type. Keep the same class shape the static
    // shells use so dimensions stay consistent.
    if (pick.type === 'video') {
      heroSlot.innerHTML =
        '<video src="' + pick.url + '" class="w-full h-full object-cover" autoplay muted loop playsinline data-agent-hero-media></video>';
    } else {
      heroSlot.innerHTML =
        '<img src="' + pick.url + '" alt="" class="w-full h-full object-cover" data-agent-hero-media>';
    }
    for (let i = 0; i < thumbs.length; i++) {
      thumbs[i].classList.toggle('ring-primary/90', i === index);
      thumbs[i].classList.toggle('ring-transparent', i !== index);
    }
  }

  prevBtn.addEventListener('click', () => {
    activate((activeIndex - 1 + allMedia.length) % allMedia.length);
  });
  nextBtn.addEventListener('click', () => {
    activate((activeIndex + 1) % allMedia.length);
  });

  nav.appendChild(prevBtn);
  nav.appendChild(thumbRow);
  nav.appendChild(nextBtn);

  // Place the nav directly under the hero. The preview shells wrap
  // #hero-media-main in a flex-row container (e.g. `flex justify-center`),
  // so a plain appendChild on the parent would lay the nav next to the
  // video instead of below it. Wrap the hero + nav in a small flex-col
  // container the first time we hydrate, then append nav into it. On
  // subsequent re-hydrations the wrapper is reused.
  let wrapper = heroSlot.parentElement?.querySelector(':scope > [data-preview-hero-wrapper]');
  if (!wrapper) {
    wrapper = document.createElement('div');
    wrapper.setAttribute('data-preview-hero-wrapper', '');
    // Inherit the flex-grow + min-h-0 the hero slot had as a direct child of
    // .v3-stage-inner. Without these the wrapper sizes to its content, so the
    // hero video escapes the stretched stage height and the right column runs
    // taller than the left workspace.
    wrapper.className = 'flex flex-col items-center flex-1 min-h-0 w-full';
    heroSlot.replaceWith(wrapper);
    wrapper.appendChild(heroSlot);
  }
  wrapper.appendChild(nav);
}

// ----------------------------------------------------------------------------
// Fatal-state helper — used when the draft is missing or preview-meta fails
// ----------------------------------------------------------------------------

function showFatal(htmlMessage, extra) {
  const note = extra ? ` <code>${escapeHtml(JSON.stringify(extra))}</code>` : '';
  whenDomReady(() => {
    document.title = 'Preview unavailable — AITOPIA';
    document.body.innerHTML = `
      <main style="max-width:680px;margin:80px auto;padding:32px;border:1px solid rgba(127,127,127,0.3);border-radius:18px;font-family:Inter,system-ui,sans-serif">
        <h1 style="font-size:1.4rem;font-weight:700;margin:0 0 12px">Preview unavailable</h1>
        <p style="line-height:1.6;color:rgba(127,127,127,1)">${htmlMessage}${note}</p>
        <p style="margin-top:24px">
          <a href="https://aitopia.ai/agent-builder" style="color:#7C3AED;font-weight:600">← Back to builder</a>
        </p>
      </main>
    `;
  });
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
