const state = {
  section: 'overview',
  user: null,
  lastPayload: null,
};

const sections = {
  overview: 'https://aitopia.ai/api/admin/metrics/overview',
  users: 'https://aitopia.ai/api/admin/metrics/users',
  revenue: 'https://aitopia.ai/api/admin/metrics/revenue',
  subscriptions: 'https://aitopia.ai/api/admin/metrics/subscriptions',
  usage: 'https://aitopia.ai/api/admin/metrics/usage',
  retention: 'https://aitopia.ai/api/admin/metrics/retention',
  financial: 'https://aitopia.ai/api/admin/metrics/financial',
  predictive: 'https://aitopia.ai/api/admin/metrics/predictive',
};

const title = document.getElementById('pageTitle');
const userLine = document.getElementById('userLine');
const keyInput = document.getElementById('adminKey');
const statusEl = document.getElementById('connectionStatus');
const cards = document.getElementById('cards');
const debugLog = document.getElementById('debugLog');

function headers() {
  return { 'Content-Type': 'application/json' };
}

function setStatus(text, mode = '') {
  statusEl.textContent = text;
  statusEl.className = `status ${mode}`.trim();
}

function card(label, value, note, mode = '') {
  const el = document.createElement('article');
  el.className = 'card';
  const heading = document.createElement('h2');
  heading.textContent = label;
  const status = document.createElement('span');
  status.className = `status ${mode}`.trim();
  status.textContent = String(value);
  const details = document.createElement('div');
  details.className = 'muted';
  details.style.marginTop = '12px';
  details.textContent = note || '';
  el.append(heading, status, details);
  return el;
}

function renderPayload(section, payload) {
  cards.replaceChildren();
  const normalized = payload || {};
  const status = normalized.status || 'ok';
  const required = Array.isArray(normalized.requiredEnv) ? normalized.requiredEnv : [];

  cards.appendChild(card('Section', section, 'Current admin section.', 'ok'));
  cards.appendChild(card('Status', status, normalized.message || 'Ready.', status === 'not_configured' ? 'warn' : 'ok'));
  cards.appendChild(card('Freshness', normalized.freshness || 'none', 'Freshness appears after rollup jobs are connected.'));

  if (required.length > 0) {
    cards.appendChild(card('Required Environment', `${required.length} item(s)`, required.join(', '), 'warn'));
  }

  debugLog.hidden = false;
  debugLog.textContent = JSON.stringify(normalized, null, 2);
}

async function apiGet(path) {
  const res = await fetch(path, { headers: headers(), credentials: 'same-origin' });
  const text = await res.text();
  const payload = text ? JSON.parse(text) : {};
  if (!res.ok && res.status !== 503) {
    const message = payload?.error?.message || payload?.error || `HTTP ${res.status}`;
    throw new Error(typeof message === 'string' ? message : JSON.stringify(message));
  }
  return payload;
}

async function apiPost(path, body = {}) {
  const res = await fetch(path, {
    method: 'POST',
    headers: headers(),
    credentials: 'same-origin',
    body: JSON.stringify(body),
  });
  const text = await res.text();
  const payload = text ? JSON.parse(text) : {};
  if (!res.ok) {
    const message = payload?.error?.message || payload?.error || `HTTP ${res.status}`;
    throw new Error(typeof message === 'string' ? message : JSON.stringify(message));
  }
  return payload;
}

// Resolve the signed-in user's email from the app auth API so the break-glass
// session is attributed to the real admin instead of the break-glass-admin@local
// fallback. Same /auth/me shape the navbar uses.
async function resolveAdminEmail() {
  try {
    const res = await fetch('https://aitopia.ai/auth/me', { method: 'GET', credentials: 'include' });
    if (!res.ok) return '';
    const resp = await res.json();
    const user = resp?.data?.user || resp?.data || resp?.user || resp;
    return (user && typeof user === 'object' && user.email) ? String(user.email).trim() : '';
  } catch {
    return '';
  }
}

async function loginWithBreakGlassKey() {
  const key = keyInput.value.trim();
  if (!key) throw new Error('Admin key required');
  const email = await resolveAdminEmail();
  const body = email ? { key, email } : { key };
  const payload = await apiPost('https://aitopia.ai/api/admin/auth/break-glass-login', body);
  keyInput.value = '';
  return payload;
}

async function loadMe() {
  const payload = await apiGet('https://aitopia.ai/api/admin/auth/me');
  state.user = payload.user;
  const roles = Array.isArray(payload.user?.roles) ? payload.user.roles.join(', ') : 'none';
  userLine.textContent = `${payload.user?.email || 'Admin'} · ${roles}`;
}

async function loadSection(section = state.section) {
  state.section = section;
  title.textContent = section.slice(0, 1).toUpperCase() + section.slice(1);
  setStatus('loading');
  try {
    await loadMe();
    const payload = await apiGet(sections[section] || sections.overview);
    state.lastPayload = payload;
    renderPayload(section, payload);
    setStatus(payload.status === 'not_configured' ? 'setup required' : 'connected', payload.status === 'not_configured' ? 'warn' : 'ok');
  } catch (err) {
    cards.replaceChildren(card('Connection', 'blocked', err.message, 'err'));
    userLine.textContent = 'Not connected';
    setStatus('blocked', 'err');
    debugLog.hidden = false;
    debugLog.textContent = String(err.stack || err.message || err);
  }
}

document.getElementById('saveKey').addEventListener('click', () => {
  setStatus('connecting');
  loginWithBreakGlassKey()
    .then(() => loadSection())
    .catch((err) => {
      cards.replaceChildren(card('Connection', 'blocked', err.message, 'err'));
      userLine.textContent = 'Not connected';
      setStatus('blocked', 'err');
    });
});

document.getElementById('clearKey').addEventListener('click', () => {
  keyInput.value = '';
  apiPost('https://aitopia.ai/api/admin/auth/logout')
    .catch(() => null)
    .finally(() => loadSection());
});

document.getElementById('refresh').addEventListener('click', () => loadSection());

document.querySelectorAll('.nav button').forEach((button) => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.nav button').forEach((b) => b.removeAttribute('aria-current'));
    button.setAttribute('aria-current', 'page');
    loadSection(button.dataset.section);
  });
});

loadSection();
