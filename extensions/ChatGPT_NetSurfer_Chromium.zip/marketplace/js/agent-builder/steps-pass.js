/**
 * Pass 4 — Steps.
 *
 * Each step is one model call. The author's flow is:
 *
 *   1. Click "+ Add step". The model picker opens *before* a step exists.
 *   2. Pick a model. A new step is created with `model_id` already set.
 *   3. The wizard immediately fetches that model's input schema from
 *      `GET /api/models/schema?modelId=<id>` and pre-fills `step.schema` from
 *      the schema's `required` + `properties`. Required keys are enabled and
 *      locked on; optional keys appear with a disabled checkbox (the author
 *      flips them on when they want to override the model's default).
 *
 * This means the schema shape always matches what the chosen model actually
 * accepts — the wizard never invents fields and never silently drops keys the
 * model requires.
 *
 * `step.__schemaMeta` carries the fetched schema in-memory for the renderer.
 * It is stripped from the persisted JSON in state.js / utils.js so it never
 * leaks into the published agent document.
 */

import { state, notify, invalidatePreviewFrom, cleanAgentForExport, rememberModel } from './state.js';
import { el, $, toast, placeholdersInSchema, resolveSchemaControl, ensureFieldForKey, floorCredits } from './utils.js';
import { REFERENCE_MODE_KEY, isHiddenByReferenceMode as refModeHides, referenceModeClassOf } from '../shared/reference-mode.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';
import { createMediaField } from '/marketplace/js/components/form/media-upload.js';
// Run-prep modal renders the same field components the published agent runner
// uses, so the author sees the exact widget end-users will see (visual-picker,
// interactive-prompt, color-picker, …) instead of a generic text fallback.
import { createTextInputField } from '/marketplace/js/components/form/text-input.js';
import { createTextAreaField } from '/marketplace/js/components/form/textarea.js';
import { createNumberField } from '/marketplace/js/components/form/number-input.js';
import { createSliderField } from '/marketplace/js/components/form/slider.js';
import { createSelectField } from '/marketplace/js/components/form/select.js';
import { createCheckboxField } from '/marketplace/js/components/form/checkbox.js';
import { createChipGroup } from '/marketplace/js/components/form/chip-group.js';
import { createMultiSelect } from '/marketplace/js/components/form/multi-select.js';
import { createEditableSelect } from '/marketplace/js/components/form/editable-select.js';
import { createColorPickerField } from '/marketplace/js/components/form/color-picker.js';
import { createVisualPickerField } from '/marketplace/js/components/form/visual-picker.js';
import { createInteractivePrompt } from '/marketplace/js/components/form/interactive-prompt.js';
import { createImagePairField } from '/marketplace/js/components/form/image-pair.js';
// Same media classifier the published agent runner uses (image / video / audio
// from URL extension or data: prefix). Reusing it keeps builder output panels
// visually identical to /agents/<slug>.
import { collectMediaUrls } from '/marketplace/js/runner/collect-media-urls.js';
// Markdown renderer for content-research text output, so the preview panel
// shows rendered headings/bold/lists like the published runner does.
import { renderMarkdownInto } from '/marketplace/js/shared/markdown.js';

// Schema keys the wizard owns at runtime — author should not be offered them
// in the optional-enable row, and they don't surface in the required block.
//   - prompt        → soul owns it (single-slot models)
//   - system_prompt → runtime maps soul to it automatically (dual-slot models)
//   - referenceMode → r2v routing flag, rendered as a dedicated toggle (see
//                     renderReferenceModeToggle); never a normal input field
const RESERVED_SCHEMA_KEYS = new Set(['prompt', 'system_prompt', REFERENCE_MODE_KEY]);

function openModal(id) {
  document.getElementById(id)?.classList.add('visible');
  document.getElementById(id)?.setAttribute('aria-hidden', 'false');
}
function closeModal(id) {
  document.getElementById(id)?.classList.remove('visible');
  document.getElementById(id)?.setAttribute('aria-hidden', 'true');
}

// ---------------------------------------------------------------------------
// Step kinds (dynamic — driven entirely by /config `stepKinds`)
// ---------------------------------------------------------------------------
//
// Nothing about a kind is hardcoded here: the kind picker, each editor, and
// pricing all read from the catalog the server ships. Adding a new kind on the
// server makes it appear in the builder with no change to this file beyond an
// editor renderer (and even unknown kinds degrade gracefully).

/** All step kinds from config; falls back to a single model kind if absent. */
function stepKinds() {
  const list = state.config?.stepKinds;
  if (Array.isArray(list) && list.length) return list;
  return [{ kind: 'model', label: 'Model step', editor: 'model', picksModel: true }];
}

/** Look up a single kind spec by id. */
function stepKindSpec(kind) {
  return stepKinds().find(k => k.kind === (kind || 'model')) || null;
}

/** A step's effective kind — legacy steps have no `kind` and are model steps. */
function stepKindOf(step) {
  return step?.kind && step.kind !== 'model' ? step.kind : 'model';
}

/**
 * Open the "what kind of step?" picker, built from the kind catalog. Picking a
 * model-kind defers to the existing model picker; any other kind creates a step
 * of that kind directly. Built as a throwaway DOM modal so new kinds need no
 * HTML.
 */
function openStepKindPicker() {
  const kinds = stepKinds();
  // Only one kind available → skip the chooser, go straight to its creation.
  if (kinds.length <= 1) {
    startAddStep(kinds[0]?.kind || 'model');
    return;
  }

  document.getElementById('ab-modal-stepkind')?.remove();
  const back = el('div', {
    class: 'ab-modal-back visible',
    id: 'ab-modal-stepkind',
    'aria-hidden': 'false',
    onclick: (e) => { if (e.target === back) back.remove(); },
  });
  // Mirror the field-type chooser's markup (.ab-catalog-pick / pick-title /
  // pick-desc) so this reads as part of the builder, not a bolted-on dialog.
  const modal = el('div', { class: 'ab-modal', style: 'max-width: 520px;' });
  modal.appendChild(el('div', { class: 'flex items-center justify-between mb-3' },
    el('h3', { class: 'text-lg font-bold' }, 'Add a step'),
    el('button', { class: 'btn', type: 'button', onclick: () => back.remove() }, '×'),
  ));
  modal.appendChild(el('p', { class: 'text-sm text-muted-foreground mb-4' },
    'Pick what this step does — the editor changes accordingly.'));
  const grid = el('div', { class: 'grid grid-cols-1 gap-3' });
  for (const spec of kinds) {
    const card = el('div', {
      class: 'ab-catalog-pick',
      role: 'button',
      tabindex: '0',
      onclick: () => { back.remove(); startAddStep(spec.kind); },
      onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); back.remove(); startAddStep(spec.kind); } },
    },
      el('div', { class: 'pick-title' }, spec.label || spec.kind),
      spec.description ? el('div', { class: 'pick-desc' }, spec.description) : null,
    );
    grid.appendChild(card);
  }
  modal.appendChild(grid);
  back.appendChild(modal);
  document.body.appendChild(back);
}

/** Begin creating a step of the given kind. */
function startAddStep(kind) {
  const spec = stepKindSpec(kind);
  // A model-picking kind opens the model picker; the step is created on pick.
  if (!spec || spec.picksModel || spec.editor === 'model') {
    modelPickerMode = { kind: 'new' };
    openModelPicker();
    return;
  }
  if (kind === 'content-research') {
    createContentResearchStep(spec);
    return;
  }
  // Unknown non-model kind — create a minimal step carrying the kind so it at
  // least persists; its editor can be added later without data loss.
  state.agent.steps.push({
    kind,
    soul: '',
    output_id: 'output_' + (state.agent.steps.length + 1),
    step: false,
    __expanded: true,
  });
  notify();
}

/** Create a content-research step seeded from its catalog spec. */
function createContentResearchStep(spec) {
  const defaultModel = Array.isArray(spec?.models) && spec.models.length ? spec.models[0].id : 'opus-4-8';
  state.agent.steps.push({
    kind: 'content-research',
    soul: '',
    model: defaultModel,
    tools: [],
    outputFormat: 'text',
    outputSchema: {},
    output_id: 'output_' + (state.agent.steps.length + 1),
    step: false,
    __expanded: true,
  });
  notify();
}

/**
 * Mode of the picker:
 *   - { kind: 'new' }                          → picking the model creates a new step
 *   - { kind: 'change', stepIndex: n }         → picking the model swaps an existing step's model
 */
let modelPickerMode = null;

/* ---------------- Schema fetch + apply ---------------- */

const _schemaCache = new Map(); // modelId → schema response

// Steps whose model schema has been re-merged this page load. A WeakSet keyed
// on the step object so it resets on refresh (the boot loop re-runs once per
// load) and never holds a step alive past a delete/replace. See the boot loop
// in renderStepsPass for why a stored `__schemaMeta` alone isn't trusted.
const _rehydratedSchemaSteps = new WeakSet();

async function fetchModelSchema(modelId) {
  if (_schemaCache.has(modelId)) return _schemaCache.get(modelId);
  // /api/agent-builder/model-schema returns a UNION of every endpoint the
  // model can route to (native provider + every FAL endpoint alias).
  // /api/models/schema only returns one endpoint at a time, which made the
  // builder miss fields like Source Image / End Frame on multi-endpoint
  // models (seedance, kling, veo, …) where production runs hit i2v or r2v
  // depending on input shape.
  const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/model-schema?modelId=${encodeURIComponent(modelId)}`);
  if (!res.ok) {
    let detail = '';
    try { detail = (await res.json())?.message || ''; } catch {}
    throw new Error(`Schema fetch failed (${res.status}) ${detail}`.trim());
  }
  const json = await res.json();
  // The schema response carries per-model pricing/output metadata in `x-model`
  // (cost, tags, tier, capabilities, creditsEstimated). Cache it so the per-step
  // floor + output-type lookups resolve — this is what hydrates a loaded agent's
  // models on edit/refresh without a separate /api/models/all call.
  if (json && json['x-model'] && typeof json['x-model'] === 'object' && json['x-model'].provider) {
    rememberModel({ id: modelId, ...json['x-model'] });
  }
  _schemaCache.set(modelId, json);
  return json;
}

/**
 * Compute a sensible literal "starter" value for an optional key. We never put
 * a `${placeholder}` here — the author wires those in explicitly via the tag
 * rows. For required keys we leave the value as an empty string so the author
 * is forced to choose a source (form field, upstream output, or literal).
 */
function starterValueFor(prop) {
  if (!prop || typeof prop !== 'object') return '';
  // Provider default wins, even if it's a falsy value (false, 0, "").
  if (Object.prototype.hasOwnProperty.call(prop, 'default')) return prop.default;
  switch (prop.type) {
    case 'integer':
    case 'number':
      if (typeof prop.minimum === 'number') return prop.minimum;
      return 0;
    case 'boolean':
      return false;
    case 'array':
      return [];
    case 'object':
      return {};
    default:
      return '';
  }
}

/**
 * Apply a fetched schema to a step. Required keys go in straight away; optional
 * keys are tracked in `step.__optionalAvailable` so the renderer can offer them
 * as checkboxes without polluting the persisted JSON. Existing values on the
 * step are preserved when their key still exists in the new schema (e.g. when
 * the author swaps to a sibling model with overlapping inputs).

 * **Prompt is highlighted, not forced.** Some models genuinely don't take a
 * prompt — background removers, upscalers, format converters. For those the
 * step's schema simply has no `prompt` key, and the wizard does not invent
 * one. But *when* the model's schema does declare a `prompt`, the wizard
 * treats it as the most important field: it's hoisted to the top of the
 * editor, given a primary-tinted card, and visually distinguished from the
 * other knobs. Authors wire form-field placeholders into the prompt, so when
 * it's there it's the spine of the step.
 */
/**
 * Apply a fetched schema to a step.
 *
 * Behaviour (auto-wire required keys):
 *   - For every required key whose previous value is empty/missing AND not
 *     already a `${placeholder}`: synthesize a form field for it and rewrite
 *     `step.schema[key] = '${' + fieldId + '}'`. Catalog match drives the
 *     concept id + ui_component; otherwise a custom textarea field is created
 *     under the schema key's own name.
 *   - Previous wirings (`${field_id}` placeholders, hand-typed literals, or
 *     upstream output references) survive intact — model change inside a step
 *     should not blow away the author's explicit choices.
 *   - `prompt` is reserved; soul owns it.
 *
 * Optional keys remain in `__optionalAvailable` until the author enables one.
 * The "+ Enable optional" handler runs the same field bridge.
 *
 * Returns `{ addedFieldIds }` so the caller can decide whether to nudge the
 * author toward Pass 4 (Fields).
 */
function applySchemaToStep(step, schema) {
  const props = (schema && schema.properties) || {};
  const required = Array.isArray(schema?.required) ? schema.required : [];
  const requiredSet = new Set(required);

  const previousSchema = step.schema && typeof step.schema === 'object' ? step.schema : {};
  const nextSchema = {};
  const addedFieldIds = [];

  const isAlreadyWired = (val) => {
    if (typeof val !== 'string') return val != null && val !== '';
    if (val === '') return false;
    // ${...} placeholder OR a hand-typed literal — both count as "author owns this".
    return true;
  };

  for (const key of required) {
    if (RESERVED_SCHEMA_KEYS.has(key)) {
      // `prompt` and `system_prompt` are runtime-owned. The runtime sees the
      // model declares them (via the fetched model schema) and writes soul
      // (and, if the author enabled an optional `prompt`, soul + user prompt)
      // into the right slot at call time. The builder does NOT pre-seed the
      // key in step.schema — that would be a stale literal the runtime has
      // to special-case. No form field is created either.
      continue;
    }
    const prev = previousSchema[key];
    if (isAlreadyWired(prev)) {
      nextSchema[key] = prev;
      continue;
    }
    // Empty / missing → auto-create field and wire placeholder.
    const fieldId = ensureFieldForRequiredKey(key, props[key]);
    nextSchema[key] = '${' + fieldId + '}';
    if (!addedFieldIds.includes(fieldId)) addedFieldIds.push(fieldId);
  }

  // Optional keys: untouched here. They stay in __optionalAvailable until the
  // author explicitly enables one via the "+ enable" row.
  //
  // `prompt` is reserved — soul owns it.
  // `system_prompt` is also reserved — the runtime maps soul → system_prompt
  // automatically when the model declares one; surfacing it as an enable-able
  // optional would let the author wire a second source of truth.
  const optionalAvailable = [];
  for (const key of Object.keys(props)) {
    if (requiredSet.has(key)) continue;
    if (RESERVED_SCHEMA_KEYS.has(key)) continue;
    if (Object.prototype.hasOwnProperty.call(previousSchema, key)) {
      nextSchema[key] = previousSchema[key];
    } else {
      optionalAvailable.push(key);
    }
  }

  // Carry the r2v flag across a re-apply (it's reserved, so the loops skip it),
  // but only if the new model still supports reference mode.
  if (schema?.supportsReference === true && previousSchema[REFERENCE_MODE_KEY] === true) {
    nextSchema[REFERENCE_MODE_KEY] = true;
  }

  step.schema = nextSchema;
  step.__schemaMeta = { properties: props, required };
  step.__supportsReference = schema?.supportsReference === true;
  step.__optionalAvailable = optionalAvailable;
  // Drop keys from the inactive mode (cleans up agents saved before this guard).
  if (step.__supportsReference) pruneReferenceModeKeys(step, isReferenceModeOn(step));
  // Persist the model's required key list onto the step itself (not __-prefixed
  // so cleanAgentForExport keeps it). Runtime uses this to decide which fields
  // are truly required — soul references and optional-key wires don't qualify.
  //
  // INVARIANT: only keep a key in requiredKeys if it actually has a counterpart
  // in this step's schema. A requiredKey with no schema entry forces nothing —
  // it's noise at best, and for `prompt` (supplied by soul, never a schema key,
  // dropped by RESERVED_SCHEMA_KEYS above) it gets treated downstream as a
  // placeholder that must resolve to a field/output, producing
  // "Placeholder ${prompt} does not match any field or upstream output_id" and
  // breaking the run. So: keep keys present in schema, drop the rest.
  step.requiredKeys = [...required].filter((k) => Object.prototype.hasOwnProperty.call(nextSchema, k));

  return { addedFieldIds };
}

/**
 * Largest duration (seconds) a model declares via its `durations:<csv>` tag,
 * or null when the model has no such tag. Callers decide how to use it (a
 * per-second cost multiplier, a progress-bar pre-estimate, …).
 */
function maxModelDurationSeconds(tags) {
  if (!Array.isArray(tags)) return null;
  const durTag = tags.find(t => /^durations:/.test(String(t)));
  if (!durTag) return null;
  const nums = String(durTag).replace(/^durations:/, '').split(',').map(Number).filter(Number.isFinite);
  return nums.length ? Math.max(...nums) : null;
}

/**
 * Build a synthesized custom field from the resolver's view of a schema key.
 * Both auto-add paths (required-key seeding and key→custom promotion) create
 * the same shape: title humanised from the key, ui_component/enum/range from
 * the resolved control, default lifted from the property when present.
 * `expanded` adds the `__expanded` flag the promotion path opens the row with.
 */
function buildCustomField(id, key, prop, resolved, { expanded = false, required = false } = {}) {
  const field = {
    __custom: true,
    __autoAdded: true,
    ...(expanded ? { __expanded: true } : {}),
    id,
    title: (prop && prop.title) || key.replace(/[_-]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
    description: (prop && prop.description) || '',
    type: (prop && prop.type) || 'string',
    ui_component: resolved.uiComponent,
    default: prop && Object.prototype.hasOwnProperty.call(prop, 'default') ? prop.default : null,
    visible: true,
    advanced: false,
    required,
    step: false,
  };
  if (Array.isArray(resolved.enum) && resolved.enum.length) field.enum = [...resolved.enum];
  if (prop && (prop.minimum != null || prop.maximum != null)) {
    field.range = { min: prop.minimum ?? null, max: prop.maximum ?? null };
  }
  return field;
}

/**
 * Ensure a form field exists for a required schema key, returning the field id
 * the step should wire its placeholder to.
 *
 *   - Catalog match (via `resolveSchemaControl`)  → push `{ id: conceptId, __autoAdded:true }`
 *     (compact catalog entry — defaults flow through from AGENT_INPUT_MAP).
 *   - No catalog match                             → push a custom field whose id is the
 *                                                    schema key itself, seeded from the
 *                                                    property's ui-component / enum / range.
 *
 * Idempotent: if a field with that id already exists, returns it untouched.
 */
function ensureFieldForRequiredKey(key, prop) {
  const resolved = resolveSchemaControl(key, prop);
  const fieldId = resolved.conceptId || key;
  const existing = state.agent.fields.find(f => f.id === fieldId);
  if (existing) return fieldId;

  if (resolved.conceptId) {
    // Step-driven auto-add: the author wired this key into a step (required or
    // optional-enable), so the field needs to show up in the end-user form.
    // We pin `visible: true` explicitly even when the catalog concept defaults
    // to `visible: false` (e.g. `images` is hidden in the taxonomy because most
    // agents don't expose multi-image input). The catalog's default is meant
    // for forms that pick the field manually without a step demanding it; a
    // step wire is a stronger signal of intent. required: true — the step reads
    // it via `${id}`, so an empty value would be an unresolved placeholder.
    state.agent.fields.push({ id: resolved.conceptId, visible: true, required: true, __autoAdded: true });
    return resolved.conceptId;
  }

  // Custom field — author has to refine, but at least the shape is plausible.
  state.agent.fields.push(buildCustomField(key, key, prop, resolved, { required: true }));
  return key;
}

/**
 * Garbage-collect `__autoAdded` fields that no step references anymore.
 *
 * Called whenever a step is removed, a model is swapped, or a schema entry is
 * unbound. Manual fields (`__autoAdded` falsy/absent) are never touched, even
 * if they become orphaned — the author put them there on purpose.
 */
export function pruneOrphanAutoAddedFields() {
  const referenced = new Set();
  const placeholderRe = /\$\{([a-zA-Z0-9_-]+)\}/g;
  for (const step of state.agent.steps) {
    const scan = (v) => {
      if (typeof v === 'string') {
        let m;
        placeholderRe.lastIndex = 0;
        while ((m = placeholderRe.exec(v)) !== null) referenced.add(m[1]);
      } else if (Array.isArray(v)) {
        for (const item of v) scan(item);
      } else if (v && typeof v === 'object') {
        for (const item of Object.values(v)) scan(item);
      }
    };
    if (typeof step.soul === 'string') scan(step.soul);
    if (step.schema) scan(step.schema);
  }
  const before = state.agent.fields.length;
  state.agent.fields = state.agent.fields.filter(f => {
    if (!f.__autoAdded) return true; // manual field — keep regardless.
    return referenced.has(f.id);
  });
  return before - state.agent.fields.length;
}

/**
 * Fetch the model's schema and apply it to the step. Returns the canonical
 * field ids that were added to `state.agent.fields` as a side-effect of the
 * auto-field detour (empty array on the happy path where everything was
 * already wired). Callers decide whether to navigate the wizard to Pass 3
 * based on this return value.
 */
async function loadAndApplySchema(step) {
  if (!step.model_id) return [];
  step.__schemaLoading = true;
  notify();
  let addedFieldIds = [];
  try {
    const schema = await fetchModelSchema(step.model_id);
    const result = applySchemaToStep(step, schema);
    addedFieldIds = result?.addedFieldIds || [];
  } catch (err) {
    toast('Could not load model schema: ' + err.message, 'error', 5000);
  } finally {
    step.__schemaLoading = false;
    notify();
  }
  return addedFieldIds;
}

/* ---------------- Step play (builder runtime) ---------------- */
//
// The author can hit ▶ Run on any step to execute that step in isolation
// against live models. We walk the pipeline from step 0 up to the target,
// using `state.previewOutputs` as a cache: any upstream step whose output
// has been cached is skipped, anything missing is run via POST /preview-step
// before the target. The target itself always re-runs (Play means "give me
// a fresh output for this step").
//
// Cache key per step is its index in `state.agent.steps`. Cache invalidation
// happens whenever a step's model_id, soul, schema, or output_id changes —
// stale outputs would silently feed the wrong values into downstream runs.

/**
 * Render a credits chip — the lightning-bolt SVG from the navbar's
 * `creditsDisplay` plus the supplied number. Returns a DOM node so the caller
 * can drop it inside a button label or an output header. Matches the visual
 * language of the rest of the marketplace (countdown banner, store credit
 * badges) so the author reads "credits" intuitively without a textual unit.
 *
 * Color: the amber tone the marketplace uses for credit-shaped accents
 * (`--cd-badge-color` / `--cd-title` in public/store/shared.css → `#FCD34D`).
 * Hard-coded here because this module is loaded outside the store CSS scope.
 */
const CREDITS_ACCENT = '#FCD34D';

function creditsChip(amount, opts = {}) {
  const wrap = document.createElement('span');
  wrap.style.cssText = `display: inline-flex; align-items: center; gap: 0.2rem; vertical-align: middle; color: ${CREDITS_ACCENT}; font-weight: 700;`;
  if (opts.dim) wrap.style.opacity = '0.75';
  wrap.innerHTML =
    '<svg style="width:0.95em;height:0.95em;flex-shrink:0;" fill="currentColor" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">' +
    '<path d="M4.48963 7.68204H5.79855V11.5184C5.79855 12.0831 6.3577 12.3496 6.65422 11.9233L9.86088 7.34104C10.1405 6.94142 9.91595 6.31802 9.49235 6.31802H8.18342V2.48171C8.18342 1.91692 7.62426 1.65051 7.32774 2.07676L4.1211 6.65903C3.84576 7.05864 4.07026 7.68204 4.48963 7.68204Z"/>' +
    '</svg>';
  const num = document.createElement('span');
  num.textContent = String(amount);
  wrap.appendChild(num);
  return wrap;
}

/**
 * Estimate the credits a single step's Play will charge. Mirrors the
 * server-side `modelMaxCostUsd` logic so the button label matches what the
 * server will actually reserve.
 *
 * Returns 0 when the model isn't picked, has no cost data, or billing is off.
 */
function estimateStepCredits(step) {
  if (!step) return 0;

  // Non-model step kinds are priced by their kind catalog entry, not the model
  // registry. content-research: baseCredits + each enabled tool's creditCost.
  if (step.kind && step.kind !== 'model') {
    const spec = stepKindSpec(step.kind);
    if (!spec) return 0;
    let credits = Number(spec.baseCredits) || 0;
    const enabled = Array.isArray(step.tools) ? step.tools : [];
    for (const toolId of enabled) {
      const tool = (spec.tools || []).find(t => t.id === toolId);
      if (tool) credits += Number(tool.creditCost) || 0;
    }
    return credits;
  }

  if (!step.model_id) return 0;
  const usdPerCredit = Number(state.config.billing?.usdPerCredit || 0.02);
  if (!Number.isFinite(usdPerCredit) || usdPerCredit <= 0) return 0;

  const model = state.config.models.find(m => m.id === step.model_id);
  const cost = model?.cost;

  let usd = 0;
  if (cost) {
    if (typeof cost.perOutput === 'number' && cost.perOutput > 0) {
      usd = cost.perOutput;
    } else if (typeof cost.perSecond === 'number' && cost.perSecond > 0) {
      const seconds = maxModelDurationSeconds(model.tags) ?? 10;
      usd = cost.perSecond * seconds;
    } else if (typeof cost.perMillionOutput === 'number' && cost.perMillionOutput > 0) {
      usd = (cost.perMillionOutput * 2000) / 1_000_000;
    }
  }

  // Floor at 1 credit. Token-based models (GPT) land at <0.01 usd and round
  // to 0. Models without registry cost data still need a non-zero label —
  // the author shouldn't see a blank button just because pricing is missing.
  return Math.max(1, Math.ceil(usd / usdPerCredit));
}

/**
 * Stable hash for a single step's authoring shape. Used as the cache key so
 * an edit to soul/schema/model_id automatically invalidates the cached run
 * without us having to wire every input listener to a manual flush.
 *
 * Exported because preview-pass.js compares cached run hashes against the
 * current draft to decide whether per-step runs unlock Publish — it MUST use
 * this exact shape, or content-research steps (which have no model_id and
 * carry kind/tools/outputSchema) never match and Publish stays locked.
 */
export function stepDocHash(step) {
  if (!step || typeof step !== 'object') return '';
  return JSON.stringify({
    kind: step.kind || 'model',
    model: step.model_id || step.model || null,
    output: step.output_id || null,
    soul: step.soul || '',
    schema: step.schema || null,
    // content-research authoring shape — editing tools/outputSchema must
    // invalidate the cached run.
    tools: Array.isArray(step.tools) ? step.tools : null,
    outputSchema: step.outputSchema || null,
  });
}

/* ----------------------------------------------------------------------
 * Run-prep modal — collect missing field values before kicking off Run.
 *
 * The per-step Play used to send `state.testInputs` verbatim; when the author
 * hadn't filled anything in, required-by-step fields resolved to `null` and
 * the provider 422'd. We now scan the pipeline up to the target step, figure
 * out which form fields are *actually* read (either via `${id}` in a step's
 * soul/schema OR as a required key on a step whose cache is empty), check
 * which of those don't already have a value in `state.testInputs`, and pop a
 * small modal so the author can fill them in. The modal writes back to
 * `state.testInputs` and then calls `runStepBuilder` with the original index.
 * -------------------------------------------------------------------- */

// Soul + schema scan: every `${id}` that resolves to a real field id in the
// agent's `fields[]`. Returns the set of field ids the runner will read for
// the steps in [0..stepIndex].
function collectFieldIdsUsedUpTo(stepIndex) {
  const steps = state.agent.steps;
  const fieldIds = new Set(state.agent.fields.map(f => f.id));
  const out = new Set();
  const re = /\$\{([a-zA-Z0-9_-]+)\}/g;
  const scan = (text) => {
    if (typeof text !== 'string') return;
    let m;
    while ((m = re.exec(text)) !== null) {
      if (fieldIds.has(m[1])) out.add(m[1]);
    }
  };
  for (let i = 0; i <= stepIndex; i++) {
    const s = steps[i];
    if (!s) continue;
    scan(s.soul);
    if (s.schema && typeof s.schema === 'object') {
      const walk = (v) => {
        if (typeof v === 'string') { scan(v); return; }
        if (Array.isArray(v)) { for (const x of v) walk(x); return; }
        if (v && typeof v === 'object') { for (const x of Object.values(v)) walk(x); }
      };
      walk(s.schema);
    }
  }
  return out;
}

// Resolve a field's effective shape — merge catalog defaults under any
// per-agent overrides. Mirrors fields-pass.js#effectiveField without the
// import cycle (steps-pass already exports helpers fields-pass consumes).
function effectiveFieldForRun(field) {
  if (!field) return null;
  if (field.__custom) return { ...field };
  const concept = state.config.catalog.find(c => c.id === field.id) || null;
  if (!concept) return { ...field };
  return { ...concept, ...field };
}

// Build the list of (field, effective) the Run-prep modal needs. A field is
// included when it's used by a step in [0..stepIndex] AND `state.testInputs`
// has no usable value for it. Defaults DO NOT count as "already filled" — the
// author asked to make a choice every time in the builder's preview flow, so
// even a field with a default pops up in the modal (pre-selected to that
// default so the common case is a single Confirm click).
// True when a field gates the run — required AND no usable value yet. Optional
// fields are shown in the modal so the author CAN fill them, but they never
// block Run.
function isFieldRequired(f, eff) {
  return (f && f.required === true) || (eff && eff.required === true);
}
function fieldHasValue(fieldId) {
  const current = state.testInputs?.[fieldId];
  return current != null && current !== '' && !(Array.isArray(current) && current.length === 0);
}

function buildRunPrepRequirements(stepIndex) {
  const used = collectFieldIdsUsedUpTo(stepIndex);
  const out = [];
  for (const f of state.agent.fields) {
    if (!used.has(f.id)) continue;
    const eff = effectiveFieldForRun(f);
    if (fieldHasValue(f.id)) continue;
    // Every used-and-empty field is shown so the author can fill it; the
    // `required` flag drives whether it BLOCKS the run (see hasBlockingRunPrep).
    out.push({ field: f, eff, required: isFieldRequired(f, eff) });
  }
  return out;
}

// Whether any REQUIRED field is still empty — the only thing that should
// prevent a run. Optional empties are fine.
function hasBlockingRunPrep(stepIndex) {
  return buildRunPrepRequirements(stepIndex).some(r => r.required);
}

// Map a ui_component to the createMediaField `kind` argument when the field
// is media-shaped. Returns null when the field is not a media uploader.
function mediaKindForField(eff) {
  if (!eff || eff.ui_component !== 'file-upload') return null;
  const hint = String(eff.type || eff.id || '').toLowerCase();
  if (hint.includes('video') && hint.includes('image')) return 'imageOrVideo';
  if (hint.includes('video')) return 'video';
  if (hint.includes('audio')) return 'audio';
  return 'image';
}

// Build the `options` array shape every enum-driven component expects
// ({ value, label }). Honours eff.enumLabels positionally; falls back to the
// raw enum value when no label is supplied.
function buildEnumOptions(eff) {
  const enums = Array.isArray(eff.enum) ? eff.enum : [];
  const labels = Array.isArray(eff.enumLabels) ? eff.enumLabels : null;
  return enums.map((v, i) => ({ value: String(v), label: labels?.[i] || String(v) }));
}

// Render one control for a single field inside the Run-prep modal. Returns
// an object with `node` (DOM) and `getValue()` (async, returns the value to
// write into state.testInputs). The component picked here mirrors what the
// published runner uses for the same `ui_component`, so the author sees the
// exact widget end-users will see — no select-instead-of-visual-picker
// downgrades, no number-instead-of-slider fallbacks.
function renderRunPrepFieldControl({ field, eff, required }) {
  const wrap = el('div', { class: 'field' });
  const labelText = eff.title || field.id;
  const help = eff.description || '';
  const ui = eff.ui_component || 'input';
  // Only required fields get the `*` marker; optional ones are fillable but
  // not flagged. Defaults to false so optional is the safe assumption.
  const req = required === true;

  // file-upload → createMediaField (handles drag-drop, paste, URL, upload).
  const mediaKind = mediaKindForField(eff);
  if (mediaKind) {
    const media = createMediaField({
      label: labelText,
      id: field.id,
      required: req,
      kind: mediaKind,
      help: help || undefined,
    });
    wrap.appendChild(media.wrap);
    return {
      node: wrap,
      getValue: async () => {
        const v = await media.getValue();
        return typeof v === 'string' ? v.trim() : v;
      },
    };
  }

  // image-pair → two stacked media uploaders (start + end frame). Emits a
  // 2-element URL array, matching what the runner submits.
  if (ui === 'image-pair') {
    const pair = createImagePairField({
      label: labelText, id: field.id, required: req, help: help || undefined,
    });
    wrap.appendChild(pair.wrap);
    return { node: wrap, getValue: async () => await pair.getValue() };
  }

  // toggle → checkbox component (label + help wired in by the factory).
  if (ui === 'toggle') {
    const cb = createCheckboxField({
      label: labelText, id: field.id, help: help || undefined,
      defaultChecked: eff.default === true,
    });
    wrap.appendChild(cb.wrap);
    return { node: wrap, getValue: async () => !!cb.getValue() };
  }

  // visual-picker → trigger card + modal grid (same widget as the runner).
  if (ui === 'visual-picker') {
    const optionImages = (eff.optionImages && typeof eff.optionImages === 'object') ? eff.optionImages : {};
    const optionLabels = (eff.optionLabels && typeof eff.optionLabels === 'object') ? eff.optionLabels : {};
    const optionCategories = (eff.optionCategories && typeof eff.optionCategories === 'object') ? eff.optionCategories : {};
    const options = (Array.isArray(eff.enum) ? eff.enum : []).map((raw, i) => {
      const value = String(raw);
      const labels = Array.isArray(eff.enumLabels) ? eff.enumLabels : null;
      const labelOut = optionLabels[value] != null
        ? String(optionLabels[value])
        : (labels?.[i] || value.replace(/[_-]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()));
      return {
        value,
        label: labelOut,
        image: typeof optionImages[value] === 'string' ? optionImages[value] : '',
        category: typeof optionCategories[value] === 'string' ? optionCategories[value] : '',
      };
    });
    const picker = createVisualPickerField({
      label: labelText, id: field.id, required: req, help: help || undefined,
      options,
      defaultValue: eff.default != null ? String(eff.default) : undefined,
      triggerLabel: eff.triggerLabel || `Choose ${labelText}`,
    });
    wrap.appendChild(picker.wrap);
    return { node: wrap, getValue: async () => picker.getValue() };
  }

  // interactive-prompt → template with inline pill slots. The agent-builder
  // field shape is { template, slotFields: [{ name, enum, enumLabels?, default? }],
  // assembledTarget }. The component expects `slots = { [name]: { options, defaultValue } }`
  // and returns the assembled string via getValue() — which is what the runner
  // submits to the `assembledTarget` key (defaults to the field id).
  //
  // If the field is mis-configured (no template or no slots), we still need to
  // give the author a way to fill in the value, so we fall back to a textarea
  // pre-loaded with whatever template scaffold exists. Without the fallback,
  // the renderer would draw a contenteditable card with no pills and no plain
  // text — which is what the author was seeing.
  if (ui === 'interactive-prompt') {
    const slots = {};
    const slotFields = Array.isArray(eff.slotFields) ? eff.slotFields : [];
    for (const s of slotFields) {
      const name = s && typeof s.name === 'string' ? s.name.trim() : '';
      if (!name) continue;
      const opts = (Array.isArray(s.enum) ? s.enum : []).map((v, i) => ({
        value: String(v),
        label: Array.isArray(s.enumLabels) && s.enumLabels[i] ? String(s.enumLabels[i]) : String(v),
      }));
      slots[name] = {
        options: opts,
        defaultValue: s.default != null ? String(s.default) : undefined,
      };
    }

    const template = typeof eff.template === 'string' ? eff.template : '';
    const hasSlotRef = /\{\w+\}/.test(template);
    const hasUsableSlots = Object.keys(slots).some(name => slots[name].options.length > 0);

    if (template && hasSlotRef && hasUsableSlots) {
      const widget = createInteractivePrompt({
        label: labelText, id: field.id, required: req, help: help || undefined,
        template, slots,
      });
      wrap.appendChild(widget.wrap);
      return { node: wrap, getValue: async () => widget.getValue() };
    }

    // Mis-configured field — surface what's wrong and fall back to a textarea
    // pre-filled with the template scaffold so the author can still type a
    // value and run the step.
    const ta = createTextAreaField({
      label: labelText, id: field.id, required: req,
      help: help
        ? `${help} (interactive-prompt is mis-configured — falling back to plain text)`
        : 'Interactive prompt has no usable template/slots — type the prompt manually for this run.',
      defaultValue: template || '',
    });
    wrap.appendChild(ta.wrap);
    return { node: wrap, getValue: async () => ta.getValue() };
  }

  // color-picker → inline hex input + swatch + SV canvas.
  if (ui === 'color-picker') {
    const picker = createColorPickerField({
      label: labelText, id: field.id, required: req, help: help || undefined,
      defaultValue: eff.default != null ? String(eff.default) : '#FFFFFF',
    });
    wrap.appendChild(picker.wrap);
    return { node: wrap, getValue: async () => picker.getValue() };
  }

  // multi-select → dropdown of checkboxes; emits an array of selected values.
  // Component returns a comma-separated string; convert to the array shape the
  // runner submits (matches eff.type === 'array' from the field seed).
  if (ui === 'multi-select') {
    const ms = createMultiSelect({
      label: labelText, id: field.id, required: req, help: help || undefined,
      options: buildEnumOptions(eff),
      defaultValue: Array.isArray(eff.default) ? eff.default.join(',') : (eff.default != null ? String(eff.default) : undefined),
    });
    wrap.appendChild(ms.wrap);
    return {
      node: wrap,
      getValue: async () => {
        const raw = ms.getValue();
        if (raw == null || raw === '') return [];
        return String(raw).split(',').map(s => s.trim()).filter(Boolean);
      },
    };
  }

  // editable-select → preset dropdown + inline "type your own".
  if (ui === 'editable-select') {
    const es = createEditableSelect({
      label: labelText, id: field.id, required: req, help: help || undefined,
      options: buildEnumOptions(eff),
      defaultValue: eff.default != null ? String(eff.default) : undefined,
    });
    wrap.appendChild(es.wrap);
    return { node: wrap, getValue: async () => es.getValue() };
  }

  // radio-group → chip group (mutually exclusive pill buttons). The runner
  // renders enums as a select today, but a chip row reads better in the
  // narrow modal column and reuses a real component instead of a downgraded
  // <select>.
  if (ui === 'radio-group') {
    const chips = createChipGroup({
      label: labelText, id: field.id, required: req, help: help || undefined,
      options: buildEnumOptions(eff),
      defaultValue: eff.default != null ? String(eff.default) : undefined,
      layout: 'wrap',
    });
    wrap.appendChild(chips.wrap);
    return { node: wrap, getValue: async () => chips.getValue() };
  }

  // select / prompt-picker → standard select component. (prompt-picker's
  // image grid only makes sense in V2's wide layout; the modal collapses it
  // to a select with the option labels.)
  if (ui === 'select' || ui === 'prompt-picker') {
    const sel = createSelectField({
      label: labelText, id: field.id, required: req, help: help || undefined,
      options: buildEnumOptions(eff),
      defaultValue: eff.default != null ? String(eff.default) : undefined,
    });
    wrap.appendChild(sel.wrap);
    return { node: wrap, getValue: async () => sel.getValue() };
  }

  // slider → real slider component with min/max from eff.range.
  if (ui === 'slider') {
    const min = eff.range?.min ?? 0;
    const max = eff.range?.max ?? 100;
    const slider = createSliderField({
      label: labelText, id: field.id, required: req, help: help || undefined,
      min, max,
      step: eff.type === 'integer' ? 1 : (max <= 1 ? 0.01 : 'any'),
      defaultValue: eff.default,
    });
    wrap.appendChild(slider.wrap);
    return {
      node: wrap,
      getValue: async () => {
        const n = slider.getNumber();
        return Number.isFinite(n) ? n : null;
      },
    };
  }

  // textarea / json-input → textarea component (json-input gets a JSON
  // placeholder hint; value still returned as the raw string the runner
  // submits — parsing happens server-side).
  if (ui === 'textarea' || ui === 'json-input') {
    const ta = createTextAreaField({
      label: labelText, id: field.id, required: req, help: help || undefined,
      placeholder: ui === 'json-input' ? '{ … }' : undefined,
      defaultValue: eff.default != null
        ? (typeof eff.default === 'string' ? eff.default : JSON.stringify(eff.default))
        : undefined,
    });
    wrap.appendChild(ta.wrap);
    return { node: wrap, getValue: async () => ta.getValue() };
  }

  // number → numeric input (no slider — slider has its own branch above).
  if (eff.type === 'number' || eff.type === 'integer' || ui === 'number') {
    const num = createNumberField({
      label: labelText, id: field.id, required: req, help: help || undefined,
      min: eff.range?.min, max: eff.range?.max,
      step: eff.type === 'integer' ? 1 : 'any',
      defaultValue: eff.default,
    });
    wrap.appendChild(num.wrap);
    return {
      node: wrap,
      getValue: async () => {
        const n = num.getNumber();
        return Number.isFinite(n) ? n : null;
      },
    };
  }

  // Default: single-line text input (handles `input` and any unknown ui_component).
  const text = createTextInputField({
    label: labelText, id: field.id, required: req, help: help || undefined,
    defaultValue: eff.default != null ? String(eff.default) : undefined,
  });
  wrap.appendChild(text.wrap);
  return { node: wrap, getValue: async () => text.getValue() };
}

let _runPrepCtx = null; // { stepIndex, fieldControls: Array<{field, getValue}> }

function closeRunPrepModal() {
  document.getElementById('ab-modal-run-prep')?.classList.remove('visible');
  document.getElementById('ab-modal-run-prep')?.setAttribute('aria-hidden', 'true');
  _runPrepCtx = null;
}

function openRunPrepModal(stepIndex, requirements) {
  const root = document.getElementById('ab-run-prep-fields');
  const errBox = document.getElementById('ab-run-prep-error');
  const title = document.getElementById('ab-run-prep-title');
  const sub = document.getElementById('ab-run-prep-sub');
  if (!root) return;

  root.innerHTML = '';
  if (errBox) { errBox.hidden = true; errBox.textContent = ''; }
  if (title) title.textContent = `Fill in the inputs Step ${stepIndex + 1} needs`;
  if (sub) sub.textContent = `These are the form fields this step (and any upstream cached step it needs to run) reads from. Fill them in and the step will run against the live models.`;

  const controls = [];
  for (const req of requirements) {
    const ctrl = renderRunPrepFieldControl(req);
    root.appendChild(ctrl.node);
    controls.push({ field: req.field, getValue: ctrl.getValue, required: req.required === true });
  }
  _runPrepCtx = { stepIndex, controls };

  document.getElementById('ab-modal-run-prep')?.classList.add('visible');
  document.getElementById('ab-modal-run-prep')?.setAttribute('aria-hidden', 'false');
}

async function submitRunPrep() {
  if (!_runPrepCtx) return;
  const errBox = document.getElementById('ab-run-prep-error');
  const submitBtn = document.getElementById('ab-run-prep-submit');
  const setErr = (msg) => {
    if (errBox) { errBox.hidden = false; errBox.textContent = msg; }
  };
  if (errBox) { errBox.hidden = true; errBox.textContent = ''; }
  if (submitBtn) submitBtn.setAttribute('disabled', 'disabled');

  try {
    const collected = {};
    for (const c of _runPrepCtx.controls) {
      let value;
      try {
        value = await c.getValue();
      } catch (err) {
        setErr(`"${c.field.id}": ${err instanceof Error ? err.message : String(err)}`);
        return;
      }
      const isEmpty = value == null || value === '' || (Array.isArray(value) && value.length === 0);
      if (isEmpty) {
        // Only REQUIRED fields block the run. An empty optional field is fine —
        // skip it (don't write an empty value into testInputs).
        if (c.required) {
          setErr(`"${c.field.id}" is required — fill it in or hit Cancel.`);
          return;
        }
        continue;
      }
      collected[c.field.id] = value;
    }
    state.testInputs = { ...(state.testInputs || {}), ...collected };
    const target = _runPrepCtx.stepIndex;
    closeRunPrepModal();
    notify();
    await runStepBuilder(target);
  } finally {
    if (submitBtn) submitBtn.removeAttribute('disabled');
  }
}

/**
 * Entry point for the Run button. If every field the pipeline reads up to
 * this step already has a value (in testInputs or as a field default), runs
 * immediately. Otherwise opens the prep modal to collect the missing values.
 */
// Module-scoped guard: only one Run pipeline may be in flight at a time. When
// the author hits Run on step 4, we walk 0..4 sequentially (skipping cached
// steps); kicking off a second Run on a different row mid-flight would race
// the credits reservation, the previewOutputs cache, and the order in which
// jobs settle. The Run buttons read this flag and disable themselves while
// it's set; requestRunStep() also bounces a stray click that slipped through.
let _runInFlight = false;

// Step-progress ticker. Updates only the running progress cells' elapsed
// counter + bar width *in place* — no notify(), no whole-list re-render.
// That's what kept videos in completed steps from being torn down every
// second. The renderer stamps each running cell with stable data hooks
// (data-step-progress-idx + data-progress-pct/bar/time) so we can find
// and mutate them without rebuilding anything.
let _progressTicker = null;
function startStepProgressTicker() {
  if (_progressTicker) return;
  _progressTicker = setInterval(() => {
    const outputs = state.previewOutputs || {};
    const runningIdxs = Object.keys(outputs).filter(k => outputs[k] && outputs[k].running);
    if (runningIdxs.length === 0) {
      clearInterval(_progressTicker);
      _progressTicker = null;
      return;
    }
    for (const k of runningIdxs) {
      updateRunningCellInPlace(Number(k), outputs[k]);
    }
  }, 1000);
}

// Update the running cell's text/bar in place. Returns false if the cell
// isn't on screen yet (first poll before initial render) so the caller
// can fall back to notify().
function updateRunningCellInPlace(stepIndex, cached) {
  const cell = document.querySelector(`[data-step-progress-idx="${stepIndex}"]`);
  if (!cell || !cached) return false;
  const startedAt = Number(cached.startedAt) || Date.now();
  // Elapsed is measured from the client startedAt only — never the server's
  // Date.now()-created_at elapsedMs, which inflates for queued/stale jobs.
  const elapsedNow = Math.max(0, Date.now() - startedAt);
  const elapsedSec = Math.round(elapsedNow / 1000);
  const serverProgress = typeof cached.progress === 'number' ? cached.progress : null;
  const estimatedMs = Number(cached.estimatedDurationMs) || 0;
  const isIndeterminate = serverProgress === null || estimatedMs <= 0;

  const timeEl = cell.querySelector('[data-progress-time]');
  if (timeEl) timeEl.textContent = formatRunningTimeText(elapsedSec, cached);

  const headerRight = cell.querySelector('[data-progress-header-right]');
  if (headerRight) {
    const exceeded = cached.estimateExceeded === true && estimatedMs > 0;
    headerRight.textContent = isIndeterminate ? (exceeded ? 'still working…' : 'estimating…') : `${serverProgress}%`;
    headerRight.style.fontStyle = isIndeterminate ? 'italic' : 'normal';
  }

  const barFill = cell.querySelector('[data-progress-bar-fill]');
  if (barFill && !isIndeterminate) barFill.style.width = `${serverProgress}%`;

  const cancelBtn = cell.querySelector('[data-progress-cancel]');
  if (cancelBtn && cancelBtn.hidden && elapsedNow >= 120000 && cached.jobId && !cached.cancelling) {
    cancelBtn.hidden = false;
  }
  return true;
}

function formatRunningTimeText(elapsedSec, cached) {
  const estimatedMs = Number(cached.estimatedDurationMs) || 0;
  if (typeof cached.progress === 'number' && estimatedMs > 0) {
    return `⏳ Running… ${elapsedSec}s / ~${Math.round(estimatedMs / 1000)}s`;
  }
  if (cached.estimateExceeded === true && estimatedMs > 0) {
    return `⏳ Taking longer than expected… ${elapsedSec}s elapsed (estimated ~${Math.round(estimatedMs / 1000)}s)`;
  }
  return `⏳ Running… ${elapsedSec}s elapsed`;
}

// Shared poll-tick handler. Writes the running snapshot into state and
// either does an in-place DOM update (no flicker) or falls back to a
// full notify() — exactly when the bar DOM has to swap shape
// (indeterminate ↔ determinate) or the cell isn't on screen yet.
function applyRunningTick(stepIndex, running) {
  const cached = state.previewOutputs[stepIndex] || {};
  const prevIndeterminate = typeof cached.progress !== 'number' || !(Number(cached.estimatedDurationMs) > 0);
  const nextProgress = typeof running.progress === 'number' ? running.progress : null;
  const nextEstimate = typeof running.estimatedDurationMs === 'number' && running.estimatedDurationMs > 0
    ? running.estimatedDurationMs
    : (cached.estimatedDurationMs || 0);
  const nextIndeterminate = nextProgress === null || !(nextEstimate > 0);
  state.previewOutputs[stepIndex] = {
    ...cached,
    running: true,
    error: null,
    progress: nextProgress,
    estimatedDurationMs: nextEstimate,
    // Do NOT store the server tick's elapsedMs. The server computes it as
    // Date.now() - job.created_at, which balloons for a queued/stale job and
    // pinned a bogus "10808s" on the bar. Elapsed is derived purely from the
    // client startedAt (set when Run was pressed) in updateRunningCellInPlace.
    estimateExceeded: running.estimateExceeded === true,
  };
  if (prevIndeterminate !== nextIndeterminate || !updateRunningCellInPlace(stepIndex, state.previewOutputs[stepIndex])) {
    notify();
  }
}

function isRunInFlight() {
  return _runInFlight;
}

/**
 * Pull a human-readable error message out of a poll response body. The job
 * row's `error` field can land here as either a string or a `{ stepIndex,
 * message }` shape (preview-run vs preview-step format). Falls back to the
 * generic message for either an unrecognized error or a missing one.
 */
function extractStepError(json, stepIndex) {
  const info = json?.error;
  if (typeof info === 'string' && info) return info;
  if (info && typeof info === 'object' && typeof info.message === 'string' && info.message) return info.message;
  if (typeof json?.message === 'string' && json.message) return json.message;
  return `Step ${stepIndex + 1} failed`;
}

/**
 * Write a poll response into state.previewOutputs[stepIndex]. The same
 * cache layout serves three callers: the foreground runStepBuilder loop,
 * the resume-on-boot path, and any future direct-poll surfaces. Keeps the
 * shape in one place so adding a field (e.g. token usage) is a one-line
 * change.
 *
 * Returns true for success, false for a runtime failure verdict — the
 * caller decides whether to early-exit (foreground sequential loop) or
 * fall through (resume path, which processes one stepIndex at a time).
 */
function applyStepResultToCache(stepIndex, json) {
  const steps = state.agent.steps;
  if (!json?.success) {
    state.previewOutputs[stepIndex] = {
      running: false,
      error: extractStepError(json, stepIndex),
      ranAt: Date.now(),
    };
    return false;
  }
  state.previewOutputs[stepIndex] = {
    running: false,
    error: null,
    outputId: json.outputId,
    modelId: json.modelId,
    output: json.output,
    exposed: json.exposed,
    durationMs: json.durationMs,
    creditsCharged: typeof json.creditsCharged === 'number' ? json.creditsCharged : 0,
    ranAt: Date.now(),
    // Snapshot the authoring shape that produced this output. Future Play
    // presses compare against this — any edit invalidates the cache.
    docHash: steps[stepIndex] ? stepDocHash(steps[stepIndex]) : '',
  };
  // Adaptive estimate — overwrite the step's stored estimate from this run's
  // real wall-clock, plus 20% headroom. Updates the pipeline total too. The
  // draft only lives client-side until Publish, so we persist via state.notify.
  recordStepEstimate(stepIndex, json.durationMs);
  return true;
}

// Persist adaptive estimate ONLY when the last step ran. Persistence is
// automatic via state.notify (which writes the whole state.agent to
// localStorage); we just mutate here.
function recordStepEstimate(stepIndex, durationMs) {
  const steps = state.agent.steps;
  if (!steps?.length || stepIndex !== steps.length - 1) return;
  if (!Number.isFinite(durationMs) || durationMs <= 0) return;
  steps[stepIndex].estimatedDurationMs = Math.ceil(durationMs * 1.2);
  const totalSec = Math.ceil(steps.reduce((s, x) => s + (Number(x?.estimatedDurationMs) || 0), 0) / 1000);
  state.agent.estimatedDuration = { ...(state.agent.estimatedDuration || { min: 0 }), max: totalSec };
}

async function requestRunStep(stepIndex) {
  if (_runInFlight) {
    toast('Another step is still running — wait for it to finish.', 'error');
    return;
  }
  const steps = state.agent.steps;
  if (stepIndex < 0 || stepIndex >= steps.length) return;
  const target = steps[stepIndex];
  if (!target || (stepKindOf(target) === 'model' && !target.model_id)) {
    toast('Pick a model for this step first.', 'error');
    return;
  }
  // Open the prep modal whenever a field the pipeline reads is still empty
  // (required or optional). submitRunPrep only blocks on empty required ones, so
  // optionals can be left blank and Run still proceeds.
  const missing = buildRunPrepRequirements(stepIndex);
  if (missing.length === 0) {
    await runStepBuilder(stepIndex);
    return;
  }
  openRunPrepModal(stepIndex, missing);
}

async function runStepBuilder(stepIndex) {
  const steps = state.agent.steps;
  if (stepIndex < 0 || stepIndex >= steps.length) return;
  const targetStep = steps[stepIndex];
  if (!targetStep || (stepKindOf(targetStep) === 'model' && !targetStep.model_id)) {
    toast('Pick a model for this step first.', 'error');
    return;
  }

  // Second-tier guard. requestRunStep() catches most stray clicks but a direct
  // call to runStepBuilder() (or a race against the button-render tick) could
  // slip past — bounce it here too. The flag is released in `finally` below so
  // any throw down the chain still resets it.
  if (_runInFlight) {
    toast('Another step is still running.', 'error');
    return;
  }
  _runInFlight = true;
  notify(); // re-render so every Run button picks up the disabled state

  const agentDoc = cleanAgentForExport(state.agent);

  try {
  // Walk from 0 to target. Cached outputs we trust; uncached steps we run.
  // We mark each step as "running" so the row can render a spinner.
  for (let i = 0; i <= stepIndex; i++) {
    const currentHash = stepDocHash(steps[i]);
    const cached = state.previewOutputs[i];
    // Cache hit only when (a) we have a successful previous run AND (b) the
    // step's authoring shape hasn't changed since then. Otherwise the cached
    // output may have been produced from a different soul/schema/model.
    const cacheValid = cached && !cached.running && !cached.error && cached.docHash === currentHash;

    if (i < stepIndex && cacheValid) continue; // upstream + cached + fresh → skip
    if (i === stepIndex) delete state.previewOutputs[i]; // target → always rerun

    // Pre-fill the running entry with a local startedAt + a reasonable
    // estimatedDurationMs so the progress bar can animate from the moment
    // the spinner appears — without waiting for the kick-off HTTP round
    // trip (which on a slow link can be 1–2s and would otherwise leave the
    // bar stuck at "0s elapsed / 5%"). The real server-issued createdAt +
    // estimatedDurationMs overwrite these the instant the kick-off response
    // lands; until then we use a same-clock estimate (matches the model
    // registry's durations: tag the way estimatedDurationMsForStep does).
    const stepModelId = steps[i]?.model_id || '';
    const localModel = state.config.models.find(m => m.id === stepModelId);
    const durSeconds = maxModelDurationSeconds(localModel?.tags);
    const preEstimateMs = durSeconds != null ? Math.max(10000, durSeconds * 1000) : 10000;
    state.previewOutputs[i] = {
      ...(state.previewOutputs[i] || {}),
      running: true,
      error: null,
      startedAt: Date.now(),
      estimatedDurationMs: preEstimateMs,
    };
    notify();

    const previousOutputs = {};
    for (let j = 0; j < i; j++) {
      const prev = state.previewOutputs[j];
      if (prev && prev.outputId) previousOutputs[prev.outputId] = prev.exposed;
    }
    console.log(`[builder-run] step ${i} starting`, {
      previousOutputs,
      cachedKeys: Object.keys(state.previewOutputs),
    });

    try {
      // Kick the step off. /preview-step now reserves credits + writes a row
      // into the jobs table, then returns 202 with the jobId before the model
      // call starts. We poll preview-step-job/:jobId below until the row's
      // status flips out of 'running'. (Validation / 402 insufficient-credits
      // still come back here as a non-2xx; we surface the body's message.)
      const kickRes = await fetchHelper('https://aitopia.ai/api/agent-builder/preview-step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agent: agentDoc,
          input: state.testInputs || {},
          stepIndex: i,
          previousOutputs,
        }),
      });
      const kickJson = await kickRes.json().catch(() => null);
      if (!kickRes.ok || !kickJson?.jobId) {
        // The server returns detailed validation problems under `validationErrors`
        // (preview-step) or `errors` (publish) — each item is { code, field?, stepIndex?, message }.
        // Surface every one of them instead of collapsing to a bare "HTTP 422".
        const detailList = Array.isArray(kickJson?.validationErrors) ? kickJson.validationErrors
          : Array.isArray(kickJson?.errors) ? kickJson.errors
          : null;
        const detailMsg = detailList && detailList.length
          ? detailList.map((e) => {
              if (typeof e === 'string') return e;
              const where = e?.field ? ` [${e.field}]`
                : (Number.isInteger(e?.stepIndex) ? ` [step ${e.stepIndex + 1}]` : '');
              return `${e?.message || e?.code || 'unknown error'}${where}`;
            }).join('\n• ')
          : null;
        const msg = detailMsg
          || kickJson?.error
          || kickJson?.message
          || `Step ${i + 1} failed to start (HTTP ${kickRes.status})`;
        // Always log the full server payload so the exact cause is recoverable
        // even when the toast truncates a long list.
        console.error(`[builder-run] step ${i + 1} failed (HTTP ${kickRes.status})`, kickJson);
        state.previewOutputs[i] = { running: false, error: msg, ranAt: Date.now() };
        notify();
        refreshCreditsBalance();
        const toastBody = detailMsg ? `Step ${i + 1} failed:\n• ${detailMsg}` : `Step ${i + 1} failed: ${msg}`;
        toast(toastBody, 'error', 10000);
        return;
      }

      // Stamp the running entry with the job id + the server's estimate.
      //
      // We keep the local `startedAt` set above (when the spinner first
      // appeared) instead of overwriting it with `kickJson.createdAt`.
      // Client clock and server clock are not guaranteed to be in sync;
      // mixing one timestamp (server createdAt) with the ticker's other
      // timestamp (client Date.now()) is what was making the progress
      // bar read "0s elapsed" forever — the server's createdAt sits in
      // the future relative to the client, so Date.now() - createdAt is
      // negative and the Math.max(0, ...) clamp pinned elapsed to zero.
      //
      // The server-issued createdAt is still useful for refresh resume
      // (resumeStepPollingOnBoot reads the jobs row directly there); for
      // the live foreground run we trust the same clock that drives the
      // ticker.
      const existing = state.previewOutputs[i] || {};
      state.previewOutputs[i] = {
        ...existing,
        running: true,
        error: null,
        jobId: kickJson.jobId,
        // Keep the same-clock startedAt we set right before this fetch.
        // Falls back to Date.now() defensively in case some other path
        // cleared it.
        startedAt: Number(existing.startedAt) || Date.now(),
        estimatedDurationMs: Number(kickJson.estimatedDurationMs) || Number(existing.estimatedDurationMs) || 10000,
        docHash: stepDocHash(steps[i]),
      };
      notify();

      // Poll the jobs row until it leaves the running state. Same shape the
      // preview tab uses for full-pipeline runs. Each running tick streams
      // the server's progress + (live, adaptive) estimatedDurationMs into
      // the row cache so the renderer can draw an honest bar — no local
      // synthetic math.
      const json = await pollPreviewStepJob(kickJson.jobId, {
        onProgress: (running) => applyRunningTick(i, running),
      });
      const ok = applyStepResultToCache(i, json);
      notify();
      // The server settled (or refunded) the reservation when the jobs row
      // flipped out of 'running'. Re-fetch the balance so the navbar credit
      // count reflects what the wallet actually has now — same hook
      // /agents/:id uses after every run.
      refreshCreditsBalance();
      if (!ok) {
        toast(`Step ${i + 1} failed: ${state.previewOutputs[i].error}`, 'error', 7000);
        return;
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      state.previewOutputs[i] = { running: false, error: msg, ranAt: Date.now() };
      notify();
      // Network errors on the kick-off or polling path leave the reservation's
      // fate to the background promise on the server (it will settle or refund
      // when it finishes). Refresh anyway so a partial charge can't sit
      // invisible in the display.
      refreshCreditsBalance();
      toast(`Step ${i + 1} network error: ${msg}`, 'error', 7000);
      return;
    }
  }

  toast(`Step ${stepIndex + 1} done.`, 'success', 3000);
  } finally {
    // Always release the in-flight flag, even when an early `return` inside
    // the loop bailed on the run (auth fail, validation, network error). The
    // notify() re-renders the Run buttons to lift their disabled state.
    _runInFlight = false;
    notify();
  }
}

/**
 * Poll /api/agent-builder/preview-step-job/:jobId until the row leaves the
 * 'running' state, then return the response body in the shape the caller
 * (runStepBuilder) expects — the same flat object the old synchronous
 * /preview-step response used to return.
 *
 * Shape on resolution:
 *   { success, stepIndex, outputId, modelId, output, exposed, durationMs,
 *     checkpoint, creditsEstimated, creditsCharged, error? }
 *
 * Throws on poll budget exhausted, on a hard 404 that never recovers, or on
 * a non-recoverable network failure. Transient 5xx and lone 404 windows
 * (a brief gap between INSERT and the row becoming readable) are tolerated
 * via short retries.
 */
async function pollPreviewStepJob(jobId, opts = {}) {
  const intervalMs = opts.intervalMs || 1500;
  const timeoutMs = opts.timeoutMs || 15 * 60 * 1000;
  const startedAt = Date.now();
  let consecutive404 = 0;

  // eslint-disable-next-line no-constant-condition
  while (true) {
    if (Date.now() - startedAt > timeoutMs) {
      throw new Error('Step polling exceeded the timeout budget.');
    }

    let res;
    try {
      res = await fetchHelper(`https://aitopia.ai/api/agent-builder/preview-step-job/${encodeURIComponent(jobId)}`, {
        method: 'GET',
        headers: { Accept: 'application/json' },
      });
    } catch (err) {
      // Transient network blip — wait and try again until the timeout budget
      // forces an exit above.
      await new Promise(r => setTimeout(r, intervalMs));
      continue;
    }

    if (res.status === 404) {
      consecutive404 += 1;
      // Five 404s in a row (≈7.5s) means the job was never created or
      // evicted. Bail out so the caller surfaces a real error instead of
      // looping forever.
      if (consecutive404 >= 5) throw new Error('Step job not found.');
      await new Promise(r => setTimeout(r, intervalMs));
      continue;
    }
    consecutive404 = 0;

    if (res.status >= 500) {
      // Server hiccup — retry on the next tick.
      await new Promise(r => setTimeout(r, intervalMs));
      continue;
    }

    const body = await res.json().catch(() => null);
    if (!body || !body.ok) {
      await new Promise(r => setTimeout(r, intervalMs));
      continue;
    }
    if (body.status === 'running') {
      // Forward the running snapshot so the caller can stamp the latest
      // server-side progress / estimatedDurationMs into the row's cache.
      // The renderer reads progress straight off the cache; without this
      // hook the bar would have nothing to update against between polls.
      if (typeof opts.onProgress === 'function') {
        try { opts.onProgress(body); } catch { /* listener errors don't kill the poll */ }
      }
      await new Promise(r => setTimeout(r, intervalMs));
      continue;
    }
    return body; // status is 'done' or 'failed' — caller branches on body.success
  }
}

/**
 * Force-refresh the navbar's credits display. Uses the shared credits
 * helper loaded via /js/shared/credits.js — same call /agents/:id makes
 * after every run. `loadCreditsBalance({ force: true })` busts the cache,
 * re-hits /api/credits/balance, and pipes the new total into the navbar
 * + drawer credit chips via updateGlobalCreditsDisplay.
 *
 * Wrapped in optional chaining so a page that hasn't loaded credits.js
 * (or a logged-out visitor whose API would 401) silently no-ops.
 */
function refreshCreditsBalance() {
  try {
    window.AitopiaCredits?.loadCreditsBalance?.({ force: true });
  } catch {
    // Display is best-effort; a missing helper or a transient fetch error
    // shouldn't surface in the wizard.
  }
}

/**
 * POST /api/agent-builder/preview-job/:jobId/cancel for a running step. The
 * row's poll loop sees the server flip to `failed`/`cancelled` on the next
 * tick and lands in the failure branch (which renders the red panel + clears
 * the spinner) — we don't need to mutate state.previewOutputs ourselves.
 *
 * We do set a `cancelling: true` transient so the button doesn't double-fire
 * if the author clicks during the round-trip. notify() between set and
 * fetch makes the "Cancelling…" message appear in place of the button.
 */
async function requestCancelStep(stepIndex) {
  const cached = state.previewOutputs[stepIndex];
  if (!cached || !cached.jobId || cached.cancelling) return;
  state.previewOutputs[stepIndex] = { ...cached, cancelling: true };
  notify();
  try {
    await fetchHelper(`https://aitopia.ai/api/agent-builder/preview-job/${encodeURIComponent(cached.jobId)}/cancel`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    // Network error — the poll loop will keep trying; reset the latch
    // so the author can click again. (No toast here; the row's running
    // panel still shows so the user sees the state.)
    const stillCached = state.previewOutputs[stepIndex];
    if (stillCached && stillCached.cancelling) {
      state.previewOutputs[stepIndex] = { ...stillCached, cancelling: false };
      notify();
    }
    console.warn('[agent-builder] cancel request failed', err);
  }
  // On success we don't touch state — the poll loop will pick up the
  // server's `failed` status within ~1.5s and write the final row state.
  refreshCreditsBalance();
}

/**
 * Render the cached output (or running/error state) for a step underneath
 * its row body. Pure visual — clicking Play mutates state and notify()
 * triggers a re-render.
 */
function renderStepOutputPanel(stepIndex) {
  const cached = state.previewOutputs[stepIndex];
  if (!cached) return null;

  if (cached.running) {
    // The server is the only source of truth for progress. Each poll tick
    // streams { progress, elapsedMs, estimatedDurationMs } into the cache
    // (see runStepBuilder#onProgress / resumeOneStepPoll#onProgress), and
    // we draw whatever is there — no local synthetic floor/ceiling.
    //
    //   - cached.progress is null  → indeterminate state. We've polled but
    //                                the server hasn't learned an estimate
    //                                for this draft yet (BUILDER_STEP_DURATION
    //                                is empty). The bar pulses gently; the
    //                                row still shows real elapsed time.
    //   - cached.progress is a num → honest percentage; 0..99. The server
    //                                will only ever send numbers in that
    //                                range until the run hits done/failed,
    //                                at which point this branch stops
    //                                rendering (replaced by the success/
    //                                error branches below).
    //
    // For the elapsed counter we still derive seconds locally between polls
    // (the server's elapsedMs is one poll old by the time we paint), but
    // we anchor that local count to the server's last elapsedMs + the time
    // we received it so a slow tick doesn't make the seconds count race
    // ahead of reality.
    const serverProgress = typeof cached.progress === 'number' ? cached.progress : null;
    const estimatedMs = Number(cached.estimatedDurationMs) || 0;
    const startedAt = Number(cached.startedAt) || Date.now();
    // Elapsed = client wall-clock since Run was pressed. We deliberately do
    // NOT floor against the server's elapsedMs (Date.now()-created_at): for a
    // queued or stale job that value balloons and pinned a bogus "10808s".
    const elapsedNow = Math.max(0, Date.now() - startedAt);
    const elapsedSec = Math.round(elapsedNow / 1000);

    const wrap = el('div', {
      class: 'mt-3 p-3 text-sm ab-step-progress',
      style: 'border-radius: 12px; background: hsl(var(--ait-m-secondary) / 0.4); border: 1px solid hsl(var(--ait-m-border));',
      'data-step-progress-idx': String(stepIndex),
    });

    // Header: elapsed/estimated text (data-progress-time) + right-side
    // status (% or "estimating…"). The ticker only mutates [data-progress-time];
    // bar width / pct only change on poll ticks (which call notify()).
    const isIndeterminate = serverProgress === null || estimatedMs <= 0;
    const exceeded = cached.estimateExceeded === true && estimatedMs > 0;
    const headerRight = isIndeterminate
      ? (exceeded ? 'still working…' : 'estimating…')
      : `${serverProgress}%`;
    wrap.appendChild(el('div', {
      style: 'display: flex; justify-content: space-between; align-items: center; gap: 0.5rem; font-size: 0.75rem; color: hsl(var(--ait-m-muted-foreground)); margin-bottom: 0.4rem;',
    },
      el('span', { 'data-progress-time': '' }, formatRunningTimeText(elapsedSec, cached)),
      el('span', {
        'data-progress-header-right': '',
        style: isIndeterminate
          ? 'font-variant-numeric: tabular-nums; font-style: italic;'
          : 'font-variant-numeric: tabular-nums;',
      }, headerRight),
    ));

    if (isIndeterminate) {
      const bar = el('div', {
        style: 'height: 6px; border-radius: 999px; background: hsl(var(--ait-m-secondary)); overflow: hidden; position: relative;',
      });
      bar.appendChild(el('div', {
        style: 'position: absolute; top: 0; left: -30%; width: 30%; height: 100%; background: hsl(var(--ait-m-primary)); animation: ab-progress-indeterminate 1.4s ease-in-out infinite;',
      }));
      wrap.appendChild(bar);
    } else {
      const bar = el('div', {
        style: 'height: 6px; border-radius: 999px; background: hsl(var(--ait-m-secondary)); overflow: hidden;',
      });
      bar.appendChild(el('div', {
        'data-progress-bar-fill': '',
        style: `width: ${serverProgress}%; height: 100%; background: hsl(var(--ait-m-primary)); transition: width 0.3s ease;`,
      }));
      wrap.appendChild(bar);
    }

    // Cancel button — hidden until the 2-minute wall. The ticker un-hides it
    // in place; we never recreate the row, so a running video output in a
    // sibling step isn't interrupted.
    const CANCEL_THRESHOLD_MS = 120000;
    const showCancelNow = elapsedNow >= CANCEL_THRESHOLD_MS && cached.jobId && !cached.cancelling;
    if (cached.cancelling) {
      wrap.appendChild(el('div', {
        style: 'margin-top: 0.55rem; font-size: 0.75rem; color: hsl(var(--ait-m-muted-foreground)); font-style: italic;',
      }, 'Cancelling…'));
    } else if (cached.jobId) {
      const cancelBtn = el('button', {
        class: 'btn danger',
        type: 'button',
        'data-progress-cancel': '',
        style: 'margin-top: 0.55rem; font-size: 0.75rem; padding: 0.3rem 0.7rem;',
        onclick: () => { void requestCancelStep(stepIndex); },
      }, '✕ Cancel run');
      cancelBtn.hidden = !showCancelNow;
      wrap.appendChild(cancelBtn);
    }

    startStepProgressTicker();
    return wrap;
  }

  if (cached.error) {
    return el('div', {
      class: 'mt-3 p-3 text-sm',
      style: 'border-radius: 12px; background: rgba(255,59,48,0.08); border: 1px solid rgba(255,59,48,0.35); color: rgb(180,40,40);',
    },
      el('div', { style: 'font-weight: 700; margin-bottom: 0.25rem;' }, 'Failed'),
      el('div', { style: 'font-family: ui-monospace, Menlo, monospace; font-size: 0.78rem; white-space: pre-wrap;' }, cached.error),
    );
  }

  // Success — render the exposed value. Priority:
  //   1. Media (videos > images > audios) — same classifier the live agent
  //      page uses (collectMediaUrls). Same render style as /agents/<slug>.
  //   2. URL string                       — clickable link.
  //   3. Plain string                     — preserved-whitespace text block.
  //   4. Anything else                    — JSON dump.
  const exposed = cached.exposed;
  const body = el('div', {
    class: 'mt-3 p-3 text-sm max-h-64 overflow-auto',
    style: 'border-radius: 12px; background: rgba(52,199,89,0.06); border: 1px solid rgba(52,199,89,0.35);',
  });
  const headerChildren = [
    `Output · ${cached.outputId} · ${cached.durationMs || 0}ms`,
  ];
  if (cached.creditsCharged > 0) {
    headerChildren.push(el('span', { style: 'opacity:0.55; margin:0 0.3rem;' }, '·'));
    headerChildren.push(creditsChip(cached.creditsCharged));
    headerChildren.push(el('span', { style: 'margin-left:0.25rem; text-transform:none; font-weight:600; letter-spacing:0;' }, 'charged'));
  }
  body.appendChild(el('div', {
    style: 'font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: rgb(20,120,60); margin-bottom: 0.35rem; display: flex; align-items: center; flex-wrap: wrap;',
  }, ...headerChildren));

  // Content-research output is text/JSON, never media — skip the media scan so a
  // quoted image URL (e.g. a gettyimages link from web search) isn't rendered as
  // an image. Model steps still scan their exposed value.
  const step = state.agent.steps[stepIndex];
  const isContentResearch = step && step.kind === 'content-research';
  const media = isContentResearch
    ? { videos: [], images: [], audios: [] }
    : collectMediaUrls(cached.exposed);

  const mediaWrap = el('div', { class: 'flex flex-col gap-2' });
  const mediaStyle = 'width: 100%; max-width: 480px; border-radius: 12px; border: 1px solid rgba(0,0,0,0.08); background: #000;';
  let rendered = false;

  if (Array.isArray(media.videos) && media.videos.length > 0) {
    for (const url of media.videos) {
      const v = document.createElement('video');
      v.src = url;
      v.controls = true;
      v.playsInline = true;
      v.style.cssText = mediaStyle;
      mediaWrap.appendChild(v);
    }
    rendered = true;
  }
  if (Array.isArray(media.images) && media.images.length > 0) {
    for (const url of media.images) {
      const a = document.createElement('a');
      a.href = url;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.style.cssText = 'display: block; width: 100%; max-width: 480px;';
      const img = document.createElement('img');
      img.src = url;
      img.alt = 'Step output';
      img.loading = 'lazy';
      img.style.cssText = 'width: 100%; height: auto; border-radius: 12px; border: 1px solid rgba(0,0,0,0.08); background: hsl(var(--ait-m-secondary) / 0.4);';
      a.appendChild(img);
      mediaWrap.appendChild(a);
    }
    rendered = true;
  }
  if (Array.isArray(media.audios) && media.audios.length > 0) {
    for (const url of media.audios) {
      const a = document.createElement('audio');
      a.src = url;
      a.controls = true;
      a.style.cssText = 'width: 100%; max-width: 480px;';
      mediaWrap.appendChild(a);
    }
    rendered = true;
  }

  if (rendered) {
    body.appendChild(mediaWrap);
    return body;
  }

  // A content-research step set to text output produces markdown — render it
  // (headings, bold, lists) instead of showing the raw `#`/`**` source, the
  // same way the published runner's Generated Content card does. The design is
  // unchanged; only the string body is upgraded from plain text to markdown.
  const isMarkdownText = isContentResearch && step.outputFormat !== 'json';

  // No media found — fall back to the text/JSON renderer.
  const renderValue = (v) => {
    if (typeof v === 'string') {
      if (/^https?:\/\//.test(v.trim())) {
        return el('a', { href: v, target: '_blank', rel: 'noopener', style: 'word-break: break-all; color: hsl(var(--ait-m-primary));' }, v);
      }
      if (isMarkdownText) {
        return renderMarkdownInto(el('div', { style: 'font-size: 0.85rem;' }), v);
      }
      return el('div', { style: 'white-space: pre-wrap; word-break: break-word; font-size: 0.85rem;' }, v);
    }
    if (Array.isArray(v)) {
      return el('div', { class: 'flex flex-col gap-1' }, ...v.map(item => renderValue(item)));
    }
    return el('pre', { style: 'font-size: 0.75rem; white-space: pre-wrap; word-break: break-word;' }, JSON.stringify(v, null, 2));
  };
  body.appendChild(renderValue(exposed));
  return body;
}

/* ---------------- Model picker ---------------- */

// Maps a registry cost.unit to the media family it produces. Used as a fallback
// when a model has no media tag (e.g. lucataco/faceswap has no tags but bills
// per image) so it doesn't wrongly land in the Text tab.
const COST_UNIT_TYPE = {
  image: 'image', edit: 'image',
  video_sec: 'video',
  audio_sec: 'audio', podcast: 'audio', transcription: 'audio',
  tokens: 'text',
};

// The media family a model outputs. First a matching family tag wins (mirrors
// the outputTypes inference in recomputeDerived); if no tag matches, the
// billing unit decides; only then does it fall back to text.
function modelOutputType(model) {
  for (const t of (model.tags || [])) {
    if (/^video/.test(t)) return 'video';
    if (/^image/.test(t)) return 'image';
    if (/^audio/.test(t)) return 'audio';
  }
  const byCost = COST_UNIT_TYPE[model.cost?.unit];
  if (byCost) return byCost;
  return 'text';
}

// Turn a model's `ui.specs` object into a flat list of readable chip strings.
// Dynamic: any key on `specs` becomes a chip, so new spec fields show up with
// no code change here. Skips empty/false values; booleans render as a label
// instead of "true" (e.g. hasAudio → "🔊 Audio").
const SPEC_BOOL_LABELS = { hasAudio: '🔊 Audio' };
function modelSpecChips(specs) {
  if (!specs || typeof specs !== 'object') return [];
  const chips = [];
  Object.entries(specs).forEach(([key, value]) => {
    if (!value) return;
    if (typeof value === 'boolean') {
      chips.push(SPEC_BOOL_LABELS[key] || key);
    } else {
      chips.push(String(value));
    }
  });
  return chips;
}


// ---------------------------------------------------------------------------
// Model picker — LIVE (paged + filtered) against /api/models/all
// ---------------------------------------------------------------------------
// The picker no longer renders a boot-time list baked into /config. It queries
// the live model catalog as the author searches/filters, so the boot payload
// stays small and the list is always current. Search + type tabs map straight
// onto the endpoint's `q` + `type` params; paging is "load more" via `offset`.

const MODEL_PICKER_PAGE = 48;

// Active output-type tab in the model picker. 'all' shows everything.
let modelPickerType = 'all';
// In-flight picker query state — bumped on every new search/tab so a slow
// earlier response can't clobber the grid after a newer query started.
let _modelQueryToken = 0;
let _modelOffset = 0;
let _modelHasMore = false;
let _modelLoading = false;
let _modelSearchDebounce = null;

// Build a picker card for one live model row. When the model carries `ui.specs`
// (resolution, duration, aspect ratios, hasAudio) we render the same spec chips
// the picker always showed; the credit estimate rides alongside as a chip using
// the marketplace credit icon (no "cr" text). Tier-fallback estimates (registry
// has no exact price) are dimmed so they read as approximate.
function modelPickCard(m) {
  const outType = m.mediaType || modelOutputType(m);
  const specChips = modelSpecChips(m.ui?.specs);
  const ce = m.creditsEstimated || null;
  let creditNode = null;
  if (ce && Number.isFinite(ce.credits)) {
    const chip = creditsChip(ce.credits, { dim: ce.source === 'tier-fallback' });
    chip.classList.add('pick-spec');
    creditNode = chip;
  }
  const specNode = (specChips.length || creditNode)
    ? el('div', { class: 'pick-specs' },
        ...specChips.map(s => el('span', { class: 'pick-spec' }, s)),
        creditNode,
      )
    : null;
  return el('div', {
    class: 'ab-catalog-pick',
    onclick: () => onPickModel(m),
  },
    el('div', { class: 'pick-head' },
      el('div', { class: 'pick-title' }, m.displayName || m.id),
      el('span', { class: 'pick-out pick-out-' + outType }, outType),
    ),
    el('div', { class: 'pick-id' }, m.id),
    m.description
      ? el('div', { class: 'pick-desc' }, m.description)
      : null,
    specNode,
  );
}

// Fetch one page of models from the live endpoint for the current type/search.
// `append=true` adds to the grid (load-more); otherwise it replaces it.
async function fetchModelPage({ append } = {}) {
  const grid = $('#ab-model-grid');
  if (!grid) return;
  const token = append ? _modelQueryToken : ++_modelQueryToken;
  const q = ($('#ab-model-search')?.value || '').trim();
  const offset = append ? _modelOffset : 0;
  _modelLoading = true;

  if (!append) {
    grid.innerHTML = '';
    grid.appendChild(el('div', { class: 'pick-id', style: 'grid-column:1/-1; padding:0.4rem 0.2rem;' }, 'Loading models…'));
  }

  const params = new URLSearchParams({ sort: 'newest', limit: String(MODEL_PICKER_PAGE), offset: String(offset) });
  if (modelPickerType !== 'all') params.set('type', modelPickerType);
  if (q) params.set('q', q);

  let json = null;
  try {
    const res = await fetchHelper(`https://aitopia.ai/api/models/all?${params.toString()}`);
    if (!res.ok) throw new Error('status ' + res.status);
    json = await res.json();
  } catch (err) {
    if (token === _modelQueryToken) {
      grid.innerHTML = '';
      grid.appendChild(el('div', { class: 'pick-id', style: 'grid-column:1/-1; padding:0.4rem 0.2rem;' }, 'Could not load models: ' + err.message));
    }
    _modelLoading = false;
    return;
  }

  // A newer query started while this was in flight — drop the stale response.
  if (token !== _modelQueryToken) { _modelLoading = false; return; }

  const models = Array.isArray(json.models) ? json.models : [];
  _modelOffset = offset + models.length;
  _modelHasMore = !!json.hasMore;

  if (!append) grid.innerHTML = '';
  // Drop any prior end-of-list marker before appending fresh cards.
  grid.querySelector('.ab-model-more')?.remove();

  for (const m of models) grid.appendChild(modelPickCard(m));

  if (!append && models.length === 0) {
    grid.appendChild(el('div', { class: 'pick-id', style: 'grid-column:1/-1; padding:0.4rem 0.2rem;' }, 'No models match.'));
  } else if (_modelHasMore) {
    // Infinite scroll: no button. A small marker row sits at the bottom; the
    // scroll handler (wireModelTabs) loads the next page as it nears the
    // viewport. The marker doubles as a manual fallback if scroll never fires.
    grid.appendChild(el('div', {
      class: 'ab-model-more pick-id',
      style: 'grid-column:1/-1; padding:0.5rem 0.2rem; text-align:center; opacity:0.6; cursor:pointer;',
      onclick: () => { if (!_modelLoading) fetchModelPage({ append: true }); },
    }, `Loading more… (${json.total - _modelOffset} more)`));
  }

  _modelLoading = false;
}

// Scroll container for the picker grid (the modal body scrolls, not the grid).
function modelPickerScroller() {
  return $('#ab-model-grid')?.closest('.ab-modal') || null;
}

// Load the next page when the user scrolls near the bottom of the picker.
// Guards: a query must be in a "has more" state and not already loading.
function onModelPickerScroll() {
  if (_modelLoading || !_modelHasMore) return;
  const scroller = modelPickerScroller();
  if (!scroller) return;
  const remaining = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight;
  // Trigger ~1.5 viewport-heights early so the next page is usually ready
  // before the user reaches the end (no visible stall).
  if (remaining < scroller.clientHeight * 1.5) {
    fetchModelPage({ append: true });
  }
}

// Wire the output-type filter tabs + search box. Tab/search changes re-query
// the live endpoint (search is debounced). Idempotent (guards on dataset.wired).
function wireModelTabs() {
  const bar = $('#ab-model-tabs');
  if (bar && !bar.dataset.wired) {
    bar.dataset.wired = '1';
    bar.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-model-type]');
      if (!btn) return;
      modelPickerType = btn.dataset.modelType;
      for (const t of bar.querySelectorAll('[data-model-type]')) {
        t.classList.toggle('active', t.dataset.modelType === modelPickerType);
      }
      fetchModelPage({ append: false });
    });
  }
  const search = $('#ab-model-search');
  if (search && !search.dataset.wired) {
    search.dataset.wired = '1';
    search.addEventListener('input', () => {
      clearTimeout(_modelSearchDebounce);
      _modelSearchDebounce = setTimeout(() => fetchModelPage({ append: false }), 250);
    });
  }
  // Infinite scroll: load the next page as the modal body nears its bottom.
  const scroller = modelPickerScroller();
  if (scroller && !scroller.dataset.modelScrollWired) {
    scroller.dataset.modelScrollWired = '1';
    scroller.addEventListener('scroll', onModelPickerScroll, { passive: true });
  }
}

// Open the model picker fresh: clear the search, reset the type filter to All,
// re-sync the tab highlight, fetch the first page, then show the modal.
function openModelPicker() {
  wireModelTabs();
  modelPickerType = 'all';
  const search = $('#ab-model-search');
  if (search) search.value = '';
  const bar = $('#ab-model-tabs');
  if (bar) {
    for (const t of bar.querySelectorAll('[data-model-type]')) {
      t.classList.toggle('active', t.dataset.modelType === 'all');
    }
  }
  // Reset scroll to the top so a prior session's scroll position doesn't
  // immediately retrigger paging on the fresh list.
  const scroller = modelPickerScroller();
  if (scroller) scroller.scrollTop = 0;
  fetchModelPage({ append: false });
  openModal('ab-modal-model');
}

async function onPickModel(model) {
  if (!modelPickerMode) return;

  // Cache the picked model's pricing/output metadata so the per-step cost +
  // output-type lookups resolve immediately (the picker row carries cost,
  // tags, mediaType, creditsEstimated from /api/models/all).
  rememberModel(model);

  closeModal('ab-modal-model');

  let addedFieldIds = [];

  if (modelPickerMode.kind === 'new') {
    if (state.agent.steps.length >= 5) {
      toast('Maximum 5 steps.', 'error');
      return;
    }
    const step = {
      soul: '',
      schema: {},
      model_id: model.id,
      output_id: 'output_' + (state.agent.steps.length + 1),
      step: false,
      // Newly created step opens expanded so the author lands directly on the
      // schema editor — no second click required after picking a model.
      __expanded: true,
    };
    state.agent.steps.push(step);
    notify();
    addedFieldIds = await loadAndApplySchema(step);
  } else if (modelPickerMode.kind === 'change') {
    const step = state.agent.steps[modelPickerMode.stepIndex];
    if (!step) return;
    step.model_id = model.id;
    // Model swap invalidates this step's cached output (different model means
    // a different result) and everything downstream that depended on it.
    invalidatePreviewFrom(modelPickerMode.stepIndex);
    notify();
    addedFieldIds = await loadAndApplySchema(step);
    // Model swap may leave fields that no remaining schema key references.
    // Drop auto-added orphans so the form doesn't accumulate ghosts.
    pruneOrphanAutoAddedFields();
    notify();
  }

  modelPickerMode = null;

  if (addedFieldIds && addedFieldIds.length) {
    toast(`Added ${addedFieldIds.length} required field${addedFieldIds.length === 1 ? '' : 's'} to your form.`, 'success', 4000);
    // Detour the author forward to Pass 4 (Fields) so they see the new rows.
    state.pass = 4;
    notify();
  }
}

/* ---------------- Step renderer ---------------- */

function insertAtCaret(textarea, text) {
  const start = textarea.selectionStart ?? textarea.value.length;
  const end = textarea.selectionEnd ?? textarea.value.length;
  const before = textarea.value.slice(0, start);
  const after = textarea.value.slice(end);
  textarea.value = before + text + after;
  textarea.focus();
  const caret = start + text.length;
  textarea.setSelectionRange(caret, caret);
  textarea.dispatchEvent(new Event('input', { bubbles: true }));
}

/**
 * Find the form field this schema key is currently wired to, if any.
 *
 * Returns the field object reference (mutable) when `step.schema[key]` is
 * exactly `${field_id}` and that field exists in `state.agent.fields`.
 * Returns `null` for literal values, mixed strings (e.g. text with `${id}`
 * inside), or placeholders that point at upstream output ids.
 */
/**
 * Apply a free-form string value into `step.schema[key]`.
 *
 * No auto-promotion: an earlier version of this helper synthesized a form
 * field for every `${id}` it spotted, even mid-keystroke (typing `${shadow`
 * created a `shadow` field that turned into a stray once the author finished
 * `${shadowPrompt}`). That was too aggressive. The author may instead want
 * to add a catalog field, pick a different name, or wire to an upstream
 * output — none of which are possible if the wizard has already pushed a
 * custom textarea field onto Pass 3 on their behalf.
 *
 * Unresolved `${id}` references are surfaced as warnings in the soul card
 * (see `unresolvedPlaceholderIds` below). The author can act on them or
 * ignore them; nothing is mutated outside `step.schema[key]`.
 */
function applyStringValue(step, key, newValue) {
  step.schema[key] = newValue;
}

function boundFieldFor(step, key) {
  const value = step.schema[key];
  if (typeof value !== 'string') return null;
  const m = /^\$\{([a-zA-Z0-9_-]+)\}$/.exec(value.trim());
  if (!m) return null;
  return state.agent.fields.find(f => f.id === m[1]) || null;
}

/**
 * Promote a schema key into a CUSTOM form field — even when the catalog has a
 * matching concept. Author explicitly chose "Custom" → they want to design the
 * field from scratch (catalog defaults don't flow through).
 *
 * If a custom field with the desired id already exists, reuse it. If a CATALOG
 * field with the same id exists (from a prior "From input-mapping" round), we
 * detach it: drop the catalog entry and write a fresh custom field with the
 * same effective shape. `step.schema[key]` is rewritten to `${fieldId}`.
 */
function promoteKeyToCustomField(step, key, prop) {
  const resolved = resolveSchemaControl(key, prop);
  // CUSTOM means "detach from the catalog and own the field outright", so the
  // field id is the schema KEY itself — never the resolved conceptId. Using the
  // conceptId here was the bug behind the unfixable `${prompt}` wiring: a
  // text-to-speech model's `text` key maps (via mapped_to) to the reserved
  // `prompt` concept, so Custom kept re-wiring `step.schema.text = "${prompt}"`
  // no matter what the author picked. The author must ALWAYS be able to make any
  // key a plain custom field; keying off the schema key guarantees that and
  // never collides with the reserved `prompt`.
  const fieldId = key; // schema key, verbatim — not resolved.conceptId

  const existingIdx = state.agent.fields.findIndex(f => f.id === fieldId);
  if (existingIdx >= 0) {
    const existing = state.agent.fields[existingIdx];
    if (existing.__custom) {
      existing.__expanded = true;
      step.schema[key] = '${' + fieldId + '}';
      return existing;
    }
    // Catalog field exists — detach into custom with the same effective shape.
    const concept = state.config.catalog.find(c => c.id === fieldId);
    // Defaults MUST be literals (string/number/boolean/JSON). A placeholder
    // like `${image}` is a wiring artefact, never a default; if one slipped
    // onto `existing.default` from a previous bug, drop it during detachment
    // so the Custom panel's default input doesn't surface it.
    const literalDefault = (v) => (typeof v === 'string' && /\$\{[a-zA-Z0-9_-]+\}/.test(v)) ? null : v;
    const detached = {
      __custom: true,
      __autoAdded: true,
      __expanded: true,
      id: fieldId,
      title: existing.title || concept?.title || fieldId,
      description: existing.description || concept?.description || '',
      type: existing.type || concept?.type || prop?.type || 'string',
      ui_component: existing.ui_component || concept?.ui_component || resolved.uiComponent,
      default: literalDefault(existing.default) ?? literalDefault(concept?.default) ?? null,
      visible: existing.visible !== false,
      advanced: existing.advanced === true,
      step: existing.step === true,
    };
    const eff = existing.enum ?? concept?.enum;
    if (Array.isArray(eff) && eff.length) detached.enum = [...eff];
    const effRange = existing.range ?? concept?.range;
    if (effRange) detached.range = { ...effRange };
    state.agent.fields[existingIdx] = detached;
    step.schema[key] = '${' + fieldId + '}';
    return detached;
  }

  // No existing field — synthesize one from the resolver's view of the schema.
  const field = buildCustomField(fieldId, key, prop, resolved, { expanded: true });
  state.agent.fields.push(field);
  step.schema[key] = '${' + fieldId + '}';
  return field;
}

/**
 * Promote a schema key into a CATALOG form field (compact `{ id }` entry).
 * Used by the "From input-mapping" radio. Falls back to a custom field when
 * the key has no catalog match — author told us "use the mapping" but the
 * mapping doesn't exist, so we synthesize a custom field with the same id as
 * the schema key (no catalog defaults flow through in that case, but author
 * can refine the row in Pass 4).
 *
 * If a field with the target id already exists (catalog OR custom), we reuse
 * it. Existing custom field gets converted back to catalog only when a catalog
 * concept exists for the id — otherwise it stays custom (catalog-less id).
 */
function promoteKeyToMappingField(step, key, prop) {
  const resolved = resolveSchemaControl(key, prop);
  const fieldId = resolved.conceptId || key;

  const existingIdx = state.agent.fields.findIndex(f => f.id === fieldId);
  if (existingIdx >= 0) {
    const existing = state.agent.fields[existingIdx];
    // Already a catalog field — nothing to do beyond wiring.
    if (!existing.__custom) {
      step.schema[key] = '${' + fieldId + '}';
      return existing;
    }
    // Custom field exists but author wants mapping. Replace with compact
    // catalog entry IF the concept exists; otherwise keep the custom field
    // (no mapping available — the radio still wired the placeholder).
    if (resolved.conceptId && state.config.catalog.find(c => c.id === resolved.conceptId)) {
      state.agent.fields[existingIdx] = { id: resolved.conceptId, visible: true, __autoAdded: true };
    }
    step.schema[key] = '${' + fieldId + '}';
    return state.agent.fields[existingIdx];
  }

  // No existing field. Catalog match → compact entry. No match → custom
  // (same shape `ensureFieldForRequiredKey` builds for catalog-less keys).
  if (resolved.conceptId) {
    const compact = { id: resolved.conceptId, visible: true, __autoAdded: true };
    state.agent.fields.push(compact);
    step.schema[key] = '${' + resolved.conceptId + '}';
    return compact;
  }
  return promoteKeyToCustomField(step, key, prop);
}

/**
 * @deprecated use promoteKeyToCustomField / promoteKeyToMappingField instead.
 * Kept as a thin alias because earlier callers (auto-detour path, schema-load
 * fallback) call this name; both new helpers preserve the same return contract.
 */
function promoteKeyToField(step, key, prop) {
  const resolved = resolveSchemaControl(key, prop);
  const fieldId = resolved.conceptId || key;
  let field = state.agent.fields.find(f => f.id === fieldId);
  if (!field) {
    // Synthesize a new custom field. Title falls back to a humanized key;
    // ui_component / enum / range / default seed from the resolver so the
    // field starts at the same effective shape the author was seeing.
    //
    // `__expanded: true` is intentional. The author just clicked Custom on
    // a schema key to edit this field's properties; landing on Pass 3 with
    // the row collapsed would force a second click ("Edit") for no payoff.
    // Auto-promote during prompt typing keeps rows collapsed (no edit
    // intent expressed) — this is the explicit-intent path.
    field = {
      __custom: !resolved.conceptId,
      __autoAdded: true,
      __expanded: true,
      id: fieldId,
      title: prop?.title || key.replace(/[_-]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
      description: prop?.description || '',
      type: prop?.type || 'string',
      ui_component: resolved.uiComponent,
      default: prop?.default ?? null,
      visible: true,
      advanced: false,
      step: false,
    };
    if (Array.isArray(resolved.enum) && resolved.enum.length) field.enum = [...resolved.enum];
    if (prop?.minimum != null || prop?.maximum != null) {
      field.range = { min: prop?.minimum ?? null, max: prop?.maximum ?? null };
    }
    state.agent.fields.push(field);
  } else {
    // Existing field — expand it too so the author lands in edit mode.
    field.__expanded = true;
  }
  step.schema[key] = '${' + fieldId + '}';
  return field;
}

/**
 * Humanize a `ui_component` value for the picker. The internal ids are fine
 * for code, but readers see the wizard.
 */
function uiComponentLabelInline(uic) {
  return ({
    'input': 'Single-line input',
    'textarea': 'Multi-line text',
    'slider': 'Slider',
    'select': 'Dropdown',
    'radio-group': 'Radio buttons',
    'toggle': 'On/off switch',
    'file-upload': 'File upload',
    'json-input': 'JSON editor',
    'interactive-prompt': 'Interactive prompt (inline pills)',
    'multi-select': 'Multi-select (checkboxes in dropdown)',
    'editable-select': 'Editable select (typeable dropdown)',
    'color-picker': 'Color picker (hex + HSV)',
    'image-pair': 'Image pair (start + end frames)',
  })[uic] || uic;
}

/**
 * Reusable row-based enum editor for a field.
 *
 * Layout per option: [ Title input ] [ Value input ] [ × multiplier ] [ × remove ]
 * Footer: [ + Add option ]
 *
 * - `field.enum`        — array of values, the only required shape for the
 *                         underlying mapper/validator contract.
 * - `field.enumLabels`  — optional parallel array of human-readable titles.
 *                         When missing for a row, the runtime form falls
 *                         back to showing the value as the label.
 * - `field.costMultiplier` — when set as an object map keyed by value, each
 *                         row's multiplier input edits that value's entry.
 *
 * Returns a DOM node. Caller decides whether to also render a Default picker
 * underneath (it's still useful as a single-pick).
 */
/**
 * @param {object} field
 * @param {object} [opts]
 * @param {boolean} [opts.inlineCost=false]
 *   When true, each option row carries a per-value cost-multiplier input —
 *   used by the step's Custom config panel (Pass 2), where there's no
 *   separate Cost multiplier section. When false (default) the row is just
 *   Title + Value + remove; the dedicated Cost multiplier panel underneath
 *   handles per-value multipliers — used by Pass 3 field editor to avoid
 *   showing the same cost input twice.
 * @param {boolean} [opts.withImages=false]
 *   When true, each option row also carries an Image URL input. The author's
 *   entry lands on `field.optionImages` as a `{ [value]: url }` map. Used by
 *   the `prompt-picker` and `visual-picker` ui_components — the runner renders
 *   each value as a visual card. Stale image entries are dropped when a value
 *   is renamed or removed.
 * @param {boolean} [opts.withCategories=false]
 *   When true, each option row carries an additional Category input. Lands on
 *   `field.optionCategories` as a `{ [value]: category }` map. Used by the
 *   `visual-picker` ui_component — categories drive the chip filter row above
 *   the modal grid. Stale entries pruned the same way as images.
 */
export function renderEnumOptionsEditor(field, opts = {}) {
  const inlineCost = !!opts.inlineCost;
  const withImages = !!opts.withImages;
  const withCategories = !!opts.withCategories;
  const wrap = el('div', { class: 'field mb-2' });
  wrap.appendChild(el('label', {}, 'Options'));

  const values = Array.isArray(field.enum) ? [...field.enum] : [];
  const labels = Array.isArray(field.enumLabels) ? [...field.enumLabels] : [];
  while (labels.length < values.length) labels.push('');
  const images = (field.optionImages && typeof field.optionImages === 'object') ? { ...field.optionImages } : {};
  const categories = (withCategories && field.optionCategories && typeof field.optionCategories === 'object')
    ? { ...field.optionCategories }
    : {};
  // Per-option step prompts — only relevant for prompt-picker (`withImages`).
  // Shape: { [value]: string[] }. Length follows state.agent.steps.length; the
  // author fills one textarea per agent step, per option. Kept up here (above
  // rebuild()) so the closure captures a defined binding.
  const optionSteps = (withImages && field.optionSteps && typeof field.optionSteps === 'object')
    ? { ...field.optionSteps }
    : {};
  const stepCount = withImages ? Math.max(0, (state.agent.steps || []).length) : 0;

  // Expand/collapse state for each option's "Step prompts" section. Kept on
  // the field as a __-prefixed Set so cleanAgentForExport strips it (never
  // reaches JSON / localStorage / publish). Rename + remove keep this Set in
  // sync with `values` the same way `optionSteps` does.
  if (withImages && !(field.__expandedOptions instanceof Set)) {
    field.__expandedOptions = new Set();
  }
  const expanded = withImages ? field.__expandedOptions : null;

  // Inline cost editing only kicks in when the field uses the map shape
  // (per-value multipliers). A scalar `costMultiplier: 1.5` is edited
  // elsewhere; this UI never overwrites it.
  const cmMapEditable = inlineCost && (!field.costMultiplier || typeof field.costMultiplier === 'object');
  const cmMap = (field.costMultiplier && typeof field.costMultiplier === 'object') ? field.costMultiplier : {};

  const rebuild = () => {
    field.enum = values.length ? [...values] : null;
    field.enumLabels = labels.some(l => l && l.trim()) ? [...labels] : null;
    if (cmMapEditable) {
      const validValues = new Set(values.map(String));
      const next = {};
      for (const [k, v] of Object.entries(cmMap)) {
        if (validValues.has(k) && typeof v === 'number' && Number.isFinite(v)) next[k] = v;
      }
      field.costMultiplier = Object.keys(next).length ? next : null;
    }
    if (withImages) {
      const validValues = new Set(values.map(String));
      const nextImg = {};
      for (const [k, v] of Object.entries(images)) {
        if (validValues.has(k) && typeof v === 'string' && v.trim()) nextImg[k] = v;
      }
      field.optionImages = Object.keys(nextImg).length ? nextImg : null;
      if (withCategories) {
        const nextCats = {};
        for (const [k, v] of Object.entries(categories)) {
          if (validValues.has(k) && typeof v === 'string' && v.trim()) nextCats[k] = v;
        }
        field.optionCategories = Object.keys(nextCats).length ? nextCats : null;
      }
      // Per-option step prompts. Keyed by value, sized to state.agent.steps.length.
      // Pruned the same way as images when values are renamed or removed.
      const nextSteps = {};
      for (const [k, v] of Object.entries(optionSteps)) {
        if (!validValues.has(k) || !Array.isArray(v)) continue;
        // Trim trailing empties but keep positional order; preserve length up to
        // the slot the author actually wrote into.
        const trimmed = [...v];
        while (trimmed.length && (trimmed[trimmed.length - 1] == null || trimmed[trimmed.length - 1] === '')) {
          trimmed.pop();
        }
        if (trimmed.length) nextSteps[k] = trimmed;
      }
      field.optionSteps = Object.keys(nextSteps).length ? nextSteps : null;
      // Prune the expand-state Set the same way.
      if (field.__expandedOptions instanceof Set) {
        for (const k of [...field.__expandedOptions]) {
          if (!validValues.has(k)) field.__expandedOptions.delete(k);
        }
      }
    }
    if (field.default != null && values.length && !values.map(String).includes(String(field.default))) {
      field.default = null;
    }
    notify();
  };

  const list = el('div', { class: withImages ? 'flex flex-col gap-3' : 'flex flex-col gap-2' });
  values.forEach((value, idx) => {
    const valueStr = String(value);
    const labelStr = labels[idx] || '';
    const cmVal = typeof cmMap[valueStr] === 'number' ? String(cmMap[valueStr]) : '';

    // prompt-picker → vertical card layout (top row: meta, then a step-prompt
    // repeater sized to state.agent.steps.length). select/radio-group keep the
    // compact single-row layout.
    const card = withImages
      ? el('div', {
          style: 'padding: 0.6rem; border: 1px solid rgba(127,127,127,0.18); border-radius: 8px; '
            + 'background: rgba(127,127,127,0.04);',
        })
      : null;
    const row = el('div', { class: 'flex items-center gap-2' });

    row.appendChild(el('input', {
      type: 'text', value: labelStr,
      placeholder: 'Title (shown to the user)',
      style: 'flex: 1 1 0; min-width: 0;',
      oninput: (e) => { labels[idx] = e.target.value; rebuild(); },
    }));
    row.appendChild(el('input', {
      type: 'text', value: valueStr,
      placeholder: 'Value (sent to the model)',
      style: 'flex: 1 1 0; min-width: 0;',
      oninput: (e) => {
        const oldKey = valueStr;
        const newKey = e.target.value;
        values[idx] = newKey;
        if (cmMapEditable && Object.prototype.hasOwnProperty.call(cmMap, oldKey)) {
          cmMap[newKey] = cmMap[oldKey];
          if (oldKey !== newKey) delete cmMap[oldKey];
        }
        if (withImages && Object.prototype.hasOwnProperty.call(images, oldKey)) {
          images[newKey] = images[oldKey];
          if (oldKey !== newKey) delete images[oldKey];
        }
        if (withCategories && Object.prototype.hasOwnProperty.call(categories, oldKey)) {
          categories[newKey] = categories[oldKey];
          if (oldKey !== newKey) delete categories[oldKey];
        }
        if (withImages && Object.prototype.hasOwnProperty.call(optionSteps, oldKey)) {
          optionSteps[newKey] = optionSteps[oldKey];
          if (oldKey !== newKey) delete optionSteps[oldKey];
        }
        if (withImages && expanded && expanded.has(oldKey)) {
          expanded.add(newKey);
          if (oldKey !== newKey) expanded.delete(oldKey);
        }
        rebuild();
      },
    }));
    if (withImages) {
      const imgUrl = typeof images[valueStr] === 'string' ? images[valueStr] : '';
      const thumb = el('div', {
        style: 'width: 36px; height: 36px; flex-shrink: 0; border-radius: 6px; background: rgba(0,0,0,0.05); '
          + 'overflow: hidden; display: flex; align-items: center; justify-content: center; '
          + 'border: 1px solid rgba(0,0,0,0.08); font-size: 0.65rem; color: hsl(var(--ait-m-muted-foreground));',
      });
      const renderThumb = (url) => {
        thumb.innerHTML = '';
        if (url && url.trim()) {
          const img = el('img', {
            src: url,
            alt: '',
            style: 'width: 100%; height: 100%; object-fit: cover;',
          });
          img.onerror = () => { thumb.innerHTML = ''; thumb.textContent = '!'; };
          thumb.appendChild(img);
        } else {
          thumb.textContent = '·';
        }
      };
      renderThumb(imgUrl);
      row.appendChild(thumb);
      row.appendChild(el('input', {
        type: 'text', value: imgUrl,
        placeholder: 'Image URL',
        style: 'flex: 1 1 0; min-width: 0;',
        oninput: (e) => {
          const url = e.target.value;
          if (url === '') delete images[valueStr];
          else images[valueStr] = url;
          renderThumb(url);
          rebuild();
        },
      }));
      if (withCategories) {
        const catVal = typeof categories[valueStr] === 'string' ? categories[valueStr] : '';
        row.appendChild(el('input', {
          type: 'text', value: catVal,
          placeholder: 'Category (chip filter)',
          style: 'flex: 0 1 9rem; min-width: 0;',
          oninput: (e) => {
            const v = e.target.value;
            if (v.trim() === '') delete categories[valueStr];
            else categories[valueStr] = v;
            rebuild();
          },
        }));
      }
    }
    if (cmMapEditable) {
      row.appendChild(el('input', {
        type: 'number', step: 'any', value: cmVal,
        placeholder: 'cost',
        style: 'width: 5rem; flex-shrink: 0;',
        oninput: (e) => {
          if (e.target.value === '') delete cmMap[valueStr];
          else cmMap[valueStr] = Number(e.target.value);
          rebuild();
        },
      }));
    }
    row.appendChild(el('button', {
      class: 'btn danger', type: 'button', style: 'flex-shrink: 0;',
      title: 'Remove this option',
      onclick: () => {
        values.splice(idx, 1);
        labels.splice(idx, 1);
        rebuild();
      },
    }, '×'));

    if (card) {
      card.appendChild(row);
      // Step-prompt repeater. One textarea per agent step. The author writes
      // what each step should do *when this option is selected*; the agent
      // looks up `field.optionSteps[value]` server-side and feeds each entry
      // into the matching step's prompt. Empty trailing entries are trimmed
      // on save (rebuild()).
      if (stepCount === 0) {
        card.appendChild(el('div', {
          style: 'margin-top: 0.5rem; font-size: 0.75rem; color: hsl(var(--ait-m-muted-foreground));',
        }, 'Add steps on the Steps pass — a prompt slot for each step will appear here.'));
      } else {
        const isOpen = expanded && expanded.has(valueStr);
        const stepsWrap = el('div', { style: 'margin-top: 0.55rem; display: flex; flex-direction: column; gap: 0.4rem;' });

        // Clickable header — toggles the collapsible body below.
        const header = el('button', {
          type: 'button',
          style: 'display: flex; align-items: center; gap: 0.4rem; width: 100%; padding: 0.25rem 0.2rem; '
            + 'background: transparent; border: none; cursor: pointer; text-align: left; '
            + 'font-size: 0.72rem; font-weight: 600; color: hsl(var(--ait-m-muted-foreground)); '
            + 'text-transform: uppercase; letter-spacing: 0.04em;',
          onclick: () => {
            if (!expanded) return;
            if (expanded.has(valueStr)) expanded.delete(valueStr);
            else expanded.add(valueStr);
            notify();
          },
        });
        header.appendChild(el('span', {
          style: 'display: inline-block; width: 0.7rem; transition: transform 0.15s; '
            + `transform: rotate(${isOpen ? 90 : 0}deg);`,
        }, '▶'));
        header.appendChild(el('span', {}, `Step prompts for "${labelStr || valueStr || '(unnamed)'}"`));
        stepsWrap.appendChild(header);

        if (isOpen) {
          const body = el('div', { style: 'display: flex; flex-direction: column; gap: 0.4rem; padding-left: 0.2rem;' });
          const current = Array.isArray(optionSteps[valueStr]) ? optionSteps[valueStr] : [];
          for (let stepIdx = 0; stepIdx < stepCount; stepIdx++) {
            const stepRef = state.agent.steps[stepIdx];
            const stepLabel = stepRef?.output_id || `step ${stepIdx + 1}`;
            const promptVal = typeof current[stepIdx] === 'string' ? current[stepIdx] : '';
            const stepRow = el('div', { style: 'display: flex; flex-direction: column; gap: 0.2rem;' });
            stepRow.appendChild(el('label', {
              style: 'font-size: 0.7rem; color: hsl(var(--ait-m-muted-foreground));',
            }, `${stepIdx + 1}. ${stepLabel}`));
            const stepTa = el('textarea', {
              rows: 2,
              placeholder: `Prompt fed into step ${stepIdx + 1} when "${valueStr || '(value)'}" is picked`,
              style: 'width: 100%; resize: vertical; min-height: 38px; font-size: 0.85rem;',
              oninput: (e) => {
                const arr = Array.isArray(optionSteps[valueStr]) ? [...optionSteps[valueStr]] : [];
                while (arr.length <= stepIdx) arr.push('');
                arr[stepIdx] = e.target.value;
                optionSteps[valueStr] = arr;
                rebuild();
              },
            });
            // <textarea> ignores a `value` attribute — its content is the
            // `.value` property. Set it after creation, the same way every
            // other textarea in this file does (template/soul/schema editors).
            stepTa.value = promptVal;
            stepRow.appendChild(stepTa);
            body.appendChild(stepRow);
          }
          stepsWrap.appendChild(body);
        }
        card.appendChild(stepsWrap);
      }
      list.appendChild(card);
    } else {
      list.appendChild(row);
    }
  });
  wrap.appendChild(list);

  wrap.appendChild(el('button', {
    class: 'btn', type: 'button', style: 'margin-top: 0.5rem;',
    onclick: () => {
      values.push('');
      labels.push('');
      // Newly added prompt-picker option starts with its Step prompts section
      // open. The author normally needs to fill those textareas right away;
      // having to click the chevron each time adds friction. Keyed by the
      // empty string `""` because that's the option's initial value — when
      // the author types a value, the value-rename handler migrates the
      // expand-flag to the new key (same as optionSteps/images).
      if (withImages && expanded) expanded.add('');
      rebuild();
    },
  }, '+ Add option'));

  return wrap;
}

/**
 * Render the type-specific config panel for the schema key in Custom mode.
 * The panel mutates the bound field's own properties (enum / range / default
 * / ui_component) — schema-key Custom mode is just a contextualized field
 * editor that always promotes through `${field_id}`.
 *
 * Layout follows the field's current `ui_component`:
 *   - select / radio-group   → enum editor + default-from-enum picker
 *   - slider / input(number) → min/max + default
 *   - toggle                 → default true/false
 *   - file-upload            → no extra config (default URL via the value editor)
 *   - textarea / input(text) → default text
 *   - json-input             → default JSON
 *
 * The ui_component itself is editable via a small picker at the top.
 */
function renderCustomConfigPanel(field) {
  const panel = el('div', {
    class: 'mt-2 mb-2',
    style: 'border: 1px solid hsl(var(--ait-m-border)); border-radius: 12px; padding: 0.6rem 0.75rem; background: hsl(var(--ait-m-secondary) / 0.25);',
  });

  // Heading + the field's id badge (so the author knows which field is being
  // edited — relevant when the key is wired to a shared field).
  panel.appendChild(el('div', { class: 'flex items-center gap-2 mb-2' },
    el('span', { class: 'text-xs font-bold uppercase tracking-wide', style: 'color: hsl(var(--ait-m-muted-foreground));' }, 'Custom config'),
    el('span', { class: 'ab-badge', style: 'background: transparent;' }, field.id),
    field.__custom
      ? el('span', { class: 'ab-badge custom' }, 'custom field')
      : el('span', { class: 'ab-badge catalog' }, 'catalog field'),
  ));

  // ui_component picker — type-aware downstream UI follows this choice.
  panel.appendChild(el('div', { class: 'field mb-2' },
    el('label', {}, 'Control type'),
    (() => {
      const sel = el('select', {
        onchange: (e) => {
          const newUi = e.target.value;
          if (newUi === field.ui_component) return;
          // Type transitions: when the new control no longer accepts enum
          // (e.g. select → slider), drop the stale enum so it doesn't show
          // up in stale validators. Same for range when leaving numeric.
          if (newUi !== 'select' && newUi !== 'radio-group') field.enum = null;
          if (newUi !== 'slider' && newUi !== 'input') field.range = null;
          field.ui_component = newUi;
          // type heuristic for the underlying JSON-Schema type
          if (newUi === 'toggle') field.type = 'boolean';
          else if (newUi === 'slider' || (newUi === 'input' && typeof field.default === 'number')) field.type = 'number';
          else field.type = 'string';
          notify();
        },
      });
      for (const uic of ['input', 'textarea', 'slider', 'select', 'radio-group', 'toggle', 'file-upload', 'json-input', 'interactive-prompt']) {
        const opt = el('option', { value: uic }, uiComponentLabelInline(uic));
        if (field.ui_component === uic) opt.selected = true;
        sel.appendChild(opt);
      }
      return sel;
    })(),
  ));

  // Pass 2's Custom config panel has no separate Cost-multiplier section,
  // so per-value cost inputs live inline in each option row.
  appendTypeSpecificConfig(panel, field, { inlineCost: true });

  return panel;
}

/**
 * Append the interactive-prompt config editor: template textarea + slot list
 * (one row per slot with name, enum options, default) + assembledTarget input.
 *
 * The widget at runtime (public/js/components/form/interactive-prompt.js)
 * renders the template as inline text with one clickable pill per slot. Each
 * slot needs an enum list of options; the chosen value substitutes into the
 * template, and the assembled string lands on `assembledTarget` (defaults to
 * the field id so step.schema can reference it with `${fieldId}`).
 */
function appendInteractivePromptEditor(panel, field) {
  // Ensure shape: template (string), slotFields ({name, enum[], default}[]),
  // assembledTarget (string).
  if (typeof field.template !== 'string') field.template = '';
  if (!Array.isArray(field.slotFields)) field.slotFields = [];
  // Normalise legacy shapes — slotFields can arrive as ["name"] string array
  // (from a raw JSON paste). Convert to the object shape the editor expects.
  field.slotFields = field.slotFields.map((s) => {
    if (typeof s === 'string') return { name: s, enum: [], default: '' };
    if (s && typeof s === 'object') {
      return {
        name: typeof s.name === 'string' ? s.name : '',
        enum: Array.isArray(s.enum) ? s.enum.map(String) : [],
        default: typeof s.default === 'string' ? s.default : '',
      };
    }
    return { name: '', enum: [], default: '' };
  });
  if (typeof field.assembledTarget !== 'string' || !field.assembledTarget) {
    field.assembledTarget = field.id;
  }

  // ---- Template editor ----
  const tmplWrap = el('div', { class: 'field mb-3' },
    el('label', {},
      'Template ',
      el('span', { class: 'text-xs text-muted-foreground font-normal' },
        '(use {slotName} for each interactive pill, e.g. "A {mood} cat in a {setting}.")'),
    ),
    (() => {
      const ta = el('textarea', {
        rows: 3,
        spellcheck: 'false',
        placeholder: 'A {mood} {style} cat in a {setting} at {timeOfDay}.',
        oninput: (e) => { field.template = e.target.value; notify(); },
      });
      ta.value = field.template || '';
      return ta;
    })(),
  );
  panel.appendChild(tmplWrap);

  // ---- Slot list ----
  const slotsWrap = el('div', { class: 'field mb-3' });
  slotsWrap.appendChild(el('label', {}, 'Slots'));

  const slotsContainer = el('div', { class: 'flex flex-col gap-2' });
  slotsWrap.appendChild(slotsContainer);

  const renderSlotRow = (slot, slotIdx) => {
    const row = el('div', {
      class: 'rounded-lg',
      style: 'padding: 0.6rem; background: hsl(var(--ait-m-muted) / 0.4); border: 1px solid hsl(var(--ait-m-border));',
    });

    const head = el('div', { class: 'flex gap-2 items-center mb-2' },
      el('span', { class: 'text-xs text-muted-foreground', style: 'min-width: 3rem;' }, 'Name'),
      el('input', {
        type: 'text',
        value: slot.name || '',
        placeholder: 'slotName',
        style: 'flex: 1; min-height: 32px;',
        oninput: (e) => {
          // Only [a-zA-Z0-9_] keeps it valid as a {placeholder} key.
          slot.name = String(e.target.value || '').replace(/[^a-zA-Z0-9_]/g, '');
          notify();
        },
      }),
      el('button', {
        type: 'button',
        class: 'btn danger',
        title: 'Remove slot',
        onclick: () => { field.slotFields.splice(slotIdx, 1); notify(); },
      }, '×'),
    );
    row.appendChild(head);

    const optsWrap = el('div', { class: 'flex flex-col gap-1' });
    optsWrap.appendChild(el('div', { class: 'text-xs text-muted-foreground' },
      'Options (one per line — each becomes a pill choice)'));
    const optsTa = el('textarea', {
      rows: 3,
      spellcheck: 'false',
      placeholder: 'cozy\nmoody\nplayful',
      oninput: (e) => {
        const lines = String(e.target.value || '')
          .split('\n')
          .map(s => s.trim())
          .filter(Boolean);
        slot.enum = lines;
        // If the current default is no longer in the enum, drop it.
        if (slot.default && !lines.includes(slot.default)) slot.default = '';
        notify();
      },
    });
    optsTa.value = Array.isArray(slot.enum) ? slot.enum.join('\n') : '';
    optsWrap.appendChild(optsTa);

    const defaultWrap = el('div', { class: 'flex items-center gap-2 mt-1' },
      el('span', { class: 'text-xs text-muted-foreground', style: 'min-width: 3rem;' }, 'Default'),
      (() => {
        const sel = el('select', {
          style: 'flex: 1;',
          onchange: (e) => { slot.default = e.target.value || ''; notify(); },
        });
        sel.appendChild(el('option', { value: '' }, '— first option —'));
        for (const opt of (slot.enum || [])) {
          const o = el('option', { value: String(opt) }, String(opt));
          if (slot.default === String(opt)) o.selected = true;
          sel.appendChild(o);
        }
        return sel;
      })(),
    );
    optsWrap.appendChild(defaultWrap);
    row.appendChild(optsWrap);

    return row;
  };

  for (let i = 0; i < field.slotFields.length; i++) {
    slotsContainer.appendChild(renderSlotRow(field.slotFields[i], i));
  }

  slotsWrap.appendChild(el('button', {
    type: 'button',
    class: 'btn',
    style: 'margin-top: 0.5rem;',
    onclick: () => {
      field.slotFields.push({ name: '', enum: [], default: '' });
      notify();
    },
  }, '+ Add slot'));

  panel.appendChild(slotsWrap);

  // ---- Assembled target ----
  panel.appendChild(el('div', { class: 'field mb-2' },
    el('label', {},
      'Assembled target ',
      el('span', { class: 'text-xs text-muted-foreground font-normal' },
        '(the assembled sentence lands on this key — defaults to the field id)'),
    ),
    el('input', {
      type: 'text',
      value: field.assembledTarget || field.id || '',
      placeholder: field.id || 'assembled',
      oninput: (e) => {
        const v = String(e.target.value || '').trim();
        field.assembledTarget = v || field.id;
        notify();
      },
    }),
  ));
}

/**
 * Append the type-aware config rows for a field to a parent node.
 *
 * Owns everything that the field's `ui_component` determines:
 *   - select / radio-group  → options array editor + default picker
 *   - slider / numeric input → range (min, max) + default
 *   - toggle                → default true/false
 *   - json-input            → default (JSON, falls back to raw)
 *   - textarea / input(text) / file-upload → default (plain text)
 *
 * Shared by the step's Custom config panel (Pass 2) and the Pass 3 field-row
 * editor so the two surfaces handle every type identically. Anything outside
 * the type-specific shape (title, description, visible/advanced flags,
 * costMultiplier) is the caller's responsibility — this helper is strictly
 * about "what shape does this widget take and what does its default look
 * like?".
 */
/**
 * @param {HTMLElement} panel
 * @param {object} field
 * @param {object} [config]
 * @param {boolean} [config.inlineCost=false]
 *   Forwarded to `renderEnumOptionsEditor` for select/radio fields. Pass 2's
 *   Custom config panel passes `true` (no separate cost section exists
 *   there); Pass 3's field row editor passes `false` because it renders its
 *   own dedicated "Cost multiplier" section beneath the options — keeping
 *   the per-value inputs in both places would duplicate the same control.
 *
 * (Parameter named `config` not `opts` on purpose — the select branch below
 *  has a local `const opts = ...` for the enum value list. Same name would
 *  trigger a temporal-dead-zone ReferenceError under strict mode.)
 */
export function appendTypeSpecificConfig(panel, field, config = {}) {
  const uic = field.ui_component;

  if (uic === 'interactive-prompt') {
    appendInteractivePromptEditor(panel, field);
    return;
  }

  if (uic === 'select' || uic === 'radio-group' || uic === 'prompt-picker' || uic === 'visual-picker'
      || uic === 'multi-select' || uic === 'editable-select') {
    // prompt-picker + visual-picker both render image thumbs per option;
    // visual-picker additionally surfaces a per-option category input (chip
    // filter in the runner modal) and a top-level trigger-label field. The
    // shared options editor (renderEnumOptionsEditor) toggles these via
    // withImages / withCategories. multi-select and editable-select use the
    // same enum-driven editor (plain options, no images / no categories).
    // See public/js/components/form/visual-picker.js for the runner-side
    // consumer of the image / category fields.
    const withImages = uic === 'prompt-picker' || uic === 'visual-picker';
    const withCategories = uic === 'visual-picker';
    panel.appendChild(renderEnumOptionsEditor(field, {
      inlineCost: !!config.inlineCost,
      withImages,
      withCategories,
    }));
    // visual-picker only — trigger-label text shown on the empty card BEFORE
    // the user opens the picker. Optional; falls back to the field's title.
    if (uic === 'visual-picker') {
      panel.appendChild(el('div', { class: 'field mb-2' },
        el('label', {},
          'Trigger label ',
          el('span', { class: 'text-xs text-muted-foreground font-normal' }, '(optional — shown on the closed picker card)')),
        el('input', {
          type: 'text',
          value: typeof field.triggerLabel === 'string' ? field.triggerLabel : '',
          placeholder: 'Choose Option',
          oninput: (e) => {
            const v = e.target.value.trim();
            field.triggerLabel = v ? v : null;
            notify();
          },
        }),
      ));
    }
    const opts = Array.isArray(field.enum) ? field.enum : [];
    if (opts.length) {
      panel.appendChild(el('div', { class: 'field mb-2' },
        el('label', {}, 'Default'),
        (() => {
          const sel = el('select', {
            onchange: (e) => { field.default = e.target.value === '' ? null : e.target.value; notify(); },
          });
          sel.appendChild(el('option', { value: '' }, '— none —'));
          for (const opt of opts) {
            const o = el('option', { value: String(opt) }, String(opt));
            if (field.default != null && String(field.default) === String(opt)) o.selected = true;
            sel.appendChild(o);
          }
          return sel;
        })(),
      ));
    }
  } else if (uic === 'slider' || (uic === 'input' && (field.type === 'number' || field.type === 'integer'))) {
    panel.appendChild(el('div', { class: 'field mb-2' },
      el('label', {}, 'Range (min, max)'),
      el('div', { class: 'flex gap-2' },
        el('input', {
          type: 'number',
          value: field.range?.min ?? '',
          placeholder: 'min',
          oninput: (e) => {
            const v = e.target.value === '' ? null : Number(e.target.value);
            field.range = { ...(field.range || {}), min: v };
            notify();
          },
        }),
        el('input', {
          type: 'number',
          value: field.range?.max ?? '',
          placeholder: 'max',
          oninput: (e) => {
            const v = e.target.value === '' ? null : Number(e.target.value);
            field.range = { ...(field.range || {}), max: v };
            notify();
          },
        }),
      ),
    ));
    panel.appendChild(el('div', { class: 'field mb-2' },
      el('label', {}, 'Default'),
      el('input', {
        type: 'number',
        value: field.default == null ? '' : String(field.default),
        placeholder: '(none)',
        oninput: (e) => { field.default = e.target.value === '' ? null : Number(e.target.value); notify(); },
      }),
    ));
  } else if (uic === 'toggle') {
    panel.appendChild(el('div', { class: 'field mb-2' },
      el('label', {}, 'Default'),
      (() => {
        const sel = el('select', {
          onchange: (e) => { field.default = e.target.value === 'true'; notify(); },
        });
        for (const v of ['false', 'true']) {
          const o = el('option', { value: v }, v);
          if (String(field.default ?? false) === v) o.selected = true;
          sel.appendChild(o);
        }
        return sel;
      })(),
    ));
  } else if (uic === 'json-input') {
    const wrap = el('div', { class: 'field mb-2' },
      el('label', {}, 'Default (JSON)'),
    );
    const ta = el('textarea', {
      rows: 2,
      spellcheck: 'false',
      oninput: (e) => {
        try { field.default = JSON.parse(e.target.value); }
        catch { field.default = e.target.value || null; }
        notify();
      },
    });
    ta.value = field.default == null ? '' : (typeof field.default === 'string' ? field.default : JSON.stringify(field.default));
    wrap.appendChild(ta);
    panel.appendChild(wrap);
  } else if (uic === 'color-picker') {
    // Default is a hex string. The runner widget accepts any CSS color string
    // but the picker UI starts in hex mode, so we validate loosely here.
    panel.appendChild(el('div', { class: 'field mb-2' },
      el('label', {}, 'Default (hex color, e.g. #FFFFFF)'),
      el('input', {
        type: 'text',
        value: field.default == null ? '' : String(field.default),
        placeholder: '#FFFFFF',
        oninput: (e) => { field.default = e.target.value === '' ? null : e.target.value; notify(); },
      }),
    ));
  } else if (uic === 'image-pair') {
    // image-pair has no editable defaults — the runner widget collects two
    // image URLs at run time. Surface a short helper note so the row editor
    // isn't blank.
    panel.appendChild(el('div', { class: 'field mb-2 text-xs text-muted-foreground' },
      'Image-pair fields collect two image URLs (start + end frames) at run time. No defaults.',
    ));
  } else {
    // textarea / input (text) / file-upload — single default text input
    panel.appendChild(el('div', { class: 'field mb-2' },
      el('label', {}, 'Default'),
      el('input', {
        type: 'text',
        value: field.default == null ? '' : String(field.default),
        placeholder: '(none)',
        oninput: (e) => { field.default = e.target.value === '' ? null : e.target.value; notify(); },
      }),
    ));
  }
}

/**
 * Render the SOUL textarea — the wizard's top-level prompt for the step.
 *
 * Soul is always shown. Every keystroke runs the auto-promote pass against
 * `state.agent.fields`, so the moment the author types `${shadowPrompt}` a
 * matching field appears on Pass 3. The card styling mirrors the prompt card
 * (`.ab-schema-prompt`) so the SOUL section reads as the step's spine.
 */
function renderSoulEditor(step, stepIdx) {
  // Upstream steps as full objects (not just ids) so the tag row can also offer
  // a content-research step's structured sub-fields (${research.priceTrend}).
  const upstreamSteps = state.agent.steps.slice(0, stepIdx).filter(s => s && s.output_id);
  const upstreamOutputs = upstreamSteps.map(s => s.output_id);
  // Defensive filter: `prompt` is a reserved id (soul owns the prompt-shaped
  // text). Even if a stray field with that id slipped through migration, the
  // SOUL card refuses to suggest it as a tag.
  const fieldIds = state.agent.fields.map(f => f.id).filter(id => id !== 'prompt');

  const block = el('div', { class: 'ab-schema-prompt' });
  block.appendChild(el('div', { class: 'text-xs text-muted-foreground mb-2' },
    'Describe what this step does. Click a tag below to insert a placeholder ',
    el('code', {}, '${id}'),
    ', or type one by hand. Names that aren\'t yet on the Fields pass will be flagged so you can add them how you like.',
  ));

  // The warning row is a separate node we live-patch on every keystroke so
  // the unresolved-placeholder feedback updates without waiting for a full
  // list rebuild. The focus-aware skip in `renderStepsPass` blocks rebuild
  // while the textarea has focus (that's how we keep caret + AltGr working);
  // patching this single node here keeps the warning responsive without
  // touching anything else.
  const warnSlot = el('div', { class: 'ab-soul-warning-slot' });
  const repaintWarning = () => {
    warnSlot.innerHTML = '';
    const ids = unresolvedPlaceholderIds(step.soul, upstreamOutputs);
    if (!ids.length) return;
    const warn = el('div', {
      class: 'ab-soul-warning',
      style: 'margin-top: 0.6rem; padding: 0.55rem 0.75rem; border-radius: 10px; '
        + 'background: rgba(245,158,11,0.08); border: 1px solid rgba(245,158,11,0.35); '
        + 'color: hsl(var(--ait-m-foreground)); font-size: 0.78rem; line-height: 1.5;',
    });
    warn.appendChild(el('div', { style: 'font-weight: 700; margin-bottom: 0.2rem;' },
      'These placeholders aren\'t on the Fields pass yet:',
    ));
    const tagWrap = el('div', { class: 'flex flex-wrap gap-1' });
    for (const id of ids) {
      tagWrap.appendChild(el('span', {
        class: 'ab-tag',
        style: 'background: rgba(245,158,11,0.18); border-color: rgba(245,158,11,0.45);',
      }, '${' + id + '}'));
    }
    warn.appendChild(tagWrap);
    warn.appendChild(el('div', { style: 'margin-top: 0.35rem; color: hsl(var(--ait-m-muted-foreground));' },
      'Add them on the Fields pass (catalog or custom) before publishing, or remove the references here.',
    ));
    warnSlot.appendChild(warn);
  };

  const ta = el('textarea', {
    rows: 6,
    spellcheck: 'false',
    oninput: (e) => {
      step.soul = e.target.value;
      // Live-patch the warning row before delegating to notify(). The full
      // list rebuild from notify() will be skipped while the textarea owns
      // focus, but this DOM mutation lands immediately so the author sees
      // unresolved ids as they type.
      repaintWarning();
      notify();
    },
  });
  ta.value = step.soul || '';
  block.appendChild(ta);
  appendTagRows(block, ta, fieldIds, upstreamOutputs, upstreamSteps);
  block.appendChild(warnSlot);
  repaintWarning();

  return block;
}

/**
 * Walk a string for `${id}` placeholders and return the ids that don't
 * resolve against either an existing form field or an upstream step output.
 * Excludes the reserved `prompt` id — it's runtime-substituted from soul,
 * never represented as a field.
 */
function unresolvedPlaceholderIds(text, upstreamOutputIds) {
  if (typeof text !== 'string' || !text) return [];
  const known = new Set([
    ...state.agent.fields.map(f => f.id),
    ...(upstreamOutputIds || []).filter(Boolean),
    'prompt',
  ]);
  const seen = new Set();
  const out = [];
  // Allow dot-paths (${research.priceTrend}); only the ROOT must be known,
  // since a content-research output's sub-fields aren't fields/outputs of
  // their own.
  const re = /\$\{([a-zA-Z0-9_.-]+)\}/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    const id = m[1];
    const root = id.split('.')[0];
    if (known.has(root) || seen.has(id)) continue;
    seen.add(id);
    out.push(id);
  }
  return out;
}

// True when the step's model exposes the r2v routing flag (union schema carried
// `supportsReference`). Read off the rehydrated meta, not the live network.
function stepSupportsReference(step) {
  return step.__supportsReference === true;
}

// Whether reference mode is currently ON for this step. The flag lives in
// step.schema so it persists into the published agent JSON and reaches the
// runtime router untouched.
function isReferenceModeOn(step) {
  return step.schema?.[REFERENCE_MODE_KEY] === true;
}

// Hide a key from the editor when it doesn't apply to the active mode. Thin
// wrapper over the shared classifier (refModeHides) gated on this step's state.
function stepHidesKey(step, prop) {
  if (!stepSupportsReference(step)) return false;
  return refModeHides(prop, isReferenceModeOn(step));
}

// Remove wired keys that don't belong to the active mode, so the schema never
// ships both `image` (i2v) and `image_urls` (r2v). ON drops standard keys, OFF
// drops reference keys; neutral keys stay.
function pruneReferenceModeKeys(step, on) {
  const props = step.__schemaMeta?.properties || {};
  for (const key of Object.keys(step.schema)) {
    if (key === REFERENCE_MODE_KEY) continue;
    const cls = referenceModeClassOf(props[key]);
    if (cls === null) continue;
    if (on ? cls === 'standard' : cls === 'reference') delete step.schema[key];
  }
}

// The "Reference mode" toggle row. Shown only when the model advertises an r2v
// endpoint (supportsReference). Flipping it writes step.schema.referenceMode and
// re-renders so the mode-gated field visibility updates. Styled to match the
// model page playground toggle.
function renderReferenceModeToggle(step) {
  const on = isReferenceModeOn(step);
  const row = el('label', {
    class: 'flex items-center justify-between gap-3 rounded-lg border p-3 mb-3 cursor-pointer select-none',
    style: 'border-color: hsl(var(--ait-m-border)); background: hsl(var(--ait-m-muted) / 0.3);',
  });
  const text = el('div', { class: 'min-w-0' },
    el('div', { class: 'text-sm font-medium' }, 'Reference mode'),
    el('div', { class: 'text-xs text-muted-foreground' },
      'Route to the reference-to-* endpoint: reference media arrays are used; the start-frame image is ignored.'),
  );
  const checkbox = el('input', {
    type: 'checkbox',
    role: 'switch',
    checked: on,
    style: 'width: 2.25rem; height: 1.25rem; flex-shrink: 0;',
    onchange: (e) => {
      const checked = e.target.checked;
      if (checked) step.schema[REFERENCE_MODE_KEY] = true;
      else delete step.schema[REFERENCE_MODE_KEY];
      pruneReferenceModeKeys(step, checked);
      notify();
    },
  });
  row.appendChild(text);
  row.appendChild(checkbox);
  return row;
}

function renderSchemaKeyEditor(step, stepIdx, key, isRequired) {
  const prop = step.__schemaMeta?.properties?.[key] || {};
  const value = step.schema[key];
  const isPrompt = key === 'prompt';

  const upstreamOutputs = state.agent.steps.slice(0, stepIdx).map(s => s.output_id).filter(Boolean);
  // `prompt` is reserved (soul owns prompt-shaped text); never suggest it as
  // a tag, even if a stray field with that id survived migration.
  const fieldIds = state.agent.fields.map(f => f.id).filter(id => id !== 'prompt');

  // Prompt gets a fully styled card (`.ab-schema-prompt`); it lives in its own
  // section above Required/Optional and never shares visual language with
  // ordinary schema rows. The card already supplies its own padding/border,
  // so we leave its inline style blank here.
  //
  // Every other key gets a flat row — no left border, no accent tint — so
  // nothing else can be mistaken for the prompt. The "required" badge in the
  // header carries the only signal of required-ness for non-prompt keys.
  const blockClass = isPrompt
    ? 'ab-schema-prompt'
    : 'mb-3 pl-1';
  const blockStyle = '';

  const block = el('div', { class: blockClass, style: blockStyle });

  // The header row differs for prompt vs other keys.
  //
  // Prompt: the section above the card already carries the "PROMPT" heading;
  //         repeating "✦ prompt [required] [string]" inside the same card is
  //         visual noise. We render only the short helper line.
  //
  // Other keys: checkbox (locked on for required, toggleable for optional)
  //         + key name + required/optional badge + type badge.
  if (isPrompt) {
    block.appendChild(el('div', { class: 'text-xs text-muted-foreground mb-2' },
      'The prompt is where every form value wires into the model. Click a tag below to insert it at the caret. Type ',
      el('code', {}, '${anything}'),
      ' and the builder turns "anything" into a form field for you.',
    ));
  } else {
    const header = el('div', { class: 'flex items-center gap-2 mb-1' },
      (() => {
        const cb = el('input', {
          type: 'checkbox',
          checked: true,
          disabled: isRequired,
          onchange: (e) => {
            if (isRequired) return;
            if (!e.target.checked) {
              delete step.schema[key];
              if (!step.__optionalAvailable) step.__optionalAvailable = [];
              if (!step.__optionalAvailable.includes(key)) step.__optionalAvailable.push(key);
              pruneOrphanAutoAddedFields();
              notify();
            }
          },
        });
        return cb;
      })(),
      el('span', { class: 'font-mono text-sm font-bold' }, key),
      isRequired
        ? el('span', { class: 'ab-badge', style: 'background: hsl(var(--ait-m-primary) / 0.12); color: hsl(var(--ait-m-primary)); border-color: hsl(var(--ait-m-primary) / 0.35);' }, 'required')
        : el('span', { class: 'ab-badge' }, 'optional'),
      prop.type ? el('span', { class: 'ab-badge' }, String(prop.type)) : null,
    );
    block.appendChild(header);
    if (prop.description) {
      block.appendChild(el('div', { class: 'text-xs text-muted-foreground mb-1' }, prop.description));
    }
  }

  // Mode model — From input-mapping vs Custom. BOTH branches produce a form
  // field; the difference is who owns the field's shape:
  //
  //   - **From input-mapping** → the catalog (`AGENT_INPUT_MAP`) owns the
  //     defaults. Field is a compact `{ id: conceptId }` entry; catalog
  //     supplies ui_component / enum / range / default at runtime. When the
  //     key has no catalog match, falls back to a custom field with the same
  //     schema-key id (the radio is still meaningful — the placeholder gets
  //     wired either way).
  //
  //   - **Custom** → the AGENT owns the shape. Field is a fully-spec'd
  //     `__custom: true` entry; catalog defaults are NOT inherited even if
  //     a concept with the same id exists. Author tunes ui_component, enum,
  //     range, default by hand.
  //
  // In both modes `step.schema[key]` is `${fieldId}` — never a literal. The
  // earlier "literal value in step.schema" path was wrong for required keys:
  // a literal "" silently shipped to the model, causing 422s. Defaults now
  // live on the FIELD (visible in Pass 4), not on the step.
  const resolved = resolveSchemaControl(key, prop);
  const boundField = boundFieldFor(step, key);
  const mode = boundField && boundField.__custom ? 'custom' : 'mapping';

  const effective = boundField
    ? {
        uiComponent: boundField.ui_component || resolved.uiComponent,
        enum: Array.isArray(boundField.enum) && boundField.enum.length ? boundField.enum : null,
      }
    : {
        uiComponent: resolved.uiComponent,
        enum: Array.isArray(prop.enum) && prop.enum.length
          ? prop.enum
          : (Array.isArray(resolved.enum) ? resolved.enum : null),
      };
  const effectiveControl = effective.uiComponent;
  const effectiveEnum = effective.enum;

  const valueLooksLikePlaceholder = typeof value === 'string' && /\$\{[a-zA-Z0-9_-]+\}/.test(value);
  const structuredControls = new Set(['select', 'radio-group', 'toggle', 'slider', 'file-upload']);
  // Placeholder mode is the textarea+tags fallback for a key whose resolved
  // widget is structured (select / toggle / slider / file-upload) but the
  // author wants to wire to a `${...}` reference instead of picking a literal.
  //
  // Three triggers, in priority order:
  //   1. Explicit toggle flag — the author clicked "Use placeholder instead",
  //      which sets `step.__placeholderMode[key] = true`. Clicking it again
  //      flips the flag off and snaps back to the structured widget. This is
  //      the toggle the author asked for; it survives partial placeholder
  //      typing (`${`, `${ab`) that wouldn't otherwise match the regex.
  //   2. Implicit — the value already looks like a real placeholder
  //      (`${something}`). The structured widget can't represent that, so we
  //      drop to textarea automatically.
  //   3. Canonical bound field — handled by the Custom panel, not this path.
  const explicitPlaceholderMode = !!(step.__placeholderMode && step.__placeholderMode[key]);
  const useTextareaForPlaceholder = !boundField && structuredControls.has(effectiveControl) && (
    explicitPlaceholderMode || valueLooksLikePlaceholder
  );

  // Mode toggle row — only meaningful for schema keys that *could* be
  // a structured form input. The prompt is a free-form template (it carries
  // ${...} placeholders, not a literal value the end user picks), so the
  // Custom panel's concepts of "options / range / default" do not apply.
  // We skip the entire Source toggle on prompt rows.
  if (!isPrompt) {
    const radioName = `mode-${stepIdx}-${key}`;

    const radioMapping = el('input', {
      type: 'radio', name: radioName, id: `${radioName}-mapping`,
      onchange: () => { promoteKeyToMappingField(step, key, prop); notify(); },
    });
    if (mode === 'mapping') radioMapping.checked = true;

    const radioCustom = el('input', {
      type: 'radio', name: radioName, id: `${radioName}-custom`,
      onchange: () => { promoteKeyToCustomField(step, key, prop); notify(); },
    });
    if (mode === 'custom') radioCustom.checked = true;

    const modeRow = el('div', {
      class: 'flex items-center gap-3 mt-1 mb-2 flex-wrap text-xs',
      style: 'white-space: nowrap;',
    },
      el('span', { class: 'text-muted-foreground' }, 'Source:'),
      el('label', { for: `${radioName}-mapping`, class: 'flex items-center gap-1 cursor-pointer' },
        radioMapping, 'From input-mapping',
      ),
      el('label', { for: `${radioName}-custom`, class: 'flex items-center gap-1 cursor-pointer' },
        radioCustom, 'Custom',
      ),
      resolved.conceptId && mode === 'mapping' && boundField
        ? el('span', { class: 'ab-badge', title: 'Resolved from AGENT_INPUT_MAP' },
            'via ', resolved.conceptId, ' (', resolved.source.replace('catalog-', ''), ')')
        : null,
    );
    block.appendChild(modeRow);

    if (mode === 'custom' && boundField) {
      block.appendChild(renderCustomConfigPanel(boundField));
      // Custom config panel already owns the entire shape (control type +
      // type-aware default/options/range). `step.schema[key]` is wired to
      // `${boundField.id}` — there is no literal-value editor to render
      // underneath. Skip the widget renderers below so we don't surface a
      // second textarea + tag-rows that would write into step.schema[key]
      // and break the wiring on the first keystroke.
      return block;
    }

    // Mapping mode: field lives in Pass 4 (Fields), edited there. Surface a
    // short pointer + the wired placeholder so the author knows the wiring
    // is in place. No widget here — the actual input control belongs to the
    // end-user form on Pass 4.
    if (mode === 'mapping' && boundField) {
      const conceptHint = resolved.conceptId
        ? `catalog field "${resolved.conceptId}"`
        : `custom field "${boundField.id}" (no catalog match for this key)`;
      const note = el('div', {
        class: 'text-xs text-muted-foreground mt-1',
        style: 'padding: 0.4rem 0.6rem; border-radius: 10px; background: hsl(var(--ait-m-secondary) / 0.4);',
      },
        'Wired to ', conceptHint, ' as ',
        el('code', {}, '${' + boundField.id + '}'),
        '. Edit title / default / enum / range on the ',
        el('a', {
          href: '#', style: 'color: hsl(var(--ait-m-primary)); font-weight: 600; text-decoration: underline;',
          onclick: (e) => { e.preventDefault(); state.pass = 4; notify(); },
        }, 'Fields tab'),
        '.',
      );
      block.appendChild(note);
      // The author must always be able to drop this key to a free-form dynamic
      // placeholder (`${anyField}` / `${upstreamOutput}`) WITHOUT being forced
      // through a form field. Offer an explicit escape from mapping mode: detach
      // the auto-wired field and flip into placeholder (textarea + tags) mode.
      block.appendChild(el('button', {
        class: 'btn', type: 'button', style: 'margin-top: 0.4rem;',
        onclick: () => {
          if (!step.__placeholderMode) step.__placeholderMode = {};
          step.__placeholderMode[key] = true;
          step.schema[key] = '';
          // Drop the auto-added field this key used to reference (manual fields
          // are never touched by the prune).
          pruneOrphanAutoAddedFields();
          notify();
        },
      }, 'Use placeholder instead'));
      // Skip the literal widget renderers below — value is already a
      // `${placeholder}`, not a literal the author types here.
      return block;
    }
  }

  /* ----------- Widget renderers ----------- */

  if (useTextareaForPlaceholder) {
    // Placeholder mode (textarea + tags). The same button that flipped us
    // here flips us back: clear the explicit-mode flag and reset the value
    // to a sensible literal for the resolved widget. This is the toggle UX
    // the author asked for — one button, two states.
    const ta = el('textarea', {
      rows: 2, spellcheck: 'false',
      oninput: (e) => { applyStringValue(step, key, e.target.value); notify(); },
    });
    ta.value = typeof value === 'string' ? value : '';
    block.appendChild(ta);
    appendTagRows(block, ta, fieldIds, upstreamOutputs);
    block.appendChild(el('button', {
      class: 'btn primary', type: 'button', style: 'margin-top: 0.4rem;',
      onclick: () => {
        if (step.__placeholderMode) delete step.__placeholderMode[key];
        if (effectiveControl === 'toggle') step.schema[key] = false;
        else if (effectiveControl === 'select' || effectiveControl === 'radio-group') step.schema[key] = effectiveEnum?.[0] ?? '';
        else step.schema[key] = '';
        notify();
      },
    }, 'Back to ', uiComponentLabelInline(effectiveControl)));

  } else if (effectiveControl === 'toggle') {
    // Literal on/off value shipped to the model. Wrap the checkbox in a label
    // so it isn't an orphaned, unexplained checkbox in the form.
    const cb = el('input', {
      type: 'checkbox',
      onchange: (e) => { step.schema[key] = e.target.checked; notify(); },
    });
    if (value === true) cb.checked = true;
    block.appendChild(el('label', { class: 'flex items-center gap-2 cursor-pointer text-sm' },
      cb, 'Send ', el('code', {}, key + ' = ' + (value === true ? 'true' : 'false')),
    ));
    if (fieldIds.length || upstreamOutputs.length) {
      block.appendChild(el('button', {
        class: 'btn', type: 'button', style: 'margin-top: 0.4rem;',
        onclick: () => {
          if (!step.__placeholderMode) step.__placeholderMode = {};
          step.__placeholderMode[key] = true;
          step.schema[key] = '';
          pruneOrphanAutoAddedFields();
          notify();
        },
      }, 'Use placeholder instead'));
    }

  } else if (effectiveControl === 'select' || effectiveControl === 'radio-group') {
    const choices = effectiveEnum || [];
    if (!choices.length) {
      // Catalog hinted at a select but no enum is available — fall back to a
      // text input so the author can at least type a value.
      const inp = el('input', {
        type: 'text', value: value == null ? '' : String(value),
        oninput: (e) => { applyStringValue(step, key, e.target.value); notify(); },
      });
      block.appendChild(inp);
    } else {
      const sel = el('select', {
        onchange: (e) => { step.schema[key] = e.target.value; notify(); },
      });
      if (value === '' || value == null) sel.appendChild(el('option', { value: '' }, '— pick —'));
      for (const opt of choices) {
        const o = el('option', { value: String(opt) }, String(opt));
        if (value != null && String(value) === String(opt)) o.selected = true;
        sel.appendChild(o);
      }
      block.appendChild(sel);
    }
    if (fieldIds.length || upstreamOutputs.length) {
      block.appendChild(el('button', {
        class: 'btn', type: 'button', style: 'margin-top: 0.4rem;',
        onclick: () => {
          // Flip the explicit placeholder-mode flag on so the next render
          // drops to the textarea+tags editor. We clear the value so the
          // author starts from a clean slate; they pick a tag from the row
          // underneath to insert the actual `${id}`.
          if (!step.__placeholderMode) step.__placeholderMode = {};
          step.__placeholderMode[key] = true;
          step.schema[key] = '';
          // Clearing the wire may have orphaned the auto-added field this key
          // used to reference. Drop it from the form unless another step still
          // points at it (manual fields are never touched by the prune).
          pruneOrphanAutoAddedFields();
          notify();
        },
      }, 'Use placeholder instead'));
    }

  } else if (effectiveControl === 'slider' || effectiveControl === 'input' && (prop.type === 'integer' || prop.type === 'number')) {
    // Slider and numeric `input` collapse to the same renderer in the editor:
    // a numeric input with min/max hints. We don't render an actual range
    // slider because the author is setting a fixed value, not exposing the
    // slider to the end user (the runner does that based on `ui_component`).
    const inp = el('input', {
      type: 'number',
      value: typeof value === 'number' ? String(value) : '',
      min: prop.minimum != null ? String(prop.minimum) : undefined,
      max: prop.maximum != null ? String(prop.maximum) : undefined,
      oninput: (e) => {
        step.schema[key] = e.target.value === '' ? null : Number(e.target.value);
        notify();
      },
    });
    block.appendChild(inp);

  } else if (effectiveControl === 'file-upload') {
    // The wizard authoring surface doesn't actually upload — at design time
    // the author is wiring this key to either a form-field placeholder
    // (`${background}`) or pasting a known URL. Show a URL input with the
    // tag rows underneath so the wiring stays one click away.
    const inp = el('input', {
      type: 'text',
      value: value == null ? '' : String(value),
      placeholder: 'Paste an image/video/audio URL, or click a tag below',
      oninput: (e) => { applyStringValue(step, key, e.target.value); notify(); },
    });
    block.appendChild(inp);
    appendTagRows(block, inp, fieldIds, upstreamOutputs);

  } else if (effectiveControl === 'json-input' || Array.isArray(value) || (prop.type === 'array' || prop.type === 'object')) {
    // Arrays/objects are stored as JSON in this branch to preserve nested
    // shapes. But the author must ALSO be able to wire this key to a dynamic
    // `${field}` / `${output}` placeholder instead of pasting a literal — the
    // same freedom every other control gives. A bare `${id}` (or an array
    // literal of them) is kept as a string so the runtime resolver sees the
    // placeholder; only genuine JSON literals get parsed.
    const ta = el('textarea', {
      rows: 2, spellcheck: 'false',
      placeholder: 'Paste JSON, or click a tag below to wire a ${placeholder}',
      oninput: (e) => {
        const raw = e.target.value;
        // Preserve placeholder wiring verbatim — never JSON.parse a value that
        // carries a `${...}` reference (that's how `audio_urls`, `image_input`,
        // etc. get a dynamic field/output instead of a hardcoded literal).
        if (/\$\{[a-zA-Z0-9_.-]+\}/.test(raw)) { step.schema[key] = raw; notify(); return; }
        try { step.schema[key] = JSON.parse(raw); }
        catch { step.schema[key] = raw; }
        notify();
      },
    });
    ta.value = typeof value === 'string' ? value : JSON.stringify(value);
    block.appendChild(ta);
    // Tag rows so a field/output can be wired with one click — without this,
    // array/object keys (e.g. audio_urls, reference_images) had no UI path to
    // a dynamic placeholder and forced the author to add a form field.
    appendTagRows(block, ta, fieldIds, upstreamOutputs);

  } else {
    // Textarea — the workhorse for prompt templates and any free-form string.
    // `applyStringValue` runs the auto-promote pass on every keystroke: type
    // `${shadowPrompt}` in the prompt and a custom textarea field
    // `shadowPrompt` appears in Pass 3 the same moment. Upstream output ids
    // and existing fields are recognised, so they're not duplicated.
    const initial = (value == null) ? '' : String(value);
    const ta = el('textarea', {
      rows: isPrompt ? 6 : 2,
      spellcheck: 'false',
      oninput: (e) => { applyStringValue(step, key, e.target.value); notify(); },
    });
    ta.value = initial;
    block.appendChild(ta);
    appendTagRows(block, ta, fieldIds, upstreamOutputs);
  }

  // Range hint — surfaced for any numeric widget that has bounds.
  if (prop.minimum != null || prop.maximum != null) {
    block.appendChild(el('div', { class: 'text-xs text-muted-foreground mt-1' },
      'Range: ', String(prop.minimum ?? '-∞'), ' … ', String(prop.maximum ?? '+∞')));
  }

  return block;
}

function appendTagRows(container, textarea, fieldIds, upstreamOutputs, upstreamSteps) {
  if (fieldIds.length) {
    container.appendChild(el('div', { class: 'ab-tags' },
      el('span', { class: 'text-xs text-muted-foreground mr-1' }, 'Fields:'),
      ...fieldIds.map(id => el('span', {
        class: 'ab-tag',
        onclick: () => insertAtCaret(textarea, `\${${id}}`),
      }, '${', id, '}'))
    ));
  }
  if (upstreamOutputs.length) {
    // Build the upstream tag list. For a content-research step that declares an
    // outputSchema, also offer each top-level field as ${output_id.field} so the
    // author can wire a specific piece of the structured result, not just the
    // whole object.
    const tags = [];
    const stepsById = new Map((upstreamSteps || []).map(s => [s.output_id, s]));
    for (const id of upstreamOutputs) {
      tags.push({ token: id, label: '${' + id + '}' });
      const up = stepsById.get(id);
      // Sub-field pills only for a JSON-format content-research step that
      // declares fields — a text step has no addressable sub-fields.
      const props = up && up.kind === 'content-research' && up.outputFormat === 'json'
        && up.outputSchema && typeof up.outputSchema === 'object'
        ? up.outputSchema.properties
        : null;
      if (props && typeof props === 'object') {
        for (const key of Object.keys(props)) {
          tags.push({ token: `${id}.${key}`, label: '${' + id + '.' + key + '}' });
        }
      }
    }
    container.appendChild(el('div', { class: 'ab-tags' },
      el('span', { class: 'text-xs text-muted-foreground mr-1' }, 'Upstream:'),
      ...tags.map(t => el('span', {
        class: 'ab-tag output',
        onclick: () => insertAtCaret(textarea, `\${${t.token}}`),
      }, t.label))
    ));
  }
}

function renderSchemaEditor(step, stepIdx) {
  const container = el('div', { class: 'mt-3' });

  if (step.__schemaLoading) {
    container.appendChild(el('div', { class: 'text-sm text-muted-foreground p-3' }, 'Loading model schema…'));
    return container;
  }
  if (!step.model_id) {
    container.appendChild(el('div', { class: 'text-sm text-muted-foreground p-3' }, 'Pick a model to load its input schema.'));
    return container;
  }
  if (!step.__schemaMeta) {
    container.appendChild(el('div', { class: 'text-sm text-muted-foreground p-3' },
      'No schema metadata yet. ',
      el('button', {
        class: 'btn', type: 'button', style: 'margin-left: 0.5rem;',
        onclick: () => loadAndApplySchema(step),
      }, 'Retry'),
    ));
    return container;
  }

  const required = step.__schemaMeta.required || [];
  const requiredSet = new Set(required);
  const props = step.__schemaMeta.properties || {};

  // SOUL — the wizard's top-level prompt. Always present, regardless of
  // whether the model schema declares a `prompt` property. The author types
  // here; at publish/runtime, the resolver substitutes soul into
  // `schema.prompt` when the model accepts one and the schema's own prompt
  // key is left empty. When the model doesn't take a prompt at all (a
  // background remover, an upscaler), soul is still useful as an authoring
  // note + as the placeholder discovery surface — every `${id}` the author
  // writes here auto-promotes a field on Pass 3.
  if (typeof step.soul !== 'string') step.soul = '';
  const soulSection = el('div', { class: 'mb-4' });
  soulSection.appendChild(
    el('h4', {
      class: 'text-xs font-bold uppercase tracking-wide mb-2',
      style: 'color: hsl(var(--ait-m-primary)); letter-spacing: 0.08em;',
      title: "Soul is the wizard's top-level prompt. Every ${placeholder} you write becomes a form field.",
    },
      'Soul ',
      el('span', { style: 'font-weight: 600; color: hsl(var(--ait-m-muted-foreground)); text-transform: none; letter-spacing: 0;' },
        '— top-level prompt for this step',
      ),
    )
  );
  soulSection.appendChild(renderSoulEditor(step, stepIdx));
  container.appendChild(soulSection);
  container.appendChild(el('hr', { style: 'border: 0; border-top: 1px dashed hsl(var(--ait-m-border)); margin: 0.25rem 0 0.75rem;' }));

  // Reference-mode toggle (only for models with an r2v endpoint). Sits at the
  // top because it gates which inputs apply, mirroring the model page.
  if (stepSupportsReference(step)) {
    container.appendChild(renderReferenceModeToggle(step));
  }

  // The model's own `prompt` key (if it declares one) is intentionally hidden
  // from the editor: the runtime substitutes soul into it when it's blank, so
  // exposing two prompt-shaped textareas would just create confusion. The key
  // stays in step.schema as `""` and is filtered out of both blocks below.
  // Reference-mode also gates visibility: keys that belong only to the inactive
  // route (reference-only while OFF, singular-frame while ON) are filtered out.
  const hidden = (k) => stepHidesKey(step, props[k]);
  const requiredOthers = required.filter(k => !RESERVED_SCHEMA_KEYS.has(k) && !hidden(k));
  const enabledOptionalKeys = Object.keys(step.schema).filter(k => !requiredSet.has(k) && !RESERVED_SCHEMA_KEYS.has(k) && !hidden(k));
  const stillAvailable = (step.__optionalAvailable || []).filter(k => !(k in step.schema) && !RESERVED_SCHEMA_KEYS.has(k) && !hidden(k));

  // Required block (without prompt — already in its own section above)
  if (requiredOthers.length) {
    container.appendChild(el('h4', { class: 'text-xs font-bold uppercase tracking-wide mt-2 mb-2', style: 'color: hsl(var(--ait-m-muted-foreground));' }, 'Required'));
    for (const key of requiredOthers) {
      container.appendChild(renderSchemaKeyEditor(step, stepIdx, key, true));
    }
  }

  // Enabled optional block
  if (enabledOptionalKeys.length) {
    container.appendChild(el('h4', { class: 'text-xs font-bold uppercase tracking-wide mt-3 mb-2', style: 'color: hsl(var(--ait-m-muted-foreground));' }, 'Optional (enabled)'));
    for (const key of enabledOptionalKeys) {
      container.appendChild(renderSchemaKeyEditor(step, stepIdx, key, false));
    }
  }

  // Add-optional row. Enabling an optional key with a catalog match runs the
  // auto-field detour: the canonical field is added to `state.agent.fields`
  // (if not already there) and `step.schema[key]` is wired to `${field_id}`.
  // The author can still flip the row's Control selector to override.
  if (stillAvailable.length) {
    const add = el('div', { class: 'flex items-center gap-2 mt-3 flex-wrap' },
      el('span', { class: 'text-xs text-muted-foreground' }, 'Enable optional:'),
      ...stillAvailable.map(key => el('button', {
        class: 'btn', type: 'button',
        onclick: () => {
          // Enabling an optional key: if the model property has no default,
          // auto-promote it to a form field (same bridge as required keys).
          // If the property does have a default, seed that as a literal — the
          // author can still flip Source: Custom to promote it later.
          const prop = step.__schemaMeta?.properties?.[key];
          // "Has a usable default" = a non-empty literal we can seed. Empty
          // strings, nulls, empty arrays and empty objects all count as
          // "no default" — they wouldn't help the model anyway, and the
          // author wanting to fill this slot still needs a wire.
          const rawDefault = prop && Object.prototype.hasOwnProperty.call(prop, 'default') ? prop.default : undefined;
          const isEmptyDefault =
            rawDefault === undefined ||
            rawDefault === null ||
            rawDefault === '' ||
            (Array.isArray(rawDefault) && rawDefault.length === 0) ||
            (typeof rawDefault === 'object' && !Array.isArray(rawDefault) && Object.keys(rawDefault).length === 0);
          const hasDefault = !isEmptyDefault;
          if (hasDefault) {
            step.schema[key] = rawDefault;
          } else {
            const fieldId = ensureFieldForRequiredKey(key, prop);
            step.schema[key] = '${' + fieldId + '}';
          }
          step.__optionalAvailable = (step.__optionalAvailable || []).filter(k => k !== key);
          notify();
        },
      }, '+ ' + key)),
    );
    container.appendChild(add);
  }

  // Placeholder validation summary
  const refs = placeholdersInSchema(step.schema);
  if (refs.length) {
    const fieldIds = new Set(state.agent.fields.map(f => f.id));
    const allOutputs = new Set(state.agent.steps.map(s => s.output_id).filter(Boolean));
    const bad = refs.filter(r => !fieldIds.has(r) && !allOutputs.has(r));
    if (bad.length) {
      container.appendChild(el('div', { class: 'ab-error mt-3' }, 'Unresolved: ' + bad.map(b => `\${${b}}`).join(', ')));
    }
  }

  return container;
}

// ---------------------------------------------------------------------------
// Output fields editor (content-research) — visual, not raw JSON
// ---------------------------------------------------------------------------

// Scalar types only — research output schema is flat so downstream
// `${output_id.field}` dot-paths always resolve (nested object/array fields
// the model often emits as a string, breaking the deep path).
const CR_OUTPUT_TYPES = [
  { value: 'string', label: 'Text' },
  { value: 'number', label: 'Number' },
  { value: 'boolean', label: 'Yes/No' },
];

/** Read step.outputSchema → a flat field list the editor renders. */
function outputSchemaToFields(schema) {
  if (!schema || typeof schema !== 'object' || !schema.properties) return [];
  const required = Array.isArray(schema.required) ? schema.required : [];
  return Object.entries(schema.properties).map(([name, def]) => {
    const d = def && typeof def === 'object' ? def : {};
    const type = d.type || 'string';
    return {
      name,
      type: CR_OUTPUT_TYPES.some(t => t.value === type) ? type : 'string',
      description: typeof d.description === 'string' ? d.description : '',
      required: required.includes(name),
    };
  });
}

/** Write a field list back into step.outputSchema as a JSON Schema. */
function fieldsToOutputSchema(fields) {
  const named = fields.filter(f => f.name && f.name.trim());
  if (named.length === 0) return {}; // no fields → free-form text output
  const properties = {};
  const required = [];
  for (const f of named) {
    const key = f.name.trim();
    const prop = { type: f.type };
    if (f.description && f.description.trim()) prop.description = f.description.trim();
    properties[key] = prop;
    if (f.required) required.push(key);
  }
  const schema = { type: 'object', properties };
  if (required.length) schema.required = required;
  return schema;
}

/**
 * Visual editor for a content-research step's structured output. The author
 * adds named fields with a type instead of writing JSON; we compile to a JSON
 * Schema in step.outputSchema. No fields = text output.
 */
function renderOutputFieldsEditor(step, idx) {
  const wrap = el('div', { class: 'field mt-3' });
  wrap.appendChild(el('label', {}, 'Output fields (optional)'));
  wrap.appendChild(el('div', { class: 'text-xs text-muted-foreground mb-2' },
    'Leave empty for a plain text answer. Add fields to get structured output you can reference downstream as ',
    el('code', {}, '${' + (step.output_id || 'output') + '.fieldName}'), '.'));

  // Working list is a draft on the step, not re-derived from outputSchema each
  // render — so a freshly added, still-unnamed field persists (the schema drops
  // nameless fields). Seeded once from the saved schema.
  if (!Array.isArray(step.__outputFields)) {
    step.__outputFields = outputSchemaToFields(step.outputSchema);
  }
  const fields = step.__outputFields;

  const commit = (next) => {
    step.__outputFields = next;
    step.outputSchema = fieldsToOutputSchema(next);
    invalidatePreviewFrom(idx);
    notify();
  };

  const listBox = el('div', { class: 'ab-cr-fields' });
  fields.forEach((f, fi) => {
    const rowEl = el('div', {
      class: 'flex items-center gap-2 flex-wrap',
      style: 'padding:0.4rem; border:1px solid hsl(var(--ait-m-border)); border-radius:8px; margin-bottom:0.4rem;',
    });
    // Name
    rowEl.appendChild(el('input', {
      value: f.name,
      placeholder: 'field name',
      style: 'flex:1 1 140px; min-width:120px;',
      oninput: (e) => { fields[fi].name = e.target.value; commit(fields); },
    }));
    // Type
    const typeSel = el('select', {
      style: 'flex:0 0 auto;',
      onchange: (e) => { fields[fi].type = e.target.value; commit(fields); },
    });
    for (const t of CR_OUTPUT_TYPES) {
      const opt = el('option', { value: t.value }, t.label);
      if (t.value === f.type) opt.selected = true;
      typeSel.appendChild(opt);
    }
    rowEl.appendChild(typeSel);
    // Description
    rowEl.appendChild(el('input', {
      value: f.description,
      placeholder: 'description (optional)',
      style: 'flex:2 1 160px; min-width:140px;',
      oninput: (e) => { fields[fi].description = e.target.value; commit(fields); },
    }));
    // Required toggle
    const reqWrap = el('label', { class: 'text-xs flex items-center gap-1', title: 'Required field', style: 'flex:0 0 auto;' });
    const reqCb = el('input', {
      type: 'checkbox',
      oninput: (e) => { fields[fi].required = e.target.checked; commit(fields); },
    });
    if (f.required) reqCb.checked = true;
    reqWrap.appendChild(reqCb);
    reqWrap.appendChild(el('span', {}, 'required'));
    rowEl.appendChild(reqWrap);
    // Remove
    rowEl.appendChild(el('button', {
      class: 'btn danger', type: 'button', title: 'Remove field',
      style: 'flex:0 0 auto;',
      onclick: () => { fields.splice(fi, 1); commit(fields); },
    }, '×'));
    listBox.appendChild(rowEl);
  });
  wrap.appendChild(listBox);

  wrap.appendChild(el('button', {
    class: 'btn', type: 'button',
    onclick: () => { fields.push({ name: '', type: 'string', description: '', required: false }); commit(fields); },
  }, '+ Add field'));

  return wrap;
}

// ---------------------------------------------------------------------------
// Shared step-row shell (used by BOTH model and content-research rows)
// ---------------------------------------------------------------------------
//
// The row shell — drag-to-reorder, the Run/Edit/Remove button cluster, and the
// output_id + checkpoint meta block — is identical across step kinds. These
// helpers are the single source for it so the two row renderers only differ in
// their editor body, not in their plumbing.

/** Drop-target attrs for a step row. Not draggable itself — only the handle is
 * (stepDragHandleHandlers), so row text stays selectable. */
function stepRowDragHandlers(idx, getRow) {
  return {
    'data-step-idx': String(idx),
    ondragover: (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; getRow().classList.add('drag-over'); },
    ondragleave: () => getRow().classList.remove('drag-over'),
    ondrop: (e) => {
      e.preventDefault();
      getRow().classList.remove('drag-over');
      const fromIdx = Number(e.dataTransfer.getData('text/plain'));
      if (!Number.isInteger(fromIdx) || fromIdx === idx) return;
      const ss = state.agent.steps;
      const [moved] = ss.splice(fromIdx, 1);
      ss.splice(idx, 0, moved);
      // Reorder shuffles which output_id is at which index and which step is
      // "final" — clear the whole preview cache to keep cache→index honest;
      // the renderer rewrites step:false on the new last step automatically.
      invalidatePreviewFrom(0);
      notify();
    },
  };
}

/** Drag-source attrs for the ⋮⋮ handle. Only the handle starts a drag. */
function stepDragHandleHandlers(idx, getRow) {
  // While dragging, hide the row's body (everything but the header) so an open
  // step is easy to move. Cosmetic only — restored on dragend, never touches
  // step.__expanded. Deferred a frame so the drag-image snapshot stays intact.
  const hideBody = (row) => {
    for (const child of Array.from(row.children)) {
      if (child === row.firstElementChild) continue;
      child.dataset.dragHidden = '1';
      child.style.display = 'none';
    }
  };
  const showBody = (row) => {
    for (const child of Array.from(row.children)) {
      if (child.dataset.dragHidden === '1') {
        delete child.dataset.dragHidden;
        child.style.display = '';
      }
    }
  };
  // Collapse ALL rows, not just the dragged one, so the list reads cleanly.
  const eachRow = (row, fn) => { for (const r of row.parentElement?.children || []) fn(r); };
  return {
    draggable: 'true',
    ondragstart: (e) => {
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', String(idx));
      const row = getRow();
      row.classList.add('dragging');
      requestAnimationFrame(() => { if (row.classList.contains('dragging')) eachRow(row, hideBody); });
    },
    ondragend: () => {
      const row = getRow();
      row.classList.remove('dragging');
      eachRow(row, showBody);
    },
  };
}

/** The Run button — cached run state, credits chip, pipeline-busy guard. */
function stepRunButton(idx, step) {
  const cached = state.previewOutputs?.[idx];
  const isRunning = !!cached?.running;
  const hasResult = cached && !cached.running && !cached.error;
  const pipelineBusy = isRunInFlight();
  const credits = estimateStepCredits(step);
  const baseLabel = isRunning ? '⏳' : (hasResult ? '⟳ Re-run' : '▶ Run');
  const children = [el('span', {}, baseLabel)];
  if (credits > 0) {
    children.push(el('span', { style: 'opacity:0.55; margin:0 0.25rem;' }, '·'));
    children.push(creditsChip(credits));
  }
  const disabled = isRunning || pipelineBusy;
  return el('button', {
    class: 'btn primary',
    type: 'button',
    title: pipelineBusy && !isRunning
      ? 'Another step is running — wait for it to finish before starting this one.'
      : 'Run this step against live models. Upstream cached outputs are reused; missing ones run first.',
    disabled: disabled ? 'disabled' : null,
    onclick: () => { if (!disabled) requestRunStep(idx); },
  }, ...children);
}

/** The Run + Edit/Collapse + Remove button cluster shared by every step row. */
function stepRowControls(step, idx, expanded) {
  return el('div', { class: 'ab-step-controls flex gap-1 shrink-0' },
    stepRunButton(idx, step),
    el('button', { class: 'btn', type: 'button', title: expanded ? 'Collapse' : 'Edit',
      onclick: () => { step.__expanded = !expanded; notify(); } }, expanded ? 'Collapse' : 'Edit'),
    el('button', { class: 'btn danger', type: 'button', title: 'Remove',
      onclick: () => {
        state.agent.steps.splice(idx, 1);
        // Indexes shift after a splice — clearing everything is simpler and
        // safer than re-indexing. Author re-runs steps from scratch.
        invalidatePreviewFrom(0);
        pruneOrphanAutoAddedFields();
        notify();
      } }, '×'),
  );
}

/**
 * output_id input + checkpoint toggle. Identical contract for model and
 * content-research steps; the checkpoint toggle is suppressed on the final
 * step (final is silent by definition — the user just sees its output).
 */
function stepMetaBlock(step, idx, isFinal, idPlaceholder) {
  return el('div', { class: isFinal ? '' : 'grid grid-cols-1 md:grid-cols-2 gap-3' },
    el('div', { class: 'field' },
      el('label', {}, 'Output ID (used as ${output_id} downstream)'),
      el('input', {
        value: step.output_id || '',
        placeholder: idPlaceholder || 'e.g. start_image',
        oninput: (e) => { step.output_id = e.target.value.trim(); notify(); },
      }),
    ),
    isFinal ? null : el('div', { class: 'field' },
      el('label', {}, 'Step mode'),
      (() => {
        const wrap = el('div', { class: 'flex items-center gap-2' });
        const cb = el('input', { type: 'checkbox', id: `ab-step-flag-${idx}`,
          oninput: (e) => { step.step = e.target.checked; notify(); } });
        if (step.step === true) cb.checked = true;
        wrap.appendChild(cb);
        wrap.appendChild(el('label', { for: `ab-step-flag-${idx}`, class: 'text-sm' },
          'Show user this step (checkpoint)'));
        return wrap;
      })(),
    ),
  );
}

/**
 * Render a content-research step row: shared row shell + an editor body of
 * Claude model picker, tool toggles, soul, and the dynamic outputSchema editor.
 */
function renderContentResearchRow(step, idx, isFinal) {
  const spec = stepKindSpec('content-research') || {};
  const models = Array.isArray(spec.models) ? spec.models : [];
  const tools = Array.isArray(spec.tools) ? spec.tools : [];
  const selModel = models.find(m => m.id === step.model) || null;

  const row = el('div', {
    class: 'ab-step-row',
    ...stepRowDragHandlers(idx, () => row),
  });

  const expanded = !!step.__expanded;

  const head = el('div', { class: 'ab-step-head flex items-center justify-between gap-2' },
    el('div', { class: 'ab-step-head-info flex items-center gap-2 min-w-0' },
      el('span', { class: 'ab-drag-handle', title: 'Drag to reorder', style: 'cursor:grab; user-select:none; padding:0 0.35rem; color:hsl(var(--ait-m-muted-foreground)); font-size:1rem;', ...stepDragHandleHandlers(idx, () => row) }, '⋮⋮'),
      el('span', { class: 'ab-badge' }, 'Step ' + (idx + 1)),
      el('span', { class: 'ab-badge', style: 'background:hsl(var(--ait-m-primary)/0.12); border-color:hsl(var(--ait-m-primary)/0.35);' }, 'research'),
      isFinal ? el('span', { class: 'ab-badge', style: 'background:rgba(52,199,89,0.12); border-color:rgba(52,199,89,0.35);' }, 'final') : null,
      el('span', { class: 'text-sm font-mono truncate' }, selModel ? selModel.label : (step.model || '(no model)')),
      step.output_id ? el('span', { class: 'ab-badge', style: 'background:transparent;', title: 'output_id (downstream placeholder)' }, '${' + step.output_id + '}') : null,
    ),
    stepRowControls(step, idx, expanded),
  );
  row.appendChild(head);

  const outputPanel = renderStepOutputPanel(idx);
  if (outputPanel) row.appendChild(outputPanel);

  if (expanded) {
    const body = el('div', { class: 'mt-3 pt-3', style: 'border-top:1px dashed hsl(var(--ait-m-border));' });

    // Claude model selector — options come from config (no hardcoded list).
    const modelField = el('div', { class: 'field mb-3' },
      el('label', {}, 'Claude model'),
      (() => {
        const sel = el('select', {
          onchange: (e) => { step.model = e.target.value; invalidatePreviewFrom(idx); notify(); },
        });
        for (const m of models) {
          const opt = el('option', { value: m.id }, m.label + (m.supportsTools ? '' : ' (no web tools)'));
          if (m.id === step.model) opt.selected = true;
          sel.appendChild(opt);
        }
        return sel;
      })(),
    );
    body.appendChild(modelField);

    // Tool toggles — each enabled tool adds its credit cost (additive).
    if (tools.length) {
      const toolsBox = el('div', { class: 'field mb-3' }, el('label', {}, 'Tools (each adds credits)'));
      const noTools = selModel && selModel.supportsTools === false;
      for (const t of tools) {
        const enabled = Array.isArray(step.tools) && step.tools.includes(t.id);
        const wrap = el('div', { class: 'flex items-center gap-2', style: 'margin:0.2rem 0;' });
        const cb = el('input', {
          type: 'checkbox', id: `ab-cr-tool-${idx}-${t.id}`,
          disabled: noTools ? 'disabled' : null,
          oninput: (e) => {
            if (!Array.isArray(step.tools)) step.tools = [];
            if (e.target.checked) { if (!step.tools.includes(t.id)) step.tools.push(t.id); }
            else { step.tools = step.tools.filter(x => x !== t.id); }
            invalidatePreviewFrom(idx);
            notify();
          },
        });
        if (enabled) cb.checked = true;
        wrap.appendChild(cb);
        wrap.appendChild(el('label', { for: `ab-cr-tool-${idx}-${t.id}`, class: 'text-sm' },
          `${t.label} (+${t.creditCost})`,
          t.description ? el('span', { class: 'text-xs', style: 'opacity:0.6; margin-left:0.4rem;' }, t.description) : null,
        ));
        toolsBox.appendChild(wrap);
      }
      if (noTools) {
        toolsBox.appendChild(el('div', { class: 'text-xs', style: 'opacity:0.7; margin-top:0.25rem; color:hsl(var(--ait-m-foreground));' },
          'Selected model does not support web tools — pick a 4.6+ model to enable them.'));
      }
      body.appendChild(toolsBox);
    }

    // output_id + checkpoint toggle (same contract as model steps).
    const meta = stepMetaBlock(step, idx, isFinal, 'e.g. research');
    meta.classList.add('mb-3');
    body.appendChild(meta);

    // Soul (prompt) — reuse the model-step soul editor verbatim.
    body.appendChild(renderSoulEditor(step, idx));

    // Output format — Text (markdown answer, rendered as a Generated Content
    // card) or JSON (structured fields, referenceable downstream as
    // ${output_id.field}). Default is text.
    if (step.outputFormat !== 'text' && step.outputFormat !== 'json') step.outputFormat = 'text';
    const formatBox = el('div', { class: 'field mt-3' },
      el('label', {}, 'Output format'),
      (() => {
        const sel = el('select', {
          onchange: (e) => { step.outputFormat = e.target.value; invalidatePreviewFrom(idx); notify(); },
        });
        for (const opt of [
          { v: 'text', l: 'Text — formatted answer (markdown)' },
          { v: 'json', l: 'JSON — structured fields (referenceable downstream)' },
        ]) {
          const o = el('option', { value: opt.v }, opt.l);
          if (step.outputFormat === opt.v) o.selected = true;
          sel.appendChild(o);
        }
        return sel;
      })(),
    );
    body.appendChild(formatBox);

    // Output fields editor only applies to JSON format. In text mode the model
    // returns free markdown, so there are no fields to define.
    if (step.outputFormat === 'json') {
      body.appendChild(renderOutputFieldsEditor(step, idx));
    }

    row.appendChild(body);
  }

  return row;
}

function renderStepRow(step, idx) {
  const isFinal = idx === state.agent.steps.length - 1;
  if (isFinal) step.step = false;

  // content-research steps render with their own editor; model steps are
  // untouched below.
  if (stepKindOf(step) === 'content-research') {
    return renderContentResearchRow(step, idx, isFinal);
  }

  const model = state.config.models.find(m => m.id === step.model_id);

  const row = el('div', {
    class: 'ab-step-row',
    ...stepRowDragHandlers(idx, () => row),
  });

  const expanded = !!step.__expanded;

  // Collapsed-state summary line on the head — model + output_id + checkpoint
  // badge — so the author can scan the pipeline without opening every row.
  const head = el('div', { class: 'ab-step-head flex items-center justify-between gap-2' },
    el('div', { class: 'ab-step-head-info flex items-center gap-2 min-w-0' },
      el('span', {
        class: 'ab-drag-handle',
        title: 'Drag to reorder this step',
        style: 'cursor: grab; user-select: none; padding: 0 0.35rem; color: hsl(var(--ait-m-muted-foreground)); font-size: 1rem;',
        ...stepDragHandleHandlers(idx, () => row),
      }, '⋮⋮'),
      el('span', { class: 'ab-badge' }, 'Step ' + (idx + 1)),
      isFinal ? el('span', { class: 'ab-badge', style: 'background: rgba(52,199,89,0.12); border-color: rgba(52,199,89,0.35);' }, 'final') : null,
      step.step === true
        ? el('span', {
            class: 'ab-badge',
            style: 'background: hsl(var(--ait-m-primary) / 0.14); color: hsl(var(--ait-m-primary)); border-color: hsl(var(--ait-m-primary) / 0.35);',
            title: 'Checkpoint — runner pauses and shows the user this step\'s output.',
          }, 'checkpoint')
        : null,
      el('span', { class: 'text-sm font-mono truncate' }, model ? model.displayName : '(no model selected)'),
      step.output_id
        ? el('span', { class: 'ab-badge', style: 'background: transparent;', title: 'output_id (downstream placeholder)' }, '${' + step.output_id + '}')
        : null,
    ),
    stepRowControls(step, idx, expanded),
  );
  row.appendChild(head);

  // Output panel — shows cached run state (running / error / success). Sits
  // below the head so it's visible whether the editor body is expanded or not.
  const outputPanel = renderStepOutputPanel(idx);
  if (outputPanel) row.appendChild(outputPanel);

  if (expanded) {
    const body = el('div', { class: 'mt-3 pt-3', style: 'border-top: 1px dashed hsl(var(--ait-m-border));' });

    // Model display + change button.
    const modelBox = el('div', { class: 'flex items-center gap-2 mb-3 flex-wrap' },
      el('button', {
        class: 'btn', type: 'button',
        onclick: () => {
          if (!confirm('Changing the model will refresh this step\'s schema. Values you\'ve already set for keys the new model also accepts will be preserved; the rest will be reset. Continue?')) return;
          modelPickerMode = { kind: 'change', stepIndex: idx };
          openModelPicker();
        },
      }, model ? '⟳ Change model' : '+ Pick model'),
      el('span', { class: 'text-sm font-mono' }, model ? model.displayName : '(no model selected)'),
      model ? el('span', { class: 'ab-badge' }, model.id) : null,
    );
    body.appendChild(modelBox);

    // output_id + step toggle. Output ID is always editable. The Step-mode
    // (checkpoint) toggle is suppressed on the final step (final is silent
    // by definition; the user just sees its output).
    body.appendChild(stepMetaBlock(step, idx, isFinal, 'e.g. start_image'));

    body.appendChild(renderSchemaEditor(step, idx));
    row.appendChild(body);
  }

  return row;
}

export function renderStepsPass() {
  const list = $('#ab-steps-list');
  const empty = $('#ab-steps-empty');
  if (!list) return;

  // Focus-aware skip. Every keystroke inside a schema textarea/text-input
  // fires `oninput` → `notify()` → `render()` → this function. If we blow
  // the whole list away (`innerHTML = ''`) and rebuild it, the editable
  // element the author is typing into is replaced by a brand-new DOM node,
  // focus leaves, and every modifier-keypress (AltGr in particular) lands
  // on the body instead of the field.
  //
  // Only continuous-typing inputs qualify for the skip:
  //   - `<textarea>` (always)
  //   - `<input type=text|number|search|email|url|tel|password>` and the
  //     no-type default (which is also text)
  //
  // Radio, checkbox, button, and `<select>` are explicitly excluded. Each
  // of those triggers a one-shot state change where the *next* state is
  // supposed to introduce or remove rows in the editor (Control type:
  // Dropdown reveals the Options input; Source: Custom opens the config
  // panel). Skipping rebuild on those would freeze the UI mid-flow.
  const active = document.activeElement;
  const TEXTLIKE_INPUT_TYPES = new Set(['text', 'number', 'search', 'email', 'url', 'tel', 'password', '']);
  const isTypingFocus = active && (
    active.tagName === 'TEXTAREA' ||
    (active.tagName === 'INPUT' && TEXTLIKE_INPUT_TYPES.has(active.type))
  );
  if (isTypingFocus && list.contains(active)) {
    syncStepsToolbar();
    return;
  }

  list.innerHTML = '';
  if (state.agent.steps.length === 0) {
    empty.hidden = false;
    syncStepsToolbar();
    return;
  }
  empty.hidden = true;
  state.agent.steps.forEach((s, i) => list.appendChild(renderStepRow(s, i)));
  syncStepsToolbar();

  // After a restore from localStorage, steps will have a model_id but no
  // __schemaMeta in memory. Fetch them in the background so the editor renders
  // properly without forcing the author to re-pick. Older snapshots may also
  // be missing the `soul` field — default it to an empty string so the editor
  // never falls back to undefined.
  //
  // Migration: an earlier version of the auto-wire path could write
  // `${prompt}` into schema.prompt and create a stray `prompt` form field.
  // Soul now owns prompt entirely; collapse any such residue on load.
  for (const s of state.agent.steps) {
    if (typeof s.soul !== 'string') s.soul = '';
    if (s.schema && typeof s.schema === 'object' && s.schema.prompt && s.schema.prompt !== '') {
      // Hoist any old prompt template up to soul if soul is still empty.
      if (!s.soul) s.soul = String(s.schema.prompt);
      s.schema.prompt = '';
    }
    // Re-merge the model schema on boot. A step restored from localStorage
    // carries a STALE `__schemaMeta`/`__optionalAvailable` snapshot (persist
    // keeps `__`-prefixed flags so a mid-edit refresh doesn't lose picker
    // state). That snapshot can lag the live schema — e.g. a key that's since
    // been deduped away (gpt-image-2: `image_urls` collapsed into `images`)
    // would still render as an "Enable optional" chip. Re-fetching and
    // re-applying refreshes the derived meta (added keys appear, removed keys
    // drop) while applySchemaToStep preserves the author's real choices
    // (everything they wired lives in `step.schema`, not the meta). Done once
    // per page load, tracked in a module-level set that resets on refresh.
    if (s.model_id && !s.__schemaLoading && !_rehydratedSchemaSteps.has(s)) {
      _rehydratedSchemaSteps.add(s);
      loadAndApplySchema(s);
    }
  }
  // Drop any stray `prompt` field the earlier auto-wire left behind. Nothing
  // should reference it now — schema.prompt is always `""` and soul owns the
  // prompt-shaped text.
  state.agent.fields = state.agent.fields.filter(f => f.id !== 'prompt');
}

// Update the Steps-section toolbar (Add step + Run all). Called every render.
function syncStepsToolbar() {
  const steps = state.agent.steps;
  const maxSteps = Number(state.config?.maxSteps) || 5;
  const addBtn = $('#ab-add-step');
  if (addBtn) {
    addBtn.disabled = steps.length >= maxSteps;
    addBtn.textContent = steps.length === 0 ? '+ Add first step' : '+ Add step';
  }
  const runAllBtn = $('#ab-run-all');
  if (!runAllBtn) return;
  runAllBtn.hidden = steps.length === 0;
  if (steps.length === 0) return;
  // Single credits source: floorCredits() — same number Pass 5 displays as
  // "Floor (credits)" and the same number the server clamps publish against.
  // Per-step Run chips can still floor-at-1-credit individually (their
  // policy: "every Play costs at least 1 credit"), but the TOTAL must
  // match the floor — otherwise authors see three different numbers
  // (Run all chip / Pass 5 floor / published agent costEstimate) for the
  // same agent.
  const total = floorCredits();
  // A step is "ready" if it's a model step with a model, or any non-model kind
  // (content-research validates itself). Only incomplete model steps block Run.
  runAllBtn.disabled = _runInFlight || steps.some(s => stepKindOf(s) === 'model' && !s?.model_id);
  runAllBtn.innerHTML = '';
  runAllBtn.appendChild(document.createTextNode('▶ Run all  '));
  if (total > 0) runAllBtn.appendChild(creditsChip(total));
}

export function wireStepsPass() {
  // Run all = wipe every cached step output, then kick the last step.
  // runStepBuilder walks 0..target; with the cache empty every step
  // actually runs (vs. the default "reuse fresh cache" path that single-
  // step Play uses). On success recordStepEstimate persists the learned
  // durations because the last step ran.
  $('#ab-run-all')?.addEventListener('click', () => {
    const last = state.agent.steps.length - 1;
    if (last < 0) return;
    invalidatePreviewFrom(0);
    void requestRunStep(last);
  });

  $('#ab-add-step')?.addEventListener('click', () => {
    // The cap is server-owned (env: AGENT_BUILDER_MAX_STEPS), fetched into
    // state.config.maxSteps on boot. We refuse to fall back to a literal —
    // if config hasn't loaded yet, the click waits rather than silently
    // applying a stale default.
    const maxSteps = Number(state.config?.maxSteps);
    if (!Number.isFinite(maxSteps) || maxSteps <= 0) {
      toast('Builder config still loading — try again in a moment.', 'error');
      return;
    }
    if (state.agent.steps.length >= maxSteps) {
      toast(`Maximum ${maxSteps} steps.`, 'error');
      return;
    }
    // Choose the step KIND first (model / content-research / …). For a model
    // kind this defers to the model picker, so we still never create an
    // orphaned model-less model-step.
    openStepKindPicker();
  });
  // Model picker search is wired (debounced, live-fetch) inside wireModelTabs(),
  // called from openModelPicker(). No separate listener here.

  // Run-prep modal submit. Cancel and X buttons are wired by the shared
  // `[data-close-modal]` handler in wireFieldsPass.
  $('#ab-run-prep-submit')?.addEventListener('click', () => { submitRunPrep(); });

  // Resume any step whose persisted cache says it was `running` when the
  // page was closed/refreshed. The DB is authoritative — we look the jobId
  // up via /api/jobs/:id and either re-attach a poller or hydrate the
  // completed/failed result without spending credits again.
  resumeStepPollingOnBoot();
}

/**
 * On page boot, walk `state.previewOutputs` for any entry the persistent
 * cache restored with `running: true && jobId set`. For each one, fire-and-
 * forget a poll that mirrors the in-line runStepBuilder behavior. Multiple
 * runners can run in parallel here (the global `_runInFlight` guard only
 * applies to *new* clicks; resuming an existing job doesn't reserve new
 * credits and shouldn't block other rows).
 */
async function resumeStepPollingOnBoot() {
  const entries = Object.entries(state.previewOutputs || {});
  const tasks = [];
  for (const [key, entry] of entries) {
    if (!entry || !entry.running || !entry.jobId) continue;
    const stepIndex = Number(key);
    if (!Number.isInteger(stepIndex) || stepIndex < 0) continue;

    // Re-anchor startedAt to client wall-clock using the server's elapsedMs.
    // The persisted startedAt was set in a previous session and the user's
    // clock may have changed (sleep/resume, daylight saving) or — more
    // commonly — the server returns elapsedMs against its own clock. We
    // probe /preview-step-job once, then convert the server's "elapsed
    // since I started the job" into "Date.now() minus that, expressed in
    // this tab's clock". Falls back to the persisted value if the probe
    // fails or the job already settled.
    try {
      const probeRes = await fetchHelper(`https://aitopia.ai/api/agent-builder/preview-step-job/${encodeURIComponent(entry.jobId)}`, {
        method: 'GET',
        headers: { Accept: 'application/json' },
      });
      if (probeRes.ok) {
        const probeJson = await probeRes.json().catch(() => null);
        if (probeJson?.ok && probeJson.status === 'running') {
          const elapsedMs = Number(probeJson.elapsedMs) || 0;
          entry.startedAt = Date.now() - Math.max(0, elapsedMs);
          if (Number(probeJson.estimatedDurationMs) > 0) {
            entry.estimatedDurationMs = Number(probeJson.estimatedDurationMs);
          }
        }
      }
    } catch { /* keep persisted values */ }

    tasks.push(resumeOneStepPoll(stepIndex, entry.jobId));
  }
  if (tasks.length === 0) return;
  // Kick off the ticker so the progress bar animates immediately on boot.
  startStepProgressTicker();
  notify(); // re-render with the re-anchored startedAt values
  // Let them run in parallel; each updates `state.previewOutputs[i]` and
  // calls notify() on its own.
  await Promise.allSettled(tasks);
}

async function resumeOneStepPoll(stepIndex, jobId) {
  try {
    const json = await pollPreviewStepJob(jobId, {
      onProgress: (running) => applyRunningTick(stepIndex, running),
    });
    applyStepResultToCache(stepIndex, json);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    state.previewOutputs[stepIndex] = { running: false, error: msg, ranAt: Date.now() };
  }
  notify();
  refreshCreditsBalance();
}
