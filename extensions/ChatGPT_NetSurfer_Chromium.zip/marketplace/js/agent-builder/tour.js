/**
 * Studio tour: three spotlit coachmarks, started only on request ("Take the
 * tour" / gear menu). The target stays clickable; Esc/Skip/Got it end it.
 */

import { state } from './state.js';

let card = null;
let spot = null;
let steps = [];
let idx = 0;
let restoreFocus = null;

function introSteps() {
  const credits = Number(state.config?.studioChatCredits) || 0;
  return [
    {
      target: '#ab-studio-form',
      text: 'Describe your agent in one sentence, then click “Send.” We’ll select the most suitable models and build your agent.',
    },
    {
      target: '#ab-studio-send',
      text: credits > 0
        ? `Each message costs ${credits} credits. Test runs are billed at provider price, shown before you run.`
        : 'Test runs are billed at provider price, shown before you run.',
    },
    {
      target: '#ab-tab-btn-customizer',
      spot: '.ab-tabs',
      text: 'Under the Setup menu, you can edit the agent’s name, input fields, model pipeline, media, and price. You can also publish your agent from this menu.',
    },
  ];
}

function clearTarget() {
  document.querySelectorAll('.ab-tour-target').forEach(el => el.classList.remove('ab-tour-target'));
}

function placeSpot(r) {
  const pad = 6;
  spot.style.left = `${Math.round(r.left - pad)}px`;
  spot.style.top = `${Math.round(r.top - pad)}px`;
  spot.style.width = `${Math.round(r.width + pad * 2)}px`;
  spot.style.height = `${Math.round(r.height + pad * 2)}px`;
}

function place(target) {
  if (!card) return;
  const r = target.getBoundingClientRect();
  const spotEl = steps[idx]?.spot ? document.querySelector(steps[idx].spot) : null;
  placeSpot(spotEl ? spotEl.getBoundingClientRect() : r);
  const mobile = window.matchMedia('(max-width: 640px)').matches;
  const sheet = mobile && r.bottom > window.innerHeight / 2;
  card.classList.toggle('full', mobile);
  card.classList.toggle('sheet', sheet);
  card.style.bottom = '';
  if (sheet) {
    const zone = document.querySelector('.ab-studio-composer-zone');
    const above = zone ? Math.round(window.innerHeight - zone.getBoundingClientRect().top + 12) : 96;
    card.style.left = ''; card.style.top = '';
    card.style.bottom = `${above}px`;
    return;
  }
  if (mobile) { card.style.left = ''; card.style.top = `${Math.round(r.bottom + 10)}px`; return; }
  const cw = card.offsetWidth;
  const ch = card.offsetHeight;
  const gap = 12;
  let top = r.top - ch - gap;
  if (top < 12) top = r.bottom + gap;
  let left = r.left + r.width / 2 - cw / 2;
  left = Math.max(12, Math.min(left, window.innerWidth - cw - 12));
  card.style.left = `${Math.round(left)}px`;
  card.style.top = `${Math.round(top)}px`;
}

function render() {
  const step = steps[idx];
  const target = step && document.querySelector(step.target);
  if (!step || !target || target.hidden || target.getClientRects().length === 0) return end();

  clearTarget();
  target.classList.add('ab-tour-target');
  target.scrollIntoView({ block: 'nearest' });

  const last = idx === steps.length - 1;
  card.innerHTML =
    `<p>${step.text}</p>` +
    `<div class="ab-tour-foot">` +
      `<span class="ab-tour-count">${steps.length > 1 ? `${idx + 1} / ${steps.length}` : ''}</span>` +
      (last ? '' : `<button type="button" class="ab-tour-skip">Skip</button>`) +
      `<button type="button" class="ab-tour-next">${last ? 'Got it' : 'Next'}</button>` +
    `</div>`;
  card.querySelector('.ab-tour-skip')?.addEventListener('click', end);
  card.querySelector('.ab-tour-next').addEventListener('click', () => { idx += 1; idx < steps.length ? render() : end(); });
  place(target);
  card.querySelector('.ab-tour-next').focus();
}

function onKey(e) { if (e.key === 'Escape') end(); }

function end() {
  clearTarget();
  card?.remove();
  spot?.remove();
  card = null;
  spot = null;
  window.removeEventListener('resize', onResize);
  window.removeEventListener('scroll', onResize, true);
  document.removeEventListener('keydown', onKey);
  restoreFocus?.focus?.();
  restoreFocus = null;
}

function onResize() {
  const step = steps[idx];
  const target = step && document.querySelector(step.target);
  if (target) place(target);
}

export function startTour() {
  if (card) end();
  restoreFocus = document.activeElement;
  steps = introSteps();
  idx = 0;
  spot = document.createElement('div');
  spot.className = 'ab-tour-spot';
  document.body.appendChild(spot);
  card = document.createElement('div');
  card.className = 'ab-tour-card';
  card.setAttribute('role', 'dialog');
  card.setAttribute('aria-label', 'Studio tour');
  document.body.appendChild(card);
  window.addEventListener('resize', onResize);
  window.addEventListener('scroll', onResize, true);
  document.addEventListener('keydown', onKey);
  render();
}
