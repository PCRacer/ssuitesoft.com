/**
 * Studio surface for the showcase media generator.
 *
 * Mirrors tester-ui: the generator does the work, this file only shows it. One
 * card per generation, with the same add/remove-to-gallery toggle a test run's
 * own output gets.
 */

import { state, notify } from './state.js';
import {
  toast,
  validateMetadata, validateTemplate, validateFields, validateSteps, validateCredits,
} from './utils.js';
import {
  appendMessage, showTab, THINKING_SVG, hasPassingTestRun,
  recordMediaRun, registerMediaRunRenderer,
} from './studio.js';
import { mediaGenerator } from './media-generator.js';
import { tester } from './tester.js';
import { openOutputModal, paintSubmitted, showCoverCredits, previewLink } from './tester-ui.js';
import { publish } from './preview-pass.js';
import { renderOutput } from '/marketplace/js/runner/result-renderer.js';
import { openPublishSheet, closePublishSheet } from './publish-sheet.js';

function paint(card, view) {
  card.innerHTML = '';
  card.classList.remove('ab-submitted-card');
  if (view.publishedAs) {
    return paintSubmitted(card, {
      ...view,
      report: { outputs: view.report?.url ? [{ url: view.report.url, kind: view.kind }] : [] },
    });
  }

  const head = document.createElement('div');
  head.className = 'ab-doc-card-head';
  const spinner = view.status === 'running'
    ? `<span class="ab-thinking-logo ab-test-spinner">${THINKING_SVG}</span>`
    : '';
  const label = view.kind === 'video' ? 'Showcase video' : 'Showcase image';
  head.innerHTML =
    `<span class="ab-doc-name">${label} — ${view.agentName || 'agent'}</span>`
    + spinner
    + `<span class="ab-doc-status ${view.status}">${view.statusLabel}</span>`;
  card.appendChild(head);

  if (view.note) {
    const note = document.createElement('div');
    note.className = 'ab-test-note';
    note.textContent = view.note;
    card.appendChild(note);
  }

  if (view.error) {
    const err = document.createElement('div');
    err.className = 'ab-test-error';
    err.textContent = view.error;
    card.appendChild(err);
  }

  // Same renderer and modal the test-run card uses, so a generated cover opens
  // full size exactly like a run's output does.
  if (view.url) {
    const strip = document.createElement('div');
    strip.className = 'ab-test-outputs';
    try {
      renderOutput(strip, view.url);
    } catch (err) {
      console.debug('[media-generator] renderOutput failed', err);
    }
    // renderOutput wraps media in links that open a new tab; the modal is the
    // better viewer here, so intercept on capture before the anchor acts.
    strip.addEventListener('click', (e) => {
      if (e.target.closest('button, input, select, textarea')) return; // slider controls
      const anchor = e.target.closest('a');
      const url = anchor?.getAttribute('href') || e.target?.currentSrc || e.target?.src;
      e.preventDefault();
      e.stopPropagation();
      openOutputModal(url || view.url);
    }, true);
    card.appendChild(strip);
  } else if (view.status === 'ok') {
    // Rendered nothing inline — offer the viewer, as the test card does.
    const open = document.createElement('button');
    open.type = 'button';
    open.className = 'ab-test-view-output';
    open.textContent = 'View output';
    open.addEventListener('click', () => openOutputModal(view.url));
    card.appendChild(open);
  }

  // What the writer thought the agent produces — the author's check that it
  // read the pipeline right, and the steer for a regenerate if it did not.
  if (view.subject) {
    const foot = document.createElement('div');
    foot.className = 'ab-test-foot';
    foot.textContent = view.subject;
    card.appendChild(foot);
  }

  if (view.footer) {
    const foot = document.createElement('div');
    foot.className = 'ab-test-foot';
    foot.textContent = view.footer;
    card.appendChild(foot);
  }

  if (view.status !== 'ok') return;

  const row = document.createElement('div');
  row.className = 'ab-doc-cta ab-test-cta';
  const secondary = document.createElement('div');
  secondary.className = 'ab-test-secondary';

  // Same first action the test-run card offers — a finished cover is often the
  // last thing before submitting.
  const submit = document.createElement('button');
  submit.type = 'button';
  submit.className = 'ab-doc-open primary';
  submit.innerHTML = 'Publish Agent <span aria-hidden="true">›</span>';
  submit.addEventListener('click', () => openPublishSheet(async (sheetBtn) => {
    await submitForReview(card, view, sheetBtn);
    if (view.publishedAs) closePublishSheet();
  }));
  row.appendChild(submit);

  // Own class, not ab-doc-open — that one is claimed by the artifact-card
  // handler, which expects a JSON block this card does not carry.
  const again = document.createElement('button');
  again.type = 'button';
  again.className = 'ab-cover-btn';
  again.textContent = 'Generate another';
  showCoverCredits(again, view.kind);
  again.disabled = _running;
  // Already generated once from a passing run — the gate was cleared then.
  again.addEventListener('click', () => { void startRun({ kind: view.kind, tested: true }); });
  secondary.appendChild(again);

  const added = mediaGenerator.inMedia(view.report);
  const toggle = document.createElement('button');
  toggle.type = 'button';
  toggle.className = `ab-doc-open ab-media-toggle ${added ? 'remove' : 'add'}`;
  toggle.innerHTML = added
    ? '<span class="ab-media-toggle-state">In showcase</span><span class="ab-media-toggle-hover">Remove</span>'
    : 'Add to showcase';
  // Tooltip names the action, not the state.
  toggle.title = added ? 'Remove from Showcase Media' : 'Add to Showcase Media';
  toggle.setAttribute('aria-label', toggle.title);
  toggle.addEventListener('click', () => {
    if (added) {
      mediaGenerator.detachFromMedia(view.report);
    } else if (!mediaGenerator.attachToMedia(view.report)) {
      toast('Showcase Media is full (5) — remove one in Setup › Media first.', 'error', 5000);
      return;
    }
    paint(card, view);
  });
  secondary.appendChild(toggle);
  const preview = previewLink();
  if (preview) secondary.appendChild(preview);
  row.appendChild(secondary);

  card.appendChild(row);
}

/**
 * Same gate the test-run card enforces: publish needs valid metadata, fields,
 * steps and a credit price, not just a finished render.
 */
async function submitForReview(card, view, btn) {
  const problems = [
    ...validateMetadata(), ...validateTemplate(),
    ...validateFields(), ...validateSteps(), ...validateCredits(),
  ];
  if (problems.length) {
    toast(problems[0], 'error', 6000);
    state.pass = 5;
    notify();
    showTab('customizer');
    return;
  }

  // Nothing picked yet → use this cover, so a listing never reaches review with
  // no media. An existing pick is left alone.
  const shots = (state.agent.showcase_images || []).length + (state.agent.showcase_videos || []).length;
  const willAdd = !shots && !!view.report?.url;

  const label = btn.innerHTML;
  btn.disabled = true;
  btn.textContent = 'Submitting…';
  if (willAdd) mediaGenerator.attachToMedia(view.report);
  const before = state.publishedVersion;
  await publish();
  // publish() reports its own errors; a changed publishedVersion is how we know
  // it actually landed.
  if (state.publishedVersion && state.publishedVersion !== before) {
    view.publishedAs = state.publishedVersion;
    view.report = { ...view.report, publishedAs: view.publishedAs };
    recordMediaRun(view.report);
  } else {
    btn.disabled = false;
    btn.innerHTML = label;
  }
  paint(card, view);
}

/** Fresh view model for one generation. */
function blankView(kind, agentName) {
  return {
    kind: kind === 'video' ? 'video' : 'image',
    agentName,
    status: 'running',
    statusLabel: 'Generating',
    note: 'Reading the agent and writing a prompt…',
    url: '',
    subject: '',
    error: '',
    footer: '',
    // Set once submitted, so a restored card does not offer the same version twice.
    publishedAs: '',
    report: null,
  };
}

/** Fold a finished report into the view model. Shared by the live run and restore. */
function applyReport(view, report) {
  view.report = report;
  if (report.publishedAs) view.publishedAs = report.publishedAs;
  if (report.ok) {
    view.status = 'ok';
    view.statusLabel = 'Done';
    view.note = '';
    view.error = '';
    view.url = report.url || '';
    view.kind = report.kind || view.kind;
    view.subject = report.subject || '';
    view.footer = `${report.model || 'model'} · ${report.credits ?? 0} credits`;
    return;
  }
  view.status = 'error';
  view.statusLabel = 'Failed';
  view.note = '';
  view.error = report.message || 'Generation failed.';
}

/** Mount a card into a fresh assistant bubble. */
function mountCard() {
  const { bubble } = appendMessage('assistant', '');
  bubble.innerHTML = '';
  const card = document.createElement('div');
  card.className = 'ab-doc-card ab-test-card';
  bubble.appendChild(card);
  return card;
}

/** Re-draw a persisted generation on reload. */
function renderStoredRun(report) {
  if (!report || typeof report !== 'object') return;
  const view = blankView(report.kind, report.agentName || state.agent?.name || '');
  const card = mountCard();

  // Still rendering when the page closed. The job runs server-side and outlives
  // the request that started it, so rejoin it instead of showing a verdict.
  if (report.running && report.jobId) {
    view.report = report;
    paint(card, view);
    void followRestored(card, view, report);
    return;
  }

  applyReport(view, report);
  paint(card, view);
}

/** Watch a restored job to its verdict, then settle the card under the same runId. */
async function followRestored(card, view, report) {
  _running = true;
  try {
    const result = await mediaGenerator.attach(report.jobId, report.kind);
    applyReport(view, {
      ...report, ...result,
      running: false,
      kind: result.kind || report.kind,
      agentName: report.agentName,
    });
    recordMediaRun(view.report);
    notify();
  } catch (err) {
    console.error('[media-generator] restored run failed', err);
    applyReport(view, {
      ...report, running: false, ok: false,
      message: err?.message || 'Generation failed.',
    });
    recordMediaRun(view.report);
  } finally {
    _running = false;
    paint(card, view);
  }
}

/** Guards against a second generation while one is on screen. */
let _running = false;

async function startRun({ kind = 'image', userHint, tested } = {}) {
  if (_running) {
    toast('A generation is already in progress.', 'error');
    return;
  }

  // Gated on a passing test: refuse before the card exists, so a draft that was
  // never run just gets the explanation. `tested` comes from a caller holding a
  // passing report — the live cache it would otherwise read is cleared by a
  // publish or a reload, which would refuse an agent that HAS been tested.
  if (!tested && !tester.passed() && !hasPassingTestRun()) {
    toast('Run a test first — the agent has to work before it gets a cover.', 'error', 6000);
    return;
  }

  _running = true;
  const runId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

  // Out here so the finally below can reach them; inside the try it threw and ate the repaint.
  const view = blankView(kind, state.agent?.name || state.agent?.id || '');
  let card = null;

  try {
    const ensureCard = () => (card ||= mountCard());

    // The price already sits on the button, so no confirm step here.
    const pending = mediaGenerator.run({
      kind: view.kind, userHint, tested,
      // Persist the moment it is queued: the render keeps going server-side, so
      // a refresh mid-render must find the card and re-attach to it.
      onJob: ({ jobId, kind: k }) => {
        view.report = {
          runId, at: Date.now(), running: true, jobId,
          kind: k, agentName: view.agentName,
        };
        paint(ensureCard(), view);
        recordMediaRun(view.report);
      },
    });
    const shown = setTimeout(() => paint(ensureCard(), view), 400);

    const report = await pending;
    clearTimeout(shown);

    if (!report.ok && report.code === 'cancelled') {
      card?.closest('.ab-msg')?.remove();
      return;
    }

    // Stamp what the card needs to redraw itself after a reload, then persist.
    applyReport(view, {
      ...view.report, ...report,
      runId, at: view.report?.at || Date.now(), running: false,
      kind: report.kind || view.kind, agentName: view.agentName,
    });
    recordMediaRun(view.report);
    notify();
  } catch (err) {
    // Never leave the card spinning on an unexpected throw — settle it as failed.
    console.error('[media-generator] run failed', err);
    applyReport(view, {
      ...view.report, runId, running: false, ok: false,
      message: err?.message || 'Generation failed.',
    });
    recordMediaRun(view.report);
  } finally {
    _running = false;
    if (card?.isConnected) paint(card, view);
  }
}

export function wireMediaGenerator() {
  registerMediaRunRenderer(renderStoredRun);

  document.addEventListener('agent-builder:generate-media', (e) => {
    void startRun({
      kind: e?.detail?.kind,
      userHint: e?.detail?.userHint,
      tested: e?.detail?.tested === true,
    });
  });
}
