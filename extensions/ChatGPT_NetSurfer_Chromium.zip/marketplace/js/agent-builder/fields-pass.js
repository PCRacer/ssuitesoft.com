/**
 * Pass 3 — Fields (progressive flow).
 *
 * The author's flow is:
 *
 *   1. Click "+ Add field". A small picker asks: **catalog or custom?**
 *   2a. **Catalog** → the catalog modal opens. Picking a concept appends a
 *       compact `{ id }` entry to `fields[]`. Catalog defaults flow through
 *       at runtime — the author edits only what they want to override.
 *   2b. **Custom** → a setup modal asks for the bare minimum (id + control
 *       type + display label). On submit the field appears in the list with
 *       a sensible default for the chosen control. The author can refine
 *       (default value, enum, range, visible/advanced) from the row editor.
 *
 * Each list row starts **collapsed** — id + badge + actions only. The "Edit"
 * toggle opens the per-row editor, which differs per field type:
 *
 *   - Catalog fields show a sparse override panel (title, description, default,
 *     enum, range — depending on the control). Changing the control detaches
 *     the field into a custom one, with a confirmation dialog.
 *   - Custom fields show the full panel (everything is authored from scratch).
 *
 * This "pick before authoring" pattern matches Pass 4's "pick model before
 * editing schema" — the user never sees an editor for something that isn't
 * fully chosen yet.
 */

import { state, notify } from './state.js';
import { el, $, $$, toast } from './utils.js';
import { renderEnumOptionsEditor, appendTypeSpecificConfig } from './steps-pass.js';

/* ---------------- Field ↔ Step relationship ----------------
 *
 * For every field in `state.agent.fields`, walk the pipeline and collect:
 *   - which steps reference it via `${id}` (anywhere in soul or schema)
 *   - whether ANY of those references is a *required* model input (the
 *     step.__schemaMeta.required list contains the schema key whose value is
 *     exactly `${id}`)
 *
 * Required-by-some-step is what gates hide + advanced; usedBySteps drives the
 * "Used by S1, S3" badge.
 */
function computeFieldUsage() {
  const usage = new Map(); // fieldId → { steps: number[], requiredBySome: boolean }
  const fieldIds = new Set(state.agent.fields.map(f => f.id));
  for (const id of fieldIds) usage.set(id, { steps: [], requiredBySome: false });

  const placeholderRe = /\$\{([a-zA-Z0-9_-]+)\}/g;
  const exactRe = /^\$\{([a-zA-Z0-9_-]+)\}$/;

  state.agent.steps.forEach((step, idx) => {
    const oneBased = idx + 1;
    const seenInThisStep = new Set();
    const requiredKeys = new Set(step.__schemaMeta?.required || []);

    const noteReference = (id, isRequiredWire) => {
      if (!fieldIds.has(id)) return;
      const entry = usage.get(id);
      if (!seenInThisStep.has(id + ':' + oneBased)) {
        entry.steps.push(oneBased);
        seenInThisStep.add(id + ':' + oneBased);
      }
      if (isRequiredWire) entry.requiredBySome = true;
    };

    // Schema: walk every (key, value). Exact `${id}` match on a required key
    // counts as a required-wire.
    if (step.schema && typeof step.schema === 'object') {
      for (const [key, value] of Object.entries(step.schema)) {
        if (typeof value === 'string') {
          const exact = exactRe.exec(value.trim());
          if (exact) {
            noteReference(exact[1], requiredKeys.has(key));
          } else {
            // Mixed string (e.g. "a ${dur}s clip") — still a reference, but
            // not a required-wire signal because the model gets a literal.
            placeholderRe.lastIndex = 0;
            let m;
            while ((m = placeholderRe.exec(value)) !== null) noteReference(m[1], false);
          }
        }
      }
    }
    // Soul references are never required-wires (soul → schema.prompt, never a
    // required structured input).
    if (typeof step.soul === 'string') {
      placeholderRe.lastIndex = 0;
      let m;
      while ((m = placeholderRe.exec(step.soul)) !== null) noteReference(m[1], false);
    }
  });

  return usage;
}

/* ---------------- Catalog helpers ---------------- */

function catalogConcept(id) {
  return state.config.catalog.find(c => c.id === id) || null;
}

function isCatalog(field) {
  return !field.__custom && !!catalogConcept(field.id);
}

/** Compose effective field by merging catalog (if any) + author overrides. */
export function effectiveField(field) {
  if (field.__custom) return { ...field };
  const concept = catalogConcept(field.id);
  if (!concept) return { ...field, __custom: true };
  return { ...concept, ...field };
}

function uiComponentLabel(c) {
  return ({
    'input': 'Single-line input',
    'textarea': 'Multi-line text',
    'slider': 'Slider',
    'select': 'Dropdown',
    'radio-group': 'Radio buttons',
    'toggle': 'On/off switch',
    'file-upload': 'File upload',
    'json-input': 'JSON editor',
    'prompt-picker': 'Image picker (visual cards)',
    'visual-picker': 'Visual picker (modal grid + categories)',
    'interactive-prompt': 'Interactive prompt (inline pills)',
    'multi-select': 'Multi-select (checkboxes in dropdown)',
    'editable-select': 'Editable select (typeable dropdown)',
    'color-picker': 'Color picker (hex + HSV)',
    'image-pair': 'Image pair (start + end frames)',
  })[c] || c;
}

/* ---------------- Modal helpers ---------------- */

function openModal(id) {
  document.getElementById(id)?.classList.add('visible');
  document.getElementById(id)?.setAttribute('aria-hidden', 'false');
}
function closeModal(id) {
  document.getElementById(id)?.classList.remove('visible');
  document.getElementById(id)?.setAttribute('aria-hidden', 'true');
}

/* ---------------- Row editor (only shown when expanded) ---------------- */

function renderRowEditor(field, idx, ctx) {
  const eff = effectiveField(field);
  const fromCatalog = isCatalog(field);
  const usage = ctx?.usage?.get(field.id) || { steps: [], requiredBySome: false };

  // Visible and Advanced are independent UI toggles:
  //   - Visible: render this field in the user form? (visible:false → hidden)
  //   - Advanced: place this field under the Advanced disclosure tab in the
  //               runner (advanced:true → grouped under "Advanced")
  //
  // Neither affects required/optional state. Whether a field is required
  // comes from the model schema (the step's __schemaMeta.required list).
  // Hiding a required field without a default is a configuration gap the
  // preview run will catch — we don't lock the toggle in the builder.
  const hasUsableDefault = (() => {
    if (field.default != null && field.default !== '') return true;
    if (eff.default != null && eff.default !== '') return true;
    return false;
  })();
  const isRequiredBySome = !!usage.requiredBySome;
  const canHide = true;
  const canMarkAdvanced = true;

  const grid = el('div', { class: 'grid grid-cols-1 md:grid-cols-2 gap-3 mt-3' });

  // Title
  grid.appendChild(el('div', { class: 'field' },
    el('label', {}, 'Title'),
    el('input', {
      value: eff.title || '',
      placeholder: 'Display label',
      oninput: (e) => { field.title = e.target.value; notify(); },
    }),
  ));

  // Description
  grid.appendChild(el('div', { class: 'field' },
    el('label', {}, 'Description'),
    el('input', {
      value: eff.description || '',
      placeholder: 'Helper text',
      oninput: (e) => { field.description = e.target.value; notify(); },
    }),
  ));

  // ui_component — changing this on a catalog field detaches it.
  grid.appendChild(el('div', { class: 'field' },
    el('label', {}, 'Control'),
    (() => {
      const sel = el('select', {
        onchange: (e) => {
          const newUi = e.target.value;
          if (fromCatalog && newUi !== catalogConcept(field.id)?.ui_component) {
            if (!confirm(`Changing the control on catalog field "${field.id}" detaches it from the catalog and turns it into a custom field. Continue?`)) {
              e.target.value = catalogConcept(field.id)?.ui_component || newUi;
              return;
            }
            const snap = effectiveField(field);
            state.agent.fields[idx] = { ...snap, __custom: true, ui_component: newUi };
            notify();
            return;
          }
          field.ui_component = newUi;
          notify();
        }
      });
      for (const c of state.config.uiComponents) {
        const opt = el('option', { value: c }, uiComponentLabel(c));
        if ((field.ui_component || eff.ui_component) === c) opt.selected = true;
        sel.appendChild(opt);
      }
      return sel;
    })(),
  ));

  // Type-specific config (enum array editor, range, default — whichever
  // applies to the current ui_component). The same helper drives the step's
  // Custom config panel on Pass 2, so the two editors stay structurally
  // identical: changing how a field looks is a single-source-of-truth job.
  //
  // For catalog rows we make sure `field.enum`/`field.range` exist locally
  // before handing off, so editing rows doesn't have to fall through to
  // catalog state midway.
  if ((eff.ui_component === 'select' || eff.ui_component === 'radio-group')
      && !Array.isArray(field.enum) && Array.isArray(eff.enum)) {
    field.enum = [...eff.enum];
  }
  if (eff.ui_component === 'slider' && !field.range && eff.range) {
    field.range = { min: eff.range.min ?? null, max: eff.range.max ?? null };
  }
  // Effective view passed in so the helper sees the catalog-merged shape
  // when no local overrides exist yet.
  const merged = { ...eff, ...field };
  // Persist any seeded keys back onto the real field reference (the helper
  // edits the object you pass, and we want those edits to land on `field`).
  merged.enum = field.enum ?? merged.enum ?? null;
  merged.range = field.range ?? merged.range ?? null;
  merged.default = field.default ?? merged.default ?? null;
  // Proxy: writes go to the real field; the helper sees an "effective" view
  // for the ui_component / type discrimination.
  const proxyField = new Proxy(field, {
    get(target, prop) {
      if (prop in target) return target[prop];
      return merged[prop];
    },
    set(target, prop, value) {
      target[prop] = value;
      return true;
    },
  });
  const slot = el('div', { class: 'field md:col-span-2' });
  appendTypeSpecificConfig(slot, proxyField);
  grid.appendChild(slot);

  // ---------- Cost multiplier ----------
  //
  // Author-controlled, opt-in. When set, the value the end user picks for
  // this field multiplies the floor of every step that references the field
  // via `${field_id}`. When omitted, the field has *no* cost impact at all —
  // that's the rule the user asked for ("eğer çarpan seçilmiyor ise onun
  // fiyata etkisi yoktur").
  //
  // Shape depends on control type:
  //   - numeric  (slider / input number) → single float; e.g. duration=5 with
  //     costMultiplier=1 means floor scales linearly with the user's pick.
  //   - enum     (select / radio-group)  → map { <option>: <float>, … }
  //     so the author can charge differently per option (hd=2, standard=1).
  //   - toggle   (boolean)               → map { true: <float>, false: <float> }
  //   - other    (textarea, file-upload, json)
  //                                      → no UI (the value isn't numerically
  //                                        meaningful as a price multiplier).
  const supportsCostMultiplier = (
    eff.ui_component === 'slider' || eff.ui_component === 'input'
    || eff.ui_component === 'select' || eff.ui_component === 'radio-group'
    || eff.ui_component === 'prompt-picker'
    || eff.ui_component === 'visual-picker'
    || eff.ui_component === 'multi-select'
    || eff.ui_component === 'editable-select'
    || eff.ui_component === 'toggle'
  );

  if (supportsCostMultiplier) {
    const numericKind = eff.ui_component === 'slider' || eff.ui_component === 'input';
    const enumKind = eff.ui_component === 'select' || eff.ui_component === 'radio-group'
      || eff.ui_component === 'prompt-picker' || eff.ui_component === 'visual-picker'
      || eff.ui_component === 'multi-select' || eff.ui_component === 'editable-select';
    const toggleKind = eff.ui_component === 'toggle';

    const wrap = el('div', { class: 'field md:col-span-2' });
    wrap.appendChild(el('label', {},
      'Cost multiplier ',
      el('span', { class: 'text-xs text-muted-foreground font-normal' },
        '(optional — leave blank for no price impact)'),
    ));

    if (numericKind) {
      // Single float. Floor scales as: model.cost × user_value × multiplier.
      // Most agents leave this blank and let model.cost speak for itself.
      // A non-blank value here is the author saying "the user's number IS
      // the price driver" (think: duration in seconds for a video model).
      const cm = field.costMultiplier;
      const inp = el('input', {
        type: 'number', step: 'any',
        value: typeof cm === 'number' ? String(cm) : '',
        placeholder: 'e.g. 1.0',
        oninput: (e) => {
          field.costMultiplier = e.target.value === '' ? null : Number(e.target.value);
          notify();
        },
      });
      wrap.appendChild(inp);
    } else if (enumKind) {
      const options = Array.isArray(eff.enum) ? eff.enum : [];
      if (options.length === 0) {
        wrap.appendChild(el('div', { class: 'text-xs text-muted-foreground' },
          'Add options above first; then assign a multiplier to each.'));
      } else {
        const currentMap = (field.costMultiplier && typeof field.costMultiplier === 'object') ? field.costMultiplier : {};
        const grid2 = el('div', { class: 'grid grid-cols-1 sm:grid-cols-2 gap-2' });
        for (const opt of options) {
          const optStr = String(opt);
          const cur = typeof currentMap[optStr] === 'number' ? String(currentMap[optStr]) : '';
          grid2.appendChild(el('div', { class: 'flex items-center gap-2' },
            el('span', { class: 'font-mono text-xs whitespace-nowrap', style: 'min-width: 5rem;' }, optStr),
            el('input', {
              type: 'number', step: 'any',
              value: cur, placeholder: '×',
              style: 'min-height: 36px;',
              oninput: (e) => {
                const map = { ...(field.costMultiplier && typeof field.costMultiplier === 'object' ? field.costMultiplier : {}) };
                if (e.target.value === '') delete map[optStr];
                else map[optStr] = Number(e.target.value);
                field.costMultiplier = Object.keys(map).length ? map : null;
                notify();
              },
            }),
          ));
        }
        wrap.appendChild(grid2);
      }
    } else if (toggleKind) {
      const cm = (field.costMultiplier && typeof field.costMultiplier === 'object') ? field.costMultiplier : {};
      const row = el('div', { class: 'flex gap-3' });
      for (const key of ['true', 'false']) {
        const cur = typeof cm[key] === 'number' ? String(cm[key]) : '';
        row.appendChild(el('div', { class: 'flex items-center gap-2' },
          el('span', { class: 'font-mono text-xs' }, key),
          el('input', {
            type: 'number', step: 'any',
            value: cur, placeholder: '×',
            style: 'min-height: 36px; width: 6rem;',
            oninput: (e) => {
              const map = { ...(field.costMultiplier && typeof field.costMultiplier === 'object' ? field.costMultiplier : {}) };
              if (e.target.value === '') delete map[key];
              else map[key] = Number(e.target.value);
              field.costMultiplier = Object.keys(map).length ? map : null;
              notify();
            },
          }),
        ));
      }
      wrap.appendChild(row);
    }

    grid.appendChild(wrap);
  }

  // Toggles
  // Visible controls render-in-form; Advanced controls grouping under the
  // Advanced disclosure tab. Required marks the field as mandatory in the
  // runner — when the user clicks Generate without filling it in, the
  // runner surfaces a red-outline inline error.
  //
  // Required has two sources, OR'd together:
  //   - Model-required: a step wires this field as a required model input
  //     (step.requiredKeys → schema.key === '${id}'). The toggle is FORCED
  //     on and locked so the author can't accidentally disable validation
  //     for an input the provider will reject with 422.
  //   - Author-required: the author flipped this toggle on manually for a
  //     field that isn't model-required. Free to toggle either way.
  const visibleTooltip = 'Uncheck to hide this field from the user form. A required field without a default that\'s hidden will fail the preview run.';
  const advancedTooltip = 'Group this field under the runner\'s Advanced disclosure tab. Purely a UI grouping; does not change required/optional state.';
  const requiredTooltip = isRequiredBySome
    ? 'A step wires this field as a required model input — it must be required in the form too. Locked on.'
    : 'When checked, the user must fill this field in before Generate runs. Shows a red inline error if left blank.';

  const toggles = el('div', { class: 'flex flex-wrap gap-3 mt-3 text-sm' },
    el('label', { class: 'flex items-center gap-2', title: visibleTooltip },
      (() => {
        const cb = el('input', {
          type: 'checkbox',
          onchange: (e) => { field.visible = e.target.checked; notify(); },
        });
        if (eff.visible !== false) cb.checked = true;
        return cb;
      })(),
      'Visible',
    ),
    el('label', {
      class: 'flex items-center gap-2',
      title: requiredTooltip,
      style: isRequiredBySome ? 'opacity:0.85;' : '',
    },
      (() => {
        const cb = el('input', {
          type: 'checkbox',
          onchange: (e) => {
            // Locked-on when model-required — revert any uncheck attempt.
            if (isRequiredBySome) {
              e.target.checked = true;
              return;
            }
            field.required = e.target.checked ? true : false;
            if (!e.target.checked) delete field.required;
            notify();
          },
        });
        if (isRequiredBySome || field.required === true) cb.checked = true;
        if (isRequiredBySome) {
          cb.disabled = true;
          cb.title = requiredTooltip;
        }
        return cb;
      })(),
      'Required',
    ),
    el('label', { class: 'flex items-center gap-2', title: advancedTooltip },
      (() => {
        const cb = el('input', {
          type: 'checkbox',
          onchange: (e) => { field.advanced = e.target.checked; notify(); },
        });
        if (eff.advanced === true) cb.checked = true;
        return cb;
      })(),
      'Advanced',
    ),
    el('label', {
      class: 'flex items-center gap-2',
      title: 'When checked, this field becomes a gating step in the runner. '
        + 'The user must fill it in before the next fields become reachable. '
        + 'Use it to build wizard-style forms where later questions depend on '
        + 'an earlier answer.',
    },
      (() => {
        const cb = el('input', { type: 'checkbox', onchange: (e) => { field.step = e.target.checked; notify(); } });
        if (field.step === true) cb.checked = true;
        return cb;
      })(),
      'Step',
    ),
  );

  const wrapper = el('div', { class: 'mt-3 pt-3', style: 'border-top: 1px dashed hsl(var(--ait-m-border));' });
  wrapper.appendChild(grid);
  wrapper.appendChild(toggles);
  return wrapper;
}

/* ---------------- Row (collapsed by default) ---------------- */

/** Drag-source attrs for the ⋮⋮ handle. Only the handle starts a drag, so row
 * text stays selectable. While dragging, all rows' bodies hide (cosmetic). */
function fieldDragHandleHandlers(idx, getRow) {
  const hideBody = (row) => {
    for (const child of Array.from(row.children)) {
      if (child === row.firstElementChild) continue;
      child.dataset.dragHidden = '1';
      child.style.display = 'none';
    }
  };
  const showBody = (row) => {
    for (const child of Array.from(row.children)) {
      if (child.dataset.dragHidden === '1') {
        delete child.dataset.dragHidden;
        child.style.display = '';
      }
    }
  };
  const eachRow = (row, fn) => { for (const r of row.parentElement?.children || []) fn(r); };
  return {
    draggable: 'true',
    ondragstart: (e) => {
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', String(idx));
      const row = getRow();
      row.classList.add('dragging');
      requestAnimationFrame(() => { if (row.classList.contains('dragging')) eachRow(row, hideBody); });
    },
    ondragend: () => {
      const row = getRow();
      row.classList.remove('dragging');
      eachRow(row, showBody);
    },
  };
}

function renderFieldRow(field, idx, ctx) {
  const eff = effectiveField(field);
  const fromCatalog = isCatalog(field);
  const expanded = !!field.__expanded;
  const autoAdded = field.__autoAdded === true;
  const usage = ctx?.usage?.get(field.id) || { steps: [], requiredBySome: false };
  const gatedByEarlierStep = !!ctx?.gatedFieldIds?.has(field.id);

  const row = el('div', {
    class: 'ab-field-row' + (fromCatalog ? '' : ' custom') + (autoAdded ? ' auto-added' : '') + (gatedByEarlierStep ? ' gated' : ''),
    style: gatedByEarlierStep ? 'opacity:0.55;' : '',
    'data-field-idx': String(idx),
    ondragover: (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; row.classList.add('drag-over'); },
    ondragleave: () => row.classList.remove('drag-over'),
    ondrop: (e) => {
      e.preventDefault();
      row.classList.remove('drag-over');
      const fromIdx = Number(e.dataTransfer.getData('text/plain'));
      const toIdx = idx;
      if (!Number.isInteger(fromIdx) || fromIdx === toIdx) return;
      const fs = state.agent.fields;
      const [moved] = fs.splice(fromIdx, 1);
      fs.splice(toIdx, 0, moved);
      notify();
    },
  });

  // Compact summary of the field's cost multiplier (when set). We emit just
  // the bare number — int when the value is whole, float otherwise. No `×`,
  // no range glyph, no "cost" label. The frontend styles the badge; the
  // number does the talking. For enum/toggle maps with multiple values we
  // show the max (worst case) so a single scalar reads cleanly.
  const cm = field.costMultiplier;
  let costBadgeText = null;
  const fmtNum = (n) => Number.isInteger(n) ? String(n) : String(n);
  if (typeof cm === 'number' && Number.isFinite(cm)) {
    costBadgeText = fmtNum(cm);
  } else if (cm && typeof cm === 'object') {
    const vals = Object.values(cm).filter(v => typeof v === 'number' && Number.isFinite(v));
    if (vals.length) costBadgeText = fmtNum(Math.max(...vals));
  }

  // Summary line
  const usedByLabel = usage.steps.length
    ? (usage.steps.length === 1 ? `Used by S${usage.steps[0]}` : 'Used by ' + usage.steps.map(n => 'S' + n).join(', '))
    : null;

  const head = el('div', { class: 'flex items-center justify-between gap-2' },
    el('div', { class: 'flex items-center gap-2 min-w-0' },
      el('span', {
        class: 'ab-drag-handle',
        title: 'Drag to reorder',
        style: 'cursor: grab; user-select: none; padding: 0 0.35rem; color: hsl(var(--ait-m-muted-foreground)); font-size: 1rem;',
        ...fieldDragHandleHandlers(idx, () => row),
      }, '⋮⋮'),
      el('span', { class: 'font-mono text-sm font-bold' }, field.id),
      el('span', { class: 'ab-badge ' + (fromCatalog ? 'catalog' : 'custom') }, fromCatalog ? 'catalog' : 'custom'),
      (usage.requiredBySome || field.required === true)
        ? (() => {
            // The "required" badge fires for two reasons:
            //   1. Model-required — a step wires this field as a required
            //      model input. Locked on.
            //   2. Author-required — the author flipped the Required toggle
            //      manually for a non-model-required field.
            // Either way the runner enforces "fill this in or see a red
            // inline error" on Generate.
            const hasDefault = (field.default != null && field.default !== '') || (eff.default != null && eff.default !== '');
            const lockedByModel = usage.requiredBySome;
            const label = lockedByModel
              ? (hasDefault ? 'required · default set' : 'required')
              : (hasDefault ? 'required (author) · default set' : 'required (author)');
            const tooltip = lockedByModel
              ? (hasDefault
                  ? 'Required by a step, but a default is set — the user can leave it blank and the runtime ships the default.'
                  : 'A step wires this field as a required model input. The user must fill it in (or set a default).')
              : (hasDefault
                  ? 'Marked required by the author. A default is set so the runtime can ship it if the user leaves it blank.'
                  : 'Marked required by the author. The user must fill this in before Generate runs.');
            const style = hasDefault
              ? 'background: rgba(52,199,89,0.18); color: rgb(20,120,60); border-color: rgba(52,199,89,0.45);'
              : 'background: hsl(var(--ait-m-primary) / 0.14); color: hsl(var(--ait-m-primary)); border-color: hsl(var(--ait-m-primary) / 0.35);';
            return el('span', { class: 'ab-badge', style, title: tooltip }, label);
          })()
        : null,
      autoAdded
        ? el('span', {
            class: 'ab-badge',
            style: 'background: rgba(52,199,89,0.18); color: rgb(20,120,60); border-color: rgba(52,199,89,0.45);',
            title: 'Added automatically because a step needs it as input.',
          }, 'auto-added')
        : null,
      usedByLabel
        ? el('span', { class: 'ab-badge', title: 'Steps that reference this field.' }, usedByLabel)
        : null,
      field.step === true
        ? el('span', {
            class: 'ab-badge',
            style: 'background: rgba(255,159,10,0.18); color: rgb(180,100,0); border-color: rgba(255,159,10,0.4);',
            title: 'Gating step — later fields stay locked until this one is answered.',
          }, 'gating step')
        : null,
      gatedByEarlierStep
        ? el('span', {
            class: 'ab-badge',
            title: 'A field above is a gating step; this row will be locked in the runner until that one is answered.',
          }, 'locked until earlier step')
        : null,
      costBadgeText
        ? el('span', {
            class: 'ab-badge ab-cost-badge',
            title: 'Cost multiplier.',
          }, costBadgeText)
        : null,
      el('span', { class: 'text-sm text-muted-foreground truncate' }, eff.title || ''),
      el('span', { class: 'ab-badge', style: 'background: transparent;' }, eff.ui_component || 'input'),
    ),
    el('div', { class: 'flex gap-1' },
      el('button', {
        class: 'btn', type: 'button', title: expanded ? 'Collapse' : 'Edit',
        onclick: () => {
          field.__expanded = !expanded;
          // Acknowledging the row (opening or closing its editor) clears the
          // auto-added highlight — the author has now seen the change.
          if (field.__autoAdded) delete field.__autoAdded;
          notify();
        }
      }, expanded ? 'Collapse' : 'Edit'),
      el('button', {
        class: 'btn danger', type: 'button', title: 'Remove',
        onclick: () => {
          if (usage.steps.length) {
            const msg = `"${field.id}" is referenced by step${usage.steps.length === 1 ? '' : 's'} ${usage.steps.join(', ')}. `
              + 'Removing it will leave those references unresolved — you\'ll have to fix them before you can publish. Continue?';
            if (!confirm(msg)) return;
          }
          state.agent.fields.splice(idx, 1);
          notify();
        }
      }, '×'),
    ),
  );
  row.appendChild(head);

  if (expanded) row.appendChild(renderRowEditor(field, idx, ctx));
  return row;
}

/**
 * Walk every step's `soul` + every step.schema string value and collect the
 * `${id}` placeholders that don't resolve against existing fields or
 * upstream output ids. Used to drive the top-of-pass warning surface so the
 * author sees, in one place, every form field the pipeline expects but the
 * agent hasn't yet defined.
 *
 * Returns a Map<id, { steps: number[] }> so the warning UI can tell the
 * author *which* steps reference each unresolved id — that's the difference
 * between "useful warning" and "yet another todo list".
 */
function collectUnresolvedFromAllSteps() {
  const fieldIds = new Set(state.agent.fields.map(f => f.id));
  const allOutputs = new Set(state.agent.steps.map(s => s.output_id).filter(Boolean));
  const reserved = new Set(['prompt']);
  const re = /\$\{([a-zA-Z0-9_-]+)\}/g;

  const out = new Map();
  const stack = [];
  state.agent.steps.forEach((step, stepIdx) => {
    const oneBased = stepIdx + 1;
    const seenInThisStep = new Set();
    const scan = (text) => {
      if (typeof text !== 'string') return;
      let m;
      while ((m = re.exec(text)) !== null) {
        const id = m[1];
        if (reserved.has(id) || fieldIds.has(id) || allOutputs.has(id)) continue;
        if (seenInThisStep.has(id)) continue;
        seenInThisStep.add(id);
        if (!out.has(id)) out.set(id, { steps: [] });
        out.get(id).steps.push(oneBased);
      }
    };
    scan(step.soul);
    // Walk schema values recursively in case any step keeps placeholders in
    // an array or nested object form.
    stack.length = 0;
    if (step.schema && typeof step.schema === 'object') stack.push(step.schema);
    while (stack.length) {
      const v = stack.pop();
      if (typeof v === 'string') scan(v);
      else if (Array.isArray(v)) v.forEach(item => stack.push(item));
      else if (v && typeof v === 'object') Object.values(v).forEach(item => stack.push(item));
    }
  });
  return out;
}

/**
 * Render the warning surface above the fields list. Shows nothing when every
 * placeholder resolves; otherwise lists each unresolved id with the steps
 * that reference it. The surface is rebuilt on every notify so reactions to
 * adding/removing fields are immediate.
 */
function renderFieldsWarnings() {
  const root = $('#ab-fields-warnings');
  if (!root) return;
  root.innerHTML = '';
  const unresolved = collectUnresolvedFromAllSteps();
  if (unresolved.size === 0) return;

  const card = el('div', {
    class: 'ab-fields-warning',
    style: 'margin-bottom: 1rem; padding: 0.85rem 1rem; border-radius: 14px; '
      + 'background: rgba(245,158,11,0.08); border: 1px solid rgba(245,158,11,0.45); '
      + 'color: hsl(var(--ait-m-foreground)); font-size: 0.85rem; line-height: 1.5;',
  });
  card.appendChild(el('div', { style: 'font-weight: 700; margin-bottom: 0.45rem;' },
    `${unresolved.size} placeholder${unresolved.size === 1 ? '' : 's'} used in your steps ${unresolved.size === 1 ? 'isn\'t' : 'aren\'t'} on the Fields pass yet.`,
  ));
  const list = el('div', { class: 'flex flex-col gap-1' });
  for (const [id, info] of unresolved) {
    const stepsLabel = info.steps.length === 1
      ? `Step ${info.steps[0]}`
      : `Steps ${info.steps.join(', ')}`;
    list.appendChild(el('div', { class: 'flex items-center gap-2 flex-wrap' },
      el('span', {
        class: 'ab-tag',
        style: 'background: rgba(245,158,11,0.18); border-color: rgba(245,158,11,0.45);',
      }, '${' + id + '}'),
      el('span', { style: 'color: hsl(var(--ait-m-muted-foreground)); font-size: 0.78rem;' },
        '— used by ', stepsLabel,
      ),
    ));
  }
  card.appendChild(list);
  card.appendChild(el('div', { style: 'margin-top: 0.5rem; color: hsl(var(--ait-m-muted-foreground)); font-size: 0.78rem;' },
    'Add a field for each one above — pick the right control (catalog or custom) for what the user should enter — or edit the step references to remove them.',
  ));
  root.appendChild(card);
}

export function renderFieldsPass() {
  const list = $('#ab-fields-list');
  const empty = $('#ab-fields-empty');
  if (!list) return;

  // Warnings always re-render. They're outside the list itself, so the
  // focus-aware skip below doesn't touch them — the author sees up-to-date
  // unresolved-id signals even while editing a row.
  renderFieldsWarnings();

  // Same focus-aware skip as `renderStepsPass`: a full list rebuild while
  // the author is typing inside a row swaps the DOM node out from under
  // them, killing focus on every keystroke. Only continuous-typing inputs
  // (textarea, text-like input) qualify for the skip — radio, checkbox,
  // button and select clicks are state changes that *need* a rebuild so
  // the new branch (e.g. enum config panel, default picker) becomes
  // visible.
  const active = document.activeElement;
  const TEXTLIKE_INPUT_TYPES = new Set(['text', 'number', 'search', 'email', 'url', 'tel', 'password', '']);
  const isTypingFocus = active && (
    active.tagName === 'TEXTAREA' ||
    (active.tagName === 'INPUT' && TEXTLIKE_INPUT_TYPES.has(active.type))
  );
  if (isTypingFocus && list.contains(active)) {
    return;
  }

  list.innerHTML = '';
  if (state.agent.fields.length === 0) {
    empty.hidden = false;
    return;
  }
  empty.hidden = true;

  // Build the per-render context once: usage map (which steps reference each
  // field, requiredBySome) + the set of fields that come AFTER a `step:true`
  // field above them (visual lock hint — the runner enforces the actual gate).
  const usage = computeFieldUsage();
  const gatedFieldIds = new Set();
  let lockTriggered = false;
  for (const f of state.agent.fields) {
    if (lockTriggered) gatedFieldIds.add(f.id);
    if (f.step === true) lockTriggered = true;
  }
  const ctx = { usage, gatedFieldIds };

  state.agent.fields.forEach((f, i) => list.appendChild(renderFieldRow(f, i, ctx)));
}

/* ---------------- Catalog picker ---------------- */

function renderCatalogGrid(filter = '') {
  const grid = $('#ab-catalog-grid');
  if (!grid) return;
  grid.innerHTML = '';
  const taken = new Set(state.agent.fields.filter(f => !f.__custom).map(f => f.id));
  const norm = filter.trim().toLowerCase();

  for (const concept of state.config.catalog) {
    const matches = !norm
      || concept.id.toLowerCase().includes(norm)
      || (concept.title || '').toLowerCase().includes(norm);
    if (!matches) continue;
    const disabled = taken.has(concept.id);
    const pick = el('div', {
      class: 'ab-catalog-pick',
      'aria-disabled': disabled ? 'true' : 'false',
      onclick: () => {
        if (disabled) return;
        // Compact entry — only the id, defaults flow through from the catalog.
        // We pin `visible: true` explicitly even when the catalog concept
        // defaults to hidden (e.g. `images`, which the taxonomy marks
        // `visible: false` because it's a backstage alias for `image`). The
        // author just clicked "Add this field to the form" — they expect it
        // to render. The Visible toggle on the row's editor is what flips it
        // back to hidden when that's actually wanted. Without this, the
        // preview tab inherits the catalog default and renders "no documented
        // inputs" even though a field was added.
        // Matches the same `visible: true` pin every other field-creation
        // path uses (steps-pass.js ensureFieldForRequiredKey, custom fields,
        // utils.js ensureFieldForKey, etc.).
        state.agent.fields.push({ id: concept.id, visible: true });
        closeModal('ab-modal-catalog');
        notify();
      },
    },
      el('div', { class: 'pick-title' }, concept.title || concept.id),
      el('div', { class: 'pick-id' }, concept.id, ' · ', concept.ui_component),
    );
    grid.appendChild(pick);
  }
}

/* ---------------- Custom field setup ---------------- */

function fillCustomUiSelect() {
  const sel = $('#ab-custom-uicomp');
  if (!sel || sel.options.length > 0) return;
  for (const c of state.config.uiComponents) {
    sel.appendChild(el('option', { value: c }, uiComponentLabel(c)));
  }
  sel.value = 'textarea';
}

function submitCustomField() {
  const id = ($('#ab-custom-id')?.value || '').trim();
  const ui = ($('#ab-custom-uicomp')?.value || 'textarea');
  const title = ($('#ab-custom-title')?.value || '').trim() || id;
  const errBox = $('#ab-custom-error');

  const showErr = (msg) => { if (errBox) { errBox.hidden = false; errBox.textContent = msg; } };
  if (errBox) errBox.hidden = true;

  if (!id || !/^[a-zA-Z0-9_-]+$/.test(id)) { showErr('ID must contain letters, digits, dash, or underscore.'); return; }
  if (state.agent.fields.some(f => f.id === id)) { showErr('A field with that id already exists.'); return; }

  // Type-aware defaults so the field is immediately useful without going into
  // the editor (it can still be expanded for fine-tuning).
  const seed = { __custom: true, id, title, description: '', type: 'string', ui_component: ui, default: null, visible: true, advanced: false, step: false };
  if (ui === 'toggle') { seed.type = 'boolean'; seed.default = false; }
  else if (ui === 'slider') { seed.type = 'number'; seed.range = { min: 0, max: 1 }; }
  else if (ui === 'select' || ui === 'radio-group') { seed.enum = []; }
  else if (ui === 'prompt-picker') { seed.enum = []; seed.optionImages = {}; }
  else if (ui === 'visual-picker') {
    // visual-picker is enum-driven like prompt-picker, but each option also
    // carries a human-readable label (enumLabels) and an optional category
    // (optionCategories) used as a chip filter inside the modal grid.
    seed.enum = [];
    seed.optionImages = {};
    seed.optionCategories = {};
  }
  else if (ui === 'interactive-prompt') {
    // interactive-prompt assembles a sentence from a fixed template and a set
    // of inline slot pills. The author defines the template ("A {mood} cat in
    // a {setting}.") and per-slot option lists; the runner widget renders the
    // sentence as editable text plus dropdown pills for each slot. The
    // assembled string lands on `assembledTarget` (defaults to the field id).
    seed.template = '';
    seed.slotFields = [];
    seed.assembledTarget = id;
  }
  else if (ui === 'multi-select') {
    // multi-select renders a dropdown of checkboxes; the user can tick several
    // options. The runner emits the selected values as an array on this key.
    seed.type = 'array';
    seed.enum = [];
  }
  else if (ui === 'editable-select') {
    // editable-select is a typeable dropdown — the user can pick from the
    // enum or type their own value. Emits a string on this key.
    seed.enum = [];
  }
  else if (ui === 'color-picker') {
    // color-picker emits a hex string (e.g. "#3366FF"). Default white so the
    // preview renders something instead of an empty swatch.
    seed.default = '#FFFFFF';
  }
  else if (ui === 'image-pair') {
    // image-pair collects two image URLs (start + end frames). The runner
    // emits them as a 2-element array on this key. No enum / no default.
    seed.type = 'array';
  }

  state.agent.fields.push(seed);
  closeModal('ab-modal-custom-setup');
  notify();
  toast(`Field "${id}" added. Expand the row to refine it.`, 'success', 3500);
}

/* ---------------- Wiring ---------------- */

export function wireFieldsPass() {
  // The single "+ Add field" entry point: opens the type picker first.
  $('#ab-add-field')?.addEventListener('click', () => {
    openModal('ab-modal-fieldtype');
  });

  // Type-picker → catalog branch
  $('#ab-pick-catalog')?.addEventListener('click', () => {
    closeModal('ab-modal-fieldtype');
    renderCatalogGrid('');
    if ($('#ab-catalog-search')) $('#ab-catalog-search').value = '';
    openModal('ab-modal-catalog');
  });

  // Type-picker → custom branch
  $('#ab-pick-custom')?.addEventListener('click', () => {
    closeModal('ab-modal-fieldtype');
    fillCustomUiSelect();
    if ($('#ab-custom-id')) $('#ab-custom-id').value = '';
    if ($('#ab-custom-title')) $('#ab-custom-title').value = '';
    if ($('#ab-custom-error')) $('#ab-custom-error').hidden = true;
    openModal('ab-modal-custom-setup');
    setTimeout(() => $('#ab-custom-id')?.focus(), 50);
  });

  $('#ab-custom-create')?.addEventListener('click', submitCustomField);
  $('#ab-custom-id')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') submitCustomField(); });

  $('#ab-catalog-search')?.addEventListener('input', (e) => {
    renderCatalogGrid(e.target.value);
  });

  $$('[data-close-modal]').forEach(b => b.addEventListener('click', () => {
    closeModal(b.getAttribute('data-close-modal'));
  }));
}
