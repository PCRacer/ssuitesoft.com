/**
 * Agent Builder showcase-media generator.
 *
 * Sibling of tester.js: same shape, one entry point. Generates a listing image
 * for the draft and hands the caller a url — writing it into the gallery is
 * opt-in, exactly as a test run's own output is.
 *
 * Gated on a passing test run: art for a pipeline that does not work is waste.
 *
 * Usage:
 *   const report = await mediaGenerator.run({ confirm, userHint });
 */

import { state, notify, cleanAgentForExport } from './state.js';
import { tester } from './tester.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';

/** Mirrors MEDIA_GRID_MAX in main.js (private there; importing it would cycle). */
const SHOWCASE_MAX = 5;

function fail(code, message) {
  return { ok: false, code, message };
}

function isVideoUrl(url) {
  return /\.(mp4|mov|webm|m4v)(\?|#|$)/i.test(String(url || ''));
}

/**
 * Fallback gate for callers with no report in hand (the chat hint). Reads the
 * live step cache, so it goes false once a publish or a reload clears it — a
 * caller holding a passing report should pass `tested` instead.
 */
function hasPassedRun(agent) {
  return tester.passed(agent);
}

/**
 * Generate one showcase image or video for the draft.
 *
 * @param {'image'|'video'} [params.kind]  what to render. Defaults to an image.
 * @param {function} [params.confirm]  called with { credits, kind }; return
 *                                     false to abort. Skipped entirely when the
 *                                     run is free (credits === 0).
 * @param {string}   [params.userHint] plain-language steer for the art
 * @param {object}   [params.doc]      the agent doc (defaults to the live draft)
 * @param {boolean}  [params.tested]   caller already knows a run passed (it is
 *                                     holding the report). Skips the live-cache
 *                                     check, which a publish or reload clears.
 * @param {function} [params.onJob]   called with { jobId, kind, credits } as soon
 *                                     as the render is queued, before the wait —
 *                                     persist it so a reload can re-attach.
 */
/** Server-side price of one showcase render, or null when the quote fails. */
async function quote(kind = 'image', agent = cleanAgentForExport(state.agent)) {
  try {
    const res = await fetchHelper('https://aitopia.ai/api/agent-builder/showcase-media-quote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agent, kind: kind === 'video' ? 'video' : 'image' }),
    });
    const json = await res.json().catch(() => null);
    return res.ok && json?.ok ? Number(json.credits) : null;
  } catch { return null; }
}

async function run({ kind = 'image', confirm, userHint, doc, tested, onJob } = {}) {
  const agent = doc || cleanAgentForExport(state.agent);
  const mediaKind = kind === 'video' ? 'video' : 'image';

  if (!agent?.id || String(agent.id).startsWith('_new')) {
    return fail('missing_id', 'Give the agent an id first.');
  }
  if (!tested && !hasPassedRun(agent)) {
    return fail('not_tested',
      'Run a test first — I need to see the agent works before making art for it.');
  }

  const credits = await quote(mediaKind, agent);

  if (credits > 0 && typeof confirm === 'function') {
    let go = false;
    try { go = await confirm({ credits, kind: mediaKind }); } catch { go = false; }
    if (!go) return fail('cancelled', 'Cancelled.');
  }

  let jobId;
  try {
    const res = await fetchHelper('https://aitopia.ai/api/agent-builder/showcase-media', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agent, kind: mediaKind, userHint: userHint || undefined }),
    });
    const json = await res.json().catch(() => null);
    if (!res.ok || !json?.ok || !json.jobId) {
      return fail(json?.code || 'generate_failed',
        json?.message || `Could not start the ${mediaKind} (HTTP ${res.status}).`);
    }
    jobId = json.jobId;
    // Hand the id over before the wait: the render outlives this page, so the
    // caller must be able to persist it and re-attach after a reload.
    if (typeof onJob === 'function') onJob({ jobId, kind: mediaKind, credits: json.credits });
  } catch (err) {
    return fail('generate_error', err?.message || String(err));
  }

  return followJob(jobId, mediaKind);
}

/** Poll interval — a video takes minutes, so this need not be tight. */
const POLL_MS = 2500;

/**
 * Watch a generation to its verdict on the shared job endpoint — the render
 * writes its result onto the jobs row, so no showcase-specific poller is
 * needed. Exported via `attach` so a card restored after a reload can rejoin a
 * render that is still running server-side.
 */
async function followJob(jobId, mediaKind = 'image') {
  for (;;) {
    await new Promise(r => setTimeout(r, POLL_MS));

    let job;
    try {
      const res = await fetchHelper(`https://aitopia.ai/jobs/${encodeURIComponent(jobId)}`, {
        headers: { Accept: 'application/json' },
      });
      if (res.status === 404) return fail('job_not_found', 'That generation is no longer available.');
      job = await res.json().catch(() => null);
    } catch {
      continue; // a dropped poll is not a failed render — keep watching
    }
    if (!job?.status) continue;
    if (job.status === 'pending' || job.status === 'processing') continue;

    const out = job.output || {};
    if (job.status === 'completed' && out.success === true) {
      return {
        ok: true,
        jobId,
        url: out.url,
        kind: out.kind || mediaKind,
        prompt: out.prompt,
        // What the writer decided the agent produces — shown under the result so
        // the author can see whether it read the pipeline correctly.
        subject: out.subject || '',
        model: out.model || '',
        credits: out.credits,
      };
    }
    return fail(out.code || 'generate_failed',
      out.message || job.error?.message || 'Generation failed.');
  }
}

/**
 * Add a generated image to the showcase gallery. The grid treats
 * showcase_images + videos as ONE capped list, so this must too.
 */
function attachToMedia(report) {
  const url = report?.url;
  if (!url) return false;

  const images = Array.isArray(state.agent.showcase_images) ? state.agent.showcase_images.filter(Boolean) : [];
  const videos = Array.isArray(state.agent.showcase_videos) ? state.agent.showcase_videos.filter(Boolean) : [];
  const combined = [...images, ...videos];
  if (combined.includes(url)) return true;
  if (combined.length >= SHOWCASE_MAX) return false;

  const kindOf = (u) => (videos.includes(u) ? 'video' : images.includes(u) ? 'image' : (isVideoUrl(u) ? 'video' : 'image'));
  combined.push(url);
  state.agent.showcase_videos = combined.filter(u => kindOf(u) === 'video');
  state.agent.showcase_images = combined.filter(u => kindOf(u) !== 'video');
  notify();
  return true;
}

/** True when this image is already in the gallery. */
function inMedia(report) {
  if (!report?.url) return false;
  return [...(state.agent.showcase_images || []), ...(state.agent.showcase_videos || [])]
    .includes(report.url);
}

/** Drop this image from the gallery, so another can take the slot. */
function detachFromMedia(report) {
  const url = report?.url;
  if (!url) return false;
  const images = state.agent.showcase_images || [];
  const videos = state.agent.showcase_videos || [];
  if (!images.includes(url) && !videos.includes(url)) return false;
  state.agent.showcase_images = images.filter(u => u !== url);
  state.agent.showcase_videos = videos.filter(u => u !== url);
  notify();
  return true;
}

export const mediaGenerator = { run, quote, attach: followJob, attachToMedia, detachFromMedia, inMedia };
