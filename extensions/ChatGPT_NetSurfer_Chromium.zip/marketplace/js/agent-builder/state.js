/**
 * Agent Builder — shared state.
 *
 * Single mutable `state` object the wizard reads from and writes to. Mirrors the
 * top-level shape of the JSON document the builder produces (see
 * docs/AGENT-BUILDER.md → JSON reference). Persisted via browser-storage so a refresh
 * does not destroy in-progress authoring.
 *
 * Storage model (v4): every draft is keyed by its `id` (or a synthetic
 * `_new-<rand>` placeholder until the author types one). The listing page
 * (/agent-builder) enumerates these keys, the edit page (/agent-builder/edit/:id)
 * reads/writes the one matching its URL. The legacy single-slot v3 snapshot
 * is migrated into the new namespace once on first load.
 *
 * Key shape: `aitopia.agent-builder.v4.draft.<id>`
 *   value: { pass, agent, creditsPerRun }
 *
 * Note: the preview-bridge in /js/agent-builder-preview/storage-keys.js
 * defines its own `aitopia.agent-builder.preview.draft.<id>` namespace.
 * That is intentionally separate: those snapshots are written *only* when
 * the author clicks Preview and represent "what the preview tab is rendering",
 * not "what the author is currently editing". They may be removed in a
 * follow-up if Preview is wired to read from the v4 draft directly.
 */
import * as store from '/marketplace/js/services/browser-storage.js';

const STORAGE_PREFIX = 'aitopia.agent-builder.v4.draft.';
const LEGACY_SINGLE_SLOT_KEY = 'aitopia.agent-builder.v3';

// Preview outputs are kept in a sibling key so the agent JSON itself stays
// clean. They survive a refresh (the author has already paid credits for
// them — losing them on reload would be cruel) but get wiped whenever the
// step pipeline structurally changes (add/remove/reorder/swap model).
const PREVIEW_OUTPUTS_PREFIX = 'aitopia.agent-builder.v4.preview-outputs.';

// The author's Local working copy lives in its OWN key, separate from the draft
// slot. This is the "active local version": the unpublished edits the author is
// building. It persists across refreshes and is NEVER touched by previewing a
// published version — only by a real edit, "New version", Studio, or an explicit
// delete. The version picker treats it as a first-class version entry.
const LOCAL_DOC_PREFIX = 'aitopia.agent-builder.v4.local.';

export function draftStorageKey(id) {
  return `${STORAGE_PREFIX}${id || '_unsaved'}`;
}

export function previewOutputsStorageKey(id) {
  return `${PREVIEW_OUTPUTS_PREFIX}${id || '_unsaved'}`;
}

function localDocStorageKey(id) {
  return `${LOCAL_DOC_PREFIX}${id || '_unsaved'}`;
}

// Which ids currently have a Local doc. Storage is async but the version
// picker asks this while rendering, so the answer is cached and refreshed by
// every read/write below.
const _localDocPresence = new Map();

/** Cached "is there a Local doc for this id" — synchronous, for render paths. */
export function hasLocalDocSync(id) {
  return _localDocPresence.get(id || '_unsaved') === true;
}

/** Prime the cache for an id; call before a render that depends on it. */
export async function primeLocalDoc(id) {
  const present = !!(await store.getItem(localDocStorageKey(id)));
  _localDocPresence.set(id || '_unsaved', present);
  return present;
}

/** Read the persisted Local doc for an id, or null when there is none. */
export async function readLocalDoc(id) {
  try {
    const raw = await store.getItem(localDocStorageKey(id));
    _localDocPresence.set(id || '_unsaved', !!raw);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch { return null; }
}

/** Persist `doc` as the Local working copy for an id. */
export async function writeLocalDoc(id, doc) {
  if (!id || !doc || typeof doc !== 'object') return;
  try {
    await store.setItem(localDocStorageKey(id), JSON.stringify(doc));
    _localDocPresence.set(id, true);
  } catch {}
}

/** Remove the Local working copy for an id (the author discarded it). */
export async function clearLocalDoc(id) {
  try {
    await store.removeItem(localDocStorageKey(id));
    _localDocPresence.set(id || '_unsaved', false);
  } catch {}
}

/**
 * Discard the Local working copy and reset the editor to the given Main doc.
 *
 * This is the REAL delete: the author's edits live in the draft slot
 * (draft.<id>) — not just the local.<id> mirror — so wiping local.<id> alone
 * leaves the draft slot intact and a refresh restores the edits. Here we
 * REPLACE state.agent with the clean Main doc (not a spread-merge, so no stale
 * fields linger), clear the "-local" marker, re-baseline, and let persist()
 * overwrite the draft slot. The local.<id> mirror is removed too.
 *
 * `mainDoc` is the published Main document; `mainVersion` its version string.
 */
export async function discardLocalToMain(id, mainDoc, mainVersion) {
  await clearLocalDoc(id);
  if (mainDoc && typeof mainDoc === 'object') {
    state.agent = { ...emptyAgent(), ...JSON.parse(JSON.stringify(mainDoc)), id };
    migrateAgent(state.agent);
  } else {
    // No Main to fall back to (never published) — reset to a clean doc so the
    // just-deleted edits don't linger in memory and get re-persisted.
    state.agent = { ...emptyAgent(), id };
    migrateAgent(state.agent);
  }
  // In sync with the published Main version now — no local edits.
  state.publishedVersion = typeof mainVersion === 'string' ? mainVersion : null;
  markSyncedBaseline();
  state.previewPassed = false;
  await notify();   // persists the clean Main doc into the draft slot
}

/** True when a Local working copy exists for an id. */
export async function hasLocalDoc(id) {
  try { return await primeLocalDoc(id); } catch { return false; }
}

/**
 * Enumerate all stored draft keys. The listing page calls this to render the
 * dashboard; the builder doesn't need it. Returns rows of
 * `{ id, agent, pass, creditsPerRun, updatedAt }`, sorted by the caller.
 */
export async function listDrafts() {
  const rows = [];
  for (const { key: k, value } of await store.entries(STORAGE_PREFIX)) {
    const id = k.slice(STORAGE_PREFIX.length);
    try {
      const parsed = JSON.parse(value);
      if (parsed && typeof parsed === 'object' && parsed.agent && typeof parsed.agent === 'object') {
        rows.push({
          id,
          agent: parsed.agent,
          pass: typeof parsed.pass === 'number' ? parsed.pass : 1,
          creditsPerRun: typeof parsed.creditsPerRun === 'number' ? parsed.creditsPerRun : 0,
          // The server version this slot was last published at. The drafts page
          // compares it to the DB's currentVersion to decide whether to render
          // the published copy (unchanged locally) or the local edits.
          publishedVersion: typeof parsed.publishedVersion === 'string' ? parsed.publishedVersion : null,
          // Epoch ms of the last write to this slot. Stamped by persist() on
          // every save and by the seed/clone/import paths. Drives the drafts
          // page's "most recently edited first" sort. 0 for legacy slots
          // written before the field existed (they sort last).
          updatedAt: typeof parsed.updatedAt === 'number' ? parsed.updatedAt : 0,
        });
      }
    } catch {
      // Corrupt entry — skip silently.
    }
  }
  return rows;
}

export async function deleteDraft(id) {
  try { await store.removeItem(draftStorageKey(id)); } catch {}
}

/**
 * Seed (or refresh) a local draft slot from the server's persisted document.
 *
 * Used by the drafts page when localStorage was cleared but the server still
 * holds the published row — re-materialising the slot lets the author keep
 * editing from where the published copy left off. The server doc is the source
 * of truth here, so we stamp `publishedVersion` to the server's currentVersion:
 * the freshly-seeded slot is, by definition, unchanged since publish.
 *
 * `data` is the agent document (BuilderAgentDoc). `version` is the DB's
 * currentVersion. Returns true when a slot was written.
 */
export async function upsertDraftFromServer(id, data, version) {
  if (!id || !data || typeof data !== 'object') return false;
  const agent = { ...emptyAgent(), ...JSON.parse(JSON.stringify(data)) };
  agent.id = id;
  const nextVersion = typeof version === 'string' ? version : null;
  const nextCredits = typeof data.creditsPerRun === 'number' ? data.creditsPerRun : 0;

  // Idempotence guard. The drafts grid calls this on EVERY render to re-seed a
  // synced/cleared slot, and render runs on every cross-tab `storage` event. If
  // we wrote unconditionally (with a fresh `updatedAt`), two open tabs would
  // ping-pong storage events forever — each write wakes the other tab, which
  // re-seeds and writes again — and the recency sort would bounce the row to the
  // top on every tick. So only write when the doc/version actually changed; when
  // it's already in sync, leave the slot (and its `updatedAt`) untouched.
  const key = draftStorageKey(id);
  try {
    const existingRaw = await store.getItem(key);
    if (existingRaw) {
      const existing = JSON.parse(existingRaw);
      if (
        existing &&
        existing.publishedVersion === nextVersion &&
        existing.creditsPerRun === nextCredits &&
        JSON.stringify(existing.agent) === JSON.stringify(agent)
      ) {
        return true; // unchanged — no write, no storage event, no sort bounce
      }
    }
  } catch { /* corrupt existing entry — fall through and overwrite */ }

  const snap = {
    // Land the author on Publish (pass 5) — the doc is complete enough to have
    // been published, so the earlier passes have nothing new to collect.
    pass: 5,
    agent,
    creditsPerRun: nextCredits,
    publishedVersion: nextVersion,
    updatedAt: Date.now(),
  };
  try {
    return await store.setItem(key, JSON.stringify(snap));
  } catch {
    return false;
  }
}

/** Moderation counterpart to upsertDraftFromServer(): memory only, no slot. */
export async function loadAgentIntoMemory(id, data, version) {
  if (!id || !data || typeof data !== 'object') return false;
  state.agent = { ...emptyAgent(), ...JSON.parse(JSON.stringify(data)), id };
  migrateAgent(state.agent);
  state.pass = 5;
  state.creditsPerRun = typeof data.creditsPerRun === 'number' ? data.creditsPerRun : 0;
  state.publishedVersion = typeof version === 'string' ? version : null;
  state.previewPassed = false;
  // Reload run state so a refresh can re-attach to an in-flight job.
  state.previewOutputs = await readPreviewOutputs(id);
  markSyncedBaseline();
  return true;
}

/** Persisted preview outputs for an id, minus stale running entries with no jobId. */
async function readPreviewOutputs(id) {
  try {
    const raw = await store.getItem(previewOutputsStorageKey(id), runScope());
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return {};
    for (const k of Object.keys(parsed)) {
      const entry = parsed[k];
      if (entry && entry.running && !entry.jobId) delete parsed[k];
    }
    return parsed;
  } catch { return {}; }
}

/**
 * Duplicate the draft identified by `sourceId` into a new local slot.
 *
 * The new row gets a fresh kebab-case id derived from the source id
 * (`<source>-copy`, then `-copy-2`, `-copy-3`, …) so multiple clones of the
 * same agent don't collide. The clone's `agent.id` is rewritten to match the
 * new slot — otherwise restore() on the new edit URL would happily overwrite
 * the source draft via the rename-on-input path.
 *
 * Preview-output cache is intentionally NOT cloned: the cached outputs were
 * paid for under the original agent's billing trail and are tied to that
 * docHash. The clone starts with an empty cache.
 *
 * Returns the new draft id, or `null` when the source slot does not exist.
 */
export async function cloneDraft(sourceId) {
  if (!sourceId) return null;
  let raw;
  try { raw = await store.getItem(draftStorageKey(sourceId)); } catch { return null; }
  if (!raw) return null;
  let parsed;
  try { parsed = JSON.parse(raw); } catch { return null; }
  if (!parsed || typeof parsed !== 'object' || !parsed.agent || typeof parsed.agent !== 'object') return null;

  // Pick the first available `<source>-copy[-N]` slug. The source id may be a
  // synthetic `_new-*` placeholder (the author never typed a real id); strip
  // the prefix and append the suffix so the clone gets a readable name.
  const baseId = sourceId.startsWith('_new-') ? 'untitled' : sourceId;
  const sanitized = String(baseId).toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/^-+|-+$/g, '') || 'untitled';
  let candidate = `${sanitized}-copy`;
  let counter = 2;
  while (await store.getItem(draftStorageKey(candidate))) {
    candidate = `${sanitized}-copy-${counter++}`;
  }

  const clonedAgent = JSON.parse(JSON.stringify(parsed.agent));
  clonedAgent.id = candidate;
  // The version field is server-owned. The clone has never been published, so
  // reset it to the 1.0.0 bootstrap value the empty-agent factory uses.
  clonedAgent.version = '1.0.0';

  const snap = {
    pass: typeof parsed.pass === 'number' ? parsed.pass : 1,
    agent: clonedAgent,
    creditsPerRun: typeof parsed.creditsPerRun === 'number' ? parsed.creditsPerRun : 0,
    updatedAt: Date.now(),
  };
  try {
    await store.setItem(draftStorageKey(candidate), JSON.stringify(snap));
  } catch {
    return null;
  }
  return candidate;
}

// Builder runtime: which draft am I editing right now? Set by the boot
// sequence in main.js from the URL (/agent-builder/edit/:id). Empty means
// the builder isn't bound to any id yet — typically the case while the
// listing page is open or before the URL parse finishes.
let _activeDraftId = '';
export function activeDraftId() { return _activeDraftId; }
export function setActiveDraftId(id) { _activeDraftId = String(id || ''); }

// Track the previous storage key so an id rename can clean up the old slot
// instead of orphaning it. Initialised by restore(); reset on every persist.
let _lastPersistedKey = '';

// Every localStorage prefix scoped to a draft id — a rename must carry them all
// or the chat, Local copy and preview state are orphaned.
const ID_SCOPED_PREFIXES = [
  STORAGE_PREFIX,
  PREVIEW_OUTPUTS_PREFIX,
  LOCAL_DOC_PREFIX,
  'aitopia.agent-builder.preview.input-errors.',
  'aitopia.agent-builder.preview.output-errors.',
  'aitopia.agent-builder.preview.run-result.',
  'aitopia.agent-builder.preview.preview-passed.',
  'aitopia.agent-builder.preview.passed-doc-hash.',
  'aitopia.agent-builder.preview.passed-at.',
];

/** Register an extra id-scoped prefix (used by studio.js for its chat log). */
export function registerIdScopedPrefix(prefix) {
  if (typeof prefix === 'string' && prefix && !ID_SCOPED_PREFIXES.includes(prefix)) {
    ID_SCOPED_PREFIXES.push(prefix);
  }
}

/**
 * Move every id-scoped entry onto `newId` and re-point the active draft.
 * Re-baselines `_lastPersistedKey` so persist() won't delete what we just moved.
 */
async function migrateIdScopedKeys(oldId, newId) {
  if (!oldId || !newId || oldId === newId) return false;
  for (const prefix of ID_SCOPED_PREFIXES) {
    try {
      const raw = await store.getItem(`${prefix}${oldId}`);
      if (raw == null) continue;
      await store.setItem(`${prefix}${newId}`, raw);
      await store.removeItem(`${prefix}${oldId}`);
      if (prefix === LOCAL_DOC_PREFIX) {
        _localDocPresence.set(newId, true);
        _localDocPresence.set(oldId, false);
      }
    } catch { /* quota / private mode — best effort */ }
  }
  return true;
}

/** Kebab-case slug for an agent id, derived from the display name. */
export function slugifyId(name) {
  return String(name || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
}

export async function migrateDraftId(oldId, newId) {
  if (!(await migrateIdScopedKeys(oldId, newId))) return false;
  setActiveDraftId(newId);
  _lastPersistedKey = draftStorageKey(newId);
  return true;
}

function emptyAgent() {
  return {
    id: '',
    name: '',
    // Server-owned. The wizard never lets the author edit this field; the value
    // here is the version the *next* successful publish will write. Bootstrapped
    // to 1.0.0 for an unpublished id, refreshed from
    //   GET /api/agent-builder/version/:id
    // when the author types an id, and from the `nextVersion` field of every
    // successful publish response.
    version: '1.0.0',
    description: '',
    category: '',
    // `icon` is no longer authored in the builder UI — empty here means the
    // runtime resolver (getAgentIcon) falls back to an ID-derived path
    // (`/agent-images/<id>-icon.{jpg,png}`). Kept in state so publish payloads
    // still carry the field for backends that whitelist it.
    icon: '',
    // Marketplace media — used by the published agent page hero and (via
    // bootstrap.js hydration) the preview page. Authored in Pass-2 (Media).
    showcase_images: [],
    showcase_videos: [],
    featured_video: '',
    capabilities: [],
    tags: [],
    estimatedDuration: { min: 10, max: 120 },
    inputTypes: ['text'],
    outputTypes: [],
    available: true,
    modelSelectorEnabled: false,
    costEstimate: { minCost: 0, maxCost: 0, currency: 'USD' },
    template: 'default',
    fields: [],
    steps: [],
  };
}

export const state = {
  pass: 1,
  agent: emptyAgent(),
  // Loaded from /api/agent-builder/config
  config: {
    // Server-owned (env: AGENT_BUILDER_TEMPLATES, parsed on the API). Empty
    // until the config fetch resolves; renderers guard against the empty
    // case (a missing template select is preferable to a literal that
    // disagrees with what the server accepts).
    templates: [],
    catalog: [],
    // No longer the full catalog. The model menu is fetched live from
    // /api/models/all when the picker opens (paged + filtered through its
    // search/type tabs). This array is a CACHE of models the author has
    // actually picked or that a loaded agent references — populated by
    // rememberModel() so the per-step cost/output-type lookups
    // (state.config.models.find(...)) still resolve without re-fetching.
    models: [],
  billing: { enabled: false, usdPerCredit: 0.02 },
    uiComponents: ['input', 'textarea', 'slider', 'select', 'radio-group', 'toggle', 'file-upload', 'json-input', 'prompt-picker', 'visual-picker', 'interactive-prompt', 'multi-select', 'editable-select', 'color-picker', 'image-pair'],
  },
  // Pass-5 author input (credits per run, before clamping to floor).
  creditsPerRun: 0,
  // Per-step Play cache — { [stepIndex]: { outputId, output, exposed, ranAt } }.
  // The Steps pass Play button reads this to skip already-run upstream steps
  // and feeds new outputs back in. Lives in-memory only; a refresh clears it
  // (intentional — provider calls cost real money, we don't want a stale
  // cache to silently survive a code change to the agent).
  previewOutputs: {},
  // Per-field author test inputs — { [fieldId]: value }. The Play button
  // feeds these to runSingleStep as the user-input scope. Also in-memory.
  testInputs: {},
  // Preview pass tracking (publish unlocks when true).
  previewPassed: false,
  // When previewPassed is false despite a previously-passing run, this says
  // why — 'changed' (pipeline edited) or 'expired' (>24h old). Used by the
  // preview pass to tailor the "out of date" copy. Empty string when there
  // is no stale state to explain.
  previewStaleReason: '',
  // True when the current state.agent.id is already claimed by a published
  // agent in the registry. Set by refreshNextVersion's server response.
  // validateMetadata reads it; the publish button gates on it.
  idTaken: false,
  // True once the author owns the id (typed it, or it isn't the name's slug).
  // Until then the id follows the name. Recomputed by restore().
  idManual: false,
  // Server-side status for the current state.agent.id (null = no row yet).
  // Once an id reaches 'approved' the input becomes read-only — renaming a
  // published agent's id would orphan its history + break every consumer
  // that pinned it.
  publishedStatus: null,
  // The server version this draft was last published at (json.version from the
  // publish response). The drafts page compares it to the DB's currentVersion:
  //   - equal   → local copy is in sync with the DB → render the DB copy.
  //   - differ  → the author edited locally since publish (an edit stamps a
  //               local "-local" marker onto this value) → render the local copy.
  // Null until the first successful publish of this slot.
  publishedVersion: null,
  // Runtime-error list written by the dedicated preview tab into
  // localStorage and synced into state by renderPreviewPass /
  // syncPreviewStateFromStorage. Non-empty here blocks Publish even when
  // input validators pass.
  previewOutputErrors: [],
  // Admin edit-in-place mode: { id, version } when an admin opens a version to
  // overwrite it (no version bump, no Local fork). Null in normal authoring.
  moderationEdit: null,
  // Subscribers (cheap pub/sub — just call render() after any mutation).
  _subs: new Set(),
};

/**
 * Drop the cached preview output for `stepIndex` and every step after it.
 * Called by the Steps pass whenever a step's model_id, soul, schema, or
 * upstream-affecting metadata changes — a stale cache would happily feed
 * the new step a value the old version produced.
 *
 * Idempotent: missing keys are no-ops.
 */
/**
 * Cache a model's pricing/output metadata so the per-step lookups
 * (`state.config.models.find(m => m.id === step.model_id)`) resolve without a
 * round-trip. Called when a model is picked and when a loaded agent's step
 * schema is fetched (the schema response carries an `x-model` block). Upserts
 * by id; a later, richer record overwrites an earlier sparse one.
 *
 * `meta` shape (from /model-schema `x-model` or /api/models/all rows):
 *   { id, provider, displayName, tier, tags, cost, capabilities, creditsEstimated }
 */
export function rememberModel(meta) {
  if (!meta || typeof meta !== 'object' || typeof meta.id !== 'string' || !meta.id) return;
  const list = Array.isArray(state.config.models) ? state.config.models : (state.config.models = []);
  const idx = list.findIndex(m => m && m.id === meta.id);
  if (idx >= 0) list[idx] = { ...list[idx], ...meta };
  else list.push({ ...meta });
}

export function invalidatePreviewFrom(stepIndex) {
  if (!state.previewOutputs || typeof state.previewOutputs !== 'object') return;
  for (const key of Object.keys(state.previewOutputs)) {
    const idx = Number(key);
    if (Number.isInteger(idx) && idx >= stepIndex) {
      delete state.previewOutputs[key];
    }
  }
}

export function subscribe(fn) {
  state._subs.add(fn);
  return () => state._subs.delete(fn);
}

export function notify() {
  // Soul is the wizard's top-level prompt; `schema.prompt` is downstream of
  // it (the runtime substitutes resolved soul into schema.prompt). Any state
  // shape that contradicts that — a `prompt` form field, a non-empty
  // schema.prompt with a `${...}` reference — is a legacy artefact from
  // earlier auto-wire code. Run the migration on every notify so even
  // in-session bugs that re-introduce it get cleaned up immediately.
  migrateAgent(state.agent);
  for (const fn of state._subs) {
    try { fn(); } catch (err) { console.error('[agent-builder] subscriber threw', err); }
  }
  // Detached: render must not wait on storage. Failures are logged, not thrown,
  // because every caller treats notify() as fire-and-forget.
  return persist().catch(err => console.warn('[agent-builder] persist failed', err));
}

/**
 * Serialize the publishable shape of an agent doc with sorted keys at every
 * depth, so two docs equal in content but differing in key order compare equal.
 * Strips the server-owned `version` and the sidecar `creditsPerRun` — neither
 * is part of the doc's published identity. Used to detect author edits.
 */
function publishableFingerprint(agent) {
  const c = cleanAgentForExport(agent || {});
  delete c.version;
  delete c.creditsPerRun;
  const stable = (v) => {
    if (v === null || typeof v !== 'object') return JSON.stringify(v);
    if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
    return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}';
  };
  return stable(c);
}

/**
 * Identity of a doc: meta, media, fields and the model chain. Price and the
 * per-step `schema` are excluded — adoption re-derives both, so including them
 * would make a doc differ from itself.
 */
export function docIdentityFingerprint(doc) {
  const incoming = (doc && typeof doc.agent === 'object' && doc.agent) ? doc.agent : doc;
  if (!incoming || typeof incoming !== 'object') return null;
  const stable = (v) => {
    if (v === null || typeof v !== 'object') return JSON.stringify(v);
    if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
    return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}';
  };
  const arr = (v) => (Array.isArray(v) ? v : []);
  return stable({
    // meta
    id: incoming.id ?? '',
    name: incoming.name ?? '',
    description: incoming.description ?? '',
    category: incoming.category ?? '',
    template: incoming.template ?? '',
    tags: arr(incoming.tags),
    capabilities: arr(incoming.capabilities),
    // media
    showcase_images: arr(incoming.showcase_images),
    showcase_videos: arr(incoming.showcase_videos),
    featured_video: incoming.featured_video ?? '',
    // fields (the input contract)
    fields: arr(incoming.fields).map(f => ({
      id: f?.id ?? null,
      type: f?.type || null,
      title: f?.title ?? '',
      required: f?.required === true,
      enum: Array.isArray(f?.enum) ? f.enum : null,
      default: f?.default ?? null,
    })),
    // models
    steps: arr(incoming.steps).map(st => ({
      kind: st?.kind || 'model',
      model: st?.model_id || st?.model || null,
      output: st?.output_id || null,
      // Adoption hoists a legacy `schema.prompt` into soul; mirror it so a card
      // written the old way still matches the doc it produced.
      soul: (typeof st?.soul === 'string' && st.soul) ? st.soul : String(st?.schema?.prompt || ''),
    })),
  });
}

// Fingerprint of the agent doc at the last sync point (publish or server seed).
// persist() compares against it to stamp publishedVersion "-local" the moment
// the publishable doc diverges — and ONLY then, so preview runs, schema-loading
// flags, and other non-doc mutations never mark the slot dirty.
let _syncedFingerprint = null;

/**
 * Record the current agent doc as the "in sync with DB" baseline. Called right
 * after publish stamps the fresh version and after a server seed. From here,
 * the next publishable change flips the slot to "-local".
 */
export function markSyncedBaseline() {
  _syncedFingerprint = publishableFingerprint(state.agent);
}

/**
 * Strip in-memory-only metadata before serializing.
 *
 * Some renderer state lives on the agent document at runtime (model schema
 * cache on each step, field-editor "pending" flags during the progressive
 * picker) but must NEVER reach localStorage or the publish payload, because
 * they are not part of the agent's contract.
 *
 *   - Top-level keys starting with `__`
 *   - Per-field keys starting with `__` (e.g. `__custom`, `__draft`)
 *   - Per-step keys starting with `__` (e.g. `__schemaMeta`, `__schemaLoading`,
 *     `__optionalAvailable`)
 */
export function cleanAgentForExport(agent) {
  const clone = JSON.parse(JSON.stringify(agent));
  for (const k of Object.keys(clone)) if (k.startsWith('__')) delete clone[k];
  if (Array.isArray(clone.fields)) {
    clone.fields = clone.fields.map(f => {
      if (!f || typeof f !== 'object') return f;
      const out = { ...f };
      for (const k of Object.keys(out)) if (k.startsWith('__')) delete out[k];
      return out;
    });
  }
  if (Array.isArray(clone.steps)) {
    clone.steps = clone.steps.map(s => {
      if (!s || typeof s !== 'object') return s;
      const out = { ...s };
      for (const k of Object.keys(out)) if (k.startsWith('__')) delete out[k];
      return out;
    });
  }
  // creditsPerRun lives on top-level state (the Pass-5 input), not state.agent.
  // Stamp the live value so the exported doc never ships a stale price.
  if (typeof state.creditsPerRun === 'number') clone.creditsPerRun = state.creditsPerRun;
  return clone;
}

// Preview mode: while the version picker is showing a non-Local version, the
// doc in state.agent is a TEMPORARY preview (so the Preview tab can run it), not
// an authored edit. persist() must NOT stamp "-local" or shift the baseline
// during it — otherwise just viewing a version would manufacture a fake local
// edit that survives a refresh. The version picker toggles this around swaps.
let _previewMode = false;
export function setPreviewMode(on) { _previewMode = !!on; }

// Moderation mode: reviewing someone else's agent. Doc stays in memory so it
// never becomes a card in the moderator's own drafts list.
let _moderationMode = false;
export function setModerationMode(on) { _moderationMode = !!on; }
export function isModerationMode() { return _moderationMode; }

// Run state (preview outputs) still has to survive a reload so an in-flight job
// can be re-attached. In moderation it is tab-scoped, so it dies with the tab
// and never reaches the drafts list.
function runScope() { return _moderationMode ? { scope: 'session' } : undefined; }

// Preview outputs live in their own sibling key — the agent JSON stays clean.
// Written on every notify so a refresh keeps the last run's results (the author
// already paid for them) and can resume an in-flight job.
async function persistPreviewOutputs() {
  if (!_activeDraftId) return;
  try {
    const outKey = previewOutputsStorageKey(_activeDraftId);
    const outputs = state.previewOutputs && Object.keys(state.previewOutputs).length
      ? state.previewOutputs
      : null;
    if (outputs) await store.setItem(outKey, JSON.stringify(outputs), runScope());
    else await store.removeItem(outKey, runScope());
  } catch { /* quota / private mode */ }
}

async function persist() {
  // Moderation writes no draft slot, but still persists run state (below) so a
  // refresh can re-attach to an in-flight job.
  if (_moderationMode) { await persistPreviewOutputs(); return; }
  if (!_activeDraftId) return; // Builder not bound to a draft yet — caller is likely the listing page.
  try {
    // Author-edit detection: when this slot is currently in sync with its DB
    // row (publishedVersion is a bare semver) and we have a synced baseline,
    // stamp the version "-local" the moment the publishable doc diverges from
    // that baseline. This is the ONE place that flips a synced slot to dirty —
    // so preview runs, schema-loading flags, and other non-doc churn (which
    // don't change the publishable fingerprint) never mark it. The drafts page
    // then renders the DB copy while bare, the local copy once "-local".
    // Skipped in preview mode: a previewed version is a temporary view, not a
    // local edit, so it must never flip the slot dirty.
    if (
      !_previewMode &&
      typeof state.publishedVersion === 'string' &&
      state.publishedVersion &&
      !state.publishedVersion.endsWith('-local') &&
      _syncedFingerprint != null &&
      publishableFingerprint(state.agent) !== _syncedFingerprint
    ) {
      state.publishedVersion = `${state.publishedVersion}-local`;
    }

    // We DO persist the __-prefixed flags on fields/steps locally so a refresh
    // mid-edit doesn't lose the progressive picker's "I'm not done yet" state.
    // Only the publish/export path strips them; localStorage carries them.
    const snap = {
      pass: state.pass,
      agent: state.agent,
      creditsPerRun: state.creditsPerRun,
      // Carry the publish damga through every save so the drafts page can
      // distinguish "unchanged since publish" from local edits. Null until the
      // first publish of this slot. See state.publishedVersion docs.
      publishedVersion: state.publishedVersion ?? null,
      // Last-write timestamp for the drafts page recency sort.
      updatedAt: Date.now(),
    };
    const targetKey = draftStorageKey(_activeDraftId);

    // Rename that bypassed migrateDraftId. Carry the id-scoped set over instead
    // of deleting the old slot — that deletion is what used to lose the chat.
    if (_lastPersistedKey && _lastPersistedKey !== targetKey) {
      await migrateIdScopedKeys(_lastPersistedKey.slice(STORAGE_PREFIX.length), _activeDraftId);
    }
    await store.setItem(targetKey, JSON.stringify(snap));
    _lastPersistedKey = targetKey;

    await persistPreviewOutputs();
  } catch (err) {
    // Quota / private mode — fine, we just don't persist.
  }
}

/**
 * Drop any state shape an older version of the wizard could have written but
 * that the current version refuses to honor. Today the only migration is the
 * `prompt`-field cleanup: a previous auto-wire pass synthesized a form field
 * literally named `prompt` and wired `schema.prompt` to `${prompt}`. Soul
 * now owns the prompt-shaped text wholesale; any stray `prompt` field is
 * residue and must be erased before the first render so the SOUL card's tag
 * rows don't surface a ghost `${prompt}` chip.
 *
 * Safe to call repeatedly; idempotent.
 */
function migrateAgent(agent) {
  if (!agent || typeof agent !== 'object') return;
  if (Array.isArray(agent.fields)) {
    agent.fields = agent.fields.filter(f => f && f.id !== 'prompt');
  }
  if (Array.isArray(agent.steps)) {
    for (const s of agent.steps) {
      if (!s || typeof s !== 'object') continue;
      if (typeof s.soul !== 'string') s.soul = '';
      if (s.schema && typeof s.schema === 'object' && s.schema.prompt && s.schema.prompt !== '') {
        // If soul is still empty, hoist the old prompt template up to soul
        // so the author's words aren't lost. Otherwise just blank schema.prompt.
        if (!s.soul) s.soul = String(s.schema.prompt);
        s.schema.prompt = '';
      }
    }
  }
}

/**
 * Load the draft identified by the active id (set with setActiveDraftId
 * before this is called). If the slot doesn't exist, leaves `state` at its
 * empty default. The caller is the boot sequence in main.js — once per page
 * load.
 *
 * Also performs a one-shot migration from the legacy v3 single-slot key:
 * if v3 has data and the active draft slot is empty, the v3 contents are
 * copied into the active slot and v3 is removed. This preserves work for
 * authors upgrading from the previous wizard.
 */
export async function restore() {
  const targetKey = draftStorageKey(_activeDraftId);

  // One-shot legacy migration: pull from v3 single-slot if the v4 slot
  // is empty and v3 has something. We honour the legacy agent's id when
  // possible — if the URL said `_new` but v3 has a real id, the caller
  // should redirect to the proper /edit/<id> URL after this returns.
  try {
    if (!(await store.getItem(targetKey))) {
      const legacy = await store.getItem(LEGACY_SINGLE_SLOT_KEY);
      if (legacy) {
        await store.setItem(targetKey, legacy);
        try { await store.removeItem(LEGACY_SINGLE_SLOT_KEY); } catch {}
      }
    }
  } catch {
    // ignore quota/private-mode errors — we'll just render an empty agent.
  }

  try {
    const raw = await store.getItem(targetKey);
    if (!raw) {
      _lastPersistedKey = '';
      _syncedFingerprint = null;
      return;
    }
    const parsed = JSON.parse(raw);
    if (parsed?.agent && typeof parsed.agent === 'object') {
      state.agent = { ...emptyAgent(), ...parsed.agent };
      migrateAgent(state.agent);
    }
    // Clamp the restored pass to the current wizard's range so a future
    // refactor that drops a pass can't leave the user staring at a blank
    // body. Default to 1 if the value is bogus.
    if (typeof parsed?.pass === 'number' && parsed.pass >= 1 && parsed.pass <= 5) {
      state.pass = parsed.pass;
    } else {
      state.pass = 1;
    }
    if (typeof parsed?.creditsPerRun === 'number') state.creditsPerRun = parsed.creditsPerRun;
    state.publishedVersion = typeof parsed?.publishedVersion === 'string' ? parsed.publishedVersion : null;
    // A hand-picked id (not the name's slug) is the author's — leave it alone.
    state.idManual = !!state.agent.id && state.agent.id !== slugifyId(state.agent.name);
    // Seed the author-edit baseline: when the slot is in sync with its DB row
    // (bare version, no "-local"), the restored doc IS the synced doc, so the
    // first publishable change after this flips it dirty. An already-"-local"
    // or never-published slot has no baseline (it's already local / has no DB
    // row to diverge from).
    _syncedFingerprint =
      typeof state.publishedVersion === 'string' &&
      state.publishedVersion &&
      !state.publishedVersion.endsWith('-local')
        ? publishableFingerprint(state.agent)
        : null;
    _lastPersistedKey = targetKey;

    // Restore the sibling preview-outputs cache. Survives refresh; a structural
    // edit (model swap, step delete/add) wipes it via invalidatePreviewFrom.
    //
    // We keep `running: true` entries intact when they carry a jobId — a
    // separate resume path (steps-pass.js#resumeStepPollingOnBoot) cross-checks
    // each one against GET /api/jobs and either re-attaches a poller (still
    // 'processing' on the server) or hydrates the result (already 'completed'
    // since we last saw it). Entries without a jobId came from older drafts
    // and have no way to recover, so we drop their stale running flag.
    try {
      const rawOutputs = await store.getItem(previewOutputsStorageKey(_activeDraftId), runScope());
      if (rawOutputs) {
        const parsedOutputs = JSON.parse(rawOutputs);
        if (parsedOutputs && typeof parsedOutputs === 'object') {
          for (const k of Object.keys(parsedOutputs)) {
            const entry = parsedOutputs[k];
            if (entry && entry.running && !entry.jobId) {
              delete parsedOutputs[k];
            }
          }
          state.previewOutputs = parsedOutputs;
        }
      }
    } catch {
      // corrupt — start clean.
      state.previewOutputs = {};
    }
  } catch (err) {
    console.warn('[agent-builder] restore failed', err);
  }
}

export async function reset() {
  state.agent = emptyAgent();
  state.pass = 1;
  state.creditsPerRun = 0;
  state.previewPassed = false;
  state.previewOutputs = {};
  state.testInputs = {};
  state.publishedVersion = null;
  _syncedFingerprint = null;
  if (_activeDraftId) {
    try { await store.removeItem(draftStorageKey(_activeDraftId)); } catch {}
    try { await store.removeItem(previewOutputsStorageKey(_activeDraftId), runScope()); } catch {}
  }
  _lastPersistedKey = '';
  notify();
}

/**
 * Replace the current draft's agent document with a parsed JSON object —
 * the import counterpart to the Export JSON button. Accepts either a bare
 * agent document or a wrapper `{ agent: {...} }` (the same shape restore()
 * reads from localStorage), so authors can re-import either flavour. Runs
 * the same migration restore() does, clears caches that depended on the
 * previous draft, and notifies subscribers so every pass re-renders.
 */
export function loadAgentFromObject(obj) {
  if (!obj || typeof obj !== 'object') throw new Error('Imported JSON is not an object.');
  const incoming = (obj && typeof obj.agent === 'object' && obj.agent) ? obj.agent : obj;
  if (!incoming || typeof incoming !== 'object') throw new Error('Imported JSON has no agent document.');
  state.agent = { ...emptyAgent(), ...incoming };
  migrateAgent(state.agent);
  state.pass = 1;
  state.creditsPerRun = 0;
  state.previewPassed = false;
  state.previewOutputs = {};
  state.testInputs = {};
  // An imported doc is not in sync with any DB row — clear the publish damga
  // and baseline so the slot renders as a local draft until it is published.
  state.publishedVersion = null;
  _syncedFingerprint = null;
  // Same rule as restore(): a non-slug id was chosen deliberately.
  state.idManual = !!state.agent.id && state.agent.id !== slugifyId(state.agent.name);
  notify();
}

/**
 * Replace the agent document in place from the Inspect JSON inline editor.
 *
 * Unlike loadAgentFromObject (the file-import path), this is a surgical edit of
 * the doc the author is already working on: it keeps the current pass,
 * creditsPerRun, and publish damga untouched. Only the agent doc changes, so
 * persist()'s author-edit detection still flips the slot "-local" and the
 * preview pass's hash check re-locks Publish if the pipeline shape changed.
 *
 * Accepts a bare agent doc or a `{ agent: {...} }` wrapper. Throws on a shape
 * that isn't a usable agent doc (caller surfaces the message inline).
 */
export function applyAgentDocEdit(obj) {
  if (!obj || typeof obj !== 'object') throw new Error('JSON is not an object.');
  const incoming = (obj && typeof obj.agent === 'object' && obj.agent) ? obj.agent : obj;
  if (!incoming || typeof incoming !== 'object') throw new Error('JSON has no agent document.');
  state.agent = { ...emptyAgent(), ...incoming };
  migrateAgent(state.agent);
  notify();
}

/**
 * Fork a specific version's doc into the local editable draft.
 *
 * Used by the version picker / Versions table "New version from this" action:
 * the author is viewing an older (or pending) version read-only and wants to
 * branch a fresh version off it. We adopt that doc as the working copy and
 * clear the publish baseline so the slot reads as local/unpublished — the next
 * publish then mints a new version (server bumps from the highest existing one).
 * The agent id is preserved (same agent, new version), the current pass is kept.
 */
export function forkAgentDoc(obj, doNotify = true) {
  if (!obj || typeof obj !== 'object') throw new Error('Fork source is not an object.');
  const incoming = (obj && typeof obj.agent === 'object' && obj.agent) ? obj.agent : obj;
  if (!incoming || typeof incoming !== 'object') throw new Error('Fork source has no agent document.');
  state.agent = { ...emptyAgent(), ...JSON.parse(JSON.stringify(incoming)) };
  migrateAgent(state.agent);
  // Not in sync with any DB row anymore — this is a new, unpublished branch.
  state.publishedVersion = null;
  _syncedFingerprint = null;
  // A forked doc hasn't been preview-validated as a new version yet.
  state.previewPassed = false;
  // Callers that re-point the draft id first (Studio) notify() themselves.
  if (doNotify) notify();
}

/**
 * Import a parsed JSON document into a NEW local draft slot — the listing
 * page's import path (the edit page uses loadAgentFromObject, which writes the
 * active draft via notify()). Accepts either a bare agent document or a
 * `{ agent: {...} }` / `{ agent, pass, creditsPerRun }` snapshot wrapper.
 *
 * Picks a fresh kebab-case slot id: the document's own `id` when it's free,
 * otherwise `<id>-imported[-N]` so re-importing the same file never clobbers
 * an existing draft. The slot's `agent.id` is rewritten to match the chosen
 * slug so the rename-on-input path in the editor doesn't overwrite a sibling.
 *
 * Returns the new draft id. Throws on a shape that isn't a usable agent doc.
 */
export async function importDraftFromObject(obj) {
  if (!obj || typeof obj !== 'object') throw new Error('Imported JSON is not an object.');
  const wrapper = (obj.agent && typeof obj.agent === 'object') ? obj : null;
  const incoming = wrapper ? wrapper.agent : obj;
  if (!incoming || typeof incoming !== 'object') throw new Error('Imported JSON has no agent document.');
  // Minimal sanity: a usable agent has at least an id, or some steps/fields to
  // edit. Anything emptier is almost certainly the wrong file.
  const hasContent = (typeof incoming.id === 'string' && incoming.id.trim())
    || (Array.isArray(incoming.steps) && incoming.steps.length)
    || (Array.isArray(incoming.fields) && incoming.fields.length);
  if (!hasContent) throw new Error('Imported JSON is not an agent (no id, steps, or fields).');

  const agent = { ...emptyAgent(), ...JSON.parse(JSON.stringify(incoming)) };
  migrateAgent(agent);

  // Derive a free slot slug from the document id (or "imported" when blank).
  const baseId = (typeof incoming.id === 'string' && incoming.id.trim())
    ? incoming.id
    : 'imported';
  const sanitized = String(baseId).toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/^-+|-+$/g, '') || 'imported';
  // Prefer the document's own slug; on collision fall back to
  // `<id>-imported`, then `-imported-2`, `-imported-3`, … (cloneDraft style).
  let candidate = sanitized;
  if (await store.getItem(draftStorageKey(candidate))) {
    candidate = `${sanitized}-imported`;
    let counter = 2;
    while (await store.getItem(draftStorageKey(candidate))) {
      candidate = `${sanitized}-imported-${counter++}`;
    }
  }
  agent.id = candidate;

  const snap = {
    pass: 1,
    agent,
    creditsPerRun: (wrapper && typeof wrapper.creditsPerRun === 'number') ? wrapper.creditsPerRun : 0,
    updatedAt: Date.now(),
  };
  await store.setItem(draftStorageKey(candidate), JSON.stringify(snap));
  return candidate;
}
