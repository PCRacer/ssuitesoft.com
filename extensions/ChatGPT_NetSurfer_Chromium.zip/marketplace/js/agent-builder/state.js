/**
 * Agent Builder — shared state.
 *
 * Single mutable `state` object the wizard reads from and writes to. Mirrors the
 * top-level shape of the JSON document the builder produces (see
 * docs/AGENT-BUILDER.md → JSON reference). Persisted to localStorage so a refresh
 * does not destroy in-progress authoring.
 *
 * Storage model (v4): every draft is keyed by its `id` (or a synthetic
 * `_new-<rand>` placeholder until the author types one). The listing page
 * (/agent-builder) enumerates these keys, the edit page (/agent-builder/edit/:id)
 * reads/writes the one matching its URL. The legacy single-slot v3 snapshot
 * is migrated into the new namespace once on first load.
 *
 * Key shape: `aitopia.agent-builder.v4.draft.<id>`
 *   value: { pass, agent, creditsPerRun }
 *
 * Note: the preview-bridge in /js/agent-builder-preview/storage-keys.js
 * defines its own `aitopia.agent-builder.preview.draft.<id>` namespace.
 * That is intentionally separate: those snapshots are written *only* when
 * the author clicks Preview and represent "what the preview tab is rendering",
 * not "what the author is currently editing". They may be removed in a
 * follow-up if Preview is wired to read from the v4 draft directly.
 */
const STORAGE_PREFIX = 'aitopia.agent-builder.v4.draft.';
const LEGACY_SINGLE_SLOT_KEY = 'aitopia.agent-builder.v3';

// Preview outputs are kept in a sibling key so the agent JSON itself stays
// clean. They survive a refresh (the author has already paid credits for
// them — losing them on reload would be cruel) but get wiped whenever the
// step pipeline structurally changes (add/remove/reorder/swap model).
const PREVIEW_OUTPUTS_PREFIX = 'aitopia.agent-builder.v4.preview-outputs.';

// The author's Local working copy lives in its OWN key, separate from the draft
// slot. This is the "active local version": the unpublished edits the author is
// building. It persists across refreshes and is NEVER touched by previewing a
// published version — only by a real edit, "New version", Studio, or an explicit
// delete. The version picker treats it as a first-class version entry.
const LOCAL_DOC_PREFIX = 'aitopia.agent-builder.v4.local.';

export function draftStorageKey(id) {
  return `${STORAGE_PREFIX}${id || '_unsaved'}`;
}

export function previewOutputsStorageKey(id) {
  return `${PREVIEW_OUTPUTS_PREFIX}${id || '_unsaved'}`;
}

function localDocStorageKey(id) {
  return `${LOCAL_DOC_PREFIX}${id || '_unsaved'}`;
}

/** Read the persisted Local doc for an id, or null when there is none. */
export function readLocalDoc(id) {
  try {
    const raw = localStorage.getItem(localDocStorageKey(id));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch { return null; }
}

/** Persist `doc` as the Local working copy for an id. */
export function writeLocalDoc(id, doc) {
  if (!id || !doc || typeof doc !== 'object') return;
  try { localStorage.setItem(localDocStorageKey(id), JSON.stringify(doc)); } catch {}
}

/** Remove the Local working copy for an id (the author discarded it). */
export function clearLocalDoc(id) {
  try { localStorage.removeItem(localDocStorageKey(id)); } catch {}
}

/**
 * Discard the Local working copy and reset the editor to the given Main doc.
 *
 * This is the REAL delete: the author's edits live in the draft slot
 * (draft.<id>) — not just the local.<id> mirror — so wiping local.<id> alone
 * leaves the draft slot intact and a refresh restores the edits. Here we
 * REPLACE state.agent with the clean Main doc (not a spread-merge, so no stale
 * fields linger), clear the "-local" marker, re-baseline, and let persist()
 * overwrite the draft slot. The local.<id> mirror is removed too.
 *
 * `mainDoc` is the published Main document; `mainVersion` its version string.
 */
export function discardLocalToMain(id, mainDoc, mainVersion) {
  clearLocalDoc(id);
  if (mainDoc && typeof mainDoc === 'object') {
    state.agent = { ...emptyAgent(), ...JSON.parse(JSON.stringify(mainDoc)), id };
    migrateAgent(state.agent);
  } else {
    // No Main to fall back to (never published) — reset to a clean doc so the
    // just-deleted edits don't linger in memory and get re-persisted.
    state.agent = { ...emptyAgent(), id };
    migrateAgent(state.agent);
  }
  // In sync with the published Main version now — no local edits.
  state.publishedVersion = typeof mainVersion === 'string' ? mainVersion : null;
  markSyncedBaseline();
  state.previewPassed = false;
  notify();   // persists the clean Main doc into the draft slot
}

/** True when a Local working copy exists for an id. */
export function hasLocalDoc(id) {
  try { return !!localStorage.getItem(localDocStorageKey(id)); } catch { return false; }
}

/**
 * Enumerate all draft keys currently in localStorage. The listing page calls
 * this to render the dashboard; the builder doesn't need it. Returns rows
 * of `{ id, agent, pass, creditsPerRun, updatedAt }` ordered by best-effort
 * recency (localStorage doesn't track mtime, so the order is insertion order
 * as iterated by the browser).
 */
export function listDrafts() {
  const rows = [];
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (!k || !k.startsWith(STORAGE_PREFIX)) continue;
    const id = k.slice(STORAGE_PREFIX.length);
    try {
      const parsed = JSON.parse(localStorage.getItem(k));
      if (parsed && typeof parsed === 'object' && parsed.agent && typeof parsed.agent === 'object') {
        rows.push({
          id,
          agent: parsed.agent,
          pass: typeof parsed.pass === 'number' ? parsed.pass : 1,
          creditsPerRun: typeof parsed.creditsPerRun === 'number' ? parsed.creditsPerRun : 0,
          // The server version this slot was last published at. The drafts page
          // compares it to the DB's currentVersion to decide whether to render
          // the published copy (unchanged locally) or the local edits.
          publishedVersion: typeof parsed.publishedVersion === 'string' ? parsed.publishedVersion : null,
          // Epoch ms of the last write to this slot. Stamped by persist() on
          // every save and by the seed/clone/import paths. Drives the drafts
          // page's "most recently edited first" sort. 0 for legacy slots
          // written before the field existed (they sort last).
          updatedAt: typeof parsed.updatedAt === 'number' ? parsed.updatedAt : 0,
        });
      }
    } catch {
      // Corrupt entry — skip silently.
    }
  }
  return rows;
}

export function deleteDraft(id) {
  try { localStorage.removeItem(draftStorageKey(id)); } catch {}
}

/**
 * Seed (or refresh) a local draft slot from the server's persisted document.
 *
 * Used by the drafts page when localStorage was cleared but the server still
 * holds the published row — re-materialising the slot lets the author keep
 * editing from where the published copy left off. The server doc is the source
 * of truth here, so we stamp `publishedVersion` to the server's currentVersion:
 * the freshly-seeded slot is, by definition, unchanged since publish.
 *
 * `data` is the agent document (BuilderAgentDoc). `version` is the DB's
 * currentVersion. Returns true when a slot was written.
 */
export function upsertDraftFromServer(id, data, version) {
  if (!id || !data || typeof data !== 'object') return false;
  const agent = { ...emptyAgent(), ...JSON.parse(JSON.stringify(data)) };
  agent.id = id;
  const nextVersion = typeof version === 'string' ? version : null;
  const nextCredits = typeof data.creditsPerRun === 'number' ? data.creditsPerRun : 0;

  // Idempotence guard. The drafts grid calls this on EVERY render to re-seed a
  // synced/cleared slot, and render runs on every cross-tab `storage` event. If
  // we wrote unconditionally (with a fresh `updatedAt`), two open tabs would
  // ping-pong storage events forever — each write wakes the other tab, which
  // re-seeds and writes again — and the recency sort would bounce the row to the
  // top on every tick. So only write when the doc/version actually changed; when
  // it's already in sync, leave the slot (and its `updatedAt`) untouched.
  const key = draftStorageKey(id);
  try {
    const existingRaw = localStorage.getItem(key);
    if (existingRaw) {
      const existing = JSON.parse(existingRaw);
      if (
        existing &&
        existing.publishedVersion === nextVersion &&
        existing.creditsPerRun === nextCredits &&
        JSON.stringify(existing.agent) === JSON.stringify(agent)
      ) {
        return true; // unchanged — no write, no storage event, no sort bounce
      }
    }
  } catch { /* corrupt existing entry — fall through and overwrite */ }

  const snap = {
    // Land the author on Publish (pass 5) — the doc is complete enough to have
    // been published, so the earlier passes have nothing new to collect.
    pass: 5,
    agent,
    creditsPerRun: nextCredits,
    publishedVersion: nextVersion,
    updatedAt: Date.now(),
  };
  try {
    localStorage.setItem(key, JSON.stringify(snap));
    return true;
  } catch {
    return false;
  }
}

/**
 * Duplicate the draft identified by `sourceId` into a new local slot.
 *
 * The new row gets a fresh kebab-case id derived from the source id
 * (`<source>-copy`, then `-copy-2`, `-copy-3`, …) so multiple clones of the
 * same agent don't collide. The clone's `agent.id` is rewritten to match the
 * new slot — otherwise restore() on the new edit URL would happily overwrite
 * the source draft via the rename-on-input path.
 *
 * Preview-output cache is intentionally NOT cloned: the cached outputs were
 * paid for under the original agent's billing trail and are tied to that
 * docHash. The clone starts with an empty cache.
 *
 * Returns the new draft id, or `null` when the source slot does not exist.
 */
export function cloneDraft(sourceId) {
  if (!sourceId) return null;
  let raw;
  try { raw = localStorage.getItem(draftStorageKey(sourceId)); } catch { return null; }
  if (!raw) return null;
  let parsed;
  try { parsed = JSON.parse(raw); } catch { return null; }
  if (!parsed || typeof parsed !== 'object' || !parsed.agent || typeof parsed.agent !== 'object') return null;

  // Pick the first available `<source>-copy[-N]` slug. The source id may be a
  // synthetic `_new-*` placeholder (the author never typed a real id); strip
  // the prefix and append the suffix so the clone gets a readable name.
  const baseId = sourceId.startsWith('_new-') ? 'untitled' : sourceId;
  const sanitized = String(baseId).toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/^-+|-+$/g, '') || 'untitled';
  let candidate = `${sanitized}-copy`;
  let counter = 2;
  while (localStorage.getItem(draftStorageKey(candidate))) {
    candidate = `${sanitized}-copy-${counter++}`;
  }

  const clonedAgent = JSON.parse(JSON.stringify(parsed.agent));
  clonedAgent.id = candidate;
  // The version field is server-owned. The clone has never been published, so
  // reset it to the 1.0.0 bootstrap value the empty-agent factory uses.
  clonedAgent.version = '1.0.0';

  const snap = {
    pass: typeof parsed.pass === 'number' ? parsed.pass : 1,
    agent: clonedAgent,
    creditsPerRun: typeof parsed.creditsPerRun === 'number' ? parsed.creditsPerRun : 0,
    updatedAt: Date.now(),
  };
  try {
    localStorage.setItem(draftStorageKey(candidate), JSON.stringify(snap));
  } catch {
    return null;
  }
  return candidate;
}

// Builder runtime: which draft am I editing right now? Set by the boot
// sequence in main.js from the URL (/agent-builder/edit/:id). Empty means
// the builder isn't bound to any id yet — typically the case while the
// listing page is open or before the URL parse finishes.
let _activeDraftId = '';
export function activeDraftId() { return _activeDraftId; }
export function setActiveDraftId(id) { _activeDraftId = String(id || ''); }

function emptyAgent() {
  return {
    id: '',
    name: '',
    // Server-owned. The wizard never lets the author edit this field; the value
    // here is the version the *next* successful publish will write. Bootstrapped
    // to 1.0.0 for an unpublished id, refreshed from
    //   GET /api/agent-builder/version/:id
    // when the author types an id, and from the `nextVersion` field of every
    // successful publish response.
    version: '1.0.0',
    description: '',
    category: '',
    // `icon` is no longer authored in the builder UI — empty here means the
    // runtime resolver (getAgentIcon) falls back to an ID-derived path
    // (`/agent-images/<id>-icon.{jpg,png}`). Kept in state so publish payloads
    // still carry the field for backends that whitelist it.
    icon: '',
    // Marketplace media — used by the published agent page hero and (via
    // bootstrap.js hydration) the preview page. Authored in Pass-2 (Media).
    showcase_images: [],
    showcase_videos: [],
    featured_video: '',
    capabilities: [],
    tags: [],
    estimatedDuration: { min: 10, max: 120 },
    inputTypes: ['text'],
    outputTypes: [],
    available: true,
    modelSelectorEnabled: false,
    costEstimate: { minCost: 0, maxCost: 0, currency: 'USD' },
    template: 'default',
    fields: [],
    steps: [],
  };
}

export const state = {
  pass: 1,
  agent: emptyAgent(),
  // Loaded from /api/agent-builder/config
  config: {
    // Server-owned (env: AGENT_BUILDER_TEMPLATES, parsed on the API). Empty
    // until the config fetch resolves; renderers guard against the empty
    // case (a missing template select is preferable to a literal that
    // disagrees with what the server accepts).
    templates: [],
    catalog: [],
    // No longer the full catalog. The model menu is fetched live from
    // /api/models/all when the picker opens (paged + filtered through its
    // search/type tabs). This array is a CACHE of models the author has
    // actually picked or that a loaded agent references — populated by
    // rememberModel() so the per-step cost/output-type lookups
    // (state.config.models.find(...)) still resolve without re-fetching.
    models: [],
  billing: { enabled: false, usdPerCredit: 0.02 },
    uiComponents: ['input', 'textarea', 'slider', 'select', 'radio-group', 'toggle', 'file-upload', 'json-input', 'prompt-picker', 'visual-picker', 'interactive-prompt', 'multi-select', 'editable-select', 'color-picker', 'image-pair'],
  },
  // Pass-5 author input (credits per run, before clamping to floor).
  creditsPerRun: 0,
  // Per-step Play cache — { [stepIndex]: { outputId, output, exposed, ranAt } }.
  // The Steps pass Play button reads this to skip already-run upstream steps
  // and feeds new outputs back in. Lives in-memory only; a refresh clears it
  // (intentional — provider calls cost real money, we don't want a stale
  // cache to silently survive a code change to the agent).
  previewOutputs: {},
  // Per-field author test inputs — { [fieldId]: value }. The Play button
  // feeds these to runSingleStep as the user-input scope. Also in-memory.
  testInputs: {},
  // Preview pass tracking (publish unlocks when true).
  previewPassed: false,
  // When previewPassed is false despite a previously-passing run, this says
  // why — 'changed' (pipeline edited) or 'expired' (>24h old). Used by the
  // preview pass to tailor the "out of date" copy. Empty string when there
  // is no stale state to explain.
  previewStaleReason: '',
  // True when the current state.agent.id is already claimed by a published
  // agent in the registry. Set by refreshNextVersion's server response.
  // validateMetadata reads it; the publish button gates on it.
  idTaken: false,
  // Server-side status for the current state.agent.id (null = no row yet).
  // Once an id reaches 'approved' the input becomes read-only — renaming a
  // published agent's id would orphan its history + break every consumer
  // that pinned it.
  publishedStatus: null,
  // The server version this draft was last published at (json.version from the
  // publish response). The drafts page compares it to the DB's currentVersion:
  //   - equal   → local copy is in sync with the DB → render the DB copy.
  //   - differ  → the author edited locally since publish (an edit stamps a
  //               local "-local" marker onto this value) → render the local copy.
  // Null until the first successful publish of this slot.
  publishedVersion: null,
  // Runtime-error list written by the dedicated preview tab into
  // localStorage and synced into state by renderPreviewPass /
  // syncPreviewStateFromStorage. Non-empty here blocks Publish even when
  // input validators pass.
  previewOutputErrors: [],
  // Admin edit-in-place mode: { id, version } when an admin opens a version to
  // overwrite it (no version bump, no Local fork). Null in normal authoring.
  moderationEdit: null,
  // Subscribers (cheap pub/sub — just call render() after any mutation).
  _subs: new Set(),
};

/**
 * Drop the cached preview output for `stepIndex` and every step after it.
 * Called by the Steps pass whenever a step's model_id, soul, schema, or
 * upstream-affecting metadata changes — a stale cache would happily feed
 * the new step a value the old version produced.
 *
 * Idempotent: missing keys are no-ops.
 */
/**
 * Cache a model's pricing/output metadata so the per-step lookups
 * (`state.config.models.find(m => m.id === step.model_id)`) resolve without a
 * round-trip. Called when a model is picked and when a loaded agent's step
 * schema is fetched (the schema response carries an `x-model` block). Upserts
 * by id; a later, richer record overwrites an earlier sparse one.
 *
 * `meta` shape (from /model-schema `x-model` or /api/models/all rows):
 *   { id, provider, displayName, tier, tags, cost, capabilities, creditsEstimated }
 */
export function rememberModel(meta) {
  if (!meta || typeof meta !== 'object' || typeof meta.id !== 'string' || !meta.id) return;
  const list = Array.isArray(state.config.models) ? state.config.models : (state.config.models = []);
  const idx = list.findIndex(m => m && m.id === meta.id);
  if (idx >= 0) list[idx] = { ...list[idx], ...meta };
  else list.push({ ...meta });
}

export function invalidatePreviewFrom(stepIndex) {
  if (!state.previewOutputs || typeof state.previewOutputs !== 'object') return;
  for (const key of Object.keys(state.previewOutputs)) {
    const idx = Number(key);
    if (Number.isInteger(idx) && idx >= stepIndex) {
      delete state.previewOutputs[key];
    }
  }
}

export function subscribe(fn) {
  state._subs.add(fn);
  return () => state._subs.delete(fn);
}

export function notify() {
  // Soul is the wizard's top-level prompt; `schema.prompt` is downstream of
  // it (the runtime substitutes resolved soul into schema.prompt). Any state
  // shape that contradicts that — a `prompt` form field, a non-empty
  // schema.prompt with a `${...}` reference — is a legacy artefact from
  // earlier auto-wire code. Run the migration on every notify so even
  // in-session bugs that re-introduce it get cleaned up immediately.
  migrateAgent(state.agent);
  for (const fn of state._subs) {
    try { fn(); } catch (err) { console.error('[agent-builder] subscriber threw', err); }
  }
  persist();
}

/**
 * Serialize the publishable shape of an agent doc with sorted keys at every
 * depth, so two docs equal in content but differing in key order compare equal.
 * Strips the server-owned `version` and the sidecar `creditsPerRun` — neither
 * is part of the doc's published identity. Used to detect author edits.
 */
function publishableFingerprint(agent) {
  const c = cleanAgentForExport(agent || {});
  delete c.version;
  delete c.creditsPerRun;
  const stable = (v) => {
    if (v === null || typeof v !== 'object') return JSON.stringify(v);
    if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
    return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}';
  };
  return stable(c);
}

// Fingerprint of the agent doc at the last sync point (publish or server seed).
// persist() compares against it to stamp publishedVersion "-local" the moment
// the publishable doc diverges — and ONLY then, so preview runs, schema-loading
// flags, and other non-doc mutations never mark the slot dirty.
let _syncedFingerprint = null;

/**
 * Record the current agent doc as the "in sync with DB" baseline. Called right
 * after publish stamps the fresh version and after a server seed. From here,
 * the next publishable change flips the slot to "-local".
 */
export function markSyncedBaseline() {
  _syncedFingerprint = publishableFingerprint(state.agent);
}

/**
 * Strip in-memory-only metadata before serializing.
 *
 * Some renderer state lives on the agent document at runtime (model schema
 * cache on each step, field-editor "pending" flags during the progressive
 * picker) but must NEVER reach localStorage or the publish payload, because
 * they are not part of the agent's contract.
 *
 *   - Top-level keys starting with `__`
 *   - Per-field keys starting with `__` (e.g. `__custom`, `__draft`)
 *   - Per-step keys starting with `__` (e.g. `__schemaMeta`, `__schemaLoading`,
 *     `__optionalAvailable`)
 */
export function cleanAgentForExport(agent) {
  const clone = JSON.parse(JSON.stringify(agent));
  for (const k of Object.keys(clone)) if (k.startsWith('__')) delete clone[k];
  if (Array.isArray(clone.fields)) {
    clone.fields = clone.fields.map(f => {
      if (!f || typeof f !== 'object') return f;
      const out = { ...f };
      for (const k of Object.keys(out)) if (k.startsWith('__')) delete out[k];
      return out;
    });
  }
  if (Array.isArray(clone.steps)) {
    clone.steps = clone.steps.map(s => {
      if (!s || typeof s !== 'object') return s;
      const out = { ...s };
      for (const k of Object.keys(out)) if (k.startsWith('__')) delete out[k];
      return out;
    });
  }
  return clone;
}

// Track the previous storage key so an id rename can clean up the old slot
// instead of orphaning it. Initialised by restore(); reset on every persist.
let _lastPersistedKey = '';

// Preview mode: while the version picker is showing a non-Local version, the
// doc in state.agent is a TEMPORARY preview (so the Preview tab can run it), not
// an authored edit. persist() must NOT stamp "-local" or shift the baseline
// during it — otherwise just viewing a version would manufacture a fake local
// edit that survives a refresh. The version picker toggles this around swaps.
let _previewMode = false;
export function setPreviewMode(on) { _previewMode = !!on; }

function persist() {
  if (!_activeDraftId) return; // Builder not bound to a draft yet — caller is likely the listing page.
  try {
    // Author-edit detection: when this slot is currently in sync with its DB
    // row (publishedVersion is a bare semver) and we have a synced baseline,
    // stamp the version "-local" the moment the publishable doc diverges from
    // that baseline. This is the ONE place that flips a synced slot to dirty —
    // so preview runs, schema-loading flags, and other non-doc churn (which
    // don't change the publishable fingerprint) never mark it. The drafts page
    // then renders the DB copy while bare, the local copy once "-local".
    // Skipped in preview mode: a previewed version is a temporary view, not a
    // local edit, so it must never flip the slot dirty.
    if (
      !_previewMode &&
      typeof state.publishedVersion === 'string' &&
      state.publishedVersion &&
      !state.publishedVersion.endsWith('-local') &&
      _syncedFingerprint != null &&
      publishableFingerprint(state.agent) !== _syncedFingerprint
    ) {
      state.publishedVersion = `${state.publishedVersion}-local`;
    }

    // We DO persist the __-prefixed flags on fields/steps locally so a refresh
    // mid-edit doesn't lose the progressive picker's "I'm not done yet" state.
    // Only the publish/export path strips them; localStorage carries them.
    const snap = {
      pass: state.pass,
      agent: state.agent,
      creditsPerRun: state.creditsPerRun,
      // Carry the publish damga through every save so the drafts page can
      // distinguish "unchanged since publish" from local edits. Null until the
      // first publish of this slot. See state.publishedVersion docs.
      publishedVersion: state.publishedVersion ?? null,
      // Last-write timestamp for the drafts page recency sort.
      updatedAt: Date.now(),
    };
    const targetKey = draftStorageKey(_activeDraftId);

    // ID rename: if the author edited state.agent.id and we're now writing to
    // a different key than last time, drop the old slot. The new URL is updated
    // by the boot/wire layer in main.js (history.replaceState).
    if (_lastPersistedKey && _lastPersistedKey !== targetKey) {
      try { localStorage.removeItem(_lastPersistedKey); } catch {}
      try { localStorage.removeItem(previewOutputsStorageKey(_lastPersistedKey.slice(STORAGE_PREFIX.length))); } catch {}
    }
    localStorage.setItem(targetKey, JSON.stringify(snap));
    _lastPersistedKey = targetKey;

    // Preview outputs live in their own sibling key — the agent JSON stays
    // clean. We persist on every notify so a refresh keeps the last successful
    // run results visible (the author already paid for them).
    const outKey = previewOutputsStorageKey(_activeDraftId);
    const outputs = state.previewOutputs && Object.keys(state.previewOutputs).length
      ? state.previewOutputs
      : null;
    if (outputs) {
      localStorage.setItem(outKey, JSON.stringify(outputs));
    } else {
      try { localStorage.removeItem(outKey); } catch {}
    }
  } catch (err) {
    // Quota / private mode — fine, we just don't persist.
  }
}

/**
 * Drop any state shape an older version of the wizard could have written but
 * that the current version refuses to honor. Today the only migration is the
 * `prompt`-field cleanup: a previous auto-wire pass synthesized a form field
 * literally named `prompt` and wired `schema.prompt` to `${prompt}`. Soul
 * now owns the prompt-shaped text wholesale; any stray `prompt` field is
 * residue and must be erased before the first render so the SOUL card's tag
 * rows don't surface a ghost `${prompt}` chip.
 *
 * Safe to call repeatedly; idempotent.
 */
function migrateAgent(agent) {
  if (!agent || typeof agent !== 'object') return;
  if (Array.isArray(agent.fields)) {
    agent.fields = agent.fields.filter(f => f && f.id !== 'prompt');
  }
  if (Array.isArray(agent.steps)) {
    for (const s of agent.steps) {
      if (!s || typeof s !== 'object') continue;
      if (typeof s.soul !== 'string') s.soul = '';
      if (s.schema && typeof s.schema === 'object' && s.schema.prompt && s.schema.prompt !== '') {
        // If soul is still empty, hoist the old prompt template up to soul
        // so the author's words aren't lost. Otherwise just blank schema.prompt.
        if (!s.soul) s.soul = String(s.schema.prompt);
        s.schema.prompt = '';
      }
    }
  }
}

/**
 * Load the draft identified by the active id (set with setActiveDraftId
 * before this is called). If the slot doesn't exist, leaves `state` at its
 * empty default. The caller is the boot sequence in main.js — once per page
 * load.
 *
 * Also performs a one-shot migration from the legacy v3 single-slot key:
 * if v3 has data and the active draft slot is empty, the v3 contents are
 * copied into the active slot and v3 is removed. This preserves work for
 * authors upgrading from the previous wizard.
 */
export function restore() {
  const targetKey = draftStorageKey(_activeDraftId);

  // One-shot legacy migration: pull from v3 single-slot if the v4 slot
  // is empty and v3 has something. We honour the legacy agent's id when
  // possible — if the URL said `_new` but v3 has a real id, the caller
  // should redirect to the proper /edit/<id> URL after this returns.
  try {
    if (!localStorage.getItem(targetKey)) {
      const legacy = localStorage.getItem(LEGACY_SINGLE_SLOT_KEY);
      if (legacy) {
        localStorage.setItem(targetKey, legacy);
        try { localStorage.removeItem(LEGACY_SINGLE_SLOT_KEY); } catch {}
      }
    }
  } catch {
    // ignore quota/private-mode errors — we'll just render an empty agent.
  }

  try {
    const raw = localStorage.getItem(targetKey);
    if (!raw) {
      _lastPersistedKey = '';
      _syncedFingerprint = null;
      return;
    }
    const parsed = JSON.parse(raw);
    if (parsed?.agent && typeof parsed.agent === 'object') {
      state.agent = { ...emptyAgent(), ...parsed.agent };
      migrateAgent(state.agent);
    }
    // Clamp the restored pass to the current wizard's range so a future
    // refactor that drops a pass can't leave the user staring at a blank
    // body. Default to 1 if the value is bogus.
    if (typeof parsed?.pass === 'number' && parsed.pass >= 1 && parsed.pass <= 5) {
      state.pass = parsed.pass;
    } else {
      state.pass = 1;
    }
    if (typeof parsed?.creditsPerRun === 'number') state.creditsPerRun = parsed.creditsPerRun;
    state.publishedVersion = typeof parsed?.publishedVersion === 'string' ? parsed.publishedVersion : null;
    // Seed the author-edit baseline: when the slot is in sync with its DB row
    // (bare version, no "-local"), the restored doc IS the synced doc, so the
    // first publishable change after this flips it dirty. An already-"-local"
    // or never-published slot has no baseline (it's already local / has no DB
    // row to diverge from).
    _syncedFingerprint =
      typeof state.publishedVersion === 'string' &&
      state.publishedVersion &&
      !state.publishedVersion.endsWith('-local')
        ? publishableFingerprint(state.agent)
        : null;
    _lastPersistedKey = targetKey;

    // Restore the sibling preview-outputs cache. Survives refresh; a structural
    // edit (model swap, step delete/add) wipes it via invalidatePreviewFrom.
    //
    // We keep `running: true` entries intact when they carry a jobId — a
    // separate resume path (steps-pass.js#resumeStepPollingOnBoot) cross-checks
    // each one against GET /api/jobs and either re-attaches a poller (still
    // 'processing' on the server) or hydrates the result (already 'completed'
    // since we last saw it). Entries without a jobId came from older drafts
    // and have no way to recover, so we drop their stale running flag.
    try {
      const rawOutputs = localStorage.getItem(previewOutputsStorageKey(_activeDraftId));
      if (rawOutputs) {
        const parsedOutputs = JSON.parse(rawOutputs);
        if (parsedOutputs && typeof parsedOutputs === 'object') {
          for (const k of Object.keys(parsedOutputs)) {
            const entry = parsedOutputs[k];
            if (entry && entry.running && !entry.jobId) {
              delete parsedOutputs[k];
            }
          }
          state.previewOutputs = parsedOutputs;
        }
      }
    } catch {
      // corrupt — start clean.
      state.previewOutputs = {};
    }
  } catch (err) {
    console.warn('[agent-builder] restore failed', err);
  }
}

export function reset() {
  state.agent = emptyAgent();
  state.pass = 1;
  state.creditsPerRun = 0;
  state.previewPassed = false;
  state.previewOutputs = {};
  state.testInputs = {};
  state.publishedVersion = null;
  _syncedFingerprint = null;
  if (_activeDraftId) {
    try { localStorage.removeItem(draftStorageKey(_activeDraftId)); } catch {}
    try { localStorage.removeItem(previewOutputsStorageKey(_activeDraftId)); } catch {}
  }
  _lastPersistedKey = '';
  notify();
}

/**
 * Replace the current draft's agent document with a parsed JSON object —
 * the import counterpart to the Export JSON button. Accepts either a bare
 * agent document or a wrapper `{ agent: {...} }` (the same shape restore()
 * reads from localStorage), so authors can re-import either flavour. Runs
 * the same migration restore() does, clears caches that depended on the
 * previous draft, and notifies subscribers so every pass re-renders.
 */
export function loadAgentFromObject(obj) {
  if (!obj || typeof obj !== 'object') throw new Error('Imported JSON is not an object.');
  const incoming = (obj && typeof obj.agent === 'object' && obj.agent) ? obj.agent : obj;
  if (!incoming || typeof incoming !== 'object') throw new Error('Imported JSON has no agent document.');
  state.agent = { ...emptyAgent(), ...incoming };
  migrateAgent(state.agent);
  state.pass = 1;
  state.creditsPerRun = 0;
  state.previewPassed = false;
  state.previewOutputs = {};
  state.testInputs = {};
  // An imported doc is not in sync with any DB row — clear the publish damga
  // and baseline so the slot renders as a local draft until it is published.
  state.publishedVersion = null;
  _syncedFingerprint = null;
  notify();
}

/**
 * Replace the agent document in place from the Inspect JSON inline editor.
 *
 * Unlike loadAgentFromObject (the file-import path), this is a surgical edit of
 * the doc the author is already working on: it keeps the current pass,
 * creditsPerRun, and publish damga untouched. Only the agent doc changes, so
 * persist()'s author-edit detection still flips the slot "-local" and the
 * preview pass's hash check re-locks Publish if the pipeline shape changed.
 *
 * Accepts a bare agent doc or a `{ agent: {...} }` wrapper. Throws on a shape
 * that isn't a usable agent doc (caller surfaces the message inline).
 */
export function applyAgentDocEdit(obj) {
  if (!obj || typeof obj !== 'object') throw new Error('JSON is not an object.');
  const incoming = (obj && typeof obj.agent === 'object' && obj.agent) ? obj.agent : obj;
  if (!incoming || typeof incoming !== 'object') throw new Error('JSON has no agent document.');
  state.agent = { ...emptyAgent(), ...incoming };
  migrateAgent(state.agent);
  notify();
}

/**
 * Fork a specific version's doc into the local editable draft.
 *
 * Used by the version picker / Versions table "New version from this" action:
 * the author is viewing an older (or pending) version read-only and wants to
 * branch a fresh version off it. We adopt that doc as the working copy and
 * clear the publish baseline so the slot reads as local/unpublished — the next
 * publish then mints a new version (server bumps from the highest existing one).
 * The agent id is preserved (same agent, new version), the current pass is kept.
 */
export function forkAgentDoc(obj, doNotify = true) {
  if (!obj || typeof obj !== 'object') throw new Error('Fork source is not an object.');
  const incoming = (obj && typeof obj.agent === 'object' && obj.agent) ? obj.agent : obj;
  if (!incoming || typeof incoming !== 'object') throw new Error('Fork source has no agent document.');
  state.agent = { ...emptyAgent(), ...JSON.parse(JSON.stringify(incoming)) };
  migrateAgent(state.agent);
  // Not in sync with any DB row anymore — this is a new, unpublished branch.
  state.publishedVersion = null;
  _syncedFingerprint = null;
  // A forked doc hasn't been preview-validated as a new version yet.
  state.previewPassed = false;
  // Callers that re-point the draft id first (Studio) notify() themselves.
  if (doNotify) notify();
}

/**
 * Import a parsed JSON document into a NEW local draft slot — the listing
 * page's import path (the edit page uses loadAgentFromObject, which writes the
 * active draft via notify()). Accepts either a bare agent document or a
 * `{ agent: {...} }` / `{ agent, pass, creditsPerRun }` snapshot wrapper.
 *
 * Picks a fresh kebab-case slot id: the document's own `id` when it's free,
 * otherwise `<id>-imported[-N]` so re-importing the same file never clobbers
 * an existing draft. The slot's `agent.id` is rewritten to match the chosen
 * slug so the rename-on-input path in the editor doesn't overwrite a sibling.
 *
 * Returns the new draft id. Throws on a shape that isn't a usable agent doc.
 */
export function importDraftFromObject(obj) {
  if (!obj || typeof obj !== 'object') throw new Error('Imported JSON is not an object.');
  const wrapper = (obj.agent && typeof obj.agent === 'object') ? obj : null;
  const incoming = wrapper ? wrapper.agent : obj;
  if (!incoming || typeof incoming !== 'object') throw new Error('Imported JSON has no agent document.');
  // Minimal sanity: a usable agent has at least an id, or some steps/fields to
  // edit. Anything emptier is almost certainly the wrong file.
  const hasContent = (typeof incoming.id === 'string' && incoming.id.trim())
    || (Array.isArray(incoming.steps) && incoming.steps.length)
    || (Array.isArray(incoming.fields) && incoming.fields.length);
  if (!hasContent) throw new Error('Imported JSON is not an agent (no id, steps, or fields).');

  const agent = { ...emptyAgent(), ...JSON.parse(JSON.stringify(incoming)) };
  migrateAgent(agent);

  // Derive a free slot slug from the document id (or "imported" when blank).
  const baseId = (typeof incoming.id === 'string' && incoming.id.trim())
    ? incoming.id
    : 'imported';
  const sanitized = String(baseId).toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/^-+|-+$/g, '') || 'imported';
  // Prefer the document's own slug; on collision fall back to
  // `<id>-imported`, then `-imported-2`, `-imported-3`, … (cloneDraft style).
  let candidate = sanitized;
  if (localStorage.getItem(draftStorageKey(candidate))) {
    candidate = `${sanitized}-imported`;
    let counter = 2;
    while (localStorage.getItem(draftStorageKey(candidate))) {
      candidate = `${sanitized}-imported-${counter++}`;
    }
  }
  agent.id = candidate;

  const snap = {
    pass: 1,
    agent,
    creditsPerRun: (wrapper && typeof wrapper.creditsPerRun === 'number') ? wrapper.creditsPerRun : 0,
    updatedAt: Date.now(),
  };
  localStorage.setItem(draftStorageKey(candidate), JSON.stringify(snap));
  return candidate;
}
