/** Publish sheet: template + price + earnings, then the existing submit-for-review flow. */

import { state, notify } from './state.js';
import { $, el, floorCredits, pricingBand } from './utils.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';

const BOLT_SVG = '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" aria-hidden="true"><path d="M13 2 4.5 13.5H11l-1 8.5 8.5-11.5H12l1-8.5z"/></svg>';

let onSubmit = null;
let earningsSeq = 0;
let earningsTimer = null;

function sheet() { return $('#ab-publish-sheet'); }

function centerSelected() {
  const host = $('#ab-publish-templates');
  const card = host?.querySelector('.ab-tpl-card.selected');
  if (!host || !card) return;
  host.scrollLeft = card.offsetLeft - (host.clientWidth - card.offsetWidth) / 2;
}

function renderTemplates() {
  const host = $('#ab-publish-templates');
  if (!host) return;
  host.innerHTML = '';
  for (const t of state.config?.templates || []) {
    host.appendChild(el('div', {
      class: 'ab-tpl-card' + (state.agent.template === t ? ' selected' : ''),
      role: 'button', tabindex: '0', title: t,
      onclick: () => { state.agent.template = t; notify(); renderTemplates(); centerSelected(); },
      onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); e.currentTarget.click(); } },
    },
      el('img', { class: 'ab-tpl-shot ab-tpl-shot-dark', src: `/img/agent-builder/templates/${encodeURIComponent(t)}.webp`, alt: '', onerror: (e) => e.target.remove() }),
      el('img', { class: 'ab-tpl-shot ab-tpl-shot-light', src: `/img/agent-builder/templates/${encodeURIComponent(t)}-light.webp`, alt: '', onerror: (e) => e.target.remove() }),
      el('span', { class: 'ab-tpl-card-name' }, t),
      el('span', { class: 'ab-tpl-check' }, '✓'),
    ));
  }
  const dots = $('#ab-publish-dots');
  if (dots) {
    dots.innerHTML = '';
    for (const t of state.config?.templates || []) {
      dots.appendChild(el('button', {
        type: 'button', class: state.agent.template === t ? 'active' : '', tabindex: '-1',
        onclick: () => { state.agent.template = t; notify(); renderTemplates(); centerSelected(); },
      }));
    }
  }
}

function renderCredits() {
  const inp = $('#ab-publish-credits');
  const hint = $('#ab-publish-credits-hint');
  if (!inp) return;
  const fc = floorCredits();
  const band = pricingBand(fc);
  inp.min = String(band.min);
  inp.max = String(band.max);
  inp.disabled = band.blocked || band.collapsed;
  if (document.activeElement !== inp) inp.value = String(state.creditsPerRun || '');
  const submit = $('#ab-publish-submit');
  if (submit && !submit.disabled) {
    const n = Math.max(0, Math.round(Number(state.creditsPerRun) || 0));
    submit.innerHTML = 'Publish Agent' + (n > 0 ? `<span class="ab-doc-credits">${BOLT_SVG}${n}</span>` : '');
  }
  if (hint) {
    hint.textContent = band.blocked
      ? `Provider cost (${fc} credits) is above the ceiling - this agent cannot be published.`
      : band.collapsed
        ? `Price is fixed at ${band.min} credits.`
        : `${band.min}–${band.max} · suggested ${band.suggested}`;
  }
}

function renderEarnings() {
  const box = $('#ab-publish-earning');
  if (!box) return;
  const credits = Math.max(0, Math.round(Number(state.creditsPerRun) || 0));
  const seq = ++earningsSeq;
  clearTimeout(earningsTimer);
  const unavailable = () => { box.innerHTML = '<strong>—</strong>'; box.classList.add('muted'); };
  if (!credits) return unavailable();
  earningsTimer = setTimeout(async () => {
    try {
      const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/earnings-estimate?credits=${credits}`);
      if (seq !== earningsSeq) return;
      const data = res.ok ? await res.json() : null;
      if (!data?.available || data.excluded) return unavailable();
      box.classList.remove('muted');
      box.innerHTML = `<strong>${data.withoutRemix.credits.toFixed(2)} Credits</strong>`
        + `<span>(${(data.withoutRemix.rate * 100).toFixed(0)}%)</span>`;
      setInfo(data);
    } catch {
      unavailable();
    }
  }, 250);
}

function setInfo(data) {
  const info = $('#ab-publish-info');
  if (!info) return;
  const pct = (n) => `${(n * 100).toFixed(0)}%`;
  const company = data.buckets.find((b) => b.name === 'bucket:company');
  info.dataset.tooltip = `Your share per run after the platform's ${company ? pct(company.rate) : 'cut'}. Estimate - depends on what each run settles.`;
}

function render() {
  renderTemplates();
  renderCredits();
  renderEarnings();
  const note = $('#ab-publish-media-note');
  if (note) note.hidden = (state.agent.showcase_images || []).length + (state.agent.showcase_videos || []).length > 0;
}

export function openPublishSheet(submit) {
  const s = sheet();
  if (!s) return;
  onSubmit = submit;
  render();
  s.hidden = false;
  const back = $('#ab-publish-backdrop');
  if (back) back.hidden = false;
  document.body.classList.add('ab-publish-open');
  centerSelected();
  $('#ab-publish-submit')?.focus();
}

export function closePublishSheet() {
  const s = sheet();
  if (s) s.hidden = true;
  const b = $('#ab-publish-submit');
  if (b) b.disabled = false;
  const back = $('#ab-publish-backdrop');
  if (back) back.hidden = true;
  document.body.classList.remove('ab-publish-open');
  onSubmit = null;
}

export function wirePublishSheet() {
  $('#ab-publish-close')?.addEventListener('click', closePublishSheet);
  $('#ab-publish-backdrop')?.addEventListener('click', closePublishSheet);
  $('#ab-publish-credits')?.addEventListener('input', (e) => {
    state.creditsPerRun = Number(e.target.value) || 0;
    if (state.agent) state.agent.creditsPerRun = state.creditsPerRun;
    notify();
    renderCredits();
    renderEarnings();
  });
  $('#ab-publish-credits')?.addEventListener('blur', () => {
    const band = pricingBand(floorCredits());
    if (band.blocked) return;
    const v = Number(state.creditsPerRun) || 0;
    const clamped = v < band.min ? band.min : v > band.max ? band.max : v;
    if (clamped !== v) { state.creditsPerRun = clamped; if (state.agent) state.agent.creditsPerRun = clamped; notify(); }
    renderCredits();
    renderEarnings();
  });
  $('#ab-publish-submit')?.addEventListener('click', () => onSubmit?.($('#ab-publish-submit')));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && sheet() && !sheet().hidden) closePublishSheet(); });
}
