/**
 * Pass 5 — Credits & Preview.
 *
 * Computes the floor from steps. Gates publish on:
 *   1. credits_per_run ≥ floor,
 *   2. every wizard validator passes (input validate),
 *   3. a preview-run end-to-end against live models returned success — the
 *      preview page (public/agent-builder/preview.html) writes
 *      output-errors / preview-passed flags to localStorage and this pass
 *      reads them on every render and on the cross-tab `storage` event.
 *
 * The Preview button does NOT run the pipeline here. It runs the input
 * validators only; on clean validators it opens
 * /agent-builder/preview/<id> in a new tab and the dedicated preview page
 * runs POST /api/agent-builder/preview-run against the inline draft JSON.
 */

import { state, notify, cleanAgentForExport, markSyncedBaseline, applyAgentDocEdit, clearLocalDoc } from './state.js';
import * as store from '/marketplace/js/services/browser-storage.js';
import { $, toast, floorCredits, pricingBand, recomputeDerived, validateMetadata, validateTemplate, validateFields, validateSteps, validateCredits, ensureSignedIn } from './utils.js';
import { hasPublishableChange } from './version-picker.js';
// Single source of truth for a step's cache-key shape. Importing it (rather
// than re-declaring) keeps the per-step "passed" check in lockstep with the
// hash steps-pass.js writes into the run cache.
import { stepDocHash } from './steps-pass.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';
import {
  inputErrorsKey,
  outputErrorsKey,
  previewPassedKey,
  passedDocHashKey,
  passedAtKey,
  previewAffectingDoc,
  PREVIEW_VALIDITY_MS,
  hashString,
  readJson,
  writeJson,
  remove as removeKey,
} from '/marketplace/js/agent-builder-preview/storage-keys.js';

/**
 * Read the runtime-error set written by the dedicated preview page into
 * `state.previewOutputErrors`. This is the single source of truth for
 * "did the live pipeline run cleanly?" — the wizard never runs the
 * pipeline itself; it just reflects what the preview tab persisted.
 *
 * Sync the boolean `state.previewPassed` from the dedicated flag too;
 * the preview page sets it to '1' after a clean run and clears it on
 * any runtime failure.
 */
// Pipeline can be marked "passed" two ways:
//   1. The dedicated preview tab finished a full Run preview cleanly →
//      previewPassedKey + passedDocHashKey set in localStorage.
//   2. The builder's per-step Run buttons have each been clicked and
//      each returned a successful result against the current draft →
//      state.previewOutputs[i] holds output, no error, for every step.
// Option 2 lets authors validate a pipeline step-by-step (cheaper when
// debugging — they don't re-pay for earlier successful steps each time)
// and still unlock Publish without a full pipeline re-run.
function allStepsPassedFromBuilderRuns() {
  const steps = Array.isArray(state.agent?.steps) ? state.agent.steps : [];
  if (steps.length === 0) return false;
  const outputs = state.previewOutputs || {};
  for (let i = 0; i < steps.length; i++) {
    const cached = outputs[i];
    if (!cached) return false;
    if (cached.running || cached.error) return false;
    if (cached.output == null && cached.exposed == null) return false;
    // Cache must match the step's current authoring shape — same guard
    // steps-pass.js uses to decide whether a row is stale.
    if (cached.docHash !== stepDocHash(steps[i])) return false;
  }
  return true;
}

// Last preview-passed flag read from storage. Cached so renderPreviewPass()
// stays synchronous — storage is async now, render is not.
let _rawPassedFlag = false;
let _syncing = false;

/**
 * Refresh preview state from storage without blocking render.
 *
 * Render must stay synchronous, so the async read runs detached and re-renders
 * only when it actually changed something — re-notifying unconditionally would
 * loop forever.
 */
function refreshPreviewStateFromStorage() {
  if (_syncing) return;
  _syncing = true;
  const before = `${state.previewPassed}|${state.previewStaleReason}|${state.previewOutputErrors?.length ?? 0}`;
  syncPreviewStateFromStorage()
    .then(() => {
      const after = `${state.previewPassed}|${state.previewStaleReason}|${state.previewOutputErrors?.length ?? 0}`;
      if (before !== after) notify();
    })
    .catch(() => {})
    .finally(() => { _syncing = false; });
}

async function syncPreviewStateFromStorage() {
  const id = state.agent?.id;
  if (!id || typeof id !== 'string') {
    state.previewOutputErrors = [];
    state.previewPassed = false;
    state.previewStaleReason = '';
    _rawPassedFlag = false;
    return;
  }
  const errors = await readJson(outputErrorsKey(id));
  const storedErrors = Array.isArray(errors) ? errors : [];

  // Per-step successes win over stale pipeline errors. If every step has a
  // clean cached run against the current draft, treat the pipeline as
  // passed and silence any leftover error from a prior failed Run preview.
  const stepPassed = allStepsPassedFromBuilderRuns();
  if (stepPassed) {
    state.previewOutputErrors = [];
    state.previewPassed = true;
    state.previewStaleReason = '';
    _rawPassedFlag = true;
    return;
  }
  state.previewOutputErrors = storedErrors;

  // Preview-passed is only honored when the successful run executed against
  // the *current* draft AND happened within the validity window. Two reasons
  // we can flip it back to stale:
  //   - hash mismatch: the steps/fields that actually drive the
  //     pipeline changed since the last passing run (template, listing copy
  //     and media are excluded — they don't affect what providers do)
  //   - expired: the passing run is older than PREVIEW_VALIDITY_MS (72h).
  //     Providers update model schemas and prices; a days-old pass
  //     shouldn't authorize a publish against drifted infrastructure.
  const flag = (await readJson(previewPassedKey(id))) === '1';
  _rawPassedFlag = flag;
  if (!flag) {
    state.previewPassed = false;
    state.previewStaleReason = '';
    return;
  }
  const passedHash = await readJson(passedDocHashKey(id));
  const currentHash = hashString(previewAffectingDoc(cleanAgentForExport(state.agent)));
  // passedAt only exists from this version onward. For older passing runs
  // written before the timestamp key existed, treat them as fresh — we
  // can't punish authors for a record they had no way to stamp. The 24h
  // window only kicks in once a NEW preview run writes the timestamp.
  const passedAt = Number(await readJson(passedAtKey(id))) || 0;
  const ageMs = passedAt ? Date.now() - passedAt : 0;

  const hashMismatch = passedHash !== currentHash;
  const expired = ageMs > PREVIEW_VALIDITY_MS;
  state.previewPassed = !hashMismatch && !expired;
  state.previewStaleReason = !state.previewPassed
    ? (hashMismatch ? 'changed' : (expired ? 'expired' : ''))
    : '';
}

// True while the Inspect JSON inline editor is open. Guards renderPreviewPass
// from overwriting the textarea on an unrelated notify(), and is flipped by the
// Edit / Save / Cancel handlers wired in wirePreviewPass.
let jsonEditing = false;

/**
 * Estimated earnings card (DN-32).
 *
 * The author is choosing a price; this tells them what that price returns to
 * them. The figures come from the server — the bucket percentages live in
 * `aiconomy_rules` and the pool rate is an environment switch, so computing
 * them here would let the card keep promising an old split.
 *
 * Two scenarios, because a bucket's fallback only fires when it has nobody to
 * pay: with no remix the owner may absorb the remix bucket, with a remix they
 * do not. Both are estimates — the actual pool depends on what the run settles.
 */
let earningsSeq = 0;
let earningsTimer = null;

function pct(n) { return `${(n * 100).toFixed(0)}%`; }

function renderEarningsCard(el, data) {
  if (data.excluded) {
    el.innerHTML = `
      <div class="ab-card">
        <h3 class="font-bold mb-1">Your estimated earnings</h3>
        <p class="text-sm text-muted-foreground">
          This account does not earn commission, so publishing pays nothing to it.
        </p>
      </div>`;
    el.hidden = false;
    return;
  }

  const company = data.buckets.find((b) => b.name === 'bucket:company');
  // What an unclaimed remix bucket adds to the author — 0 unless its fallback
  // points at the owner. Derived from the two scenarios rather than the bucket
  // list, so it stays right whatever the fallback is configured to do.
  const remixShare = Math.max(0, data.withoutRemix.rate - data.withRemix.rate);

  const line = (label, value, note) => `
    <div class="flex items-baseline justify-between gap-3 text-sm">
      <span>${label}${note ? ` <span class="text-muted-foreground">— ${note}</span>` : ''}</span>
      <span class="text-muted-foreground">${value}</span>
    </div>`;

  el.innerHTML = `
    <div class="ab-card">
      <h3 class="font-bold mb-1">Your estimated earnings</h3>
      <p class="text-sm text-muted-foreground mb-3">
        Per run, out of the <strong>${data.poolCredits.toFixed(2)}</strong> credits
        ($${data.poolUsd.toFixed(4)}) a ${data.creditsPerRun}-credit run leaves to share.
        <a href="/marketplace/agent-builder-landing.html" target="_blank" rel="noopener" class="underline">Learn more</a>
      </p>

      <div class="space-y-1">
        ${company ? line('Platform', pct(company.rate)) : ''}
        ${line('You', pct(data.withRemix.rate))}
        ${remixShare > 0
          ? line('Remix share', pct(remixShare), 'yours while nobody has remixed this agent')
          : ''}
      </div>

      <div class="flex items-baseline justify-between gap-3 border-t mt-3 pt-3">
        <span class="font-bold">Your total <span class="text-muted-foreground font-normal">(estimate)</span></span>
        <span>
          <strong>${data.withoutRemix.credits.toFixed(2)}</strong> credits
          <span class="text-muted-foreground">· $${data.withoutRemix.usd.toFixed(4)}</span>
          <strong class="ml-1">${pct(data.withoutRemix.rate)}</strong>
        </span>
      </div>

      <p class="text-xs text-muted-foreground mt-3">
        These are estimates${remixShare > 0
          ? `. If somebody remixes your agent, the ${pct(remixShare)} remix share goes to them
             instead and your total becomes ${pct(data.withRemix.rate)}
             (${data.withRemix.credits.toFixed(2)} credits · $${data.withRemix.usd.toFixed(4)}).`
          : ` — the remix share always goes to whoever remixes this agent.`}
      </p>
    </div>`;
  el.hidden = false;
}

async function renderEarningsEstimate() {
  const el = $('#ab-earnings');
  if (!el) return;

  const credits = Math.max(0, Math.round(Number(state.creditsPerRun) || 0));
  if (!credits) { el.hidden = true; return; }

  // The price input fires on every keystroke; only the last one matters, and a
  // stale response must never overwrite a newer one.
  const seq = ++earningsSeq;
  clearTimeout(earningsTimer);
  earningsTimer = setTimeout(async () => {
    try {
      const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/earnings-estimate?credits=${credits}`);
      if (seq !== earningsSeq) return;
      if (!res.ok) { el.hidden = true; return; }
      const data = await res.json();
      // `available: false` means the platform is not on the profit/bucket
      // model, so no per-creator figure can be promised — show nothing.
      if (!data?.available) { el.hidden = true; return; }
      renderEarningsCard(el, data);
    } catch {
      el.hidden = true;   // never block the pass over a display-only panel
    }
  }, 300);
}

export function renderPreviewPass() {
  recomputeDerived();
  refreshPreviewStateFromStorage();
  const fc = floorCredits();

  // The floor is no longer shown as its own field — the author only sets a
  // price. It still drives the allowed band and the publish validators below,
  // so it is computed exactly as before, just not displayed.
  const creditsInp = $('#m-credits');

  // Open at the suggested price and keep the author inside the band. Floor is
  // the cost; the band is what may actually be charged for it. An unpriced
  // draft, or one still sitting at/below the bare floor (Studio writes those —
  // its guide only requires clearing the floor), opens at `suggested` rather
  // than `min`, so the default is a real markup instead of near-cost.
  const band = pricingBand(fc);
  if (!band.blocked) {
    if (!state.creditsPerRun || state.creditsPerRun <= fc) state.creditsPerRun = band.suggested;
    else if (state.creditsPerRun < band.min) state.creditsPerRun = band.min;
    else if (state.creditsPerRun > band.max) state.creditsPerRun = band.max;
  }
  if (state.agent) state.agent.creditsPerRun = state.creditsPerRun;
  if (creditsInp) {
    creditsInp.min = String(band.min);
    creditsInp.max = String(band.max);
    creditsInp.disabled = band.blocked || band.collapsed;
    if (document.activeElement !== creditsInp) creditsInp.value = String(state.creditsPerRun);
  }
  const hintEl = $('#m-credits-hint');
  if (hintEl) {
    hintEl.textContent = band.blocked
      ? `Provider cost (${fc} credits) is above the ceiling — this agent cannot be published. Reduce cost instead of the price.`
      : band.collapsed
        ? `Cost is near the credit ceiling, so the price is fixed at ${band.min}.`
        : `Allowed range ${band.min}–${band.max} credits. Suggested ${band.suggested} (${(band.suggested / fc).toFixed(2)}× cost).`;
  }

  // The sidebar cost summary is rendered by main.js's renderCostSummary on
  // every state change, so we don't touch it here.

  renderEarningsEstimate();

  // JSON preview — show the cleaned (publishable) document, not in-memory cruft.
  // While the inline editor is open we leave the textarea alone: a stray notify()
  // from another pass must not clobber the author's in-progress edits.
  const jsonEl = $('#ab-json-preview');
  if (jsonEl && !jsonEditing) jsonEl.textContent = JSON.stringify(cleanAgentForExport(state.agent), null, 2);

  // Publish gate combines three signals:
  //   - input validators clean,
  //   - credits ≥ floor,
  //   - preview run succeeded end-to-end (state.previewPassed === true,
  //     synced from localStorage above) AND no runtime errors persisted.
  const publishBtn = $('#ab-publish');
  const inputErrors = [
    ...validateMetadata(),
    ...validateTemplate(),
    ...validateFields(),
    ...validateSteps(),
    ...validateCredits(),
  ];
  const runtimeErrors = state.previewOutputErrors || [];

  // Distinguish three failure modes so the author can act on the right one:
  //   - rawFlag missing → preview never returned success for this id yet
  //   - rawFlag present, hash mismatch → pipeline edited since the pass
  //   - rawFlag present, 24h elapsed → expired
  // Previously only the middle case surfaced a message, which meant a
  // disabled Publish button could silently sit there with no explanation
  // when the preview tab failed to write the passed flag (e.g. the run
  // settled via a code path that didn't reach applyPreviewRunFinal). Now
  // every disabled-because-of-preview state explains itself.
  const id = state.agent?.id;
  const rawFlag = id ? _rawPassedFlag : false;
  const previewMissing = !rawFlag && !state.previewPassed && runtimeErrors.length === 0;
  const previewStale = rawFlag && !state.previewPassed && runtimeErrors.length === 0;
  // True when the draft has something new to publish (forked / edited). False
  // when it's in sync with a published version — nothing to ship.
  const hasChange = hasPublishableChange();

  const errBox = $('#m5-errors');
  if (errBox) {
    const blocks = [];
    if (inputErrors.length) {
      blocks.push('<div class="ab-error"><strong>Validation:</strong>' + inputErrors.map(e => `<div>• ${e}</div>`).join('') + '</div>');
    }
    if (runtimeErrors.length) {
      blocks.push(
        '<div class="ab-error"><strong>Last preview run failed:</strong>' +
          runtimeErrors.map(e => {
            const stepLabel = (e.stepIndex != null && e.stepIndex >= 0) ? ` (step ${e.stepIndex + 1})` : '';
            return `<div>• ${e.message || JSON.stringify(e)}${stepLabel}</div>`;
          }).join('') +
          '</div>'
      );
    }
    if (previewStale) {
      const reason = state.previewStaleReason;
      const detail = reason === 'expired'
        ? 'The last successful preview run is more than 72 hours old. Re-run Preview to unlock Publish.'
        : 'The pipeline (steps or fields) has changed since the last successful preview run. Re-run Preview to unlock Publish.';
      blocks.push(
        `<div class="ab-error"><strong>Preview is out of date.</strong> ${detail}</div>`
      );
    }
    if (!state.moderationEdit && previewMissing && inputErrors.length === 0) {
      blocks.push(
        '<div class="ab-error"><strong>Preview required.</strong> Click <em>Preview</em> and run the pipeline end-to-end. Publish unlocks once a run finishes successfully against this draft.</div>'
      );
    }
    // Nothing new to ship: the draft is in sync with a published version, so a
    // publish would just re-mint an identical version. Block it. (Not in
    // moderation mode — there the admin overwrites the opened version.)
    if (!state.moderationEdit && !hasChange && inputErrors.length === 0) {
      blocks.push(
        '<div class="ab-error"><strong>No changes to publish.</strong> This matches the published version. Edit something (it becomes a new version) before publishing.</div>'
      );
    }
    errBox.hidden = blocks.length === 0;
    errBox.innerHTML = blocks.join('');
  }

  if (publishBtn) {
    if (state.moderationEdit) {
      // Save over the opened version: block invalid/failed docs only.
      publishBtn.disabled = inputErrors.length > 0 || runtimeErrors.length > 0;
      publishBtn.textContent = 'Save in place';
    } else {
      publishBtn.disabled =
        inputErrors.length > 0 || runtimeErrors.length > 0 || !state.previewPassed || !hasChange;
    }
  }
}

export function wirePreviewPass() {
  $('#m-credits')?.addEventListener('input', (e) => {
    state.creditsPerRun = Number(e.target.value) || 0;
    // Keep state.agent in sync — it's the doc that gets exported/previewed.
    if (state.agent) state.agent.creditsPerRun = state.creditsPerRun;
    notify();
  });

  $('#ab-preview')?.addEventListener('click', openPreviewTab);
  $('#ab-publish')?.addEventListener('click', publish);

  wireJsonInspector();

  // The dedicated preview tab updates output-errors and preview-passed.
  // Listen for cross-tab writes so the publish gate flips live without the
  // author having to switch back to this tab and refresh.
  store.onExternalChange((e) => {
    if (!e.key) return;
    const id = state.agent?.id;
    if (!id) return;
    if (e.key === outputErrorsKey(id) || e.key === previewPassedKey(id)) {
      notify();
    }
  });
  // Also poll on tab focus — `storage` events only fire on OTHER windows,
  // so a user clicking back to this tab after running preview in the same
  // session would otherwise miss the update.
  window.addEventListener('focus', () => notify());
}

/**
 * Wire the Inspect JSON inline editor (Edit / Save / Cancel).
 *
 *   Edit   — copy the current cleaned doc into the textarea, swap the <pre> for
 *            the editor, show Save/Cancel.
 *   Save   — parse the textarea; on valid JSON apply it to the draft (which
 *            persists to localStorage via notify()) and close the editor. On a
 *            parse/shape error, keep the editor open and show the message.
 *   Cancel — discard the edits and restore the read-only view from state.
 */
function wireJsonInspector() {
  const pre = $('#ab-json-preview');
  const editor = $('#ab-json-editor');
  const editBtn = $('#ab-json-edit');
  const saveBtn = $('#ab-json-save');
  const cancelBtn = $('#ab-json-cancel');
  const status = $('#ab-json-status');
  if (!pre || !editor || !editBtn || !saveBtn || !cancelBtn) return;

  const showView = () => {
    jsonEditing = false;
    pre.hidden = false;
    editor.hidden = true;
    editBtn.hidden = false;
    saveBtn.hidden = true;
    cancelBtn.hidden = true;
    if (status) status.textContent = '';
    // Refresh the read-only view from the (possibly just-saved) state.
    pre.textContent = JSON.stringify(cleanAgentForExport(state.agent), null, 2);
  };

  const showEditor = () => {
    jsonEditing = true;
    editor.value = JSON.stringify(cleanAgentForExport(state.agent), null, 2);
    pre.hidden = true;
    editor.hidden = false;
    editBtn.hidden = true;
    saveBtn.hidden = false;
    cancelBtn.hidden = false;
    if (status) status.textContent = '';
    editor.focus();
  };

  editBtn.addEventListener('click', showEditor);
  cancelBtn.addEventListener('click', showView);
  saveBtn.addEventListener('click', () => {
    let parsed;
    try {
      parsed = JSON.parse(editor.value);
    } catch (err) {
      if (status) status.textContent = 'Invalid JSON: ' + err.message;
      return;
    }
    try {
      applyAgentDocEdit(parsed);
    } catch (err) {
      if (status) status.textContent = err.message;
      return;
    }
    // applyAgentDocEdit → notify() re-renders every pass; close the editor and
    // show the freshly-saved doc.
    showView();
    toast('Agent JSON updated.', 'success', 3000);
  });
}

/**
 * Click handler for the Preview button.
 *
 * Validates the draft locally; on clean input opens the static preview shell
 * in a new tab. The shell (public/agent-builder/preview.html, served as a
 * static file by apps/web) loads bootstrap.js, which reads the current draft
 * straight from localStorage (`aitopia.agent-builder.v4.draft.<id>` — the
 * same key the builder writes to on every notify) and redirects to the V2
 * shell if `draft.template === 'V2'`.
 *
 * No priming fetch, no snapshot copy, no separate credits key. The URL's
 * :id scopes the localStorage read; everything else flows from there.
 */
function openPreviewTab() {
  const status = $('#ab-preview-status');
  const out = $('#ab-preview-out');
  if (status) status.textContent = '';
  if (out) out.innerHTML = '';

  const id = state.agent?.id;
  if (!id || typeof id !== 'string') {
    toast('Set the agent id (Pass 1) before previewing.', 'error', 5000);
    return;
  }

  const inputErrors = [
    ...validateMetadata(),
    ...validateTemplate(),
    ...validateFields(),
    ...validateSteps(),
  ];

  if (inputErrors.length) {
    // Persist for cross-tab visibility — if the user reopens the preview tab
    // it can render these errors instead of the form.
    writeJson(inputErrorsKey(id), inputErrors.map(message => ({ code: 'input_validation', message })));  // detached: nothing below depends on it
    if (status) status.textContent = 'Preview blocked by validation errors.';
    if (out) out.innerHTML = '<div class="ab-error">' + inputErrors.map(e => `<div>• ${e}</div>`).join('') + '</div>';
    state.previewPassed = false;
    notify();
    return;
  }

  // Input is clean. Clear any stale input errors and stale runtime errors
  // — the upcoming run is responsible for re-populating output-errors.
  // Not awaited: window.open below must stay in the click's gesture context
  // or the popup blocker kills it. The preview tab re-reads these anyway.
  removeKey(inputErrorsKey(id));
  removeKey(outputErrorsKey(id));
  removeKey(previewPassedKey(id));
  _rawPassedFlag = false;

  if (status) status.textContent = 'Opening preview tab…';
  if (out) {
    out.innerHTML = `
      <div class="rounded-2xl border border-blue-300/40 bg-blue-50/40 dark:bg-blue-950/20 p-3 text-sm">
        <strong>Preview opened in new tab.</strong> Run it and come back -
        Publish unlocks once a preview returns success.
      </div>
    `;
  }

  // Moderation has no draft slot, so tell the preview tab to read the DB row.
  const modQs = state.moderationEdit
    ? `?mod=1&version=${encodeURIComponent(state.moderationEdit.version || '')}`
    : '';
  window.open(`/agent-builder/preview/${encodeURIComponent(id)}${modQs}`, '_blank', 'noopener');

  // previewPassed will land via the cross-tab `storage` event when the run
  // completes; nothing else to do here.
  notify();
}

// Admin edit-in-place: overwrite the opened version row (no new version, owner
// and status preserved server-side). Error envelope differs from /publish.
async function publishModeration(docToPublish, status) {
  const { id, version } = state.moderationEdit;
  const res = await fetchHelper(
    `https://aitopia.ai/api/admin/builder-agents/${encodeURIComponent(id)}/${encodeURIComponent(version)}`,
    {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agent: docToPublish }),
    },
  );
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    const errs = json?.error?.errors || (json?.error?.message ? [{ message: json.error.message }] : [{ message: 'Save failed.' }]);
    const lines = errs.map(e => '• ' + (e.message || JSON.stringify(e))).join('\n');
    toast(lines, 'error', 7000);
    if (status) status.textContent = 'Save blocked. See errors above.';
    const out = $('#ab-preview-out');
    if (out) out.innerHTML = '<div class="ab-error">' + errs.map(e => `<div>• ${e.message || JSON.stringify(e)}</div>`).join('') + '</div>';
    return;
  }
  // Re-baseline so the next edit is detected; version stays pinned.
  markSyncedBaseline();
  notify();
  toast(`Saved v${version} in place (admin edit).`, 'success', 6000);
  if (status) status.textContent = `Saved ${id} v${version} in place.`;
}

export async function publish() {
  const status = $('#ab-preview-status');
  if (status) status.textContent = 'Publishing…';

  try {
    // creditsPerRun lives on `state` (not inside state.agent) so the wizard's
    // schema doesn't conflate it with the publish-payload doc shape. But the
    // marketplace needs it to size the Generate button correctly post-publish
    // — the floor in costEstimate is what a run AT LEAST costs, the author's
    // choice in Pass 5 is what we actually charge. Persist it into the doc
    // here so the registry-path response can read it back. Floor-clamped
    // server-side too; client-side clamp here matches Pass 5 input behavior.
    const docToPublish = cleanAgentForExport(state.agent);
    const credits = Math.max(1, Math.round(Number(state.creditsPerRun) || 0));
    if (credits > 0) docToPublish.creditsPerRun = credits;

    // Admin moderator edit-in-place: overwrite the opened version in place via
    // the admin endpoint instead of minting a new version through /publish.
    if (state.moderationEdit) {
      await publishModeration(docToPublish, status);
      return;
    }

    if (!(await ensureSignedIn('Sign in to publish this agent to the marketplace.'))) {
      if (status) status.textContent = 'Sign in to publish.';
      return;
    }

    const res = await fetchHelper('https://aitopia.ai/api/agent-builder/publish', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agent: docToPublish }),
    });
    const json = await res.json();
    if (!res.ok) {
      const lines = (json.errors || [{ message: 'Publish failed.' }]).map(e => '• ' + (e.message || JSON.stringify(e))).join('\n');
      toast(lines, 'error', 7000);
      if (status) status.textContent = 'Publish blocked. See errors above.';
      const out = $('#ab-preview-out');
      if (out) out.innerHTML = '<div class="ab-error">' + (json.errors || []).map(e => `<div>• ${e.message || JSON.stringify(e)}</div>`).join('') + '</div>';
      return;
    }
    // Server is authoritative for version. The response carries the version it
    // wrote (`json.version`) AND the version the wizard should display from now
    // on (`json.nextVersion`). We store the latter — the next publish bumps
    // patch from there.
    const writtenVersion = json.version || state.agent.version;
    // Stamp the slot with the bare version we just wrote (no "-local" marker):
    // the local copy now matches the DB row, so the drafts page renders the
    // published copy until the author edits again.
    if (typeof writtenVersion === 'string') {
      state.publishedVersion = writtenVersion;
    }
    if (typeof json.nextVersion === 'string') {
      state.agent.version = json.nextVersion;
    }
    // Re-baseline AFTER stamping the version: the just-published doc is now the
    // "in sync with DB" reference, so the next publishable edit flips the slot
    // "-local". Must run before notify()/persist() so that persist doesn't see
    // a stale baseline and immediately re-mark the fresh publish dirty.
    markSyncedBaseline();
    // The Local working copy has been published — it's now a real version, so
    // drop the Local mirror. The picker will show the new version, not Local.
    await clearLocalDoc(state.agent.id);
    notify();
    // Tell the version picker a new version row landed so it refreshes its list.
    window.dispatchEvent(new CustomEvent('agent-builder:published'));
    toast(`Submitted as v${writtenVersion}. Next publish will be v${json.nextVersion || '?'}.`, 'success', 6000);
    if (status) status.textContent = `Submitted as ${json.id} v${writtenVersion} (status: ${json.status}).`;
  } catch (err) {
    toast('Network error: ' + err.message, 'error', 6000);
    if (status) status.textContent = 'Publish failed (network).';
  }
}
