/**
 * Agent Builder — main controller.
 *
 * Boots the wizard: loads config, restores any in-progress draft from localStorage,
 * wires the pass navigation, and re-renders on every state change.
 */

import { state, subscribe, notify, restore, reset, cleanAgentForExport, loadAgentFromObject, setActiveDraftId, activeDraftId, draftStorageKey, upsertDraftFromServer, clearLocalDoc } from './state.js';
import { $, $$, el, toast, validateMetadata, validateTemplate, validateFields, validateSteps, stepwiseFloorUsd, totalFloorUsd, floorCredits, usdToCredits, kindStepCredits } from './utils.js';
import { renderFieldsPass, wireFieldsPass } from './fields-pass.js';
import { renderStepsPass, wireStepsPass } from './steps-pass.js';
import { renderPreviewPass, wirePreviewPass } from './preview-pass.js';
import { wireVersionPicker, loadVersionPicker, onStateChangeForVersioning, refreshPickerOptions, initActiveSelection } from './version-picker.js';
import { wireVersionsTab, loadVersionsTab } from './versions-tab.js';
import { wireStudio } from './studio.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';
import { createMediaField } from '/marketplace/js/components/form/media-upload.js';

// The wizard is five passes. Steps comes BEFORE Fields on purpose: step
// schemas drive which form fields the agent needs (the auto-field detour
// inside steps-pass.js adds catalog-matched fields to `state.agent.fields`
// as a side-effect of picking a model). Authoring the form before knowing
// what the pipeline asks for is backwards. Media sits between Metadata and
// Steps so the gallery assets have an agent identity to attach to.
const PASSES = [
  { num: 1, title: 'Metadata', sub: 'Identity, listing copy & template' },
  { num: 2, title: 'Media',    sub: 'Showcase gallery & card video' },
  { num: 3, title: 'Steps',    sub: 'Model pipeline' },
  { num: 4, title: 'Fields',   sub: 'The user form' },
  { num: 5, title: 'Publish',  sub: 'Credits & preview' },
];
const LAST_PASS = PASSES[PASSES.length - 1].num;

function renderStepnav() {
  const nav = $('#ab-stepnav');
  if (!nav) return;
  nav.innerHTML = '';
  const doneness = passDoneness();
  for (const p of PASSES) {
    const cls = 'ab-step'
      + (state.pass === p.num ? ' active' : '')
      + (doneness[p.num] ? ' done' : '');
    const node = el('div', {
      class: cls,
      onclick: () => { state.pass = p.num; notify(); },
    },
      el('span', { class: 'ab-step-num' }, String(p.num)),
      el('div', {},
        el('div', { class: 'ab-step-title' }, p.title),
        el('div', { class: 'ab-step-sub' }, p.sub),
      ),
    );
    nav.appendChild(node);
  }
}

function passDoneness() {
  // Template validation is folded into pass 1 because the template dropdown
  // lives inside the Metadata card. Pass 2 (Media) is optional — the agent
  // can publish without showcase assets and getAgentIcon synthesises an
  // ID-derived fallback at render time — so we mark it done unconditionally.
  // Steps is pass 3 (it precedes Fields so the schema-driven detour can
  // populate fields[] automatically).
  return {
    1: validateMetadata().length === 0 && validateTemplate().length === 0,
    2: true,
    3: validateSteps().length === 0,
    4: validateFields().length === 0,
    5: !!state.previewPassed,
  };
}

function showActivePass() {
  $$('.ab-pass').forEach(p => p.classList.toggle('active', Number(p.dataset.pass) === state.pass));
}

/**
 * Sync the Pass 1 metadata inputs from `state.agent.*`.
 *
 * Called on every render so a restore from localStorage hydrates the DOM
 * even when Pass 1 isn't the active pass. The `setIfNotFocused` helper
 * skips inputs the author is currently typing into — `<input>.value = …`
 * resets the caret position, which would feel broken mid-type.
 */
function renderMetadataPass() {
  const setIfNotFocused = (sel, value) => {
    const node = $(sel);
    if (!node) return;
    if (document.activeElement === node) return;
    node.value = value;
  };

  setIfNotFocused('#m-id', state.agent.id);
  // ID input rules:
  //   - approved → read-only forever (renaming a published agent breaks
  //     consumers + orphans history). title attribute explains why.
  //   - taken (someone else's published id) → red border + shadow.
  //   - otherwise → neutral style, editable.
  const idInput = $('#m-id');
  if (idInput) {
    const locked = state.publishedStatus === 'approved';
    idInput.readOnly = locked;
    idInput.title = locked ? 'This agent is published — its id is now permanent.' : '';
    idInput.style.opacity = locked ? '0.65' : '';
    idInput.style.cursor = locked ? 'not-allowed' : '';
    idInput.style.borderColor = state.idTaken ? 'rgba(255,59,48,0.55)' : '';
    idInput.style.boxShadow = state.idTaken ? '0 0 0 3px rgba(255,59,48,0.16)' : '';
  }
  setIfNotFocused('#m-name', state.agent.name);
  setIfNotFocused('#m-version', state.agent.version);
  setIfNotFocused('#m-category', state.agent.category);
  setIfNotFocused('#m-description', state.agent.description);
  setIfNotFocused('#m-tags', (state.agent.tags || []).join(', '));
  setIfNotFocused('#m-capabilities', (state.agent.capabilities || []).join(', '));
  setIfNotFocused('#m-duration-min', state.agent.estimatedDuration?.min ?? 10);
  setIfNotFocused('#m-duration-max', state.agent.estimatedDuration?.max ?? 120);

  // Media: grids manage their own DOM and re-render whenever state changes.
  _gridShowcaseImages?.refresh();
  _gridShowcaseVideos?.refresh();
  _gridFeaturedVideo?.refresh();

  const errs = validateMetadata();
  const box = $('#m-errors');
  if (errs.length) {
    box.hidden = false;
    box.innerHTML = errs.map(e => `<div>• ${e}</div>`).join('');
  } else {
    box.hidden = true; box.innerHTML = '';
  }
}

function renderTemplatePass() {
  const sel = $('#m-template');
  if (!sel) return;
  if (sel.options.length === 0 || sel.dataset.templatesCount !== String(state.config.templates.length)) {
    sel.innerHTML = '';
    for (const t of state.config.templates) {
      sel.appendChild(el('option', { value: t }, t));
    }
    sel.dataset.templatesCount = String(state.config.templates.length);
  }
  sel.value = state.agent.template;
}

// Debounce the version lookup so we don't hammer the server while the author
// is mid-type. 300ms is short enough to feel responsive when they tab away.
let _versionLookupTimer = null;
async function refreshNextVersion(agentId) {
  const trimmed = String(agentId || '').trim();
  // System notify: a version/taken lookup is not an author edit, so it must not
  // flip the slot's publishedVersion to "-local".
  if (!trimmed) { state.idTaken = false; state.publishedStatus = null; notify({ system: true }); return; }
  try {
    const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/version/${encodeURIComponent(trimmed)}`);
    if (!res.ok) return;
    const json = await res.json();
    // Moderation edit-in-place pins the opened version — never bump to next.
    if (!state.moderationEdit && json?.nextVersion && typeof json.nextVersion === 'string') {
      state.agent.version = json.nextVersion;
    }
    state.publishedStatus = json?.status ?? null;
    // `taken` from the server only matters when it's someone else's id.
    // If this draft IS the approved row (same id, status='approved'), the
    // author is editing their own published agent — that's not a collision.
    state.idTaken = json?.taken === true && state.publishedStatus !== 'approved';
    notify({ system: true });
    // Keep the version picker in sync with whatever id is now in the field.
    loadVersionPicker(trimmed);
  } catch (err) {
    // Server unreachable / 404 → silently keep whatever's in state.
    console.debug('[agent-builder] version lookup failed', err);
  }
}

// Media grids are wired once at boot and refreshed from state on every render
// tick. Each grid manages its own DOM (thumbnail tiles + a trailing upload
// slot); the featured-video grid runs in single-slot mode (one thumbnail OR
// one dropzone, never both).
let _gridShowcaseImages = null;
let _gridShowcaseVideos = null;
let _gridFeaturedVideo = null;
const MEDIA_GRID_MAX = 5;

function wireMetadataPass() {
  const bind = (id, key, parser = (v) => v) => {
    $('#' + id)?.addEventListener('input', (e) => {
      state.agent[key] = parser(e.target.value);
      notify();
    });
  };
  bind('m-id', 'id', v => v.trim());
  // When the author edits the id, look up the next version for that id from the
  // server (debounced). The id field is the only thing that influences which
  // version this agent will publish as.
  $('#m-id')?.addEventListener('input', (e) => {
    const v = e.target.value.trim();
    // Clear the stale taken flag immediately — the previous server answer
    // was for a different id. The debounced refresh below will flip it back
    // on if the new id is also taken.
    state.idTaken = false;
    clearTimeout(_versionLookupTimer);
    _versionLookupTimer = setTimeout(() => refreshNextVersion(v), 300);
  });
  // Id rename: rebind the storage key + URL so the next persist() lands in
  // the right slot and a refresh keeps the same draft. Synthetic `_new-*`
  // ids are placeholders — we only swap once the author has typed a real id.
  $('#m-id')?.addEventListener('input', (e) => {
    const v = e.target.value.trim();
    if (!v) return;
    if (v === activeDraftId()) return;
    setActiveDraftId(v);
    try {
      history.replaceState(null, '', `/agent-builder/edit/${encodeURIComponent(v)}`);
    } catch {
      // History API blocked (sandboxed file://, etc.) — persist still works.
    }
  });
  bind('m-name', 'name');
  // m-version is intentionally NOT bound — it is server-owned (read-only).
  bind('m-category', 'category');
  bind('m-description', 'description');
  $('#m-tags')?.addEventListener('input', (e) => {
    state.agent.tags = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
    notify();
  });
  $('#m-capabilities')?.addEventListener('input', (e) => {
    state.agent.capabilities = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
    notify();
  });
  $('#m-duration-min')?.addEventListener('input', (e) => {
    state.agent.estimatedDuration = { ...(state.agent.estimatedDuration || {}), min: Number(e.target.value) || 0 };
    notify();
  });
  $('#m-duration-max')?.addEventListener('input', (e) => {
    state.agent.estimatedDuration = { ...(state.agent.estimatedDuration || {}), max: Number(e.target.value) || 0 };
    notify();
  });

  mountMediaFields();
}

/**
 * Mount the three showcase media surfaces.
 *
 * - Showcase images / videos: a grid of thumbnails (X to remove) followed by
 *   one upload slot that recycles a createMediaField. The upload slot
 *   disappears once the grid is full (MEDIA_GRID_MAX items) and reappears
 *   when the author removes one.
 * - Featured video: a plain createMediaField (kind: imageOrVideo). The
 *   component already renders the filled-state preview + remove button
 *   automatically.
 */
function mountMediaFields() {
  _gridShowcaseImages = createMediaGrid({
    mountId: 'm-showcase-images-mount',
    kind: 'image',
    stateKey: 'showcase_images',
    dropzoneTitle: 'Upload showcase image',
  });
  _gridShowcaseVideos = createMediaGrid({
    mountId: 'm-showcase-videos-mount',
    kind: 'video',
    stateKey: 'showcase_videos',
    dropzoneTitle: 'Upload showcase video',
  });
  // Featured uses the same grid in single-slot mode: after the author picks
  // one file the dropzone is replaced by a thumbnail + X. Removing the
  // thumbnail brings the dropzone back. The state is a single string (not an
  // array) so the publish payload contract stays the same.
  _gridFeaturedVideo = createMediaGrid({
    mountId: 'm-featured-video-mount',
    kind: 'imageOrVideo',
    stateKey: 'featured_video',
    dropzoneTitle: 'Upload featured media',
    maxItems: 1,
    asArray: false,
  });
}

/**
 * Build a thumbnail grid for a media state key.
 *
 * Layout (Tailwind grid auto-cols, capped at 4 columns):
 *   [thumb1] [thumb2] [thumb3] [thumb4]
 *   [thumb5] (when full — no upload slot)
 *
 * Two state shapes are supported via `asArray`:
 *   - asArray: true  → state.agent[stateKey] is an array of URLs (showcase_*)
 *   - asArray: false → state.agent[stateKey] is a single URL string. The grid
 *                       caps at maxItems: 1 in this mode regardless of caller.
 *
 * When `count < maxItems`, the last cell hosts a fresh createMediaField
 * upload slot. As soon as that slot resolves we write the CDN URL into state
 * and call refresh() — which discards the spent field, rebuilds a fresh
 * empty one (or hides it if full), and re-renders the thumbnails.
 */
function createMediaGrid({ mountId, kind, stateKey, dropzoneTitle, maxItems = MEDIA_GRID_MAX, asArray = true }) {
  const mount = $('#' + mountId);
  if (!mount) return null;

  const grid = document.createElement('div');
  grid.className = 'ab-media-grid';
  mount.appendChild(grid);

  // Single-string mode is effectively a 1-slot grid.
  const cap = asArray ? maxItems : 1;

  function urls() {
    const v = state.agent[stateKey];
    if (asArray) return Array.isArray(v) ? v.filter(Boolean) : [];
    return typeof v === 'string' && v ? [v] : [];
  }

  function writeUrls(next) {
    if (asArray) {
      state.agent[stateKey] = next.slice(0, cap);
    } else {
      state.agent[stateKey] = next[0] || '';
    }
  }

  function isVideoUrl(url) {
    const s = String(url || '').toLowerCase();
    return /\.(mp4|mov|webm|m4v)(\?|#|$)/.test(s) || s.startsWith('data:video/') || s.includes('/video/');
  }

  function renderThumb(url, idx) {
    const cell = document.createElement('div');
    cell.className =
      'relative rounded-2xl overflow-hidden border border-border bg-panel-input ' +
      'aspect-[4/3] min-w-0';

    const showVideo = kind === 'video' || (kind === 'imageOrVideo' && isVideoUrl(url));
    if (showVideo) {
      const v = document.createElement('video');
      v.src = url;
      v.muted = true;
      v.loop = true;
      v.autoplay = true;
      v.playsInline = true;
      v.className = 'w-full h-full object-cover';
      cell.appendChild(v);
    } else {
      const img = document.createElement('img');
      img.src = url;
      img.alt = '';
      img.className = 'w-full h-full object-cover';
      cell.appendChild(img);
    }

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className =
      'absolute top-2 right-2 w-7 h-7 rounded-full bg-neutral-800/70 hover:bg-neutral-800/90 ' +
      'backdrop-blur flex items-center justify-center transition-colors z-10';
    remove.innerHTML = '<svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>';
    remove.setAttribute('aria-label', 'Remove media');
    remove.addEventListener('click', () => {
      const next = urls().filter((_, i) => i !== idx);
      writeUrls(next);
      notify();
    });
    cell.appendChild(remove);
    return cell;
  }

  function buildUploadSlot() {
    const field = createMediaField({
      id: `${mountId}-slot-${Math.random().toString(16).slice(2)}`,
      label: '',
      kind,
      multiple: false,
      dropzoneTitle,
    });
    // The component's dropzone has a fixed 115px height; wrap it in our cell
    // so it matches the thumbnail aspect ratio visually.
    const cell = document.createElement('div');
    cell.className = 'min-w-0';
    cell.appendChild(field.wrap);

    let timer = null;
    const onResolve = () => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        try {
          const v = await field.getValue();
          const url = typeof v === 'string' ? v.trim() : '';
          if (!url) return; // user typed and cleared, or upload aborted
          const next = [...urls(), url];
          writeUrls(next);
          notify();
        } catch (err) {
          console.debug('[agent-builder] grid upload failed', err);
        }
      }, 200);
    };
    field.fileInput.addEventListener('change', onResolve);
    field.urlInput.addEventListener('input', onResolve);
    field.urlInput.addEventListener('change', onResolve);

    return { cell, field };
  }

  function refresh() {
    grid.innerHTML = '';
    const list = urls();
    list.forEach((url, i) => grid.appendChild(renderThumb(url, i)));
    if (list.length < cap) {
      grid.appendChild(buildUploadSlot().cell);
    }
  }

  refresh();
  return { refresh };
}

function wireTemplatePass() {
  $('#m-template')?.addEventListener('change', (e) => {
    state.agent.template = e.target.value;
    // `field.step` used to be template-gated (V2-only), so switching off V2
    // coerced every step:true to false. That gate has been removed —
    // wizard-form fields are valid under every template — so the template
    // switch no longer touches field state.
    notify();
  });
}

function wirePassNav() {
  $$('[data-action="next"]').forEach(b => b.addEventListener('click', () => {
    const blockers = blockingErrorsForPass(state.pass);
    if (blockers.length) {
      toast(blockers[0], 'error');
      return;
    }
    state.pass = Math.min(LAST_PASS, state.pass + 1);
    notify();
  }));
  $$('[data-action="back"]').forEach(b => b.addEventListener('click', () => {
    state.pass = Math.max(1, state.pass - 1);
    notify();
  }));
}

function blockingErrorsForPass(pass) {
  switch (pass) {
    // Pass 1 covers metadata AND template; template has no dedicated screen anymore.
    case 1: return [...validateMetadata(), ...validateTemplate()];
    // Pass 2 is Media — assets are optional (a draft can ship with just an
    // ID-derived icon fallback), so no validators block the Next button here.
    case 2: return [];
    case 3: return validateSteps();
    case 4: return validateFields();
    default: return [];
  }
}

function wireGlobalControls() {
  // The header description used to spell out "Four-pass wizard that turns a
  // form, a model pipeline, and a price into a publishable agent. Spec:
  // docs/AGENT-BUILDER.md" — accurate but useless to a first-time creator
  // who never opens the spec file. The "How it works" button replaces that
  // wall of text with a popup the creator can open on demand.
  $('#ab-help')?.addEventListener('click', () => {
    document.getElementById('ab-modal-guide')?.classList.add('visible');
    document.getElementById('ab-modal-guide')?.setAttribute('aria-hidden', 'false');
  });

  $('#ab-export-json')?.addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(cleanAgentForExport(state.agent), null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = el('a', { href: url, download: `${state.agent.id || 'agent'}.json` });
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  });

  // Import JSON — counterpart to Export JSON. Reads a file the author picks
  // and replaces state.agent with it. We accept both the bare agent document
  // produced by Export and the localStorage snapshot shape `{ agent, pass,
  // creditsPerRun }` so a draft round-trip works either way. Confirm before
  // overwriting in-progress work; the persist() hook fires via notify() so
  // the current draft slot picks up the imported document immediately.
  const importBtn = $('#ab-import-json');
  const importInput = $('#ab-import-file');
  if (importBtn && importInput) {
    importBtn.addEventListener('click', () => {
      const hasWork = state.agent.id || state.agent.name || (state.agent.fields?.length) || (state.agent.steps?.length);
      if (hasWork && !confirm('Replace the current draft with the imported JSON?')) return;
      importInput.value = '';
      importInput.click();
    });
    importInput.addEventListener('change', async () => {
      const file = importInput.files?.[0];
      if (!file) return;
      try {
        const text = await file.text();
        const parsed = JSON.parse(text);
        loadAgentFromObject(parsed);
        toast('Imported.', 'success');
      } catch (err) {
        console.error('[agent-builder] import failed', err);
        toast('Import failed: ' + (err?.message || 'invalid JSON'), 'error', 5000);
      } finally {
        importInput.value = '';
      }
    });
  }

  $('#ab-reset')?.addEventListener('click', () => {
    if (!confirm('Discard the in-progress agent and start over?')) return;
    reset();
    toast('Reset.', 'success');
  });
}

async function loadConfig() {
  try {
    const res = await fetchHelper('https://aitopia.ai/api/agent-builder/config');
    if (!res.ok) throw new Error('config status ' + res.status);
    const cfg = await res.json();
    state.config = { ...state.config, ...cfg };
    if (!state.config.templates.includes(state.agent.template)) {
      state.agent.template = state.config.templates[0] || 'default';
    }
  } catch (err) {
    const box = $('#ab-load-error');
    if (box) {
      box.hidden = false;
      box.classList.remove('hidden');
      box.textContent = 'Failed to load builder config: ' + err.message + '. The API server at /api/agent-builder/config may not be running yet.';
    }
    console.error('[agent-builder] config load failed', err);
  }
}

/**
 * Render the per-step cost breakdown into the sidebar. Visible whenever at
 * least one step exists, on every pass — the floor changes as the author
 * edits fields, schemas, or model picks, and the sidebar reflects that
 * change live no matter which pass is in focus.
 *
 * Per-step rows convey:
 *   - `Step N` label + a "checkpoint" mini-badge when `step:true`
 *   - The model id (truncated)
 *   - The step's USD floor as credits (max bound, since publish credits-per-run
 *     must be at or above the max)
 *
 * The total row reflects the agent's publish floor.
 */
function renderCostSummary() {
  const wrap = $('#ab-cost-summary');
  const stepsRoot = $('#ab-cost-steps');
  const totalCell = $('#ab-cost-floor');
  if (!wrap || !stepsRoot || !totalCell) return;

  const steps = stepwiseFloorUsd();
  if (steps.length === 0) {
    wrap.hidden = true;
    return;
  }
  wrap.hidden = false;
  stepsRoot.innerHTML = '';

  // Per-step rows + the total row carry the credit amount as a bare number.
  // No "cr" suffix, no formatting; whole numbers stay as integers, fractional
  // ones (when present) keep their natural toString. Visual treatment is the
  // frontend's job (the .amt class styles the cell).
  const fmtCredits = (n) => Number.isInteger(n) ? String(n) : String(n);

  for (const s of steps) {
    // Per-step minimum 1 credit when the step has a model — token-based
    // models compute to <0.01 USD and round to 0 otherwise. Same floor the
    // total uses (see floorCredits()), so the per-step rows and the total
    // row stay consistent (Σ rows == total). "—" only when no model is
    // picked yet (s.model_id is empty).
    // A step is "priced" when it has a model (model step) or a non-model kind
    // (content-research etc., priced by its kind catalog). Only a bare,
    // model-less model step shows "—".
    const isKindStep = s.kind && s.kind !== 'model';
    // Model steps price from USD floor; kind steps (content-research) price from
    // their kind catalog (base + enabled tools), same as floorCredits().
    const creditsMax = isKindStep
      ? kindStepCredits(state.agent.steps[s.index])
      : (s.model_id ? Math.max(1, usdToCredits(s.max)) : 0);
    // Label: model id for model steps; the kind ("research" for content-research)
    // for kind steps; placeholder when nothing is picked yet.
    const label = s.model_id
      ? s.model_id
      : (s.kind === 'content-research' ? 'research' : (s.kind || '(no model)'));
    const row = el('div', { class: 'ab-cost-step' },
      el('div', { class: 'lbl' },
        el('span', { class: 'step-num' }, 'S' + (s.index + 1)),
        s.isCheckpoint
          ? el('span', { class: 'mini-badge', title: 'Each regenerate of this step charges this amount.' }, 'cp')
          : null,
        el('span', { class: 'step-model' }, label),
      ),
      el('div', { class: 'amt' }, creditsMax > 0 ? fmtCredits(creditsMax) : '—'),
    );
    stepsRoot.appendChild(row);
  }

  totalCell.textContent = fmtCredits(floorCredits());
}

/**
 * Re-render every pass body on every state change.
 *
 * Even though only one pass is *visible* at a time (`.ab-pass.active`), the
 * DOM for all four lives in the document — and Pass 1's inputs in particular
 * are simple `<input>` elements whose values must mirror `state.agent.*`
 * after a restore from localStorage. If we only re-rendered the active pass,
 * a refresh would leave the hidden Pass 1 inputs blank: state would say
 * "name = …" but the DOM `<input>` value would be empty, so the moment the
 * author navigated back the form would look reset.
 *
 * Every renderer is cheap (DOM diffing isn't worth it at this scale; list
 * rebuilds are O(fields + steps)) and idempotent against the current state,
 * so calling them all every notify() is correct and predictable.
 */
// Reflect the agent's name + description in the page heading + browser tab.
// Once the draft has a name/description, show those instead of the generic
// "Agent Builder" copy; each falls back to its generic label while still empty
// (a brand-new draft).
function renderPageTitle() {
  const name = (state.agent?.name || '').trim();
  const description = (state.agent?.description || '').trim();
  const h1 = $('#ab-page-title');
  if (h1) {
    h1.textContent = name || 'Agent Builder';
    // Full name on hover, since the heading truncates with an ellipsis.
    h1.title = name || '';
  }
  const sub = $('#ab-page-subtitle');
  if (sub) sub.textContent = description || 'Build a new AI agent for the marketplace — no code required.';
  document.title = name ? `${name} | Agent Builder | AITOPIA` : 'Agent Builder | AITOPIA';
}

function render() {
  renderStepnav();
  renderCostSummary();
  showActivePass();
  renderPageTitle();
  renderMetadataPass();
  renderTemplatePass();
  renderStepsPass();
  renderFieldsPass();
  renderPreviewPass();
  // Re-render the version dropdown from cache so the "Local (vX)" entry appears
  // the instant the author edits (no server round-trip).
  refreshPickerOptions();
}

/**
 * Resolve which draft this page load is editing.
 *
 * URL contract:
 *   - /agent-builder/edit/<id>  → edit that draft (or create it if no slot
 *                                 exists yet under that id)
 *   - /agent-builder/edit/_new  → start a fresh draft. We mint a synthetic
 *                                 placeholder id so multiple "_new" tabs
 *                                 don't clobber each other. The author's
 *                                 first real id keystroke will rename it.
 *   - anything else             → bail to the listing page so the user
 *                                 picks (or creates) a draft.
 */
function resolveBootDraftId() {
  const m = window.location.pathname.match(/^\/agent-builder\/edit\/([^/?#]+)/);
  if (!m) return null;
  const id = decodeURIComponent(m[1]);
  if (id === '_new') {
    return `_new-${Math.random().toString(36).slice(2, 8)}`;
  }
  return id;
}

async function boot() {
  const bootId = resolveBootDraftId();
  if (!bootId) {
    // Reached the builder URL directly (without /edit/<id>) — send the user
    // to the listing page so they can pick or create a draft.
    window.location.replace('/agent-builder');
    return;
  }
  setActiveDraftId(bootId);
  restore();

  // Admin edit-in-place: ?version=<v>&mod=1 always re-seeds the exact version.
  const urlParams = new URLSearchParams(window.location.search);
  const wantVersion = urlParams.get('version');
  const isModeration = urlParams.get('mod') === '1' && !!wantVersion && !bootId.startsWith('_new-');

  // Cleared-session recovery: no local slot for this id → seed from the DB.
  // Moderation mode always re-seeds (ignoring any stale local fork).
  if ((isModeration || !state.agent.id) && !bootId.startsWith('_new-')) {
    try {
      // ?version pins the exact row to seed, not whatever getById calls Main.
      const versionQs = wantVersion ? `&version=${encodeURIComponent(wantVersion)}` : '';
      const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/version/${encodeURIComponent(bootId)}?withData=1${versionQs}`);
      // 403 = the doc isn't ours to read. Never fall back to a stale local copy
      // from a prior session — wipe it and bounce to the listing.
      if (res.status === 403) {
        clearLocalDoc(bootId);
        try { localStorage.removeItem(draftStorageKey(bootId)); } catch {}
        window.location.replace('/agent-builder');
        return;
      }
      const json = res.ok ? await res.json() : null;
      if (json?.currentData && typeof json.currentData === 'object') {
        const seededVersion = json.dataVersion ?? json.currentVersion;
        if (isModeration) {
          clearLocalDoc(bootId);
          state.moderationEdit = { id: bootId, version: seededVersion };
        }
        upsertDraftFromServer(bootId, json.currentData, seededVersion);
        restore();
        // Moderation keeps the loaded version (no next-version bump).
        if (isModeration && typeof seededVersion === 'string') {
          state.agent.version = seededVersion;
        }
      }
    } catch {
      // Offline / not found — fall through to the empty-agent default.
    }
  }

  // The author's id field is the canonical identity. If restore() loaded
  // a draft whose stored agent.id disagrees with the URL slug (legacy v3
  // migration, or the user hand-edited the URL), prefer the agent.id and
  // refresh the URL to match.
  if (state.agent.id && state.agent.id !== bootId && !bootId.startsWith('_new-')) {
    setActiveDraftId(state.agent.id);
    history.replaceState(null, '', `/agent-builder/edit/${encodeURIComponent(state.agent.id)}`);
  } else if (state.agent.id && bootId.startsWith('_new-')) {
    setActiveDraftId(state.agent.id);
    history.replaceState(null, '', `/agent-builder/edit/${encodeURIComponent(state.agent.id)}`);
  }

  await loadConfig();
  wireMetadataPass();
  wireTemplatePass();
  wireFieldsPass();
  wireStepsPass();
  wirePreviewPass();
  wirePassNav();
  wireGlobalControls();
  wireVersionPicker();
  wireVersionsTab();
  wireStudio();
  // Versioning hook runs BEFORE render so an auto-branch (editing a viewed
  // version) settles the state before the UI redraws.
  subscribe(onStateChangeForVersioning);
  subscribe(render);
  render();
  // Initial validation pass for the loaded id (next-version + taken flag).
  if (state.agent.id) {
    refreshNextVersion(state.agent.id);
    // Load the version list, THEN restore the active selection (Local if one
    // exists, else Main) and load its doc — so a refresh shows exactly what was
    // active and the Preview tab runs that version.
    loadVersionPicker(state.agent.id).then(() => initActiveSelection());
    loadVersionsTab(state.agent.id);
  }

  // Refresh both version surfaces after a successful publish — a new version row
  // landed and the Local copy was cleared. Re-resolve the active selection.
  window.addEventListener('agent-builder:published', () => {
    if (state.agent.id) {
      loadVersionPicker(state.agent.id).then(() => initActiveSelection());
      loadVersionsTab(state.agent.id);
    }
  });

  // After forking a version into a local draft, refresh the next-version label
  // (so the wizard shows the version the next publish will mint) and re-render
  // the picker (a "Local (unpublished edits)" entry now applies).
  window.addEventListener('agent-builder:forked', () => {
    if (state.agent.id) {
      refreshNextVersion(state.agent.id);
      refreshPickerOptions();
      loadVersionsTab(state.agent.id);
    }
  });

  // A version was deleted from the Versions table — keep the header dropdown
  // in sync with the new list.
  window.addEventListener('agent-builder:versions-changed', () => {
    if (state.agent.id) {
      refreshPickerOptions();
      loadVersionsTab(state.agent.id);
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}
