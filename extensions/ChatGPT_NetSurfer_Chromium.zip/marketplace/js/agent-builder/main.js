/**
 * Agent Builder — main controller.
 *
 * Boots the wizard: loads config, restores any in-progress draft from localStorage,
 * wires the pass navigation, and re-renders on every state change.
 */

import { state, subscribe, notify, restore, reset, cleanAgentForExport, loadAgentFromObject, setActiveDraftId, activeDraftId, draftStorageKey, upsertDraftFromServer, clearLocalDoc, migrateDraftId, slugifyId, setModerationMode, loadAgentIntoMemory } from './state.js';
import { $, $$, el, toast, confirmModal, installDarkSelectDropdowns, validateMetadata, validateTemplate, validateFields, validateSteps, stepwiseFloorUsd, totalFloorUsd, floorCredits, usdToCredits, kindStepCredits, priceMargin} from './utils.js';

import { renderFieldsPass, wireFieldsPass } from './fields-pass.js';
import { renderStepsPass, wireStepsPass } from './steps-pass.js';
import { renderPreviewPass, wirePreviewPass } from './preview-pass.js';
import { wireVersionPicker, loadVersionPicker, onStateChangeForVersioning, refreshPickerOptions, initActiveSelection } from './version-picker.js';
import { wireVersionsTab, loadVersionsTab } from './versions-tab.js';
import { wireStudio, rebindDraftId } from './studio.js';
import { wirePublishSheet } from './publish-sheet.js';
import { wireTester } from './tester-ui.js';
import { wireMediaGenerator } from './media-generator-ui.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';
import * as store from '/marketplace/js/services/browser-storage.js';
import { createMediaField } from '/marketplace/js/components/form/media-upload.js';

// The wizard is five passes. Steps comes BEFORE Fields on purpose: step
// schemas drive which form fields the agent needs (the auto-field detour
// inside steps-pass.js adds catalog-matched fields to `state.agent.fields`
// as a side-effect of picking a model). Authoring the form before knowing
// what the pipeline asks for is backwards. Media sits between Metadata and
// Steps so the gallery assets have an agent identity to attach to.
const PASSES = [
  { num: 1, title: 'General & Style', sub: 'Identity, listing copy & template' },
  { num: 2, title: 'Media',    sub: 'Showcase gallery & card video' },
  { num: 3, title: 'Model Pipeline', sub: 'Pipeline of model calls', advanced: true },
  { num: 4, title: 'Input Fields', sub: 'The user form', advanced: true },
  { num: 5, title: 'Preview & Publish', sub: 'Credits & preview' },
];
const LAST_PASS = PASSES[PASSES.length - 1].num;

// On load: steps/fields validation errors open Advanced.
let advancedView = false;

function visiblePasses() {
  return PASSES.filter(p => advancedView || !p.advanced);
}

const STEP_CHECK_SVG = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3.5 8.5 6.5 11.5 12.5 4.5"></polyline></svg>';

function renderStepnav() {
  const nav = $('#ab-stepnav');
  if (!nav) return;
  nav.innerHTML = '';
  const doneness = passDoneness();
  const passes = visiblePasses();
  passes.forEach((p, i) => {
    const done = !!doneness[p.num];
    if (i > 0) {
      const prevDone = !!doneness[passes[i - 1].num];
      nav.appendChild(el('span', { class: 'ab-step-link' + (prevDone ? ' done' : ''), 'aria-hidden': 'true' }));
    }
    const cls = 'ab-step'
      + (state.pass === p.num ? ' active' : '')
      + (done ? ' done' : '');
    const badge = el('span', { class: 'ab-step-check' });
    if (done) badge.innerHTML = STEP_CHECK_SVG;
    else badge.textContent = String(i + 1);
    const node = el('div', {
      class: cls,
      role: 'tab',
      'aria-selected': state.pass === p.num ? 'true' : 'false',
      onclick: () => { state.pass = p.num; notify(); },
    }, badge, p.title);
    nav.appendChild(node);
  });
  const toggle = $('#ab-adv-toggle-input');
  if (toggle) toggle.checked = advancedView;
}
function renderFootNav() {
  const back = $('#ab-nav-back');
  const next = $('#ab-nav-next');
  const passes = visiblePasses();
  if (back) back.style.visibility = state.pass === passes[0].num ? 'hidden' : '';
  // On the last pass Publish takes Next's slot in the same footbar, so the
  // Total chip, Back and the primary action share one row on every pass
  // (Publish used to live inside the pass-5 card, off on its own).
  const last = state.pass === LAST_PASS;
  if (next) {
    const upcoming = passes.find(p => p.num > state.pass);
    next.textContent = upcoming ? `Next: ${upcoming.title}` : '';
    next.style.display = last ? 'none' : '';
  }
  const publish = $('#ab-publish');
  if (publish) publish.style.display = last ? '' : 'none';
}

function passDoneness() {
  // Template validation is folded into pass 1 because the template dropdown
  // lives inside the Metadata card. Pass 2 (Media) is optional — the agent
  // can publish without showcase assets and getAgentIcon synthesises an
  // ID-derived fallback at render time — so we mark it done unconditionally.
  // Steps is pass 3 (it precedes Fields so the schema-driven detour can
  // populate fields[] automatically).
  const hasMedia = (state.agent.showcase_images?.length || 0) > 0
    || (state.agent.showcase_videos?.length || 0) > 0
    || !!state.agent.featured_video;
  return {
    1: validateMetadata().length === 0 && validateTemplate().length === 0,
    2: hasMedia,
    3: validateSteps().length === 0,
    4: state.agent.fields.length > 0 && validateFields().length === 0,
    5: !!state.previewPassed,
  };
}

let lastShownPass = null;

function showActivePass() {
  $$('.ab-pass').forEach(p => p.classList.toggle('active', Number(p.dataset.pass) === state.pass));
  // Entering a different pass starts the reader at its top. Without this the
  // window keeps the previous pass's offset — "Next: Media" clicked at the
  // bottom of Pass 1 dropped the author mid-way down Pass 2. Guarded so the
  // every-keystroke notify() rerenders don't yank the scroll, and null-seeded
  // so boot doesn't fight the browser's own scroll restoration.
  if (lastShownPass !== null && lastShownPass !== state.pass) window.scrollTo(0, 0);
  lastShownPass = state.pass;
}

/**
 * Sync the Pass 1 metadata inputs from `state.agent.*`.
 *
 * Called on every render so a restore from localStorage hydrates the DOM
 * even when Pass 1 isn't the active pass. The `setIfNotFocused` helper
 * skips inputs the author is currently typing into — `<input>.value = …`
 * resets the caret position, which would feel broken mid-type.
 */
function renderMetadataPass() {
  const setIfNotFocused = (sel, value) => {
    const node = $(sel);
    if (!node) return;
    if (document.activeElement === node) return;
    node.value = value;
  };

  setIfNotFocused('#m-id', state.agent.id);
  // ID input rules:
  //   - approved → read-only forever (renaming a published agent breaks
  //     consumers + orphans history). title attribute explains why.
  //   - taken (someone else's published id) → red border + shadow.
  //   - otherwise → neutral style, editable.
  const idInput = $('#m-id');
  if (idInput) {
    const locked = state.publishedStatus === 'approved';
    idInput.readOnly = locked;
    idInput.title = locked ? 'This agent is published - its id is now permanent.' : '';
    idInput.style.opacity = locked ? '0.65' : '';
    idInput.style.cursor = locked ? 'not-allowed' : '';
    idInput.style.borderColor = state.idTaken ? 'rgba(255,59,48,0.55)' : '';
    idInput.style.boxShadow = state.idTaken ? '0 0 0 3px rgba(255,59,48,0.16)' : '';
  }
  setIfNotFocused('#m-name', state.agent.name);
  setIfNotFocused('#m-version', state.agent.version);
  setIfNotFocused('#m-category', state.agent.category);
  setIfNotFocused('#m-description', state.agent.description);
  _chipTags?.renderChips();
  _chipCapabilities?.renderChips();
  setIfNotFocused('#m-duration-min', state.agent.estimatedDuration?.min ?? 10);
  setIfNotFocused('#m-duration-max', state.agent.estimatedDuration?.max ?? 120);

  // Media: grids manage their own DOM and re-render whenever state changes.
  _gridShowcaseImages?.refresh();
  _gridFeaturedVideo?.refresh();

  const errs = validateMetadata();
  const box = $('#m-errors');
  if (errs.length) {
    box.hidden = false;
    box.innerHTML = errs.map(e => `<div>• ${e}</div>`).join('');
  } else {
    box.hidden = true; box.innerHTML = '';
  }
}

function renderTemplatePass() {
  const sel = $('#m-template');
  if (!sel) return;
  if (sel.options.length === 0 || sel.dataset.templatesCount !== String(state.config.templates.length)) {
    sel.innerHTML = '';
    for (const t of state.config.templates) {
      sel.appendChild(el('option', { value: t }, t));
    }
    sel.dataset.templatesCount = String(state.config.templates.length);
  }
  sel.value = state.agent.template;

  const cards = $('#m-template-cards');
  if (!cards) return;
  const key = state.config.templates.join(';') + '|' + state.agent.template;
  if (cards.dataset.key === key) return;
  cards.dataset.key = key;
  cards.innerHTML = '';
  for (const t of state.config.templates) {
    const card = el('div', {
      class: 'ab-tpl-card' + (state.agent.template === t ? ' selected' : ''),
      role: 'button',
      title: t,
      onclick: () => { state.agent.template = t; notify(); },
    },
      el('img', {
        class: 'ab-tpl-shot ab-tpl-shot-dark',
        src: `/img/agent-builder/templates/${encodeURIComponent(t)}.webp`,
        alt: `${t} template preview`,
        onerror: (e) => { e.target.remove(); },
      }),
      el('img', {
        class: 'ab-tpl-shot ab-tpl-shot-light',
        src: `/img/agent-builder/templates/${encodeURIComponent(t)}-light.webp`,
        alt: `${t} template preview`,
        onerror: (e) => { e.target.remove(); },
      }),
      el('div', { class: 'ab-tpl-card-name' }, t),
      el('span', { class: 'ab-tpl-check' }, '✓'),
    );
    cards.appendChild(card);
  }
}

// Debounce the version lookup so we don't hammer the server while the author
// is mid-type. 300ms is short enough to feel responsive when they tab away.
let _versionLookupTimer = null;
async function refreshNextVersion(agentId) {
  const trimmed = String(agentId || '').trim();
  // System notify: a version/taken lookup is not an author edit, so it must not
  // flip the slot's publishedVersion to "-local".
  if (!trimmed) { state.idTaken = false; state.publishedStatus = null; notify({ system: true }); return; }
  try {
    const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/version/${encodeURIComponent(trimmed)}`);
    if (!res.ok) return;
    const json = await res.json();
    // Moderation edit-in-place pins the opened version — never bump to next.
    if (!state.moderationEdit && json?.nextVersion && typeof json.nextVersion === 'string') {
      state.agent.version = json.nextVersion;
    }
    state.publishedStatus = json?.status ?? null;
    // `taken` from the server only matters when it's someone else's id.
    // If this draft IS the approved row (same id, status='approved'), the
    // author is editing their own published agent — that's not a collision.
    state.idTaken = json?.taken === true && state.publishedStatus !== 'approved';
    notify({ system: true });
    // Keep the version picker in sync with whatever id is now in the field.
    loadVersionPicker(trimmed);
  } catch (err) {
    // Server unreachable / 404 → silently keep whatever's in state.
    console.debug('[agent-builder] version lookup failed', err);
  }
}

// Media grids are wired once at boot and refreshed from state on every render
// tick. Each grid manages its own DOM (thumbnail tiles + a trailing upload
// slot); the featured-video grid runs in single-slot mode (one thumbnail OR
// one dropzone, never both).
let _gridShowcaseImages = null;
let _gridFeaturedVideo = null;
const MEDIA_GRID_MAX = 5;
function createChipField({ mountId, entryId, placeholder, getItems, setItems }) {
  const mount = $('#' + mountId);
  if (!mount) return { renderChips: () => {} };
  const entry = el('input', { class: 'ab-chip-entry', id: entryId, placeholder, autocomplete: 'off' });

  const commit = () => {
    const v = entry.value.trim().replace(/,+$/, '').trim();
    if (!v) { entry.value = ''; return; }
    const items = [...getItems()];
    if (!items.includes(v)) items.push(v);
    entry.value = '';
    setItems(items);
    notify();
  };
  entry.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); commit(); return; }
    if (e.key === 'Backspace' && !entry.value) {
      const items = [...getItems()];
      if (items.length) { items.pop(); setItems(items); notify(); }
    }
  });
  entry.addEventListener('blur', commit);
  entry.addEventListener('paste', (e) => {
    const text = (e.clipboardData?.getData('text') || '');
    if (!text.includes(',')) return;
    e.preventDefault();
    const items = [...getItems()];
    for (const part of text.split(',').map(s => s.trim()).filter(Boolean)) {
      if (!items.includes(part)) items.push(part);
    }
    setItems(items);
    notify();
  });
  mount.addEventListener('click', (e) => { if (e.target === mount) entry.focus(); });
  mount.appendChild(entry);

  const renderChips = () => {
    mount.querySelectorAll('.ab-chip').forEach(n => n.remove());
    for (const item of getItems()) {
      const chip = el('span', { class: 'ab-chip' },
        item,
        el('button', {
          type: 'button', class: 'ab-chip-x', 'aria-label': `Remove ${item}`,
          onmousedown: (e) => e.preventDefault(),
          onclick: () => {
            const items = [...getItems()];
            const at = items.indexOf(item);
            if (at === -1) return;
            items.splice(at, 1);
            setItems(items);
            notify();
          },
        }, '×'),
      );
      mount.insertBefore(chip, entry);
    }
  };
  return { renderChips };
}

let _chipTags = null;
let _chipCapabilities = null;

/** Re-point the draft onto `next`, carrying every id-scoped entry with it. */
async function applyIdRename(next) {
  if (!next) return;
  const prev = activeDraftId();
  if (next === prev) return;
  if (!(await migrateDraftId(prev, next))) setActiveDraftId(next);
  try {
    history.replaceState(null, '', `/agent-builder/edit/${encodeURIComponent(next)}`);
  } catch {
    // History API blocked (sandboxed file://, etc.) — persist still works.
  }
  rebindDraftId(next);
}

function wireMetadataPass() {
  _chipTags = createChipField({
    mountId: 'm-tags-chips',
    entryId: 'm-tags-entry',
    placeholder: 'Add a tag…',
    getItems: () => state.agent.tags || [],
    setItems: (items) => { state.agent.tags = items; },
  });
  _chipCapabilities = createChipField({
    mountId: 'm-capabilities-chips',
    entryId: 'm-capabilities-entry',
    placeholder: 'Add a capability…',
    getItems: () => state.agent.capabilities || [],
    setItems: (items) => { state.agent.capabilities = items; },
  });

  const bind = (id, key, parser = (v) => v) => {
    $('#' + id)?.addEventListener('input', (e) => {
      state.agent[key] = parser(e.target.value);
      notify();
    });
  };
  bind('m-id', 'id', v => v.trim());
  // When the author edits the id, look up the next version for that id from the
  // server (debounced). The id field is the only thing that influences which
  // version this agent will publish as.
  $('#m-id')?.addEventListener('input', (e) => {
    const v = e.target.value.trim();
    // Clear the stale taken flag immediately — the previous server answer
    // was for a different id. The debounced refresh below will flip it back
    // on if the new id is also taken.
    state.idTaken = false;
    clearTimeout(_versionLookupTimer);
    _versionLookupTimer = setTimeout(() => refreshNextVersion(v), 300);
  });
  $('#m-id')?.addEventListener('input', (e) => {
    // The author is choosing the id by hand — stop deriving it from the name.
    state.idManual = true;
    applyIdRename(e.target.value.trim());
  });
  bind('m-name', 'name');
  // Until publish, the id tracks the name. Afterwards it is the agent's public
  // identity and is frozen.
  $('#m-name')?.addEventListener('input', (e) => {
    if (state.idManual || state.publishedVersion || state.publishedStatus === 'approved') return;
    const next = slugifyId(e.target.value);
    if (!next || next === state.agent.id) return;
    state.agent.id = next;
    const idInput = $('#m-id');
    if (idInput) idInput.value = next;
    state.idTaken = false;
    clearTimeout(_versionLookupTimer);
    _versionLookupTimer = setTimeout(() => refreshNextVersion(next), 300);
    // Persist only after the rename has moved the id-scoped keys, or the save
    // lands on the old slot.
    applyIdRename(next).then(notify);
  });
  // m-version is intentionally NOT bound — it is server-owned (read-only).
  bind('m-category', 'category');
  bind('m-description', 'description');
  $('#m-duration-min')?.addEventListener('input', (e) => {
    state.agent.estimatedDuration = { ...(state.agent.estimatedDuration || {}), min: Number(e.target.value) || 0 };
    notify();
  });
  $('#m-duration-max')?.addEventListener('input', (e) => {
    state.agent.estimatedDuration = { ...(state.agent.estimatedDuration || {}), max: Number(e.target.value) || 0 };
    notify();
  });

  mountMediaFields();
}

/**
 * Mount the three showcase media surfaces.
 *
 * - Showcase images / videos: a grid of thumbnails (X to remove) followed by
 *   one upload slot that recycles a createMediaField. The upload slot
 *   disappears once the grid is full (MEDIA_GRID_MAX items) and reappears
 *   when the author removes one.
 * - Featured video: a plain createMediaField (kind: imageOrVideo). The
 *   component already renders the filled-state preview + remove button
 *   automatically.
 */
function mountMediaFields() {
  // One merged "Showcase Media" grid over BOTH state arrays
  _gridShowcaseImages = createMediaGrid({
    mountId: 'm-showcase-images-mount',
    kind: 'imageOrVideo',
    stateKey: 'showcase_images',
    dropzoneTitle: 'Upload image or video',
    getUrls: () => [
      ...(Array.isArray(state.agent.showcase_images) ? state.agent.showcase_images.filter(Boolean) : []),
      ...(Array.isArray(state.agent.showcase_videos) ? state.agent.showcase_videos.filter(Boolean) : []),
    ],
    kindOf: (u) => ((state.agent.showcase_videos || []).includes(u) ? 'video'
      : (state.agent.showcase_images || []).includes(u) ? 'image' : null),
    setUrls: (next, kindOfUrl) => {
      state.agent.showcase_videos = next.filter(u => kindOfUrl(u) === 'video');
      state.agent.showcase_images = next.filter(u => kindOfUrl(u) !== 'video');
    },
  });
  // Featured uses the same grid in single-slot mode: after the author picks
  // one file the dropzone is replaced by a thumbnail + X. Removing the
  // thumbnail brings the dropzone back. The state is a single string (not an
  // array) so the publish payload contract stays the same.
  _gridFeaturedVideo = createMediaGrid({
    mountId: 'm-featured-video-mount',
    kind: 'imageOrVideo',
    stateKey: 'featured_video',
    dropzoneTitle: 'Upload featured media',
    maxItems: 1,
    asArray: false,
  });
}

/**
 * Build a thumbnail grid for a media state key.
 *
 * Layout (Tailwind grid auto-cols, capped at 4 columns):
 *   [thumb1] [thumb2] [thumb3] [thumb4]
 *   [thumb5] (when full — no upload slot)
 *
 * Two state shapes are supported via `asArray`:
 *   - asArray: true  → state.agent[stateKey] is an array of URLs (showcase_*)
 *   - asArray: false → state.agent[stateKey] is a single URL string. The grid
 *                       caps at maxItems: 1 in this mode regardless of caller.
 *
 * When `count < maxItems`, the last cell hosts a fresh createMediaField
 * upload slot. As soon as that slot resolves we write the CDN URL into state
 * and call refresh() — which discards the spent field, rebuilds a fresh
 * empty one (or hides it if full), and re-renders the thumbnails.
 */
function isVideoUrl(url) {
  const s = String(url || '').toLowerCase();
  return /\.(mp4|mov|webm|m4v)(\?|#|$)/.test(s) || s.startsWith('data:video/') || s.includes('/video/');
}

function createMediaGrid({ mountId, kind, stateKey, dropzoneTitle, maxItems = MEDIA_GRID_MAX, asArray = true, getUrls, setUrls, kindOf }) {
  const mount = $('#' + mountId);
  if (!mount) return null;

  const grid = document.createElement('div');
  grid.className = 'ab-media-grid';
  mount.appendChild(grid);

  // Single-string mode is effectively a 1-slot grid.
  const cap = asArray ? maxItems : 1;

  // Known kind beats URL sniffing: caller's kindOf > extension guess.
  const mediaKindOf = (url) => kindOf?.(url) || (isVideoUrl(url) ? 'video' : 'image');

  function urls() {
    if (getUrls) return getUrls();
    const v = state.agent[stateKey];
    if (asArray) return Array.isArray(v) ? v.filter(Boolean) : [];
    return typeof v === 'string' && v ? [v] : [];
  }

  function writeUrls(next) {
    if (setUrls) { setUrls(next.slice(0, cap), mediaKindOf); return; }
    if (asArray) {
      state.agent[stateKey] = next.slice(0, cap);
    } else {
      state.agent[stateKey] = next[0] || '';
    }
  }

  function renderThumb(url, idx) {
    const cell = document.createElement('div');
    cell.className =
      'relative rounded-2xl overflow-hidden border border-border bg-panel-input ' +
      'aspect-[4/3] min-w-0';

    const showVideo = kind === 'video' || (kind === 'imageOrVideo' && mediaKindOf(url) === 'video');
    if (showVideo) {
      const v = document.createElement('video');
      v.src = url;
      v.muted = true;
      v.loop = true;
      v.autoplay = true;
      v.playsInline = true;
      v.className = 'w-full h-full object-cover';
      cell.appendChild(v);
    } else {
      const img = document.createElement('img');
      img.src = url;
      img.alt = '';
      img.className = 'w-full h-full object-cover';
      cell.appendChild(img);
    }

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className =
      'absolute top-2 right-2 w-7 h-7 rounded-full bg-neutral-800/70 hover:bg-neutral-800/90 ' +
      'backdrop-blur flex items-center justify-center transition-colors z-10';
    remove.innerHTML = '<svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>';
    remove.setAttribute('aria-label', 'Remove media');
    remove.addEventListener('click', () => {
      const next = urls().filter((_, i) => i !== idx);
      writeUrls(next);
      notify();
    });
    cell.appendChild(remove);
    return cell;
  }

  function buildUploadSlot() {
    const field = createMediaField({
      id: `${mountId}-slot-${Math.random().toString(16).slice(2)}`,
      label: '',
      kind,
      multiple: false,
      dropzoneTitle,
    });
    // The component's dropzone has a fixed 115px height; wrap it in our cell
    // so it matches the thumbnail aspect ratio visually.
    const cell = document.createElement('div');
    cell.className = 'min-w-0';
    cell.appendChild(field.wrap);

    let timer = null;
    const onResolve = (delay) => {
      clearTimeout(timer);
      const busySince = Date.now();
      timer = setTimeout(async () => {
        const previewNode = field.wrap.querySelector('img[src^="blob:"], video[src^="blob:"]');
        const previewUrl = previewNode?.getAttribute('src') || null;
        uploadingPreviews.push(previewUrl);
        uploadingCount++;
        refresh();
        try {
          const v = await field.getValue();
          const url = typeof v === 'string' ? v.trim() : '';
          if (!url) return; // user typed and cleared, or upload aborted
          const wait = 600 - (Date.now() - busySince);
          if (wait > 0) await new Promise(r => setTimeout(r, wait));
          const next = [...urls(), url];
          writeUrls(next);
        } catch (err) {
          console.debug('[agent-builder] grid upload failed', err);
        } finally {
          uploadingCount--;
          const at = uploadingPreviews.indexOf(previewUrl);
          if (at !== -1) uploadingPreviews.splice(at, 1);
          notify(); // success or failure, re-render without the busy cell
        }
      }, delay);
    };
    field.fileInput.addEventListener('change', () => onResolve(0));
    field.urlInput.addEventListener('change', () => onResolve(0));
    field.wrap.addEventListener('drop', () => onResolve(200));
    field.wrap.addEventListener('paste', () => onResolve(200));

    return { cell, field };
  }

  let uploadingCount = 0;
  const uploadingPreviews = [];

  function refresh() {
    grid.innerHTML = '';
    const list = urls();
    // Upload slot stays first; uploaded items fill in to its right.
    if (list.length + uploadingCount < cap) {
      grid.appendChild(buildUploadSlot().cell);
    }
    list.forEach((url, i) => grid.appendChild(renderThumb(url, i)));
    for (let i = 0; i < uploadingCount; i++) {
      const busyCell = document.createElement('div');
      busyCell.className = 'ab-media-uploading';
      const preview = uploadingPreviews[i];
      if (preview) {
        busyCell.classList.add('has-preview');
        busyCell.style.backgroundImage = `url("${preview}")`;
      }
      grid.appendChild(busyCell);
    }
    if (cap > 1) {
      for (let i = grid.children.length; i < cap; i++) {
        const ghost = document.createElement('div');
        ghost.className = 'ab-media-ghost';
        grid.appendChild(ghost);
      }
    }
  }

  refresh();
  return { refresh };
}

function wireTemplatePass() {
  $('#m-template')?.addEventListener('change', (e) => {
    state.agent.template = e.target.value;
    // `field.step` used to be template-gated (V2-only), so switching off V2
    // coerced every step:true to false. That gate has been removed —
    // wizard-form fields are valid under every template — so the template
    // switch no longer touches field state.
    notify();
  });
}

function wirePassNav() {
  $$('[data-action="next"]').forEach(b => b.addEventListener('click', () => {
    const blockers = blockingErrorsForPass(state.pass);
    if (blockers.length) {
      toast(blockers[0], 'error');
      return;
    }
    const upcoming = visiblePasses().find(p => p.num > state.pass);
    if (upcoming) { state.pass = upcoming.num; notify(); }
  }));
  $$('[data-action="back"]').forEach(b => b.addEventListener('click', () => {
    const previous = [...visiblePasses()].reverse().find(p => p.num < state.pass);
    if (previous) { state.pass = previous.num; notify(); }
  }));
}

function wireAdvancedToggle() {
  const input = $('#ab-adv-toggle-input');
  if (!input) return;
  input.checked = advancedView;
  input.addEventListener('change', () => {
    advancedView = input.checked;
    if (!advancedView && PASSES.find(p => p.num === state.pass)?.advanced) {
      state.pass = visiblePasses().find(p => p.num > state.pass)?.num ?? LAST_PASS;
    }
    notify();
  });
}

function blockingErrorsForPass(pass) {
  switch (pass) {
    // Pass 1 covers metadata AND template; template has no dedicated screen anymore.
    case 1: return [...validateMetadata(), ...validateTemplate()];
    // Pass 2 is Media — assets are optional (a draft can ship with just an
    // ID-derived icon fallback), so no validators block the Next button here.
    case 2: return [];
    case 3: return validateSteps();
    case 4: return validateFields();
    default: return [];
  }
}

function wireGlobalControls() {
  const menuBtn = $('#ab-menu-btn');
  const menu = $('#ab-menu');
  if (menuBtn && menu) {
    const setOpen = (open) => {
      menu.hidden = !open;
      menuBtn.setAttribute('aria-expanded', String(open));
    };
    menuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      setOpen(menu.hidden);
    });
    menu.addEventListener('click', () => setOpen(false));
    document.addEventListener('click', (e) => {
      if (!menu.hidden && !menu.contains(e.target) && e.target !== menuBtn) setOpen(false);
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !menu.hidden) setOpen(false);
    });
  }

  // The header description used to spell out "Four-pass wizard that turns a
  // form, a model pipeline, and a price into a publishable agent. Spec:
  // docs/AGENT-BUILDER.md" — accurate but useless to a first-time creator
  // who never opens the spec file. The "How it works" button replaces that
  // wall of text with a popup the creator can open on demand.
  $('#ab-help')?.addEventListener('click', () => {
    document.getElementById('ab-modal-guide')?.classList.add('visible');
    document.getElementById('ab-modal-guide')?.setAttribute('aria-hidden', 'false');
  });

  $('#ab-export-json')?.addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(cleanAgentForExport(state.agent), null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = el('a', { href: url, download: `${state.agent.id || 'agent'}.json` });
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  });

  // Import JSON — counterpart to Export JSON. Reads a file the author picks
  // and replaces state.agent with it. We accept both the bare agent document
  // produced by Export and the localStorage snapshot shape `{ agent, pass,
  // creditsPerRun }` so a draft round-trip works either way. Confirm before
  // overwriting in-progress work; the persist() hook fires via notify() so
  // the current draft slot picks up the imported document immediately.
  const importBtn = $('#ab-import-json');
  const importInput = $('#ab-import-file');
  if (importBtn && importInput) {
    importBtn.addEventListener('click', async () => {
      const hasWork = state.agent.id || state.agent.name || (state.agent.fields?.length) || (state.agent.steps?.length);
      if (hasWork) {
        const ok = await confirmModal({
          title: 'Import JSON?',
          message: 'The current draft will be replaced with the imported JSON.',
          confirmLabel: 'Replace',
        });
        if (!ok) return;
      }
      importInput.value = '';
      importInput.click();
    });
    importInput.addEventListener('change', async () => {
      const file = importInput.files?.[0];
      if (!file) return;
      try {
        const text = await file.text();
        const parsed = JSON.parse(text);
        loadAgentFromObject(parsed);
        toast('Imported.', 'success');
      } catch (err) {
        console.error('[agent-builder] import failed', err);
        toast('Import failed: ' + (err?.message || 'invalid JSON'), 'error', 5000);
      } finally {
        importInput.value = '';
      }
    });
  }

  $('#ab-reset')?.addEventListener('click', async () => {
    const ok = await confirmModal({
      title: 'Reset the builder?',
      message: 'The in-progress agent will be discarded and you\'ll start over.',
      confirmLabel: 'Reset',
      danger: true,
    });
    if (!ok) return;
    await reset();
    toast('Reset.', 'success');
  });
}

async function loadConfig() {
  try {
    const res = await fetchHelper('https://aitopia.ai/api/agent-builder/config');
    if (!res.ok) throw new Error('config status ' + res.status);
    const cfg = await res.json();
    state.config = { ...state.config, ...cfg };
    if (!state.config.templates.includes(state.agent.template)) {
      state.agent.template = state.config.templates[0] || 'default';
    }
  } catch (err) {
    const box = $('#ab-load-error');
    if (box) {
      box.hidden = false;
      box.classList.remove('hidden');
      box.textContent = 'Failed to load builder config: ' + err.message + '. The API server at /api/agent-builder/config may not be running yet.';
    }
    console.error('[agent-builder] config load failed', err);
  }
}

/**
 * Render the per-step cost breakdown into the sidebar. Visible whenever at
 * least one step exists, on every pass — the floor changes as the author
 * edits fields, schemas, or model picks, and the sidebar reflects that
 * change live no matter which pass is in focus.
 *
 * Per-step rows convey:
 *   - `Step N` label + a "checkpoint" mini-badge when `step:true`
 *   - The model id (truncated)
 *   - The step's USD floor as credits (max bound, since publish credits-per-run
 *     must be at or above the max)
 *
 * The total row reflects the agent's publish floor.
 */
function renderCostSummary() {
  const wrap = $('#ab-cost-summary');
  const stepsRoot = $('#ab-cost-steps');
  const totalCell = $('#ab-cost-floor');
  if (!wrap || !stepsRoot || !totalCell) return;

  const steps = stepwiseFloorUsd();
  if (steps.length === 0) {
    wrap.hidden = true;
    return;
  }
  wrap.hidden = false;
  stepsRoot.innerHTML = '';

  // Per-step rows + the total row carry the credit amount as a bare number.
  // No "cr" suffix, no formatting; whole numbers stay as integers, fractional
  // ones (when present) keep their natural toString. Visual treatment is the
  // frontend's job (the .amt class styles the cell).
  const fmtCredits = (n) => Number.isInteger(n) ? String(n) : String(n);

  for (const s of steps) {
    // Per-step minimum 1 credit when the step has a model — token-based
    // models compute to <0.01 USD and round to 0 otherwise. Same floor the
    // total uses (see floorCredits()), so the per-step rows and the total
    // row stay consistent (Σ rows == total). "—" only when no model is
    // picked yet (s.model_id is empty).
    // A step is "priced" when it has a model (model step) or a non-model kind
    // (content-research etc., priced by its kind catalog). Only a bare,
    // model-less model step shows "—".
    const isKindStep = s.kind && s.kind !== 'model';
    // Per-step credits from the SAME math source as the total (floorCredits):
    // lowest-allowed field value + baked-in literals + margin. Σ rows == total.
    const stepFn = window.AitopiaCredits?.getBuilderDraftStepCredits;
    const creditsMax = (typeof stepFn === 'function')
      ? stepFn(state.agent.steps[s.index], {
          fields: state.agent.fields,
          models: state.config.models,
          usdPerCredit: Number(state.config.billing?.usdPerCredit || 0.02),
          margin: priceMargin(),
          kindCreditsFn: kindStepCredits,
        })
      : (isKindStep
          ? Math.max(1, Math.ceil(Math.max(1, Math.ceil(kindStepCredits(state.agent.steps[s.index]))) * priceMargin()))
          : (s.model_id ? Math.max(1, Math.ceil(Math.max(1, Math.ceil(s.max / Number(state.config.billing?.usdPerCredit || 0.02))) * priceMargin())) : 0));
    // Label: model id for model steps; the kind ("research" for content-research)
    // for kind steps; placeholder when nothing is picked yet.
    const label = s.model_id
      ? s.model_id
      : (s.kind === 'content-research' ? 'research' : (s.kind || '(no model)'));
    const row = el('div', { class: 'ab-cost-step' },
      el('div', { class: 'lbl' },
        el('span', { class: 'step-num' }, 'S' + (s.index + 1)),
        s.isCheckpoint
          ? el('span', { class: 'mini-badge', title: 'Each regenerate of this step charges this amount.' }, 'cp')
          : null,
        el('span', { class: 'step-model' }, label),
      ),
      el('div', { class: 'amt' }, creditsMax > 0 ? fmtCredits(creditsMax) : '-'),
    );
    stepsRoot.appendChild(row);
  }

  totalCell.textContent = fmtCredits(floorCredits());
}

/**
 * Re-render every pass body on every state change.
 *
 * Even though only one pass is *visible* at a time (`.ab-pass.active`), the
 * DOM for all four lives in the document — and Pass 1's inputs in particular
 * are simple `<input>` elements whose values must mirror `state.agent.*`
 * after a restore from localStorage. If we only re-rendered the active pass,
 * a refresh would leave the hidden Pass 1 inputs blank: state would say
 * "name = …" but the DOM `<input>` value would be empty, so the moment the
 * author navigated back the form would look reset.
 *
 * Every renderer is cheap (DOM diffing isn't worth it at this scale; list
 * rebuilds are O(fields + steps)) and idempotent against the current state,
 * so calling them all every notify() is correct and predictable.
 */
// Reflect the agent's name in the page heading + browser tab. Once the draft
// has a name, show it instead of the generic "New Agent" copy.
function renderPageTitle() {
  const name = (state.agent?.name || '').trim();
  const h1 = $('#ab-page-title');
  if (h1) {
    h1.textContent = name || 'New Agent';
    // Full name on hover, since the heading truncates with an ellipsis.
    h1.title = name || '';
  }
  document.title = name ? `${name} | Agent Builder | AITOPIA` : 'Agent Builder | AITOPIA';
}

// Show the header "Preview →" link only once the draft can actually be
// previewed: it needs a real id and clean input validators — the same gate
// openPreviewTab() enforces before opening the preview tab. The link points at
// the dedicated preview page so the author can jump there straight from the
// header without scrolling to Pass 5.
function renderHeaderPreviewLink() {
  const link = $('#ab-open-preview');
  if (!link) return;
  const id = state.agent?.id;
  const ready = !!id && typeof id === 'string'
    && validateMetadata().length === 0
    && validateTemplate().length === 0
    && validateFields().length === 0
    && validateSteps().length === 0;
  link.hidden = !ready;
  if (ready) link.href = `/agent-builder/preview/${encodeURIComponent(id)}`;
}

function render() {
  renderStepnav();
  renderFootNav();
  renderCostSummary();
  showActivePass();
  renderPageTitle();
  renderHeaderPreviewLink();
  renderMetadataPass();
  renderTemplatePass();
  renderStepsPass();
  renderFieldsPass();
  renderPreviewPass();
  // Re-render the version dropdown from cache so the "Local (vX)" entry appears
  // the instant the author edits (no server round-trip).
  refreshPickerOptions();
}

/**
 * Resolve which draft this page load is editing.
 *
 * URL contract:
 *   - /agent-builder/edit/<id>  → edit that draft (or create it if no slot
 *                                 exists yet under that id)
 *   - /agent-builder/edit/_new  → start a fresh draft. We mint a synthetic
 *                                 placeholder id so multiple "_new" tabs
 *                                 don't clobber each other. The author's
 *                                 first real id keystroke will rename it.
 *   - anything else             → bail to the listing page so the user
 *                                 picks (or creates) a draft.
 */
function resolveBootDraftId() {
  const m = window.location.pathname.match(/^\/agent-builder\/edit\/([^/?#]+)/);
  if (!m) return null;
  const id = decodeURIComponent(m[1]);
  if (id === '_new') {
    return `_new-${Math.random().toString(36).slice(2, 8)}`;
  }
  return id;
}

async function boot() {
  const bootId = resolveBootDraftId();
  if (!bootId) {
    // Reached the builder URL directly (without /edit/<id>) — send the user
    // to the listing page so they can pick or create a draft.
    window.location.replace('/agent-builder');
    return;
  }
  // Admin edit-in-place: ?version=<v>&mod=1 always loads the exact version.
  const urlParams = new URLSearchParams(window.location.search);
  const wantVersion = urlParams.get('version');
  const isModeration = urlParams.get('mod') === '1' && !!wantVersion && !bootId.startsWith('_new-');

  // Set before restore() so no moderation boot ever touches localStorage.
  setModerationMode(isModeration);
  setActiveDraftId(bootId);
  if (!isModeration) await restore();

  // Cleared-session recovery: no local slot for this id → seed from the DB.
  // Moderation mode always re-seeds (ignoring any stale local fork).
  if ((isModeration || !state.agent.id) && !bootId.startsWith('_new-')) {
    try {
      // ?version pins the exact row to seed, not whatever getById calls Main.
      const versionQs = wantVersion ? `&version=${encodeURIComponent(wantVersion)}` : '';
      const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/version/${encodeURIComponent(bootId)}?withData=1${versionQs}`);
      // 403 = the doc isn't ours to read. Never fall back to a stale local copy
      // from a prior session — wipe it and bounce to the listing.
      if (res.status === 403) {
        await clearLocalDoc(bootId);
        try { await store.removeItem(draftStorageKey(bootId)); } catch {}
        window.location.replace('/agent-builder');
        return;
      }
      const json = res.ok ? await res.json() : null;
      if (json?.currentData && typeof json.currentData === 'object') {
        const seededVersion = json.dataVersion ?? json.currentVersion;
        if (isModeration) {
          // Load into memory only — no draft slot, so the reviewed agent never
          // appears in the moderator's own list. Edits go back via admin PUT.
          state.moderationEdit = { id: bootId, version: seededVersion };
          await loadAgentIntoMemory(bootId, json.currentData, seededVersion);
          if (typeof seededVersion === 'string') state.agent.version = seededVersion;
        } else {
          await upsertDraftFromServer(bootId, json.currentData, seededVersion);
          await restore();
        }
      }
    } catch {
      // Offline / not found — fall through to the empty-agent default.
    }
  }

  // The author's id field is the canonical identity. If restore() loaded
  // a draft whose stored agent.id disagrees with the URL slug (legacy v3
  // migration, or the user hand-edited the URL), prefer the agent.id and
  // refresh the URL to match.
  if (state.agent.id && state.agent.id !== bootId && !bootId.startsWith('_new-')) {
    setActiveDraftId(state.agent.id);
    history.replaceState(null, '', `/agent-builder/edit/${encodeURIComponent(state.agent.id)}`);
  } else if (state.agent.id && bootId.startsWith('_new-')) {
    setActiveDraftId(state.agent.id);
    history.replaceState(null, '', `/agent-builder/edit/${encodeURIComponent(state.agent.id)}`);
  }

  await loadConfig();
  wireMetadataPass();
  wireTemplatePass();
  wireFieldsPass();
  wireStepsPass();
  wirePreviewPass();
  wirePassNav();
  // check errors list for Steps/fields need editing -> open Advanced.
  // Also open it when the restored draft was left on an advanced pass, so the
  // active panel always has its stepnav pill.
  advancedView = validateSteps().length > 0 || validateFields().length > 0
    || !!PASSES.find(p => p.num === state.pass)?.advanced;
  wireAdvancedToggle();
  wireGlobalControls();
  wireVersionPicker();
  wireVersionsTab();
  // Before wireStudio: it replays the saved chat log, which needs both
  // renderers already registered to redraw persisted runs and covers.
  wireTester();
  wireMediaGenerator();
  wireStudio();
  wirePublishSheet();
  installDarkSelectDropdowns();
  // Versioning hook runs BEFORE render so an auto-branch (editing a viewed
  // version) settles the state before the UI redraws.
  subscribe(onStateChangeForVersioning);
  subscribe(render);
  render();
  // Initial validation pass for the loaded id (next-version + taken flag).
  if (state.agent.id) {
    refreshNextVersion(state.agent.id);
    // Load the version list, THEN restore the active selection (Local if one
    // exists, else Main) and load its doc — so a refresh shows exactly what was
    // active and the Preview tab runs that version.
    loadVersionPicker(state.agent.id).then(() => initActiveSelection());
    loadVersionsTab(state.agent.id);
  }

  // Refresh both version surfaces after a successful publish — a new version row
  // landed and the Local copy was cleared. Re-resolve the active selection.
  window.addEventListener('agent-builder:published', () => {
    if (state.agent.id) {
      loadVersionPicker(state.agent.id).then(() => initActiveSelection());
      loadVersionsTab(state.agent.id);
    }
  });

  // After forking a version into a local draft, refresh the next-version label
  // (so the wizard shows the version the next publish will mint) and re-render
  // the picker (a "Local (unpublished edits)" entry now applies).
  window.addEventListener('agent-builder:forked', () => {
    if (state.agent.id) {
      refreshNextVersion(state.agent.id);
      refreshPickerOptions();
      loadVersionsTab(state.agent.id);
    }
  });

  // A version was deleted from the Versions table — keep the header dropdown
  // in sync with the new list.
  window.addEventListener('agent-builder:versions-changed', () => {
    if (state.agent.id) {
      refreshPickerOptions();
      loadVersionsTab(state.agent.id);
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}
