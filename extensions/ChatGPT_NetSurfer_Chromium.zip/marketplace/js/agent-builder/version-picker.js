/**
 * Version picker — switch between an agent's versions.
 *
 * Selection (`_selected`) changes ONLY by author action (dropdown, table, banner
 * buttons); render never overrides it. Whatever is selected is loaded in the
 * editor and is what the Preview tab runs.
 *
 *   - **Local (vNext)** — the unpublished working copy, persisted in its own
 *     localStorage key (state.readLocalDoc/writeLocalDoc). Created only by a real
 *     edit, "New version", or Studio. Deletable from the Versions table.
 *   - **Main (vX)**     — the live version (approved, else latest).
 *   - **vX**            — a historical version.
 *
 * Selecting Main/vX is a preview: the doc loads (editable) but Local is left
 * intact. The first real edit of a previewed version copies it into Local and
 * switches there, so history is never mutated.
 *
 * Builder-only: store/runtime always use Main via the server's getById resolver.
 */

import {
  state, notify, activeDraftId, setPreviewMode, forkAgentDoc,
  readLocalDoc, writeLocalDoc, hasLocalDoc, discardLocalToMain, cleanAgentForExport,
} from './state.js';
import { $ } from './utils.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';

const MAIN = '__main__';
const LOCAL = '__local__';

let _selected = MAIN;        // active selection; author-driven only
let _swapping = false;       // true during our own doc swaps (edit-detector ignores them)
let _loadedFingerprint = null; // baseline of the doc we last loaded; null = picker not ready
let _previewDoc = null;      // clean doc currently previewed — to revert a cancelled edit
let _versions = [];
let _mainVersion = null;
let _mainDoc = null;

// ---- helpers ---------------------------------------------------------------

function curId() { return state.agent?.id || activeDraftId() || ''; }
function localExists() { return hasLocalDoc(curId()); }

/** Stable fingerprint of the publishable doc (ignores version + __runtime flags). */
function docFingerprint(agent) {
  const c = cleanAgentForExport(agent || {});
  delete c.version;
  // Schema-derived step fields: loadAndApplySchema re-stamps these on every
  // async schema (re)load, so they're not part of the doc's published identity.
  // Excluding them stops a late schema notify() from looking like an author edit.
  if (Array.isArray(c.steps)) {
    for (const s of c.steps) {
      if (s && typeof s === 'object') { delete s.estimatedDurationMs; delete s.requiredKeys; }
    }
  }
  const stable = (v) => {
    if (v === null || typeof v !== 'object') return JSON.stringify(v);
    if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
    return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}';
  };
  return stable(c);
}

/**
 * Load `doc` into the editor as a programmatic swap: the edit-detector ignores
 * it (_swapping) and, when `preview` is set, persist() won't mark the slot local
 * (it's a temporary view, not an edit). Also captures the baseline fingerprint.
 */
function loadDoc(doc, { preview = false } = {}) {
  const id = curId();
  _swapping = true;
  if (preview) setPreviewMode(true);
  state.agent = { ...state.agent, ...doc, id };
  _loadedFingerprint = docFingerprint(state.agent);
  notify();
  if (preview) setPreviewMode(false);
  _swapping = false;
}

function nextVersionLabel() {
  const v = state.agent?.version;
  return typeof v === 'string' && /^\d+\.\d+\.\d+$/.test(v) ? v : '';
}

function statusLabel(s) {
  return ({ approved: 'approved', inactive: 'retired', pending: 'pending', rejected: 'rejected', draft: 'draft' })[s] || (s || '');
}
function escapeHtml(s) { return String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c])); }
function escapeAttr(s) { return String(s).replace(/"/g, '&quot;'); }

async function fetchVersionDoc(id, version) {
  try {
    const res = await fetchHelper(
      `https://aitopia.ai/api/agent-builder/version/${encodeURIComponent(id)}?withData=1&version=${encodeURIComponent(version)}`,
    );
    const json = res.ok ? await res.json() : null;
    if (json?.currentData && typeof json.currentData === 'object') return json.currentData;
  } catch { /* fall through */ }
  return null;
}

/** Resolve the doc for a selection value (MAIN / semver). Null on failure. */
async function docFor(selectValue) {
  const id = curId();
  if (!id) return null;
  if (selectValue === MAIN) return _mainDoc || (_mainVersion ? await fetchVersionDoc(id, _mainVersion) : null);
  return fetchVersionDoc(id, selectValue);
}

// ---- public API ------------------------------------------------------------

export function isViewingOldVersion() { return _selected !== LOCAL && _selected !== MAIN; }

/** Something to publish? Local edits exist, or it's a brand-new draft. */
export function hasPublishableChange() {
  return _mainVersion == null ? true : localExists();
}

/** Fetch the version list + Main doc, then re-render. Does not change selection. */
export async function loadVersionPicker(id) {
  const trimmed = String(id || '').trim();
  if (!$('#ab-version-row')) return;
  if (!trimmed || trimmed.startsWith('_new-')) {
    _versions = []; _mainVersion = null; _mainDoc = null;
    renderOptions();
    return;
  }
  try {
    const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/versions/${encodeURIComponent(trimmed)}`);
    const json = res.ok ? await res.json() : null;
    _versions = Array.isArray(json?.versions) ? json.versions : [];
    _mainVersion = typeof json?.mainVersion === 'string' ? json.mainVersion : null;
  } catch {
    _versions = []; _mainVersion = null;
  }
  _mainDoc = _mainVersion ? await fetchVersionDoc(trimmed, _mainVersion) : null;
  renderOptions();
}

/** Boot: load the doc for the active selection (Local if one exists, else Main). */
export async function initActiveSelection() {
  if (!curId() || _versions.length === 0) { _selected = MAIN; return; }
  // Moderation: stay on the version boot() seeded; don't switch to Local/Main.
  if (state.moderationEdit) {
    _selected = state.moderationEdit.version;
    _loadedFingerprint = docFingerprint(state.agent);
    setBanner(false);
    renderOptions();
    return;
  }
  if (localExists()) {
    _selected = LOCAL;
    const doc = readLocalDoc(curId());
    if (doc) loadDoc(doc);
    else _loadedFingerprint = docFingerprint(state.agent);
    setBanner(false);
  } else {
    await previewVersion(MAIN);
  }
  renderOptions();
}

export function refreshPickerOptions() { renderOptions(); }

function renderOptions() {
  const row = $('#ab-version-row');
  const sel = $('#ab-version-select');
  if (!row || !sel) return;
  if (_versions.length === 0) { row.hidden = true; return; }
  row.hidden = false;

  const opts = [];
  if (localExists()) {
    const nv = nextVersionLabel();
    opts.push(`<option value="${LOCAL}">Local${nv ? ` (v${escapeHtml(nv)})` : ''} — unpublished</option>`);
  }
  opts.push(`<option value="${MAIN}">${_mainVersion ? `Main (v${_mainVersion})` : 'Main'}</option>`);
  for (const v of _versions) {
    if (v.isMain) continue;
    opts.push(`<option value="${escapeAttr(v.version)}">v${escapeHtml(v.version)} — ${statusLabel(v.status)}</option>`);
  }

  sel.innerHTML = opts.join('');
  if (!opts.some(o => o.includes(`value="${_selected}"`))) _selected = MAIN;
  sel.value = _selected;
}

/** Banner shown while previewing a non-Local version. */
function setBanner(on, versionLabel) {
  const banner = $('#ab-readonly-banner');
  if (!banner) return;
  if (!on) { banner.classList.add('hidden'); return; }
  banner.classList.remove('hidden');
  const vl = versionLabel ? `<strong>v${escapeHtml(versionLabel)}</strong>` : 'this version';
  const hasLocal = localExists();
  const text = $('#ab-readonly-text');
  const back = $('#ab-readonly-back');
  const fork = $('#ab-readonly-fork');
  if (text) text.innerHTML =
    `Viewing ${vl}. Editing it (or “New version from this”) makes it your ` +
    `<strong>local version</strong>${hasLocal ? ' (replacing the current local copy)' : ''}.`;
  if (back) { back.classList.toggle('hidden', !hasLocal); back.textContent = 'Back to Local'; }
  if (fork) { fork.classList.remove('hidden'); fork.textContent = 'New version from this'; }
}

/** Preview Main or a vX (Local untouched). */
async function previewVersion(selectValue) {
  const doc = await docFor(selectValue);
  if (!doc) { renderOptions(); return; }
  _selected = selectValue;
  // Banner only when it tells the author something useful: they have a Local
  // copy to protect, or they're viewing an older (non-Main) version. Previewing
  // Main with no Local is just normal editing — no warning needed (an edit
  // simply becomes the Local version).
  const showBanner = localExists() || selectValue !== MAIN;
  setBanner(showBanner, selectValue === MAIN ? _mainVersion : selectValue);
  _previewDoc = JSON.parse(JSON.stringify(doc));
  loadDoc(doc, { preview: true });
  renderOptions();
}

/** Switch to the persistent Local working copy. */
function selectLocal() {
  const doc = readLocalDoc(curId());
  _selected = LOCAL;
  if (doc) loadDoc(doc);
  else _loadedFingerprint = docFingerprint(state.agent);
  _previewDoc = null;
  setBanner(false);
}

/** Make the current editor doc the Local working copy, selected. */
function commitLocal() {
  writeLocalDoc(curId(), cleanAgentForExport(state.agent));
  _selected = LOCAL;
  _loadedFingerprint = docFingerprint(state.agent);
  _previewDoc = null;
  setBanner(false);
  renderOptions();
  window.dispatchEvent(new CustomEvent('agent-builder:forked', { detail: { id: curId() } }));
}

/** "New version from this" — copy the previewed doc into Local. */
export function forkToNewVersion() {
  if (localExists() && !confirm('Your current local changes will be replaced by this version. Continue?')) return;
  commitLocal();                 // the previewed doc is already in state.agent
}

/** Versions-table "New version" on a specific version → copy it into Local. */
export async function forkVersionToLocal(version) {
  if (localExists() && !confirm('Your current local changes will be replaced by this version. Continue?')) return;
  const doc = await docFor(version);
  if (!doc) return;
  loadDoc(doc);
  commitLocal();
}

/** Studio output → Local. */
export function adoptExternalDocAsLocal(doc, doNotify = true) {
  if (!doc || typeof doc !== 'object') return;
  _swapping = true;
  try { forkAgentDoc(doc, doNotify); } finally { _swapping = false; }
  _loadedFingerprint = docFingerprint(state.agent);
  commitLocal();
}

/** Delete the Local working copy and reset the editor to Main. */
export async function deleteLocal() {
  if (!localExists()) return;
  if (!confirm('Delete your local (unpublished) version? Your unsaved changes will be lost.')) return;
  const id = curId();
  // Fetch Main before the suppressed window — docFor may hit the network.
  // Null when this id was never published; discardLocalToMain resets to clean.
  const mainDoc = await docFor(MAIN);
  // Real delete: wipe local.<id> AND reset the draft slot to Main so a refresh
  // can't restore the edits. Baseline after the call so the next notify matches.
  _swapping = true;
  discardLocalToMain(id, mainDoc, _mainVersion);
  _selected = MAIN;
  _previewDoc = null;
  _loadedFingerprint = docFingerprint(state.agent);
  _swapping = false;
  setBanner(false);
  renderOptions();
  window.dispatchEvent(new CustomEvent('agent-builder:versions-changed', { detail: { id } }));
}

/**
 * Edit detector (subscriber, runs before render). A real edit while previewing
 * Main/vX copies the doc into Local and switches there; on Local it keeps the
 * copy current. Ignores our own swaps, and stays quiet until the baseline is
 * set (so boot-time churn never fabricates a Local).
 */
export function onStateChangeForVersioning() {
  if (_swapping || _loadedFingerprint === null) return;
  // Moderation: edit the opened version directly, never fork a Local copy.
  if (state.moderationEdit) return;
  if (!curId() || _versions.length === 0) return;
  if (docFingerprint(state.agent) === _loadedFingerprint) return; // no real change

  // Editing while previewing a version (not on Local) and a Local copy already
  // exists → this edit would replace it. Ask first; on cancel, revert the edit
  // back to the previewed doc so nothing is lost.
  if (_selected !== LOCAL && localExists()) {
    if (!confirm('You have a local version. Editing this will replace it with a new local version. Continue?')) {
      // Revert: drop focus first so the re-render can overwrite the field the
      // author just typed into (render skips the focused input), then reload the
      // clean previewed doc.
      try { document.activeElement?.blur(); } catch {}
      if (_previewDoc) loadDoc(_previewDoc, { preview: true });
      return;
    }
  }
  commitLocal();
}

function onSelect(value) {
  if (value === _selected) return;
  if (value === LOCAL) selectLocal();
  else previewVersion(value);
}

export function wireVersionPicker() {
  $('#ab-version-select')?.addEventListener('change', (e) => onSelect(e.target.value));
  $('#ab-readonly-back')?.addEventListener('click', () => { if (localExists()) selectLocal(); });
  $('#ab-readonly-fork')?.addEventListener('click', () => forkToNewVersion());
}

/** Versions-table actions. */
export function viewOldVersion(version) {
  if (version === LOCAL) selectLocal();
  else previewVersion(version);
}
export function localRowInfo() { return { exists: localExists(), version: nextVersionLabel() }; }
export { LOCAL as LOCAL_VALUE, MAIN as MAIN_VALUE };
