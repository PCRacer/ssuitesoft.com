/**
 * Version picker — switch between an agent's versions.
 *
 * Selection (`_selected`) changes ONLY by author action (dropdown, table, banner
 * buttons); render never overrides it. Whatever is selected is loaded in the
 * editor and is what the Preview tab runs.
 *
 *   - **Local (vNext)** — the unpublished working copy, persisted in its own
 *     localStorage key (state.readLocalDoc/writeLocalDoc). Created only by a real
 *     edit, "New version", or Studio. Deletable from the Versions table.
 *   - **Main (vX)**     — the live version (approved, else latest).
 *   - **vX**            — a historical version.
 *
 * Selecting Main/vX is a preview: the doc loads (editable) but Local is left
 * intact. The first real edit of a previewed version copies it into Local and
 * switches there, so history is never mutated.
 *
 * Builder-only: store/runtime always use Main via the server's getById resolver.
 */

import {
  state, notify, activeDraftId, setPreviewMode, forkAgentDoc,
  readLocalDoc, writeLocalDoc, hasLocalDocSync, primeLocalDoc, discardLocalToMain, cleanAgentForExport,
} from './state.js';
import { $, confirmModal, floorCredits, totalFloorUsd } from './utils.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';

const MAIN = '__main__';
const LOCAL = '__local__';

let _selected = MAIN;        // active selection; author-driven only
let _swapping = false;       // true during our own doc swaps (edit-detector ignores them)
let _loadedFingerprint = null; // baseline of the doc we last loaded; null = picker not ready
let _previewDoc = null;      // clean doc currently previewed — to revert a cancelled edit
let _versions = [];
let _mainVersion = null;
let _mainDoc = null;
let _confirmPending = false;

// ---- helpers ---------------------------------------------------------------

function curId() { return state.agent?.id || activeDraftId() || ''; }
function localExists() { return hasLocalDocSync(curId()); }

/** Stable fingerprint of the publishable doc (ignores version + __runtime flags). */
function docFingerprint(agent) {
  const c = cleanAgentForExport(agent || {});
  delete c.version;
  // Schema-derived step fields: loadAndApplySchema re-stamps these on every
  // async schema (re)load, so they're not part of the doc's published identity.
  // Excluding them stops a late schema notify() from looking like an author edit.
  if (Array.isArray(c.steps)) {
    for (const s of c.steps) {
      if (s && typeof s === 'object') { delete s.estimatedDurationMs; delete s.requiredKeys; }
    }
  }
  const stable = (v) => {
    if (v === null || typeof v !== 'object') return JSON.stringify(v);
    if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
    return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}';
  };
  return stable(c);
}

/**
 * On (re)load, refresh the author's creditsPerRun against TODAY's floor while
 * keeping the same margin ratio. Page-only: mutates state, never the DB.
 *
 * The doc's saved costEstimate.minCost is the floor's cheapest-config USD at
 * publish time; the live totalFloorUsd().min is the same quantity at today's
 * registry prices. Their ratio is exactly how much the cost moved, so:
 *   oldFloor = newFloor × (doc.costEstimate.minCost / liveMin)
 * When the cost is unchanged the two mins are equal → oldFloor == newFloor →
 * the price is left exactly as the author set it (idempotent). When it moved,
 * keep the same margin ratio (creditsPerRun / oldFloor) on the new floor.
 */
function repriceAgainstLiveFloor(doc) {
  const cpr = Number(doc?.creditsPerRun);
  if (!Number.isFinite(cpr) || cpr <= 0) return; // no author price to scale

  const savedMin = Number(doc?.costEstimate?.minCost);
  const liveMin = totalFloorUsd().min;
  if (!Number.isFinite(savedMin) || savedMin <= 0 || !Number.isFinite(liveMin) || liveMin <= 0) return;

  // Cost unchanged since publish → do NOTHING. Compared on the floor's USD min
  // (the same quantity stored in costEstimate.minCost), so re-loads never touch
  // the price. Tiny float epsilon guards against re-serialization drift.
  if (Math.abs(savedMin - liveMin) < 1e-6) return;

  const newFloor = floorCredits(); // live floor (current registry cost + margin)
  if (newFloor <= 0) return;
  const oldFloor = newFloor * (savedMin / liveMin); // floor at publish-time cost
  if (oldFloor <= 0) return;

  const ratio = cpr / oldFloor;
  state.creditsPerRun = Math.max(newFloor, Math.ceil(newFloor * ratio));
  if (state.agent) state.agent.creditsPerRun = state.creditsPerRun;
}

/**
 * Load `doc` into the editor as a programmatic swap: the edit-detector ignores
 * it (_swapping) and, when `preview` is set, persist() won't mark the slot local
 * (it's a temporary view, not an edit). Also captures the baseline fingerprint.
 */
function loadDoc(doc, { preview = false } = {}) {
  const id = curId();
  _swapping = true;
  if (preview) setPreviewMode(true);
  state.agent = { ...state.agent, ...doc, id };
  // Reprice against the live floor BEFORE notify() so the first render shows the
  // margin-preserved price. Uses the just-loaded doc's saved costEstimate to
  // recover the old ratio (recomputeDerived in render will then refresh
  // costEstimate itself).
  repriceAgainstLiveFloor(doc);
  _loadedFingerprint = docFingerprint(state.agent);
  notify();
  if (preview) setPreviewMode(false);
  _swapping = false;
}

function nextVersionLabel() {
  const v = state.agent?.version;
  return typeof v === 'string' && /^\d+\.\d+\.\d+$/.test(v) ? v : '';
}

function statusLabel(s) {
  return ({ approved: 'approved', inactive: 'retired', pending: 'pending', rejected: 'rejected', draft: 'draft' })[s] || (s || '');
}
function escapeHtml(s) { return String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c])); }
function escapeAttr(s) { return String(s).replace(/"/g, '&quot;'); }

async function fetchVersionDoc(id, version) {
  try {
    const res = await fetchHelper(
      `https://aitopia.ai/api/agent-builder/version/${encodeURIComponent(id)}?withData=1&version=${encodeURIComponent(version)}`,
    );
    const json = res.ok ? await res.json() : null;
    if (json?.currentData && typeof json.currentData === 'object') return json.currentData;
  } catch { /* fall through */ }
  return null;
}

/** Resolve the doc for a selection value (MAIN / semver). Null on failure. */
async function docFor(selectValue) {
  const id = curId();
  if (!id) return null;
  if (selectValue === MAIN) return _mainDoc || (_mainVersion ? await fetchVersionDoc(id, _mainVersion) : null);
  return fetchVersionDoc(id, selectValue);
}

// ---- public API ------------------------------------------------------------

export function isViewingOldVersion() { return _selected !== LOCAL && _selected !== MAIN; }

/** Something to publish? Local edits exist, or it's a brand-new draft. */
export function hasPublishableChange() {
  return _mainVersion == null ? true : localExists();
}

/** Fetch the version list + Main doc, then re-render. Does not change selection. */
export async function loadVersionPicker(id) {
  await primeLocalDoc(id || curId());
  const trimmed = String(id || '').trim();
  if (!$('#ab-version-row')) return;
  if (!trimmed || trimmed.startsWith('_new-')) {
    _versions = []; _mainVersion = null; _mainDoc = null;
    renderOptions();
    return;
  }
  try {
    const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/versions/${encodeURIComponent(trimmed)}`);
    const json = res.ok ? await res.json() : null;
    _versions = Array.isArray(json?.versions) ? json.versions : [];
    _mainVersion = typeof json?.mainVersion === 'string' ? json.mainVersion : null;
  } catch {
    _versions = []; _mainVersion = null;
  }
  _mainDoc = _mainVersion ? await fetchVersionDoc(trimmed, _mainVersion) : null;
  renderOptions();
}

/** Boot: load the doc for the active selection (Local if one exists, else Main). */
export async function initActiveSelection() {
  if (!curId() || _versions.length === 0) { _selected = MAIN; return; }
  // Prime the presence cache so localExists() can answer synchronously below.
  await primeLocalDoc(curId());
  // Moderation: stay on the version boot() seeded; don't switch to Local/Main.
  if (state.moderationEdit) {
    _selected = state.moderationEdit.version;
    _loadedFingerprint = docFingerprint(state.agent);
    setBanner(false);
    renderOptions();
    return;
  }
  if (localExists()) {
    _selected = LOCAL;
    const doc = await readLocalDoc(curId());
    if (doc) loadDoc(doc);
    else _loadedFingerprint = docFingerprint(state.agent);
    setBanner(false);
  } else {
    await previewVersion(MAIN);
  }
  renderOptions();
}

export function refreshPickerOptions() { renderOptions(); }

function renderOptions() {
  const row = $('#ab-version-row');
  const sel = $('#ab-version-select');
  if (!row || !sel) return;
  if (_versions.length === 0) { row.hidden = true; return; }
  row.hidden = false;

  const opts = [];
  if (localExists()) {
    const nv = nextVersionLabel();
    opts.push(`<option value="${LOCAL}">Local${nv ? ` (v${escapeHtml(nv)})` : ''} - unpublished</option>`);
  }
  // Main is the newest version whatever its status, so carry that status the
  // same way the other rows do — it is no longer always the approved one.
  const mainRow = _versions.find(v => v.version === _mainVersion);
  const mainStatus = mainRow ? ` - ${statusLabel(mainRow.status)}` : '';
  opts.push(`<option value="${MAIN}">${_mainVersion ? `Main (v${escapeHtml(_mainVersion)})${mainStatus}` : 'Main'}</option>`);
  for (const v of _versions) {
    if (v.isMain) continue;
    opts.push(`<option value="${escapeAttr(v.version)}">v${escapeHtml(v.version)} - ${statusLabel(v.status)}</option>`);
  }

  sel.innerHTML = opts.join('');
  if (!opts.some(o => o.includes(`value="${_selected}"`))) _selected = MAIN;
  sel.value = _selected;
}

/** Banner shown while previewing a non-Local version. */
function setBanner(on, versionLabel) {
  const banner = $('#ab-readonly-banner');
  if (!banner) return;
  if (!on) { banner.classList.add('hidden'); return; }
  banner.classList.remove('hidden');
  const vl = versionLabel ? `<strong>v${escapeHtml(versionLabel)}</strong>` : 'this version';
  const hasLocal = localExists();
  const text = $('#ab-readonly-text');
  const back = $('#ab-readonly-back');
  const fork = $('#ab-readonly-fork');
  if (text) text.innerHTML =
    `Viewing ${vl}. Editing it (or “New version from this”) makes it your ` +
    `<strong>unpublished working copy</strong>${hasLocal ? ' (replacing your current unpublished changes)' : ''}.`;
  if (back) { back.classList.toggle('hidden', !hasLocal); back.textContent = 'Back to Local'; }
  if (fork) { fork.classList.remove('hidden'); fork.textContent = 'New version from this'; }
}

/** Preview Main or a vX (Local untouched). */
async function previewVersion(selectValue) {
  const doc = await docFor(selectValue);
  if (!doc) { renderOptions(); return; }
  _selected = selectValue;
  // Banner only when it tells the author something useful: they have a Local
  // copy to protect, or they're viewing an older (non-Main) version. Previewing
  // Main with no Local is just normal editing — no warning needed (an edit
  // simply becomes the Local version).
  const showBanner = localExists() || selectValue !== MAIN;
  setBanner(showBanner, selectValue === MAIN ? _mainVersion : selectValue);
  _previewDoc = JSON.parse(JSON.stringify(doc));
  loadDoc(doc, { preview: true });
  renderOptions();
}

/** Switch to the persistent Local working copy. */
async function selectLocal() {
  const doc = await readLocalDoc(curId());
  _selected = LOCAL;
  if (doc) loadDoc(doc);
  else _loadedFingerprint = docFingerprint(state.agent);
  _previewDoc = null;
  setBanner(false);
}

/** Make the current editor doc the Local working copy, selected. */
async function commitLocal() {
  await writeLocalDoc(curId(), cleanAgentForExport(state.agent));
  _selected = LOCAL;
  _loadedFingerprint = docFingerprint(state.agent);
  _previewDoc = null;
  setBanner(false);
  renderOptions();
  window.dispatchEvent(new CustomEvent('agent-builder:forked', { detail: { id: curId() } }));
}

const REPLACE_LOCAL_CONFIRM = {
  title: 'Replace unpublished changes?',
  message: 'Your unpublished changes will be replaced by this version.',
  confirmLabel: 'Replace',
};

/** "New version from this" — copy the previewed doc into Local. */
export async function forkToNewVersion() {
  if (localExists() && !(await confirmModal(REPLACE_LOCAL_CONFIRM))) return;
  await commitLocal();           // the previewed doc is already in state.agent
}

/** Versions-table "New version" on a specific version → copy it into Local. */
export async function forkVersionToLocal(version) {
  if (localExists() && !(await confirmModal(REPLACE_LOCAL_CONFIRM))) return;
  const doc = await docFor(version);
  if (!doc) return;
  loadDoc(doc);
  await commitLocal();
}

/** Studio output → Local. */
export async function adoptExternalDocAsLocal(doc, doNotify = true) {
  if (!doc || typeof doc !== 'object') return;
  _swapping = true;
  try { forkAgentDoc(doc, doNotify); } finally { _swapping = false; }
  _loadedFingerprint = docFingerprint(state.agent);
  await commitLocal();
}

/** Delete the Local working copy and reset the editor to Main. */
export async function deleteLocal() {
  if (!localExists()) return;
  const ok = await confirmModal({
    title: 'Delete unpublished changes?',
    message: 'Your unpublished changes will be deleted and cannot be recovered.',
    confirmLabel: 'Delete',
    danger: true,
  });
  if (!ok) return;
  const id = curId();
  // Fetch Main before the suppressed window — docFor may hit the network.
  // Null when this id was never published; discardLocalToMain resets to clean.
  const mainDoc = await docFor(MAIN);
  // Real delete: wipe local.<id> AND reset the draft slot to Main so a refresh
  // can't restore the edits. Baseline after the call so the next notify matches.
  _swapping = true;
  await discardLocalToMain(id, mainDoc, _mainVersion);
  _selected = MAIN;
  _previewDoc = null;
  _loadedFingerprint = docFingerprint(state.agent);
  _swapping = false;
  setBanner(false);
  renderOptions();
  window.dispatchEvent(new CustomEvent('agent-builder:versions-changed', { detail: { id } }));
}

/**
 * Edit detector (subscriber, runs before render). A real edit while previewing
 * Main/vX copies the doc into Local and switches there; on Local it keeps the
 * copy current. Ignores our own swaps, and stays quiet until the baseline is
 * set (so boot-time churn never fabricates a Local).
 */
export function onStateChangeForVersioning() {
  if (_swapping || _loadedFingerprint === null) return;
  // Moderation: edit the opened version directly, never fork a Local copy.
  if (state.moderationEdit) return;
  if (!curId() || _versions.length === 0) return;
  if (docFingerprint(state.agent) === _loadedFingerprint) return; // no real change

  // Editing while previewing a version (not on Local) and a Local copy already
  // exists → this edit would replace it. Ask first; on cancel, revert the edit
  // back to the previewed doc so nothing is lost.
  if (_selected !== LOCAL && localExists()) {
    if (_confirmPending) return;
    _confirmPending = true;
    void confirmModal({
      title: 'Replace unpublished changes?',
      message: 'You have unpublished changes. Editing this version will replace them.',
      confirmLabel: 'Replace',
    }).then((ok) => {
      _confirmPending = false;
      if (!ok) {
        try { document.activeElement?.blur(); } catch {}
        if (typeof state.publishedVersion === 'string' && state.publishedVersion.endsWith('-local')) {
          state.publishedVersion = state.publishedVersion.slice(0, -'-local'.length);
        }
        if (_previewDoc) loadDoc(_previewDoc, { preview: true });
        return;
      }
      commitLocal();
    });
    return;
  }
  commitLocal();
}

function onSelect(value) {
  if (value === _selected) return;
  if (value === LOCAL) selectLocal();
  else previewVersion(value);
}

export function wireVersionPicker() {
  $('#ab-version-select')?.addEventListener('change', (e) => onSelect(e.target.value));
  $('#ab-readonly-back')?.addEventListener('click', () => { if (localExists()) selectLocal(); });
  $('#ab-readonly-fork')?.addEventListener('click', () => forkToNewVersion());
}

/** Versions-table actions. */
export function viewOldVersion(version) {
  if (version === LOCAL) selectLocal();
  else previewVersion(version);
}
export function localRowInfo() { return { exists: localExists(), version: nextVersionLabel() }; }
export { LOCAL as LOCAL_VALUE, MAIN as MAIN_VALUE };
