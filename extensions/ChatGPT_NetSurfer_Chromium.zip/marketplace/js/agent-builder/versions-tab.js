/**
 * Versions tab — the (id, version) history table for the current agent.
 *
 * One row per version with three actions:
 *   - Select       → view that version read-only in the Customizer (reuses the
 *                    header picker's viewOldVersion). The Main row just returns
 *                    to the editable Main.
 *   - New version  → fork that version's data into a fresh local draft so the
 *                    author can publish a new version on top of it (works for a
 *                    pending version, which has no editable Main of its own).
 *   - Delete       → permanently remove that version (DB + local). Approved is
 *                    blocked here (disabled + badge) AND on the server (409).
 *
 * Stays in sync with the header dropdown: both read /versions/:id, and any
 * mutation re-fetches both via the shared events.
 */

import { state, activeDraftId } from './state.js';
import { $ } from './utils.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';
import { showTab } from './studio.js';
import { viewOldVersion, forkVersionToLocal, deleteLocal, localRowInfo, LOCAL_VALUE, MAIN_VALUE } from './version-picker.js';

let _rows = [];
let _mainVersion = null;

function statusLabel(s) {
  return ({
    approved: 'approved',
    inactive: 'retired',
    pending: 'pending',
    rejected: 'rejected',
    draft: 'draft',
  })[s] || (s || '');
}

function fmtDate(iso) {
  if (!iso) return '—';
  try {
    const d = new Date(iso);
    return d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch {
    return '—';
  }
}

function escapeHtml(s) {
  return String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
}

/** Fetch the version list for the current id and (re)render the table + tab. */
export async function loadVersionsTab(id) {
  const trimmed = String(id || state.agent?.id || activeDraftId() || '').trim();
  const tabBtn = $('#ab-tab-btn-versions');
  if (!trimmed || trimmed.startsWith('_new-')) {
    if (tabBtn) tabBtn.hidden = true;
    _rows = [];
    return;
  }

  try {
    const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/versions/${encodeURIComponent(trimmed)}`);
    const json = res.ok ? await res.json() : null;
    _rows = Array.isArray(json?.versions) ? json.versions : [];
    _mainVersion = typeof json?.mainVersion === 'string' ? json.mainVersion : null;
  } catch {
    _rows = [];
    _mainVersion = null;
  }

  // Show the tab once there's a server-side version OR a local working copy.
  if (tabBtn) tabBtn.hidden = _rows.length === 0 && !localRowInfo().exists;
  renderTable();
}

/** One table row. `opts` = { rowClass, title, badgeClass, badge, updated,
 *  approved, selectVal, forkAction, delAttrs }. */
function rowHtml(o) {
  return `
      <tr class="${o.rowClass}">
        <td>${o.title}</td>
        <td><span class="ab-ver-badge ${o.badgeClass}">${o.badge}</span></td>
        <td>${o.updated}</td>
        <td>${o.approved}</td>
        <td class="text-right">
          <button class="btn" type="button" data-action="select" data-version="${o.selectVal}">Select</button>
          <button class="btn" type="button" ${o.forkAction}>New version</button>
          <button class="btn danger" type="button" ${o.delAttrs}>Delete</button>
        </td>
      </tr>`;
}

function renderTable() {
  const tbody = $('#ab-versions-tbody');
  const empty = $('#ab-versions-empty');
  const table = $('#ab-versions-table');
  if (!tbody) return;

  const local = localRowInfo();
  if (_rows.length === 0 && !local.exists) {
    tbody.innerHTML = '';
    if (empty) empty.hidden = false;
    if (table) table.hidden = true;
    return;
  }
  if (empty) empty.hidden = true;
  if (table) table.hidden = false;

  // Local first (when present): Select to edit, New = overwrite from Main, Delete.
  const localRow = local.exists ? rowHtml({
    rowClass: 'is-local',
    title: `<strong>Local${local.version ? ` (v${escapeHtml(local.version)})` : ''}</strong><span class="ab-ver-main-tag">working copy</span>`,
    badgeClass: 'draft', badge: 'unpublished', updated: '—', approved: '—',
    selectVal: LOCAL_VALUE,
    forkAction: 'data-action="fork-main" title="Replace local with Main"',
    delAttrs: 'data-action="delete-local"',
  }) : '';

  const versionRows = _rows.map(r => {
    const isMain = r.version === _mainVersion;
    const ver = escapeHtml(r.version);
    return rowHtml({
      rowClass: isMain ? 'is-main' : '',
      title: `<strong>v${ver}</strong>${isMain ? '<span class="ab-ver-main-tag">Main</span>' : ''}`,
      badgeClass: escapeHtml(r.status), badge: statusLabel(r.status),
      updated: fmtDate(r.updatedAt), approved: fmtDate(r.approvedAt),
      selectVal: ver,
      forkAction: `data-action="fork" data-version="${ver}"`,
      delAttrs: r.status === 'approved'
        ? 'disabled title="Published (approved) versions cannot be deleted"'
        : `data-action="delete" data-version="${ver}"`,
    });
  }).join('');

  tbody.innerHTML = localRow + versionRows;
}

async function deleteVersion(version) {
  const id = state.agent?.id || activeDraftId();
  if (!id || !version) return;
  if (!confirm(`Delete v${version}? This permanently removes that version and cannot be undone.`)) return;
  try {
    const res = await fetchHelper(
      `https://aitopia.ai/api/agent-builder/version/${encodeURIComponent(id)}/${encodeURIComponent(version)}`,
      { method: 'DELETE' },
    );
    if (!res.ok) {
      let msg = 'Delete failed.';
      try { const j = await res.json(); if (j?.message) msg = j.message; } catch {}
      alert(msg);
      return;
    }
    // If we were viewing the just-deleted version, snap back to Main.
    viewOldVersion(MAIN_VALUE);
    await loadVersionsTab(id);
    // Keep the header dropdown in sync too.
    window.dispatchEvent(new CustomEvent('agent-builder:versions-changed', { detail: { id } }));
  } catch (err) {
    alert('Network error deleting version: ' + (err?.message || err));
  }
}

export function wireVersionsTab() {
  $('#ab-tab-btn-versions')?.addEventListener('click', () => {
    showTab('versions');
    if (state.agent.id) loadVersionsTab(state.agent.id);
  });
  $('#ab-versions-refresh')?.addEventListener('click', () => {
    if (state.agent.id) loadVersionsTab(state.agent.id);
  });

  // Delegated row actions.
  $('#ab-versions-tbody')?.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-action]');
    if (!btn) return;
    const action = btn.getAttribute('data-action');
    const version = btn.getAttribute('data-version');
    if (action === 'select') {
      // Select Main/Local/a version into the Customizer. The version === Main
      // case maps to MAIN_VALUE so the picker treats it as a Main preview.
      viewOldVersion(version === _mainVersion ? MAIN_VALUE : version);
      showTab('customizer');
    } else if (action === 'fork') {
      forkVersionToLocal(version);
      showTab('customizer');
    } else if (action === 'fork-main') {
      forkVersionToLocal(MAIN_VALUE);   // Local row "New version" = copy Main
      showTab('customizer');
    } else if (action === 'delete') {
      deleteVersion(version);
    } else if (action === 'delete-local') {
      deleteLocal().then(() => loadVersionsTab(state.agent.id));
    }
  });
}
