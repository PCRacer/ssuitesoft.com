/**
 * Versions tab — the (id, version) history table for the current agent.
 *
 * One row per version with three actions:
 *   - Select       → view that version read-only in the Customizer (reuses the
 *                    header picker's viewOldVersion). The Main row just returns
 *                    to the editable Main.
 *   - New version  → fork that version's data into a fresh local draft so the
 *                    author can publish a new version on top of it (works for a
 *                    pending version, which has no editable Main of its own).
 *   - Delete       → permanently remove that version (DB + local). Approved is
 *                    blocked here (disabled + badge) AND on the server (409).
 *
 * Stays in sync with the header dropdown: both read /versions/:id, and any
 * mutation re-fetches both via the shared events.
 */

import { state, activeDraftId } from './state.js';
import { $, toast, confirmModal } from './utils.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';
import { showTab } from './studio.js';
import { viewOldVersion, forkVersionToLocal, deleteLocal, localRowInfo, LOCAL_VALUE, MAIN_VALUE } from './version-picker.js';

let _rows = [];
let _mainVersion = null;

function statusLabel(s) {
  return ({
    approved: 'Approved',
    inactive: 'Retired',
    pending: 'Pending',
    rejected: 'Rejected',
    draft: 'Draft',
  })[s] || (s || '');
}

function fmtDate(iso) {
  if (!iso) return '-';
  try {
    const d = new Date(iso);
    return d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch {
    return '-';
  }
}

function escapeHtml(s) {
  return String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
}

/** Fetch the version list for the current id and (re)render the table + tab. */
export async function loadVersionsTab(id) {
  const trimmed = String(id || state.agent?.id || activeDraftId() || '').trim();
  const tabBtn = $('#ab-tab-btn-versions');
  if (!trimmed || trimmed.startsWith('_new-')) {
    if (tabBtn) tabBtn.hidden = true;
    _rows = [];
    return;
  }

  try {
    const res = await fetchHelper(`https://aitopia.ai/api/agent-builder/versions/${encodeURIComponent(trimmed)}`);
    const json = res.ok ? await res.json() : null;
    _rows = Array.isArray(json?.versions) ? json.versions : [];
    _mainVersion = typeof json?.mainVersion === 'string' ? json.mainVersion : null;
  } catch {
    _rows = [];
    _mainVersion = null;
  }

  // Show the tab once there's a server-side version OR a local working copy.
  if (tabBtn) tabBtn.hidden = _rows.length === 0 && !localRowInfo().exists;
  renderTable();
}

/** One table row. `opts` = { rowClass, title, badgeClass, badge, updated,
 *  approved, selectVal, forkAction, delAttrs }. */
const PLUS_SQ_SVG = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"></rect><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>';
const TRASH_SVG = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"></path><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>';

function rowHtml(o) {
  return `
      <tr class="${o.rowClass}" data-select-version="${o.selectVal}">
        <td>${o.title}</td>
        <td><span class="ab-ver-badge ${o.badgeClass}">${o.badge}</span></td>
        <td data-label="Updated">${o.updated}</td>
        <td data-label="Approved">${o.approved}</td>
        <td class="text-right">
          <button class="ab-ver-iconbtn" type="button" aria-label="New version from this" ${o.forkAction}>${PLUS_SQ_SVG}</button>
          <button class="ab-ver-iconbtn danger" type="button" aria-label="Delete" ${o.delAttrs}>${TRASH_SVG}</button>
        </td>
      </tr>`;
}

function renderTable() {
  const tbody = $('#ab-versions-tbody');
  const empty = $('#ab-versions-empty');
  const table = $('#ab-versions-table');
  if (!tbody) return;

  const local = localRowInfo();
  if (_rows.length === 0 && !local.exists) {
    tbody.innerHTML = '';
    if (empty) empty.hidden = false;
    if (table) table.hidden = true;
    return;
  }
  if (empty) empty.hidden = true;
  if (table) table.hidden = false;

  // Local first (when present): Select to edit, New = overwrite from Main, Delete.
  const localRow = local.exists ? rowHtml({
    rowClass: 'is-local',
    title: `<strong>Local${local.version ? ` (v${escapeHtml(local.version)})` : ''}</strong><span class="ab-ver-main-tag">working copy</span>`,
    badgeClass: 'draft', badge: 'Unpublished', updated: '-', approved: '-',
    selectVal: LOCAL_VALUE,
    forkAction: 'data-action="fork-main" title="Replace local with Main"',
    delAttrs: 'data-action="delete-local" title="Delete unpublished changes"',
  }) : '';

  const versionRows = _rows.map(r => {
    const isMain = r.version === _mainVersion;
    const ver = escapeHtml(r.version);
    return rowHtml({
      rowClass: isMain ? 'is-main' : '',
      title: `<strong>v${ver}</strong>${isMain ? '<span class="ab-ver-main-tag">Main</span>' : ''}`,
      badgeClass: escapeHtml(r.status), badge: statusLabel(r.status),
      updated: fmtDate(r.updatedAt), approved: fmtDate(r.approvedAt),
      selectVal: ver,
      forkAction: `data-action="fork" data-version="${ver}" title="New version from this"`,
      delAttrs: r.status === 'approved'
        ? 'disabled title="Published (approved) versions cannot be deleted"'
        : `data-action="delete" data-version="${ver}" title="Delete this version"`,
    });
  }).join('');

  tbody.innerHTML = localRow + versionRows;
}

async function deleteVersion(version) {
  const id = state.agent?.id || activeDraftId();
  if (!id || !version) return;
  const ok = await confirmModal({
    title: `Delete v${version}?`,
    message: 'This permanently removes that version and cannot be undone.',
    confirmLabel: 'Delete',
    danger: true,
  });
  if (!ok) return;
  try {
    const res = await fetchHelper(
      `https://aitopia.ai/api/agent-builder/version/${encodeURIComponent(id)}/${encodeURIComponent(version)}`,
      { method: 'DELETE' },
    );
    if (!res.ok) {
      let msg = 'Delete failed.';
      try { const j = await res.json(); if (j?.message) msg = j.message; } catch {}
      toast(msg, 'error', 5000);
      return;
    }
    // If we were viewing the just-deleted version, snap back to Main.
    viewOldVersion(MAIN_VALUE);
    await loadVersionsTab(id);
    // Keep the header dropdown in sync too.
    window.dispatchEvent(new CustomEvent('agent-builder:versions-changed', { detail: { id } }));
  } catch (err) {
    toast('Network error deleting version: ' + (err?.message || err), 'error', 5000);
  }
}

export function wireVersionsTab() {
  $('#ab-tab-btn-versions')?.addEventListener('click', () => {
    showTab('versions');
    if (state.agent.id) loadVersionsTab(state.agent.id);
  });
  $('#ab-versions-refresh')?.addEventListener('click', () => {
    if (state.agent.id) loadVersionsTab(state.agent.id);
  });

  // Delegated row actions. A click anywhere on the row
  // selects that version into the Setup tab.
  $('#ab-versions-tbody')?.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-action]');
    if (!btn) {
      const tr = e.target.closest('tr[data-select-version]');
      if (!tr) return;
      const version = tr.getAttribute('data-select-version');
      // Main maps to MAIN_VALUE so the picker treats it as a Main preview.
      viewOldVersion(version === _mainVersion ? MAIN_VALUE : version);
      showTab('customizer');
      return;
    }
    const action = btn.getAttribute('data-action');
    const version = btn.getAttribute('data-version');
    if (action === 'fork') {
      forkVersionToLocal(version);
      showTab('customizer');
    } else if (action === 'fork-main') {
      forkVersionToLocal(MAIN_VALUE);   // Local row "New version" = copy Main
      showTab('customizer');
    } else if (action === 'delete') {
      deleteVersion(version);
    } else if (action === 'delete-local') {
      deleteLocal().then(() => loadVersionsTab(state.agent.id));
    }
  });
}
