/**
 * Studio tab — chat-driven agent authoring.
 *
 * The user describes the agent they want; we POST the running conversation to
 * /api/agent-builder/studio-chat, whose backend follows the authoring guide and
 * (when ready) replies with the agent doc inside a ```json fenced block. We
 * parse that out, adopt it as the Local version (adoptExternalDocAsLocal), and flip to
 * the Customizer tab so the author can refine and publish.
 *
 * Tab switching is independent of the wizard's pass system — it just toggles
 * the two .ab-tabpane elements.
 */

import {
  state, notify, activeDraftId, hasLocalDoc,
  draftStorageKey, cleanAgentForExport,
  migrateDraftId, registerIdScopedPrefix, docIdentityFingerprint, isModerationMode,
} from './state.js';
import * as store from '/marketplace/js/services/browser-storage.js';
import { $, toast, confirmModal, floorCredits, pricingBand, isInsufficientCredits, insufficientCreditsMessage, openPricingModal, ensureSignedIn } from './utils.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';
import { adoptExternalDocAsLocal } from './version-picker.js';
import { startTour } from './tour.js';
import { tester } from './tester.js';

// Running conversation: [{ role: 'user'|'assistant', content }]. Sent verbatim
// to the backend each turn so the model keeps context across messages. `content`
// is a plain string, or an array of Anthropic content blocks (text + image)
// when the user attached/pasted a screenshot — the model fetches the image url
// (a CDN url we uploaded to first) and analyzes it natively.
let conversation = [];

// Images the author has attached/pasted but not yet sent. Each entry is
// { url, status: 'uploading'|'ready'|'error' }; once ready, `url` is the CDN
// url we POST as an image block. Cleared after a successful send.
let pendingAttachments = [];

const STUDIO_REFINE_PLACEHOLDER = 'Refine your agent or ask for changes…';
let typewriter = null;

const STUDIO_PLACEHOLDERS = [
  'An agent that makes my product go viral with a talking AI twin',
  'An agent that turns one idea into a week of TikTok & Reels',
  'An agent that writes scroll-stopping hooks from trending audio',
  'An agent that builds a launch campaign from a single sentence',
  'An agent that turns customer reviews into testimonial videos',
  'An agent that designs thumbnails that beat my YouTube average',
  'An agent that generates carousel posts from my blog',
];

// localStorage scope for the Studio chat, keyed by the active draft id — same
// id the wizard's draft uses. A brand-new draft has a synthetic `_new-<rand>`
// id (the auto value assigned at boot when the real id is still undefined);
// once the author/agent settles a real `agent.id`, the wizard re-points the
// active draft id and we migrate this cache key onto it (see watchDraftId).
const STUDIO_CHAT_PREFIX = 'aitopia.agent-builder.v4.studio-chat.';
function chatStorageKey(id) {
  return `${STUDIO_CHAT_PREFIX}${id || '_unsaved'}`;
}
// The draft id this module currently persists under. Tracked so we can detect
// the `_new-*` → real-id rename and move the stored conversation across.
let boundDraftId = '';

// Pre-rename draft id, sent once on the next turn so the server can move the
// events_log rows across — only the client sees both ids.
let pendingEventRekeyFrom = '';

// Identity of the doc last applied to Setup, so a card can tell Open from Apply.
// Stored rather than re-derived: adoption hydrates schemas and auto-creates
// fields, so the live doc never matches the card it came from.
const APPLIED_DOC_PREFIX = 'aitopia.agent-builder.v4.applied-doc.';
let _appliedDocFingerprint = null;

async function loadAppliedFingerprint(id) {
  try { _appliedDocFingerprint = await store.getItem(`${APPLIED_DOC_PREFIX}${id || '_unsaved'}`, chatScope()); }
  catch { _appliedDocFingerprint = null; }
}

async function saveAppliedFingerprint(fp) {
  const id = activeDraftId() || '_unsaved';
  try {
    if (fp) await store.setItem(`${APPLIED_DOC_PREFIX}${id}`, fp, chatScope());
    else await store.removeItem(`${APPLIED_DOC_PREFIX}${id}`, chatScope());
  } catch { /* quota — the label just falls back to comparing the live doc */ }
}

// Register with state.js so an id rename carries these across.
registerIdScopedPrefix(STUDIO_CHAT_PREFIX);
registerIdScopedPrefix(APPLIED_DOC_PREFIX);

/** The draft was renamed; migrateDraftId already moved the stored chat, so
 * only the local pointer needs rebinding. */
export function rebindDraftId(newId) {
  if (newId) boundDraftId = newId;
}

/**
 * Read the builder agent doc currently saved for the active draft from
 * localStorage and return its EXPORT-CLEAN form — the same JSON the "Export
 * JSON" button produces, with internal `__`-prefixed runtime flags
 * (`__schemaMeta`, `__optionalAvailable`, …) stripped. Sent to the backend each
 * turn so the model edits the live agent doc (including manual Customizer
 * changes) instead of regenerating from scratch. Returns null when there's no
 * draft yet or it has no real substance (so the first "create from nothing"
 * turn behaves as before).
 *
 * Because the version picker writes whatever version is active (Local if there
 * are unpublished edits, otherwise the selected version) into this same
 * localStorage slot, this naturally sends "Local if present, else the selected
 * version". Studio's reply is then adopted as Local (adoptExternalDocAsLocal),
 * so every subsequent turn keeps editing Local.
 */
async function readCurrentDoc() {
  const id = activeDraftId();
  if (!id) return null;
  try {
    const raw = await store.getItem(draftStorageKey(id));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const agent = parsed && typeof parsed === 'object' ? parsed.agent : null;
    if (!agent || typeof agent !== 'object') return null;
    // Only send it once the doc actually has content — an empty shell would
    // just constrain the model with blanks on the very first creation turn.
    const hasSubstance = agent.id || agent.name ||
      (Array.isArray(agent.steps) && agent.steps.length) ||
      (Array.isArray(agent.fields) && agent.fields.length);
    if (!hasSubstance) return null;
    // Strip internal `__`-flags so the model sees the publishable agent doc,
    // not the wizard's runtime bookkeeping.
    return cleanAgentForExport(agent);
  } catch {
    return null;
  }
}

// Moderation keeps its chat tab-scoped: it survives a reload but dies with the
// tab, so a reviewed agent never lingers in the moderator's storage.
function chatScope() {
  return isModerationMode() ? { scope: 'session' } : undefined;
}

async function persistConversation() {
  const id = activeDraftId();
  if (!id) return;
  try {
    if (conversation.length) {
      await store.setItem(chatStorageKey(id), JSON.stringify(conversation), chatScope());
    } else {
      await store.removeItem(chatStorageKey(id), chatScope());
    }
  } catch { /* quota / disabled — chat just won't survive reload */ }
}

async function restoreConversation(id) {
  conversation = [];
  if (!id) return;
  try {
    const raw = await store.getItem(chatStorageKey(id), chatScope());
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        conversation = parsed.filter(
          (m) => m && (
            // A test-run/media-run entry carries a report instead of prose; it
            // is re-rendered by its own module, not by appendMessage.
            ((m.role === 'test-run' || m.role === 'media-run')
              && m.report && typeof m.report === 'object') ||
            ((m.role === 'user' || m.role === 'assistant') &&
              (typeof m.content === 'string' || Array.isArray(m.content)))
          ),
        );
      }
    }
  } catch { /* corrupt entry — start fresh */ }
}

/**
 * Renderer for persisted test-run entries, supplied by tester-ui.js. Kept as a
 * hook so studio.js does not need to know how a run report looks — and so the
 * import stays one-way (tester-ui → studio).
 */
let _testRunRenderer = null;
export function registerTestRunRenderer(fn) { _testRunRenderer = fn; }

/** Renderer for persisted media-run entries, supplied by media-generator-ui.js. */
let _mediaRunRenderer = null;
export function registerMediaRunRenderer(fn) { _mediaRunRenderer = fn; }

/** How many past test runs stay in the log. */
const MAX_TEST_RUNS = 5;

/** How many past generated covers stay in the log. */
const MAX_MEDIA_RUNS = 5;

/**
 * Record a generated cover so it survives a reload. Same contract as
 * recordTestRun: matched by `report.runId`, re-recording updates in place.
 */
export function recordMediaRun(report) {
  const at = report?.runId
    ? conversation.findIndex((m) => m.role === 'media-run' && m.report?.runId === report.runId)
    : -1;
  if (at !== -1) {
    conversation[at] = { role: 'media-run', report };
  } else {
    conversation.push({ role: 'media-run', report });
    const runs = conversation.filter((m) => m.role === 'media-run');
    for (const stale of runs.slice(0, Math.max(0, runs.length - MAX_MEDIA_RUNS))) {
      conversation.splice(conversation.indexOf(stale), 1);
    }
  }
  persistConversation();
  updateClearVisibility();
}

/**
 * True when this draft has a passing test run. Two sources, either is enough:
 * the step cache (per-agent, survives clearing the chat, and self-invalidates
 * when a step changes) and the chat log (survives a publish, which drops that
 * cache). Neither alone covers both cases.
 */
export function hasPassingTestRun() {
  if (tester.passed()) return true;
  return conversation.some((m) => m.role === 'test-run' && m.report?.ok === true);
}

/**
 * Record a test run so it survives a reload. Matched by `report.runId`: the same
 * run re-recorded (publish, autofix) updates in place, a new one appends and the
 * oldest drops once there are more than MAX_TEST_RUNS.
 */
export function recordTestRun(report) {
  const at = report?.runId
    ? conversation.findIndex((m) => m.role === 'test-run' && m.report?.runId === report.runId)
    : -1;
  if (at !== -1) {
    conversation[at] = { role: 'test-run', report };
  } else {
    conversation.push({ role: 'test-run', report });
    const runs = conversation.filter((m) => m.role === 'test-run');
    for (const stale of runs.slice(0, Math.max(0, runs.length - MAX_TEST_RUNS))) {
      conversation.splice(conversation.indexOf(stale), 1);
    }
  }
  persistConversation();
  updateClearVisibility();
}

/** Re-render the whole log from the conversation array (used on restore). */
function rerenderLog() {
  const log = $('#ab-studio-log');
  if (!log) return;
  log.innerHTML = '';
  for (const m of conversation) {
    if (m.role === 'test-run') {
      _testRunRenderer?.(m.report);
      continue;
    }
    if (m.role === 'media-run') {
      _mediaRunRenderer?.(m.report);
      continue;
    }
    appendMessage(m.role, m.content);
  }
  refreshDocCardLabels();
}

/**
 * Label each doc card against the live Customizer doc: identical reads "Open In
 * Setup", different reads "Apply In Setup". The live doc is the source of truth
 * because the old DOM-only `applied` mark was lost on every re-render.
 */
function refreshDocCardLabels() {
  hydrateDocCredits();
  const live = _appliedDocFingerprint;
  for (const btn of document.querySelectorAll('.ab-doc-block .ab-doc-open')) {
    const pre = btn.closest('.ab-doc-block').querySelector('pre code');
    let doc;
    try { doc = JSON.parse(pre?.textContent.trim() || ''); } catch { doc = null; }
    const same = !!doc && live != null && docIdentityFingerprint(doc) === live;
    btn.classList.toggle('is-apply', !same);
    const label = btn.querySelector('.ab-doc-open-label');
    if (label) label.textContent = same ? 'Open In Setup' : 'Apply In Setup';
    btn.title = same
      ? 'This schema is already active in Setup.'
      : 'Apply this schema to Setup, replacing the current unpublished doc.';
  }
}

/** Show the Clear button only when there's a conversation to clear. */
function updateClearVisibility() {
  const btn = $('#ab-studio-clear');
  if (btn) btn.hidden = conversation.length === 0;
  if (typewriter) {
    if (conversation.length) typewriter.disable(STUDIO_REFINE_PLACEHOLDER);
    else typewriter.enable();
  }
  updateEmptyState();
}

function updateEmptyState() {
  const empty = $('#ab-studio-empty');
  if (!empty) return;
  const log = $('#ab-studio-log');
  empty.hidden = conversation.length > 0 || !!(log && log.children.length > 0);
  // Every log mutation funnels through here — re-measure so the pill can't
  // outlive the content it points at (e.g. Clear Chat under a scrolled-up view).
  updateJumpPill();
}

/**
 * Reset the Studio chat for the active draft: wipe the in-memory conversation,
 * drop its localStorage entry, and clear the log. The loaded agent doc in the
 * Customizer is left untouched — this only forgets the chat history so the next
 * message starts a fresh thread (the current doc is still sent as currentDoc).
 */
function clearChat() {
  conversation = [];
  pendingAttachments = [];
  renderAttachments();
  persistConversation(); // empty → removes the stored entry
  const log = $('#ab-studio-log');
  if (log) log.innerHTML = '';
  updateClearVisibility();
}

/**
 * A Studio-generated agent arrives with a real `id` while the draft is still
 * filed under its synthetic `_new-*` slot. Nothing else re-points the draft
 * mid-session (the wizard only does this at boot), so the preview/publish
 * routes look up the real id and find nothing. Here we complete the rename the
 * moment an agent loads with an id:
 *   - carry the draft, preview-outputs and studio-chat entries onto the real id,
 *   - delete the old `_new-*` entries,
 *   - point the active draft id at the real id and update the URL.
 * After this the wizard's own persist() writes to the real-id key, and a manual
 * Preview finds the draft where it expects it.
 */
async function migrateDraftToRealId(newId) {
  if (!newId) return;
  const oldId = activeDraftId();
  if (!oldId || oldId === newId) {
    boundDraftId = newId;
    return;
  }

  // Don't clobber an existing draft under the real id (e.g. the author is
  // re-generating into an id they already have a slot for) — but we still
  // re-point so edits land on it. The wizard's persist() will overwrite with
  // the freshly imported doc on the next notify().
  await migrateDraftId(oldId, newId);
  pendingEventRekeyFrom = oldId;
  boundDraftId = newId;
  try { history.replaceState(null, '', `/agent-builder/edit/${encodeURIComponent(newId)}`); } catch {}
}

/** Switch the visible top-level tab. Exported so the Versions tab can call it. */
export function showTab(tab) {
  for (const name of ['studio', 'customizer', 'versions']) {
    const pane = $(`#ab-tab-${name}`);
    const btn = $(`#ab-tab-btn-${name}`);
    const active = name === tab;
    if (pane) pane.classList.toggle('active', active);
    if (btn) btn.classList.toggle('active', active);
  }
  // The Studio chat runs in a viewport-locked shell (only its log scrolls); the
  // other tabs are ordinary scrolling pages. All the CSS for that hangs off this
  // one class, and every tab switch - including boot - comes through here.
  document.body.classList.toggle('ab-shell-studio', tab === 'studio');
  // The Customizer doc may have moved on since the log was rendered.
  if (tab === 'studio') refreshDocCardLabels();
}

/**
 * Minimal markdown → HTML for chat bubbles: fenced code blocks, inline code,
 * bold, and line breaks. Everything is escaped first so model output can't
 * inject markup.
 */
function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

/**
 * `streaming: true` renders the cheap variant used while tokens are still
 * arriving: no JSON.parse/schema detection per chunk, and an unterminated fence
 * renders as a plain <pre> instead of falling through to the inline regexes.
 * Without it a long ```json doc costs a full re-parse of the whole buffer on
 * every token. The full renderer runs once on `done`.
 */
function renderMarkdown(text, streaming = false) {
  const parts = [];
  // The info string may carry an argument (```agent-media video), so match the
  // whole line and let isControlFence read the first token off it.
  const fence = /```([^\n]*)\n([\s\S]*?)```/g;
  let last = 0;
  let m;
  while ((m = fence.exec(text)) !== null) {
    if (m.index > last) parts.push(inline(text.slice(last, m.index)));
    parts.push(codeBlock(m[2], (m[1] || '').toLowerCase()));
    last = fence.lastIndex;
  }
  if (last < text.length) {
    const rest = text.slice(last);
    // A fence that has opened but not closed yet — only possible mid-stream.
    const open = streaming ? rest.match(/```([^\n]*)\n([\s\S]*)$/) : null;
    if (open) {
      if (open.index > 0) parts.push(inline(rest.slice(0, open.index)));
      // Same hiding rule as a closed fence, so a control block never flashes
      // into view while it streams.
      if (!isControlFence(open[1])) {
        parts.push(`<pre><code>${escapeHtml(open[2])}</code></pre>`);
      }
    } else {
      parts.push(inline(rest));
    }
  }
  return parts.join('');

  // A fenced block. When its body parses as a builder agent doc, render it as
  // an artifact card (filename + Completed + "Open In Customizer" + view /
  // download actions) with the raw JSON kept in a hidden <pre> the delegated
  // handlers read back. Any other fence stays a plain pre.
  function codeBlock(body, lang) {
    // A control block is an instruction to the builder, not content — the
    // reply's own prose already tells the author what is about to happen.
    if (isControlFence(lang)) return '';
    const pre = `<pre><code>${escapeHtml(body)}</code></pre>`;
    // Mid-stream the parse would rerun on every token for no benefit — the
    // card only needs to exist once the reply is final.
    if (streaming) return pre;
    let doc = null;
    try { const parsed = JSON.parse(body.trim()); if (looksLikeAgentDoc(parsed)) doc = parsed; } catch { /* not JSON */ }
    if (!doc) return pre;
    const fname = ((String(doc.name || doc.id || 'agent').trim().replace(/\s+/g, '_').replace(/[^\w-]/g, '')) || 'agent') + '.json';
    return `<div class="ab-schema-block ab-doc-block" data-filename="${escapeHtml(fname)}">` +
      `<pre hidden><code>${escapeHtml(body)}</code></pre>` +
      `<div class="ab-doc-card">` +
        `<div class="ab-doc-card-head">` +
          `<span class="ab-doc-icon">${DOC_FILE_SVG}</span>` +
          `<span class="ab-doc-name">${escapeHtml(String(doc.name || doc.id || 'agent'))}</span>` +
          `<span class="ab-doc-status">Completed</span>` +
        `</div>` +
        `<div class="ab-doc-cta">` +
          `<button type="button" class="ab-doc-test">Next: Test Run<span class="ab-doc-credits" hidden></span><span class="ab-doc-arrow" aria-hidden="true">›</span></button>` +
        `</div>` +
      `</div>` +
      `<div class="ab-doc-actions">` +
        `<button type="button" class="ab-doc-expand" title="View JSON" aria-label="View JSON">${EXPAND_SVG}</button>` +
        `<button type="button" class="ab-doc-download" title="Download JSON" aria-label="Download JSON">${DOWNLOAD_SVG}</button>` +
      `</div>` +
    `</div>`;
  }

  function inline(chunk) {
    return escapeHtml(chunk)
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/\n/g, '<br>');
  }
}

/** Animated logo shown while work is in flight. Reused by the test-run card. */
export const THINKING_SVG = '<svg fill="none" height="100%" width="100%" aria-hidden="true" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><g id="i0"><g opacity="0"><animate repeatCount="indefinite" attributeName="opacity" dur="1.583s" begin="0s" fill="freeze" values="0; 0.146; 0.279; 0.401; 0.51; 0.609; 0.697; 0.774; 0.842; 0.9; 0.949; 0.99; 1.023; 1.049; 1.069; 1.083; 1.091; 1.094; 1.094; 1.09; 1.084; 1.075; 1.065; 1.054; 1.043; 1.032; 1.022; 1.013; 1.006; 1.002; 1; 1" keyTimes="0; 0.004094; 0.008187; 0.012281; 0.016374; 0.020468; 0.024561; 0.028655; 0.032749; 0.036842; 0.040936; 0.045029; 0.049123; 0.053216; 0.05731; 0.061404; 0.065497; 0.069591; 0.073684; 0.077778; 0.081871; 0.085965; 0.090058; 0.094152; 0.098246; 0.102339; 0.106433; 0.110526; 0.11462; 0.118713; 0.122807; 1" calcMode="linear" /><g transform="translate(12,12)"><animateTransform repeatCount="indefinite" type="translate" attributeName="transform" dur="1.583s" begin="0s" calcMode="spline" values="12 12; 7.8 7.8; 4.533 4.533; 2.119 2.119; 0.46 0.46; -0.553 -0.553; -1.04 -1.04; -1.129 -1.129; -0.95 -0.95; -0.63 -0.63; -0.294 -0.294; -0.054 -0.054; 0 0; 0 0" keyTimes="0; 0.010526; 0.021053; 0.031579; 0.042105; 0.052631; 0.063158; 0.073684; 0.08421; 0.094737; 0.105263; 0.115789; 0.122807; 1" keySplines="0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1" fill="freeze" /><g transform="scale(0,0)"><animateTransform repeatCount="indefinite" type="scale" attributeName="transform" dur="1.583s" begin="0s" calcMode="spline" values="0 0; 0.35 0.35; 0.622 0.622; 0.823 0.823; 0.962 0.962; 1.046 1.046; 1.087 1.087; 1.094 1.094; 1.079 1.079; 1.053 1.053; 1.024 1.024; 1.005 1.005; 1 1; 1 1" keyTimes="0; 0.010526; 0.021053; 0.031579; 0.042105; 0.052631; 0.063158; 0.073684; 0.08421; 0.094737; 0.105263; 0.115789; 0.122807; 1" keySplines="0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1" fill="freeze" /><path fill="currentColor" d="M8.29,12.76C8.24,12.85,8.17,12.79,8.1,12.58C7.75,11.21,7.77,9.65,8.11,8.26C8.51,6.8,9.15,5.35,10.29,4.41C11.76,3.13,13.65,3.71,14.37,5.48C14.58,5.86,14.84,7.23,14.39,6.54C14.23,6.3,14.04,5.87,13.78,5.6C12.56,4.36,11.05,5.98,10.36,7.03C9.47,8.37,8.79,10.01,8.51,11.63C8.44,11.97,8.41,12.45,8.3,12.75C8.3,12.75,8.29,12.76,8.29,12.76C8.29,12.76,8.29,12.76,8.29,12.76Z" /></g></g></g><g opacity="0"><animate repeatCount="indefinite" attributeName="opacity" dur="1.583s" begin="0s" fill="freeze" values="0; 0; 0.146; 0.279; 0.401; 0.51; 0.609; 0.697; 0.774; 0.842; 0.9; 0.949; 0.99; 1.023; 1.049; 1.069; 1.083; 1.091; 1.094; 1.094; 1.09; 1.084; 1.075; 1.065; 1.054; 1.043; 1.032; 1.022; 1.013; 1.006; 1.002; 1; 1" keyTimes="0; 0.024561; 0.03193; 0.039298; 0.046667; 0.054035; 0.061404; 0.068772; 0.07614; 0.083509; 0.090877; 0.098246; 0.105614; 0.112982; 0.120351; 0.127719; 0.135088; 0.142456; 0.149825; 0.157193; 0.164561; 0.17193; 0.179298; 0.186667; 0.194035; 0.201404; 0.208772; 0.21614; 0.223509; 0.230877; 0.238246; 0.245614; 1" calcMode="linear" /><g transform="translate(12,12)"><animateTransform repeatCount="indefinite" type="translate" attributeName="transform" dur="1.583s" begin="0s" calcMode="spline" values="12 12; 12 12; 9.547 9.547; 7.392 7.392; 5.523 5.523; 3.926 3.926; 2.586 2.586; 1.487 1.487; 0.61 0.61; -0.063 -0.063; -0.553 -0.553; -0.88 -0.88; -1.067 -1.067; -1.136 -1.136; -1.108 -1.108; -1.006 -1.006; -0.853 -0.853; -0.669 -0.669; -0.476 -0.476; -0.294 -0.294; -0.142 -0.142; -0.038 -0.038; 0 0; 0 0" keyTimes="0; 0.024561; 0.035088; 0.045614; 0.05614; 0.066667; 0.077193; 0.087719; 0.098246; 0.108772; 0.119298; 0.129825; 0.140351; 0.150877; 0.161404; 0.17193; 0.182456; 0.192983; 0.203509; 0.214035; 0.224561; 0.235088; 0.245614; 1" keySplines="0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1" fill="freeze" /><g transform="scale(0,0)"><animateTransform repeatCount="indefinite" type="scale" attributeName="transform" dur="1.583s" begin="0s" calcMode="spline" values="0 0; 0 0; 0.204 0.204; 0.384 0.384; 0.54 0.54; 0.673 0.673; 0.784 0.784; 0.876 0.876; 0.949 0.949; 1.005 1.005; 1.046 1.046; 1.073 1.073; 1.089 1.089; 1.095 1.095; 1.092 1.092; 1.084 1.084; 1.071 1.071; 1.056 1.056; 1.04 1.04; 1.024 1.024; 1.012 1.012; 1.003 1.003; 1 1; 1 1" keyTimes="0; 0.024561; 0.035088; 0.045614; 0.05614; 0.066667; 0.077193; 0.087719; 0.098246; 0.108772; 0.119298; 0.129825; 0.140351; 0.150877; 0.161404; 0.17193; 0.182456; 0.192983; 0.203509; 0.214035; 0.224561; 0.235088; 0.245614; 1" keySplines="0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1" fill="freeze" /><path fill="currentColor" d="M10.19,8.7C10.08,8.68,10.12,8.6,10.3,8.47C11.49,7.71,12.98,7.24,14.41,7.13C15.92,7.06,17.5,7.22,18.75,8.02C20.42,9.02,20.46,11.01,19,12.23C18.71,12.54,17.48,13.22,18,12.58C18.18,12.36,18.52,12.03,18.69,11.7C19.5,10.16,17.5,9.22,16.28,8.89C14.73,8.45,12.96,8.32,11.33,8.55C10.98,8.59,10.53,8.72,10.21,8.7C10.21,8.7,10.19,8.7,10.19,8.7C10.19,8.7,10.19,8.7,10.19,8.7C10.19,8.7,10.19,8.7,10.19,8.7Z" /></g></g></g><g opacity="0"><animate repeatCount="indefinite" attributeName="opacity" dur="1.583s" begin="0s" fill="freeze" values="0; 0; 0.146; 0.279; 0.401; 0.51; 0.609; 0.697; 0.774; 0.842; 0.9; 0.949; 0.99; 1.023; 1.049; 1.069; 1.083; 1.091; 1.094; 1.094; 1.09; 1.084; 1.075; 1.065; 1.054; 1.043; 1.032; 1.022; 1.013; 1.006; 1.002; 1; 1" keyTimes="0; 0.049123; 0.059766; 0.070409; 0.081053; 0.091696; 0.102339; 0.112982; 0.123626; 0.134269; 0.144912; 0.155555; 0.166199; 0.176842; 0.187485; 0.198129; 0.208772; 0.219415; 0.230059; 0.240702; 0.251345; 0.261988; 0.272632; 0.283275; 0.293918; 0.304561; 0.315205; 0.325848; 0.336491; 0.347134; 0.357778; 0.368421; 1" calcMode="linear" /><g transform="translate(12,12)"><animateTransform repeatCount="indefinite" type="translate" attributeName="transform" dur="1.583s" begin="0s" calcMode="spline" values="12 12; 12 12; 10.27 10.27; 8.684 8.684; 7.239 7.239; 5.93 5.93; 4.753 4.753; 3.704 3.704; 2.776 2.776; 1.965 1.965; 1.265 1.265; 0.67 0.67; 0.173 0.173; -0.232 -0.232; -0.553 -0.553; -0.796 -0.796; -0.968 -0.968; -1.077 -1.077; -1.129 -1.129; -1.134 -1.134; -1.097 -1.097; -1.026 -1.026; -0.929 -0.929; -0.812 -0.812; -0.684 -0.684; -0.55 -0.55; -0.418 -0.418; -0.294 -0.294; -0.184 -0.184; -0.095 -0.095; -0.033 -0.033; -0.002 -0.002; 0 0; 0 0" keyTimes="0; 0.049123; 0.059649; 0.070176; 0.080702; 0.091228; 0.101755; 0.112281; 0.122807; 0.133333; 0.14386; 0.154386; 0.164912; 0.175439; 0.185965; 0.196491; 0.207018; 0.217544; 0.228071; 0.238597; 0.249123; 0.25965; 0.270176; 0.280702; 0.291229; 0.301755; 0.312281; 0.322807; 0.333334; 0.34386; 0.354386; 0.364913; 0.368421; 1" keySplines="0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1" fill="freeze" /><g transform="scale(0,0)"><animateTransform repeatCount="indefinite" type="scale" attributeName="transform" dur="1.583s" begin="0s" calcMode="spline" values="0 0; 0 0; 0.144 0.144; 0.276 0.276; 0.397 0.397; 0.506 0.506; 0.604 0.604; 0.691 0.691; 0.769 0.769; 0.836 0.836; 0.895 0.895; 0.944 0.944; 0.986 0.986; 1.019 1.019; 1.046 1.046; 1.066 1.066; 1.081 1.081; 1.09 1.09; 1.094 1.094; 1.094 1.094; 1.091 1.091; 1.085 1.085; 1.077 1.077; 1.068 1.068; 1.057 1.057; 1.046 1.046; 1.035 1.035; 1.024 1.024; 1.015 1.015; 1.008 1.008; 1.003 1.003; 1 1; 1 1; 1 1" keyTimes="0; 0.049123; 0.059649; 0.070176; 0.080702; 0.091228; 0.101755; 0.112281; 0.122807; 0.133333; 0.14386; 0.154386; 0.164912; 0.175439; 0.185965; 0.196491; 0.207018; 0.217544; 0.228071; 0.238597; 0.249123; 0.25965; 0.270176; 0.280702; 0.291229; 0.301755; 0.312281; 0.322807; 0.333334; 0.34386; 0.354386; 0.364913; 0.368421; 1" keySplines="0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1" fill="freeze" /><path fill="currentColor" d="M14.64,9.25C14.63,9.14,14.72,9.15,14.9,9.28C15.99,10.18,16.88,11.45,17.43,12.78C17.97,14.19,18.3,15.75,17.93,17.18C17.5,19.08,15.62,19.73,14,18.72C13.61,18.54,12.59,17.58,13.36,17.87C13.63,17.97,14.04,18.2,14.41,18.26C16.13,18.55,16.4,16.36,16.34,15.1C16.27,13.49,15.86,11.77,15.13,10.29C14.98,9.97,14.72,9.58,14.64,9.27C14.64,9.27,14.64,9.25,14.64,9.25C14.64,9.25,14.64,9.25,14.64,9.25C14.64,9.25,14.64,9.25,14.64,9.25Z" /></g></g></g><g opacity="0"><animate repeatCount="indefinite" attributeName="opacity" dur="1.583s" begin="0s" fill="freeze" values="0; 0; 0.146; 0.279; 0.401; 0.51; 0.609; 0.697; 0.774; 0.842; 0.9; 0.949; 0.99; 1.023; 1.049; 1.069; 1.083; 1.091; 1.094; 1.094; 1.09; 1.084; 1.075; 1.065; 1.054; 1.043; 1.032; 1.022; 1.013; 1.006; 1.002; 1; 1" keyTimes="0; 0.073684; 0.087602; 0.101521; 0.115439; 0.129357; 0.143275; 0.157193; 0.171111; 0.185029; 0.198947; 0.212865; 0.226784; 0.240702; 0.25462; 0.268538; 0.282456; 0.296374; 0.310293; 0.324211; 0.338129; 0.352047; 0.365965; 0.379883; 0.393801; 0.407719; 0.421637; 0.435556; 0.449474; 0.463392; 0.47731; 0.491228; 1" calcMode="linear" /><g transform="translate(12,12)"><animateTransform repeatCount="indefinite" type="translate" attributeName="transform" dur="1.583s" begin="0s" calcMode="spline" values="12 12; 12 12; 10.664 10.664; 9.412 9.412; 8.244 8.244; 7.158 7.158; 6.151 6.151; 5.222 5.222; 4.368 4.368; 3.588 3.588; 2.879 2.879; 2.239 2.239; 1.664 1.664; 1.153 1.153; 0.702 0.702; 0.309 0.309; -0.029 -0.029; -0.315 -0.315; -0.553 -0.553; -0.745 -0.745; -0.895 -0.895; -1.006 -1.006; -1.081 -1.081; -1.124 -1.124; -1.137 -1.137; -1.125 -1.125; -1.09 -1.09; -1.036 -1.036; -0.966 -0.966; -0.883 -0.883; -0.79 -0.79; -0.691 -0.691; -0.589 -0.589; -0.487 -0.487; -0.388 -0.388; -0.294 -0.294; -0.208 -0.208; -0.134 -0.134; -0.074 -0.074; -0.03 -0.03; -0.005 -0.005; 0 0; 0 0" keyTimes="0; 0.073684; 0.084211; 0.094737; 0.105263; 0.11579; 0.126316; 0.136843; 0.147369; 0.157895; 0.168421; 0.178948; 0.189474; 0.2; 0.210526; 0.221053; 0.231579; 0.242105; 0.252632; 0.263158; 0.273685; 0.284211; 0.294737; 0.305263; 0.31579; 0.326316; 0.336842; 0.347369; 0.357895; 0.368421; 0.378947; 0.389474; 0.4; 0.410527; 0.421053; 0.431579; 0.442105; 0.452632; 0.463158; 0.473684; 0.484211; 0.491228; 1" keySplines="0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1" fill="freeze" /><g transform="scale(0,0)"><animateTransform repeatCount="indefinite" type="scale" attributeName="transform" dur="1.583s" begin="0s" calcMode="spline" values="0 0; 0 0; 0.111 0.111; 0.216 0.216; 0.313 0.313; 0.404 0.404; 0.487 0.487; 0.565 0.565; 0.636 0.636; 0.701 0.701; 0.76 0.76; 0.813 0.813; 0.861 0.861; 0.904 0.904; 0.941 0.941; 0.974 0.974; 1.002 1.002; 1.026 1.026; 1.046 1.046; 1.062 1.062; 1.075 1.075; 1.084 1.084; 1.09 1.09; 1.094 1.094; 1.095 1.095; 1.094 1.094; 1.091 1.091; 1.086 1.086; 1.08 1.08; 1.074 1.074; 1.066 1.066; 1.058 1.058; 1.049 1.049; 1.041 1.041; 1.032 1.032; 1.024 1.024; 1.017 1.017; 1.011 1.011; 1.006 1.006; 1.002 1.002; 1 1; 1 1; 1 1" keyTimes="0; 0.073684; 0.084211; 0.094737; 0.105263; 0.11579; 0.126316; 0.136843; 0.147369; 0.157895; 0.168421; 0.178948; 0.189474; 0.2; 0.210526; 0.221053; 0.231579; 0.242105; 0.252632; 0.263158; 0.273685; 0.284211; 0.294737; 0.305263; 0.31579; 0.326316; 0.336842; 0.347369; 0.357895; 0.368421; 0.378947; 0.389474; 0.4; 0.410527; 0.421053; 0.431579; 0.442105; 0.452632; 0.463158; 0.473684; 0.484211; 0.491228; 1" keySplines="0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1" fill="freeze" /><path fill="currentColor" d="M15.49,13.65C15.59,13.6,15.6,13.7,15.54,13.91C15.02,15.23,14.08,16.47,12.99,17.4C11.81,18.35,10.45,19.15,8.97,19.24C7.03,19.42,5.83,17.82,6.29,15.97C6.34,15.54,6.94,14.28,6.9,15.1C6.89,15.39,6.8,15.85,6.85,16.22C7.1,17.94,9.28,17.53,10.45,17.08C11.96,16.52,13.47,15.59,14.65,14.44C14.91,14.2,15.2,13.83,15.47,13.66C15.47,13.66,15.49,13.65,15.49,13.65C15.49,13.65,15.49,13.65,15.49,13.65C15.49,13.65,15.49,13.65,15.49,13.65Z" /></g></g></g><g opacity="0"><animate repeatCount="indefinite" attributeName="opacity" dur="1.583s" begin="0s" fill="freeze" values="0; 0; 0.146; 0.279; 0.401; 0.51; 0.609; 0.697; 0.774; 0.842; 0.9; 0.949; 0.99; 1.023; 1.049; 1.069; 1.083; 1.091; 1.094; 1.094; 1.09; 1.084; 1.075; 1.065; 1.054; 1.043; 1.032; 1.022; 1.013; 1.006; 1.002; 1; 1" keyTimes="0; 0.098246; 0.115438; 0.132632; 0.149825; 0.167017; 0.184211; 0.201404; 0.218596; 0.23579; 0.252982; 0.270175; 0.287369; 0.304561; 0.321754; 0.338948; 0.35614; 0.373333; 0.390526; 0.407719; 0.424912; 0.442105; 0.459298; 0.476491; 0.493684; 0.510877; 0.52807; 0.545263; 0.562456; 0.579649; 0.596842; 0.614035; 1" calcMode="linear" /><g transform="translate(12,12)"><animateTransform repeatCount="indefinite" type="translate" attributeName="transform" dur="1.583s" begin="0s" calcMode="spline" values="12 12; 12 12; 10.912 10.912; 9.879 9.879; 8.902 8.902; 7.978 7.978; 7.108 7.108; 6.29 6.29; 5.523 5.523; 4.806 4.806; 4.138 4.138; 3.518 3.518; 2.944 2.944; 2.415 2.415; 1.93 1.93; 1.487 1.487; 1.085 1.085; 0.723 0.723; 0.398 0.398; 0.11 0.11; -0.144 -0.144; -0.364 -0.364; -0.553 -0.553; -0.712 -0.712; -0.843 -0.843; -0.947 -0.947; -1.027 -1.027; -1.084 -1.084; -1.12 -1.12; -1.136 -1.136; -1.134 -1.134; -1.117 -1.117; -1.085 -1.085; -1.042 -1.042; -0.987 -0.987; -0.924 -0.924; -0.853 -0.853; -0.776 -0.776; -0.696 -0.696; -0.614 -0.614; -0.531 -0.531; -0.449 -0.449; -0.369 -0.369; -0.294 -0.294; -0.224 -0.224; -0.161 -0.161; -0.106 -0.106; -0.062 -0.062; -0.028 -0.028; -0.007 -0.007; 0 0; 0 0" keyTimes="0; 0.098246; 0.108772; 0.119298; 0.129825; 0.140351; 0.150878; 0.161404; 0.17193; 0.182456; 0.192983; 0.203509; 0.214036; 0.224562; 0.235088; 0.245614; 0.25614; 0.266667; 0.277193; 0.28772; 0.298246; 0.308772; 0.319298; 0.329825; 0.340351; 0.350878; 0.361404; 0.37193; 0.382456; 0.392983; 0.403509; 0.414036; 0.424562; 0.435088; 0.445614; 0.456141; 0.466667; 0.477193; 0.48772; 0.498246; 0.508772; 0.519299; 0.529825; 0.540351; 0.550878; 0.561404; 0.57193; 0.582457; 0.592983; 0.603509; 0.614036; 1" keySplines="0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1" fill="freeze" /><g transform="scale(0,0)"><animateTransform repeatCount="indefinite" type="scale" attributeName="transform" dur="1.583s" begin="0s" calcMode="spline" values="0 0; 0 0; 0.091 0.091; 0.177 0.177; 0.258 0.258; 0.335 0.335; 0.408 0.408; 0.476 0.476; 0.54 0.54; 0.599 0.599; 0.655 0.655; 0.707 0.707; 0.755 0.755; 0.799 0.799; 0.839 0.839; 0.876 0.876; 0.91 0.91; 0.94 0.94; 0.967 0.967; 0.991 0.991; 1.012 1.012; 1.03 1.03; 1.046 1.046; 1.059 1.059; 1.07 1.07; 1.079 1.079; 1.086 1.086; 1.09 1.09; 1.093 1.093; 1.095 1.095; 1.095 1.095; 1.093 1.093; 1.09 1.09; 1.087 1.087; 1.082 1.082; 1.077 1.077; 1.071 1.071; 1.065 1.065; 1.058 1.058; 1.051 1.051; 1.044 1.044; 1.037 1.037; 1.031 1.031; 1.024 1.024; 1.019 1.019; 1.013 1.013; 1.009 1.009; 1.005 1.005; 1.002 1.002; 1.001 1.001; 1 1; 1 1" keyTimes="0; 0.098246; 0.108772; 0.119298; 0.129825; 0.140351; 0.150878; 0.161404; 0.17193; 0.182456; 0.192983; 0.203509; 0.214036; 0.224562; 0.235088; 0.245614; 0.25614; 0.266667; 0.277193; 0.28772; 0.298246; 0.308772; 0.319298; 0.329825; 0.340351; 0.350878; 0.361404; 0.37193; 0.382456; 0.392983; 0.403509; 0.414036; 0.424562; 0.435088; 0.445614; 0.456141; 0.466667; 0.477193; 0.48772; 0.498246; 0.508772; 0.519299; 0.529825; 0.540351; 0.550878; 0.561404; 0.57193; 0.582457; 0.592983; 0.603509; 0.614036; 1" keySplines="0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1" fill="freeze" /><path fill="currentColor" d="M11.57,15.82C11.64,15.9,11.56,15.95,11.34,15.95C9.93,15.86,8.45,15.36,7.23,14.61C5.97,13.78,4.78,12.73,4.24,11.35C3.47,9.56,4.62,7.93,6.52,7.79C6.94,7.71,8.34,7.89,7.54,8.1C7.26,8.18,6.8,8.22,6.46,8.39C4.9,9.16,5.96,11.1,6.75,12.08C7.75,13.35,9.11,14.5,10.56,15.27C10.86,15.44,11.31,15.61,11.56,15.81C11.56,15.81,11.57,15.82,11.57,15.82C11.57,15.82,11.57,15.82,11.57,15.82C11.57,15.82,11.57,15.82,11.57,15.82Z" /></g></g></g><g opacity="0"><animate repeatCount="indefinite" attributeName="opacity" dur="1.583s" begin="0s" fill="freeze" values="0; 0; 0.146; 0.279; 0.401; 0.51; 0.609; 0.697; 0.774; 0.842; 0.9; 0.949; 0.99; 1.023; 1.049; 1.069; 1.083; 1.091; 1.094; 1.094; 1.09; 1.084; 1.075; 1.065; 1.054; 1.043; 1.032; 1.022; 1.013; 1.006; 1.002; 1; 1" keyTimes="0; 0.122807; 0.143275; 0.163743; 0.184211; 0.204678; 0.225146; 0.245614; 0.266082; 0.28655; 0.307018; 0.327485; 0.347953; 0.368421; 0.388889; 0.409357; 0.429825; 0.450292; 0.47076; 0.491228; 0.511696; 0.532164; 0.552632; 0.573099; 0.593567; 0.614035; 0.634503; 0.654971; 0.675439; 0.695906; 0.716374; 0.736842; 1" calcMode="linear" /><g transform="translate(12,12)"><animateTransform repeatCount="indefinite" type="translate" attributeName="transform" dur="1.583s" begin="0s" calcMode="spline" values="12 12; 12 12; 11.082 11.082; 10.204 10.204; 9.364 9.364; 8.563 8.563; 7.8 7.8; 7.074 7.074; 6.386 6.386; 5.733 5.733; 5.116 5.116; 4.533 4.533; 3.985 3.985; 3.47 3.47; 2.988 2.988; 2.538 2.538; 2.119 2.119; 1.73 1.73; 1.37 1.37; 1.039 1.039; 0.736 0.736; 0.46 0.46; 0.209 0.209; -0.016 -0.016; -0.218 -0.218; -0.396 -0.396; -0.553 -0.553; -0.688 -0.688; -0.804 -0.804; -0.9 -0.9; -0.979 -0.979; -1.04 -1.04; -1.086 -1.086; -1.116 -1.116; -1.133 -1.133; -1.137 -1.137; -1.129 -1.129; -1.111 -1.111; -1.082 -1.082; -1.046 -1.046; -1.001 -1.001; -0.95 -0.95; -0.893 -0.893; -0.832 -0.832; -0.767 -0.767; -0.7 -0.7; -0.63 -0.63; -0.561 -0.561; -0.491 -0.491; -0.423 -0.423; -0.357 -0.357; -0.294 -0.294; -0.235 -0.235; -0.18 -0.18; -0.131 -0.131; -0.089 -0.089; -0.054 -0.054; -0.027 -0.027; -0.009 -0.009; -0.001 -0.001; 0 0; 0 0" keyTimes="0; 0.122807; 0.133333; 0.14386; 0.154386; 0.164912; 0.175438; 0.185965; 0.196491; 0.207017; 0.217544; 0.22807; 0.238596; 0.249122; 0.259649; 0.270175; 0.280702; 0.291228; 0.301754; 0.31228; 0.322807; 0.333333; 0.343859; 0.354386; 0.364912; 0.375439; 0.385964; 0.396491; 0.407017; 0.417544; 0.42807; 0.438596; 0.449123; 0.459649; 0.470175; 0.480701; 0.491228; 0.501754; 0.512281; 0.522807; 0.533333; 0.543859; 0.554385; 0.564912; 0.575438; 0.585965; 0.596491; 0.607017; 0.617543; 0.62807; 0.638596; 0.649122; 0.659649; 0.670175; 0.680701; 0.691227; 0.701754; 0.71228; 0.722807; 0.733333; 0.736842; 1" keySplines="0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1" fill="freeze" /><g transform="scale(0,0)"><animateTransform repeatCount="indefinite" type="scale" attributeName="transform" dur="1.583s" begin="0s" calcMode="spline" values="0 0; 0 0; 0.076 0.076; 0.15 0.15; 0.22 0.22; 0.286 0.286; 0.35 0.35; 0.41 0.41; 0.468 0.468; 0.522 0.522; 0.574 0.574; 0.622 0.622; 0.668 0.668; 0.711 0.711; 0.751 0.751; 0.789 0.789; 0.823 0.823; 0.856 0.856; 0.886 0.886; 0.913 0.913; 0.939 0.939; 0.962 0.962; 0.983 0.983; 1.001 1.001; 1.018 1.018; 1.033 1.033; 1.046 1.046; 1.057 1.057; 1.067 1.067; 1.075 1.075; 1.082 1.082; 1.087 1.087; 1.09 1.09; 1.093 1.093; 1.094 1.094; 1.095 1.095; 1.094 1.094; 1.093 1.093; 1.09 1.09; 1.087 1.087; 1.083 1.083; 1.079 1.079; 1.074 1.074; 1.069 1.069; 1.064 1.064; 1.058 1.058; 1.053 1.053; 1.047 1.047; 1.041 1.041; 1.035 1.035; 1.03 1.03; 1.024 1.024; 1.02 1.02; 1.015 1.015; 1.011 1.011; 1.007 1.007; 1.005 1.005; 1.002 1.002; 1.001 1.001; 1 1; 1 1; 1 1" keyTimes="0; 0.122807; 0.133333; 0.14386; 0.154386; 0.164912; 0.175438; 0.185965; 0.196491; 0.207017; 0.217544; 0.22807; 0.238596; 0.249122; 0.259649; 0.270175; 0.280702; 0.291228; 0.301754; 0.31228; 0.322807; 0.333333; 0.343859; 0.354386; 0.364912; 0.375439; 0.385964; 0.396491; 0.407017; 0.417544; 0.42807; 0.438596; 0.449123; 0.459649; 0.470175; 0.480701; 0.491228; 0.501754; 0.512281; 0.522807; 0.533333; 0.543859; 0.554385; 0.564912; 0.575438; 0.585965; 0.596491; 0.607017; 0.617543; 0.62807; 0.638596; 0.649122; 0.659649; 0.670175; 0.680701; 0.691227; 0.701754; 0.71228; 0.722807; 0.733333; 0.736842; 1" keySplines="0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1; 0 0 1 1" fill="freeze" /><path fill="currentColor" d="M11.02,10.86C11.53,10.42,12.04,10.34,12.67,10.58C12.92,10.68,13.13,10.89,13.3,11.1C13.53,11.39,13.64,11.81,13.61,12.17C13.57,12.59,13.39,12.89,13.11,13.17C12.45,13.82,11.44,13.76,10.84,13.04C10.26,12.36,10.35,11.43,11.02,10.86C11.02,10.86,11.02,10.86,11.02,10.86C11.02,10.86,11.02,10.86,11.02,10.86Z" /></g></g></g></g></svg>';
const DOC_FILE_SVG = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 7v10c0 3-1.5 5-5 5H8c-3.5 0-5-2-5-5V7c0-3 1.5-5 5-5h8c3.5 0 5 2 5 5z"/><path d="M14.5 4.5v2c0 1.1.9 2 2 2h2"/><path d="M10 13l-2 2 2 2M14 13l2 2-2 2"/></svg>';
const EXPAND_SVG = '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 14.67h4c3.33 0 4.67-1.34 4.67-4.67V6c0-3.33-1.34-4.67-4.67-4.67H6C2.67 1.33 1.33 2.67 1.33 6v4c0 3.33 1.34 4.67 4.67 4.67z"/><path d="M12 4L4 12M12 6.67V4H9.33M4 9.33V12h2.67M4 4l8 8M4 6.67V4h2.67M12 9.33V12H9.33"/></svg>';
const DOWNLOAD_SVG = '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 7.33v4l1.33-1.33M6 11.33L4.67 10"/><path d="M14.67 6.67V10c0 3.33-1.34 4.67-4.67 4.67H6c-3.33 0-4.67-1.34-4.67-4.67V6c0-3.33 1.34-4.67 4.67-4.67h3.33"/><path d="M14.67 6.67H12c-2 0-2.67-.67-2.67-2.67V1.33l5.34 5.34z"/></svg>';
export const BOLT_SVG = '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" aria-hidden="true"><path d="M13 2 4.5 13.5H11l-1 8.5 8.5-11.5H12l1-8.5z"/></svg>';

const docCreditsCache = new Map();
function hydrateDocCredits() {
  for (const block of document.querySelectorAll('.ab-doc-block')) {
    const badge = block.querySelector('.ab-doc-credits');
    const body = block.querySelector('pre code')?.textContent || '';
    if (!badge || !body || badge.dataset.done) continue;
    badge.dataset.done = '1';
    const show = (n) => { if (n > 0) { badge.innerHTML = `${BOLT_SVG}${n}`; badge.hidden = false; } };
    if (docCreditsCache.has(body)) { show(docCreditsCache.get(body)); continue; }
    let doc = null;
    try { doc = JSON.parse(body.trim()); } catch { continue; }
    fetchHelper('https://aitopia.ai/api/agent-builder/preview-meta', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ agent: doc }),
    })
      .then(r => r.ok ? r.json() : null)
      .then(json => {
        const n = Math.ceil(Number(json?.pricing?.floorCredits) || 0);
        docCreditsCache.set(body, n);
        show(n);
      })
      .catch(() => {});
  }
}

/**
 * Open the lightbox at full size. `kind` picks the element: an image, a video
 * with transport controls, or an audio player. Inferred from the extension when
 * not supplied, so existing image-only callers keep working unchanged.
 */
export function openLightbox(url, kind) {
  const box = $('#ab-studio-lightbox');
  if (!box || !url) return;
  const k = kind || (/\.(mp4|mov|webm|m4v)(\?|#|$)/i.test(url) ? 'video'
    : /\.(mp3|wav|m4a|ogg)(\?|#|$)/i.test(url) ? 'audio' : 'image');

  const img = $('#ab-studio-lightbox-img');
  const video = $('#ab-studio-lightbox-video');
  const audio = $('#ab-studio-lightbox-audio');
  for (const [node, mine] of [[img, k === 'image'], [video, k === 'video'], [audio, k === 'audio']]) {
    if (!node) continue;
    node.hidden = !mine;
    if (mine) node.src = url;
    else { node.removeAttribute('src'); if (node.pause) node.pause(); }
  }
  box.hidden = false;
}

function closeLightbox() {
  const box = $('#ab-studio-lightbox');
  if (box) box.hidden = true;
  for (const sel of ['#ab-studio-lightbox-img', '#ab-studio-lightbox-video', '#ab-studio-lightbox-audio']) {
    const node = $(sel);
    if (!node) continue;
    // Clearing src stops playback — a lightbox closed mid-video must go quiet.
    if (node.pause) node.pause();
    node.removeAttribute('src');
  }
}

/**
 * Stick-to-bottom: streaming output auto-scrolls only while the author is
 * already at the bottom of the log. Scrolling up to read pauses the follow;
 * scrolling back down (within the slack) resumes it. The flag flips only on
 * real scroll events — programmatic scrolls land exactly at the bottom, so
 * the listener re-reads them as "near bottom" and following continues.
 */
const FOLLOW_SLACK_PX = 80;
let followLog = true;
let lastLogScrollTop = 0;

function logDistanceFromBottom(log) {
  return log.scrollHeight - log.scrollTop - log.clientHeight;
}

function watchLogScroll() {
  const log = $('#ab-studio-log');
  if (!log) return;
  log.addEventListener('scroll', () => {
    const top = log.scrollTop;
    const goingUp = top < lastLogScrollTop;
    lastLogScrollTop = top;
    if (goingUp) {
      // Any upward movement is reader intent — break the follow at once. The
      // rule must be asymmetric: judging purely by distance-to-bottom made
      // escaping a live stream nearly impossible, because each frame's re-pin
      // reset the distance before the reader could scroll past the slack.
      // (Our own pins only ever move the view DOWN, so they never trip this.)
      followLog = false;
    } else if (logDistanceFromBottom(log) <= FOLLOW_SLACK_PX) {
      followLog = true;
    }
    updateJumpPill();
  }, { passive: true });
  // Wheel and touch scrolls run on the compositor: the view moves before the
  // scroll event reaches the main thread, and a same-frame pin can overwrite
  // the move so the handler above only ever sees "still at the bottom". Input
  // events can't be masked that way — an upward wheel tick or any touch drag
  // breaks the follow; the scroll handler re-engages it at the bottom.
  log.addEventListener('wheel', (e) => {
    if (e.deltaY < 0) { followLog = false; updateJumpPill(); }
  }, { passive: true });
  log.addEventListener('touchmove', () => {
    followLog = false;
    updateJumpPill();
  }, { passive: true });
}

/**
 * "Jump to latest" pill above the composer: visible whenever the reader has
 * scrolled up; `fresh` (label + accent) once new streamed text lands below
 * them in the meantime. Reaching the bottom again — by click or by hand —
 * hides it and resumes following.
 *
 * Both helpers measure the log live instead of trusting `followLog`: the flag
 * only moves on scroll events, so it goes stale when the content changes under
 * a still reader (Clear Chat, a retry wiping a long partial reply) — and a
 * pill over a log with nothing below the fold would be pointing at nothing.
 */
function updateJumpPill() {
  const pill = $('#ab-studio-jump');
  const log = $('#ab-studio-log');
  if (!pill || !log) return;
  if (logDistanceFromBottom(log) <= FOLLOW_SLACK_PX) {
    pill.hidden = true;
    pill.classList.remove('fresh');
  } else {
    pill.hidden = false;
  }
}

function markJumpFresh() {
  const pill = $('#ab-studio-jump');
  const log = $('#ab-studio-log');
  if (!pill || !log) return;
  if (logDistanceFromBottom(log) <= FOLLOW_SLACK_PX) return;
  pill.hidden = false;
  pill.classList.add('fresh');
}

/**
 * Append a chat bubble. `content` is a plain string (markdown) or an array of
 * content blocks (text + image) — the latter renders the text plus a thumbnail
 * for each image url. Returns the bubble node so callers can mutate it.
 */
export function appendMessage(role, content) {
  const log = $('#ab-studio-log');
  if (!log) return null;
  const wrap = document.createElement('div');
  wrap.className = `ab-msg ${role}`;
  const bubble = document.createElement('div');
  bubble.className = 'ab-msg-bubble';
  if (Array.isArray(content)) {
    const text = content.filter((b) => b?.type === 'text').map((b) => b.text).join('\n');
    if (text) bubble.innerHTML = renderMarkdown(text);
    for (const block of content) {
      if (block?.type === 'image' && block.source?.url) {
        const img = document.createElement('img');
        img.className = 'ab-studio-msg-img';
        img.src = block.source.url;
        img.alt = 'attached image';
        bubble.appendChild(img);
      }
    }
  } else {
    bubble.innerHTML = renderMarkdown(content);
  }
  wrap.appendChild(bubble);
  if (role === 'user') {
    const text = Array.isArray(content)
      ? content.filter((b) => b?.type === 'text').map((b) => b.text).join('\n')
      : String(content ?? '');
    if (text.trim()) {
      const copyBtn = document.createElement('button');
      copyBtn.type = 'button';
      copyBtn.className = 'ab-msg-copy';
      copyBtn.title = 'Copy message';
      copyBtn.setAttribute('aria-label', 'Copy message');
      copyBtn.innerHTML = COPY_SVG;
      copyBtn.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(text);
          copyBtn.innerHTML = COPY_OK_SVG;
          setTimeout(() => { copyBtn.innerHTML = COPY_SVG; }, 1200);
        } catch {
          toast('Copy failed.', 'error');
        }
      });
      wrap.appendChild(copyBtn);
    }
  }
  log.appendChild(wrap);
  // A whole new message (a send, or the reply bubble it creates) pins the view
  // back to the bottom; only mid-stream growth respects the pause.
  followLog = true;
  log.scrollTop = log.scrollHeight;
  updateEmptyState();
  return { wrap, bubble };
}

const COPY_SVG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
const COPY_OK_SVG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"></polyline></svg>';

/** Append a "✓ Loaded into Customizer" confirmation chip. */
function appendLoadedChip(agentName) {
  const log = $('#ab-studio-log');
  if (!log) return;
  const chip = document.createElement('button');
  chip.type = 'button';
  chip.className = 'ab-studio-loaded';
  chip.textContent = `✓ "${agentName || 'Agent'}" loaded - open Setup`;
  chip.addEventListener('click', () => showTab('customizer'));
  log.appendChild(chip);
  if (followLog) log.scrollTop = log.scrollHeight;
  else markJumpFresh();
}

/**
 * Does this parsed JSON object look like a builder agent doc? Same shape test
 * extractAgentDoc uses — an object carrying an id, a name, or a steps array.
 * Shared so the inline "apply this schema" button and the auto-adopt path agree
 * on what counts as an applicable schema.
 */
function looksLikeAgentDoc(parsed) {
  return !!parsed && typeof parsed === 'object' && !Array.isArray(parsed) &&
    (parsed.id || parsed.name || Array.isArray(parsed.steps));
}

/**
 * Adopt a builder agent doc into the Customizer as a new Local version — the
 * same pipeline the streamed `done` handler runs, factored out so the inline
 * "Apply this schema" button reuses it. Re-points the draft id onto the doc's
 * real id, persists, notifies, and refreshes the version surfaces. Returns the
 * effective agent name for the confirmation chip/toast.
 */
/**
 * Gate a card/apply click that would replace an existing Local working copy.
 */
async function confirmReplaceLocal() {
  if (!(await hasLocalDoc(state.agent?.id || activeDraftId() || ''))) return true;
  return confirmModal({
    title: 'Replace unpublished changes?',
    message: 'You have unpublished changes. Opening this will replace them with the generated version.',
    confirmLabel: 'Replace',
  });
}

/**
 * Price a freshly adopted Studio doc from its own floor.
 *
 * Studio doesn't price agents — the authoring guide only tells it a price must
 * clear the floor, so when it writes one at all it lands at/near bare cost.
 * Neither is a market price, and forkAgentDoc doesn't carry `creditsPerRun`
 * over anyway. So the band decides: recompute the floor from the adopted steps
 * and write `band.suggested` — the same floor -> pricingBand() math Pass 5 uses
 * (mirror of builderPricingBand() server-side), so the JSON already carries a
 * sensibly marked-up price instead of one pinned to cost.
 *
 * A doc price is honoured only when it is ABOVE suggested: that is a real
 * pricing decision the band shouldn't undo (still capped at band.max). Anything
 * at or below suggested is treated as "no opinion" and replaced.
 */
function priceAdoptedDoc(doc) {
  const asked = Math.round(Number(doc?.creditsPerRun ?? doc?.agent?.creditsPerRun) || 0);
  const fc = floorCredits();
  const band = pricingBand(fc);

  // No usable floor (model catalog not loaded yet, or no priced steps) means
  // the band is all zeros — writing it would wipe the price. Keep whatever the
  // doc asked for; Pass 5 re-clamps once the catalog is in.
  if (fc <= 0 || band.blocked) {
    if (asked > 0) setAdoptedPrice(asked);
    return;
  }

  setAdoptedPrice(asked > band.suggested ? Math.min(asked, band.max) : band.suggested);
}

function setAdoptedPrice(credits) {
  state.creditsPerRun = credits;
  if (state.agent) state.agent.creditsPerRun = credits;
}

async function applyDocToCustomizer(doc) {
  _appliedDocFingerprint = docIdentityFingerprint(doc);
  await adoptExternalDocAsLocal(doc, false);
  await migrateDraftToRealId(state.agent?.id || doc.id);
  await saveAppliedFingerprint(_appliedDocFingerprint);
  priceAdoptedDoc(doc);
  persistConversation();
  notify();
  window.dispatchEvent(new CustomEvent('agent-builder:forked', { detail: { id: state.agent?.id } }));
  return doc.name || doc.id;
}

/**
 * Fence names that mean "run the loaded agent". `test-run` is the older spelling,
 * still accepted so replies already in a conversation keep rendering correctly.
 */
const RUN_FENCES = ['agent-run', 'test-run'];

/** Fence languages that are instructions to the builder, never shown as content. */
const CONTROL_FENCES = [...RUN_FENCES, 'agent-media'];

/** First token of a fence info string, so ```agent-media video still matches. */
function isControlFence(info) {
  return CONTROL_FENCES.includes(String(info || '').trim().split(/\s+/)[0].toLowerCase());
}

/**
 * Pull a ```agent-run request out of an assistant reply. Returns the hint string
 * (possibly empty — "just test it"), or null when the reply has no such block.
 */
function extractTestRunHint(reply) {
  const m = new RegExp('```(?:' + RUN_FENCES.join('|') + ')\\s*\\n([\\s\\S]*?)```', 'i').exec(String(reply || ''));
  if (!m) return null;
  return m[1].trim().slice(0, 500);
}

/**
 * Pull a ```agent-media request out of an assistant reply. The fence may name
 * the kind (```agent-media video), defaulting to an image.
 * Returns { kind, hint }, or null when the reply has no such block.
 */
function extractMediaHint(reply) {
  const m = /```agent-media(?:[ \t]+(image|video))?[ \t]*\n([\s\S]*?)```/i.exec(String(reply || ''));
  if (!m) return null;
  return {
    kind: String(m[1] || '').toLowerCase() === 'video' ? 'video' : 'image',
    hint: m[2].trim().slice(0, 500),
  };
}

/**
 * Pull the agent doc out of an assistant reply. The guide tells the model to
 * emit the doc as a single ```json block; we take the last fenced JSON block
 * that parses into an object with the builder doc's shape.
 */
function extractAgentDoc(reply) {
  const fence = /```(?:json)?\s*\n([\s\S]*?)```/gi;
  let m;
  let found = null;
  while ((m = fence.exec(reply)) !== null) {
    try {
      const parsed = JSON.parse(m[1].trim());
      if (looksLikeAgentDoc(parsed)) found = parsed;
    } catch {
      // Not valid JSON — skip this block.
    }
  }
  return found;
}

/**
 * Read an SSE response body, invoking `onEvent(type, data)` for each event.
 * Mirrors the server's SSEWriter wire format: `event:` + `data:` lines, double
 * newline terminated, `:` comment lines (keep-alive) ignored. `data` is the
 * parsed JSON; the payload of interest lives under `.data` (and `.data.result`
 * for `done`), matching SSEWriter's envelope.
 */
async function readSSE(res, onEvent) {
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const chunks = buffer.split('\n\n');
    buffer = chunks.pop() || '';
    for (const chunk of chunks) {
      let eventType = 'message';
      let dataStr = '';
      for (const line of chunk.split('\n')) {
        if (line.startsWith('event:')) eventType = line.slice(6).trim();
        else if (line.startsWith('data:')) dataStr += line.slice(5).trim();
        // `:` comment (keep-alive) and `id:` lines are ignored.
      }
      if (!dataStr) continue;
      let parsed;
      try { parsed = JSON.parse(dataStr); } catch { continue; }
      onEvent(eventType, parsed?.data ?? parsed);
    }
  }
}

// Per-page-load counter. `pendingAttachments.length` restarts at 1 after each
// send, so it cannot number uploads uniquely on its own.
let uploadSeq = 0;

/**
 * Build the upload filename. The CDN overwrites by filename (last writer wins),
 * so every upload needs a distinct name. Pasted screenshots are the worst case:
 * they arrive either with a blank `File.name` or with the browser's generic
 * `image.png`, so a second paste would clobber the first. Anchor the name on the
 * draft (agent) id — e.g. `my-agent-studio-3-1712...-a1b2c3.png` — so uploads
 * stay traceable to the chat that produced them, then add a sequence number plus
 * a timestamp/random suffix to guarantee uniqueness across sends, tabs, and
 * uploads landing in the same millisecond. The backend appends the real
 * extension from the content-type, so we only supply the base name.
 */
function uploadFilename(file, index) {
  const id = activeDraftId() || 'studio';
  const slug = String(id).replace(/^_new-/, '').replace(/[^a-zA-Z0-9._-]+/g, '-');
  const unique = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  // Keep the user's own filename as a readable prefix, minus its extension —
  // the backend re-adds one from the content-type.
  const base = file.name ? file.name.replace(/\.[^.]+$/, '').replace(/[^a-zA-Z0-9._-]+/g, '-') : '';
  const label = base ? `${slug}-${base}` : `${slug}-studio`;
  return `${label}-${index}-${unique}`;
}

/**
 * Upload one image file to the CDN via /api/uploads (same binary endpoint the
 * media uploaders use) and return the resulting CDN url. Throws on failure.
 */
async function uploadImage(file, index) {
  const qs = `?filename=${encodeURIComponent(uploadFilename(file, index))}`;
  const res = await fetchHelper(`https://aitopia.ai/api/uploads${qs}`, {
    method: 'POST',
    headers: { 'Content-Type': file.type || 'application/octet-stream' },
    body: file,
  });
  const json = await res.json().catch(() => null);
  if (!res.ok || !json?.url) {
    throw new Error(json?.message || json?.error || `Upload failed (${res.status}).`);
  }
  return json.url;
}

/** Re-render the pending-attachment thumbnail strip from `pendingAttachments`. */
function renderAttachments() {
  const strip = $('#ab-studio-attachments');
  if (!strip) return;
  strip.innerHTML = '';
  strip.hidden = pendingAttachments.length === 0;
  pendingAttachments.forEach((att, i) => {
    const thumb = document.createElement('div');
    thumb.className = 'ab-studio-thumb' + (att.status === 'ready' ? '' : ' loading');
    if (att.status === 'ready') {
      const img = document.createElement('img');
      img.src = att.url;
      img.alt = 'attachment';
      thumb.appendChild(img);
    } else {
      thumb.textContent = att.status === 'error' ? '⚠️' : '…';
    }
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'ab-studio-thumb-remove';
    remove.textContent = '×';
    remove.title = 'Remove';
    remove.addEventListener('click', () => {
      pendingAttachments.splice(i, 1);
      renderAttachments();
    });
    thumb.appendChild(remove);
    strip.appendChild(thumb);
  });
}

/**
 * Accept image files from the attach button, drop, or paste, upload each to the
 * CDN, and add it to the pending strip. Non-images are ignored.
 */
async function addImageFiles(files) {
  for (const file of files) {
    if (!file || !file.type?.startsWith('image/')) continue;
    const att = { url: '', status: 'uploading' };
    pendingAttachments.push(att);
    const index = ++uploadSeq; // never reused, unlike the pending-strip slot
    renderAttachments();
    try {
      att.url = await uploadImage(file, index);
      att.status = 'ready';
    } catch (err) {
      att.status = 'error';
      toast('Image upload failed: ' + (err?.message || 'error'), 'error', 5000);
    }
    renderAttachments();
  }
}

// Matches an image url anywhere in a chunk of text. We accept either a known
// image extension or our own CDN host (whose urls don't always end in an
// extension). Used to pull pasted/typed image links out of the textarea and
// turn them into attachments instead of plain text.
const IMAGE_URL_RE = /https?:\/\/[^\s]+?(?:\.(?:png|jpe?g|gif|webp)|cdn\.aitopia\.ai\/[^\s]+)/gi;

function looksLikeImageUrl(s) {
  const v = String(s || '').trim();
  if (!/^https?:\/\/\S+$/i.test(v)) return false;
  return /\.(png|jpe?g|gif|webp)(\?|#|$)/i.test(v) || /cdn\.aitopia\.ai\//i.test(v);
}

/**
 * Add an already-hosted image url as a ready attachment. No upload — the backend
 * downloads the url and inlines it for Claude, same as our CDN uploads. Skips
 * duplicates so pasting the same link twice doesn't stack thumbnails.
 */
function addImageUrl(url) {
  const clean = String(url || '').trim();
  if (!clean) return;
  if (pendingAttachments.some((a) => a.url === clean)) return;
  pendingAttachments.push({ url: clean, status: 'ready' });
  renderAttachments();
}

let sendInFlight = false;

/**
 * Send one turn. Exported so the auto-runner can hand a failure report to the
 * assistant: the reply path already extracts a corrected agent doc and applies
 * it to the Customizer, so a fix needs no separate plumbing.
 */
export async function send(content) {
  // Reentry guard. The sign-in check below awaits a network round-trip, and the
  // button-disable alone can't cover it: on mobile that window is long enough
  // for a second tap (and Enter submits via requestSubmit even while the button
  // is disabled), which replayed the identical message as a parallel request.
  if (sendInFlight) return;
  sendInFlight = true;
  const sendBtn = $('#ab-studio-send');
  const input = $('#ab-studio-text');
  if (sendBtn) sendBtn.disabled = true;
  if (!(await ensureSignedIn('Sign in to send this to Studio.'))) {
    sendInFlight = false;
    if (sendBtn) sendBtn.disabled = false;
    return;
  }
  try {
    conversation.push({ role: 'user', content });
    persistConversation();
    appendMessage('user', content);
    updateClearVisibility();
    if (input) { input.value = ''; input.style.height = ''; }
    pendingAttachments = [];
    renderAttachments();

    // Assistant bubble: a stage line on top (updated as work progresses) and a
    // text area below that fills in as tokens stream.
    const pending = appendMessage('assistant', '');
    const stageLine = document.createElement('div');
    stageLine.className = 'ab-studio-thinking';
    const stageLogo = document.createElement('span');
    stageLogo.className = 'ab-thinking-logo';
    stageLogo.innerHTML = THINKING_SVG;
    const stageText = document.createElement('span');
    stageText.className = 'ab-shimmer-text';
    stageText.textContent = 'Starting…';
    stageLine.append(stageLogo, stageText);
    const textArea = document.createElement('div');
    if (pending) {
      pending.bubble.innerHTML = '';
      pending.bubble.appendChild(stageLine);
      pending.bubble.appendChild(textArea);
    }
    const log = $('#ab-studio-log');
    const scroll = () => {
      if (!log) return;
      if (followLog) { log.scrollTop = log.scrollHeight; return; }
      // Not following: re-measure both ways. An error render can COLLAPSE the
      // content (it replaces the streamed text), leaving a stale pill pointing
      // at nothing — updateJumpPill hides it; markJumpFresh only marks when
      // something really sits below the fold.
      updateJumpPill();
      markJumpFresh();
    };

    let streamed = '';
    let finished = false;

    // Steady-type reveal. Network chunks land in `streamed` (the backlog) in
    // bursts of 40-80 characters; painting them on arrival made the text lurch
    // in slabs. Instead a per-frame loop advances `revealed` at a backlog-aware
    // rate — at least 1 char, at most REVEAL_MAX_PER_FRAME, speeding up as the
    // backlog grows — so bursts are absorbed into one continuous typing flow.
    // Rendering a prefix slice is safe: the streaming renderer already tolerates
    // partial markdown. `flushRender` cancels the pending frame so a final
    // render can't be overwritten by a stale one; `onCaughtUp` lets the done
    // handler wait for the tail to finish revealing before its full render.
    const REVEAL_MAX_PER_FRAME = 26;
    const REVEAL_CATCHUP_DIVISOR = 40;
    let rafId = 0;
    let revealed = 0;
    let onCaughtUp = null;
    const paint = () => {
      rafId = 0;
      const backlog = streamed.length - revealed;
      if (backlog > 0) {
        revealed += Math.max(1, Math.min(REVEAL_MAX_PER_FRAME, Math.ceil(backlog / REVEAL_CATCHUP_DIVISOR)));
        if (revealed > streamed.length) revealed = streamed.length;
        textArea.innerHTML = renderMarkdown(streamed.slice(0, revealed), true);
        if (log && followLog) log.scrollTop = log.scrollHeight;
        else if (log) markJumpFresh();
      }
      if (revealed < streamed.length) { scheduleRender(); return; }
      if (onCaughtUp) { const finalize = onCaughtUp; onCaughtUp = null; finalize(); }
    };
    const scheduleRender = () => {
      if (rafId) return;
      rafId = requestAnimationFrame(paint);
    };
    const flushRender = () => {
      if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
    };

    // One full request attempt. Transport failures (fetch throw, or a stream that
    // closed with no `done`/`error`) are retried up to MAX_ATTEMPTS; a retry resets
    // the bubble and re-sends, so the user always ends up with one clean reply
    // rather than two half-streamed ones. Server-sent errors return immediately so
    // we never double-charge on a deterministic failure.
    const MAX_ATTEMPTS = 3;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      // Reset per-attempt render state — a retry discards whatever partial text
      // the failed attempt painted.
      streamed = '';
      revealed = 0;
      onCaughtUp = null;
      finished = false;
      flushRender();
      textArea.innerHTML = '';
      if (!stageLine.isConnected && pending) pending.bubble.insertBefore(stageLine, textArea);
      stageText.textContent = attempt === 1 ? 'Starting…' : `Reconnecting - attempt ${attempt} of ${MAX_ATTEMPTS}…`;
      scroll();

      // Snapshot first: this turn's `done` can set a NEW rename for the next one.
      const sentRekeyFrom = pendingEventRekeyFrom;
      try {
        const res = await fetchHelper('https://aitopia.ai/api/agent-builder/studio-chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' },
          // currentDoc: the live draft from localStorage so the model edits it in
          // place (preserving manual Customizer tweaks) instead of regenerating.
          // test-run entries are local UI records, not chat turns — the API
          // only accepts user/assistant roles.
          body: JSON.stringify({
            messages: conversation.filter((m) => m.role === 'user' || m.role === 'assistant'),
            currentDoc: await readCurrentDoc(),
            previousAgentId: sentRekeyFrom || undefined,
            // The filter above drops test-run records; this is how the model learns one passed.
            tested: hasPassingTestRun(),
          }),
        });

        // Server consumed the hint on opening the stream; don't resend on retry.
        const ctype = res.headers.get('content-type') || '';
        if (res.ok && ctype.includes('text/event-stream') && sentRekeyFrom
            && pendingEventRekeyFrom === sentRekeyFrom) {
          pendingEventRekeyFrom = '';
        }

        // A non-stream error (e.g. 402 credits) comes back as plain JSON.
        if (!res.ok || !ctype.includes('text/event-stream')) {
          // 5xx without a stream is a transient server/proxy failure — retry it.
          // Everything else (402 credits, 400 validation, 401) is deterministic.
          if (res.status >= 500 && attempt < MAX_ATTEMPTS) {
            await new Promise((r) => setTimeout(r, 600 * attempt));
            continue;
          }
          const json = await res.json().catch(() => null);
          const insufficient = isInsufficientCredits(res.status, json);
          const msg = insufficient
            ? insufficientCreditsMessage(json)
            : (json?.message || json?.error || `Request failed (${res.status}).`);
          if (insufficient) openPricingModal();
          stageLine.remove();
          textArea.innerHTML = renderMarkdown(`⚠️ ${msg}`);
          toast('Studio: ' + msg, 'error', 5000);
          scroll();
          return;
        }

        await readSSE(res, (type, data) => {
          if (type === 'progress') {
            if (data?.message) stageText.textContent = data.message;
            scroll();
          } else if (type === 'token') {
            if (data?.content) {
              streamed += data.content;
              scheduleRender();
            }
          } else if (type === 'error') {
            finished = true;
            // Server reported a real failure and already refunded the
            // reservation. `finished` stops the retry loop — retrying would
            // re-reserve credits for a request that will fail the same way.
            flushRender();
            stageLine.remove();
            const msg = data?.message || 'Studio chat failed.';
            textArea.innerHTML = renderMarkdown(`⚠️ ${msg}`);
            toast('Studio: ' + msg, 'error', 5000);
            scroll();
          } else if (type === 'done') {
            finished = true;
            const result = data?.result || {};
            const reply = String(result.reply ?? streamed ?? '');
            // Persist the turn NOW — the visual tail may still be revealing,
            // and a quick next Send must not race a deferred push.
            conversation.push({ role: 'assistant', content: reply });
            persistConversation();

            const finalizeDone = async () => {
              flushRender();
              stageLine.remove();
              textArea.innerHTML = renderMarkdown(reply || '(empty reply)');
              const doc = extractAgentDoc(reply);
              if (doc) {
                // Studio always edits "whatever is active" (Local if present, else
                // the selected version) and its result lands on Local as a new
                // unpublished branch — never overwriting a published/pending
                // version. Same pipeline the card's Open button runs on restore.
                await applyDocToCustomizer(doc);
                refreshDocCardLabels();
                toast('Agent loaded into Setup (as unpublished changes).', 'success');
              }
              // A test request runs the agent as it stands; a doc reply already
              // rewrote it, so the two can't both apply to the same turn.
              if (!doc) {
                const hint = extractTestRunHint(reply);
                if (hint !== null) {
                  document.dispatchEvent(new CustomEvent('agent-builder:test-run', {
                    detail: { userHint: hint },
                  }));
                } else {
                  // Media generation is gated on a passing test, so it can never
                  // share a turn with a run request.
                  const media = extractMediaHint(reply);
                  if (media) {
                    document.dispatchEvent(new CustomEvent('agent-builder:generate-media', {
                      detail: { kind: media.kind, userHint: media.hint },
                    }));
                  }
                }
              }
              scroll();
            };
            // Let the reveal catch up first — swapping the full reply in over a
            // half-revealed tail would be exactly the lurch the reveal removes.
            if (revealed >= streamed.length) finalizeDone();
            else { onCaughtUp = finalizeDone; scheduleRender(); }
          }
        });

        // Reached a `done` (or a fatal `error`) — the turn is resolved either way.
        if (finished) return;

        // Stream closed without a done/error event (proxy dropped it). Retry
        // while attempts remain; the next pass clears the partial text so the
        // user never sees a truncated reply stitched onto a fresh one.
        if (attempt < MAX_ATTEMPTS) continue;

        // Out of attempts. Keep whatever streamed so the user isn't left with a
        // blank bubble.
        flushRender();
        stageLine.remove();
        if (streamed) {
          textArea.innerHTML = renderMarkdown(streamed);
          conversation.push({ role: 'assistant', content: streamed });
          persistConversation();
        } else {
          textArea.innerHTML = renderMarkdown('⚠️ Connection ended unexpectedly. Please try again.');
          toast('Studio: connection ended unexpectedly.', 'error', 5000);
        }
        scroll();
        return;
      } catch (err) {
        console.error(`[agent-builder] studio-chat failed (attempt ${attempt}/${MAX_ATTEMPTS})`, err);
        // Transport-level failure: the server refunds its own reservation, so a
        // retry is safe. Back off briefly so we don't hammer a restarting proxy.
        if (attempt < MAX_ATTEMPTS) {
          await new Promise((r) => setTimeout(r, 600 * attempt));
          continue;
        }
        flushRender();
        stageLine.remove();
        textArea.innerHTML = renderMarkdown('⚠️ ' + (err?.message || 'Network error'));
        toast('Studio request failed.', 'error', 5000);
        scroll();
        return;
      }
    }
  } finally {
    sendInFlight = false;
    if (sendBtn) sendBtn.disabled = false;
    // Every Send moves credits (a flat charge is reserved + settled server-side),
    // but the navbar/drawer balance is cached and won't reflect it until a reload.
    // Force-refresh it here — same call the runner makes after a run — so the
    // displayed balance drops live. Best-effort; a logged-out/helper-less page
    // silently no-ops.
    try { window.AitopiaCredits?.loadCreditsBalance?.({ force: true }); } catch { /* display only */ }
  }
}

export function wireStudio() {
  // Studio tab is gated by a server flag (AGENT_BUILDER_STUDIO). The markup
  // ships with the Studio button hidden + the Customizer active so the page
  // never flashes Studio before config loads. When off, just leave it that way.
  // Temporary while Studio is iterated on; flip the env var to bring it back.
  // config is loaded before wireStudio in boot().
  if (state.config?.studioEnabled !== true) {
    return;
  }

  // Flag on — reveal the Studio tab the markup left hidden.
  $('#ab-tab-btn-studio')?.removeAttribute('hidden');
  $('#ab-studio-tour')?.removeAttribute('hidden');
  $('#ab-studio-tour')?.addEventListener('click', () => { $('#ab-menu')?.setAttribute('hidden', ''); showTab('studio'); startTour(); });

  if (window.matchMedia('(max-width: 640px)').matches) {
    const ta = $('#ab-studio-text');
    if (ta) ta.placeholder = 'e.g. a studio product-shot agent.';
  }

  typewriter = window.initTypewriterPlaceholder?.($('#ab-studio-text'), STUDIO_PLACEHOLDERS) || null;
  updateClearVisibility();

  // Show the per-Send credit cost on the send button's second line. The flat
  // price comes from /config (AGENT_BUILDER_STUDIO_CREDITS); hidden when absent.
  const studioCredits = Number(state.config?.studioChatCredits);
  if (Number.isFinite(studioCredits) && studioCredits > 0) {
    const amount = $('#ab-studio-send-credits');
    const cost = $('.ab-studio-send-cost');
    if (amount) amount.textContent = String(studioCredits);
    if (cost) cost.hidden = false;
  }

  // Tab buttons.
  $('#ab-tab-btn-studio')?.addEventListener('click', () => showTab('studio'));
  $('#ab-tab-btn-customizer')?.addEventListener('click', () => showTab('customizer'));

  watchLogScroll();
  $('#ab-studio-jump')?.addEventListener('click', (e) => {
    const log = $('#ab-studio-log');
    if (!log) return;
    // Instant, not smooth: a glide emits intermediate scroll events that the
    // follow listener reads as "scrolled away again", flipping the flag back
    // off mid-animation — and while streaming, the glide aims at a stale
    // scrollHeight and never catches the growing bottom.
    followLog = true;
    e.currentTarget.hidden = true;
    e.currentTarget.classList.remove('fresh');
    log.scrollTop = log.scrollHeight;
  });

  const form = $('#ab-studio-form');
  const input = $('#ab-studio-text');

  // Auto-grow the textarea with content; the CSS max-height caps it.
  input?.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = `${input.scrollHeight}px`;
  });

  /**
   * Build the message content from the textarea + any ready attachments. Returns
   * a plain string when there are no images (unchanged behavior), or an array of
   * content blocks (text + one image block per ready attachment) otherwise.
   * Returns null when there's nothing to send.
   */
  function buildContent() {
    const text = (input?.value || '').trim();
    const images = pendingAttachments.filter((a) => a.status === 'ready');
    if (!text && !images.length) return null;
    if (!images.length) return text;
    const blocks = [];
    if (text) blocks.push({ type: 'text', text });
    for (const att of images) {
      blocks.push({ type: 'image', source: { type: 'url', url: att.url } });
    }
    return blocks;
  }

  // Pull any image urls left in the textarea into attachments, stripping them
  // from the text so the message reads cleanly. Covers urls typed (not pasted)
  // into the box, or pasted before this handler existed.
  function harvestUrlsFromText() {
    if (!input) return;
    const text = input.value;
    const matches = text.match(IMAGE_URL_RE);
    if (!matches?.length) return;
    for (const url of matches) addImageUrl(url);
    input.value = text.replace(IMAGE_URL_RE, '').replace(/[ \t]{2,}/g, ' ').trim();
  }

  form?.addEventListener('submit', (e) => {
    e.preventDefault();
    harvestUrlsFromText();
    if (pendingAttachments.some((a) => a.status === 'uploading')) {
      toast('Wait for the image to finish uploading.', 'info', 3000);
      return;
    }
    const content = buildContent();
    if (!content) return;
    send(content);
  });

  // Attach button → file picker.
  const fileInput = $('#ab-studio-file');
  $('#ab-studio-attach')?.addEventListener('click', () => fileInput?.click());
  fileInput?.addEventListener('change', () => {
    if (fileInput.files?.length) addImageFiles(Array.from(fileInput.files));
    fileInput.value = '';
  });

  // Paste a screenshot — or an image url — directly into the textarea.
  input?.addEventListener('paste', (e) => {
    const items = Array.from(e.clipboardData?.items || []);
    const files = items.filter((it) => it.kind === 'file' && it.type.startsWith('image/'))
      .map((it) => it.getAsFile()).filter(Boolean);
    if (files.length) {
      e.preventDefault();
      addImageFiles(files);
      return;
    }
    // A clipboard whose entire text is an image url becomes an attachment
    // instead of pasted text — so the link doesn't clutter the message.
    const pasted = (e.clipboardData?.getData('text') || '').trim();
    if (pasted && looksLikeImageUrl(pasted)) {
      e.preventDefault();
      addImageUrl(pasted);
    }
  });

  // Drag-and-drop images onto the textarea.
  input?.addEventListener('dragover', (e) => { e.preventDefault(); });
  input?.addEventListener('drop', (e) => {
    const files = Array.from(e.dataTransfer?.files || []).filter((f) => f.type.startsWith('image/'));
    if (files.length) {
      e.preventDefault();
      addImageFiles(files);
    }
  });

  // Click any image (chat bubble or attachment strip) to open the lightbox.
  // Delegated so dynamically-added images are covered without per-image wiring.
  const openFromImg = (e) => {
    const img = e.target.closest('.ab-studio-msg-img, .ab-studio-thumb img');
    if (img?.src) openLightbox(img.src);
  };
  $('#ab-studio-log')?.addEventListener('click', openFromImg);
  $('#ab-studio-attachments')?.addEventListener('click', openFromImg);

  // Artifact-card actions + legacy "Apply this schema" - delegated so they
  // cover every block, including ones rendered after this wiring. The hidden
  // sibling <pre> is the single source for the JSON (no state to carry).
  $('#ab-studio-log')?.addEventListener('click', async (e) => {
    const expandBtn = e.target.closest('.ab-doc-expand');
    if (expandBtn) {
      const pre = expandBtn.closest('.ab-doc-block')?.querySelector('pre');
      if (pre) pre.hidden = !pre.hidden;
      return;
    }
    const dlBtn = e.target.closest('.ab-doc-download');
    if (dlBtn) {
      const block = dlBtn.closest('.ab-doc-block');
      const txt = block?.querySelector('pre code')?.textContent || '';
      const url = URL.createObjectURL(new Blob([txt], { type: 'application/json' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = block?.dataset.filename || 'agent.json';
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(url);
      return;
    }

    // Test run: the tester works off the live draft, so the card's doc must be
    // in the Customizer first. Adopt it (once), then hand over to the runner.
    const testBtn = e.target.closest('.ab-doc-block .ab-doc-test');
    if (testBtn) {
      const pre = testBtn.closest('.ab-doc-block')?.querySelector('pre code');
      let doc;
      try { doc = JSON.parse(pre?.textContent.trim() || ''); } catch { doc = null; }
      if (!looksLikeAgentDoc(doc)) {
        toast('This block is not a valid agent doc.', 'error', 4000);
        return;
      }
      if (doc.id !== state.agent?.id) {
        if (!(await confirmReplaceLocal())) return;
        await applyDocToCustomizer(doc);
      }
      document.dispatchEvent(new CustomEvent('agent-builder:test-run'));
      return;
    }
    // Only inside an artifact block: the test-run card reuses .ab-doc-open for
    // its own actions, and those carry no JSON to apply.
    const openBtn = e.target.closest('.ab-doc-block .ab-doc-open');
    if (openBtn) {
      const pre = openBtn.closest('.ab-doc-block').querySelector('pre code');
      let doc;
      try { doc = JSON.parse(pre?.textContent.trim() || ''); } catch { doc = null; }
      if (!looksLikeAgentDoc(doc)) {
        toast('This block is not a valid agent doc.', 'error', 4000);
        return;
      }
      // Identical means there is nothing to apply — just switch tabs.
      if (docIdentityFingerprint(doc) !== _appliedDocFingerprint) {
        if (!(await confirmReplaceLocal())) return;
        await applyDocToCustomizer(doc);
        refreshDocCardLabels();
        toast('Schema applied to Setup (as unpublished changes).', 'success');
      }
      showTab('customizer');
      return;
    }
    const btn = e.target.closest('.ab-schema-apply');
    if (!btn) return;
    // Already applied — the button now reads as the "loaded" chip; a second click
    // just jumps to the Customizer (same as that chip does).
    if (btn.classList.contains('applied')) { showTab('customizer'); return; }
    const pre = btn.closest('.ab-schema-block')?.querySelector('pre code');
    if (!pre) return;
    let doc;
    try { doc = JSON.parse(pre.textContent.trim()); } catch { doc = null; }
    if (!looksLikeAgentDoc(doc)) {
      toast('This block is not a valid agent schema.', 'error', 4000);
      return;
    }
    if (!(await confirmReplaceLocal())) return;
    const name = await applyDocToCustomizer(doc);
    // The button itself becomes the "loaded" chip — same styling, same wording —
    // instead of stacking a separate chip below it.
    btn.classList.add('applied');
    btn.textContent = `✓ "${name || 'Agent'}" loaded - open Setup`;
    toast('Schema loaded into Setup (as unpublished changes).', 'success');
    showTab('customizer');
  });

  // Lightbox dismissal: backdrop click, close button, or Escape.
  $('#ab-studio-lightbox')?.addEventListener('click', (e) => {
    if (e.target.id === 'ab-studio-lightbox' || e.target.id === 'ab-studio-lightbox-close') {
      closeLightbox();
    }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !$('#ab-studio-lightbox')?.hidden) closeLightbox();
  });

  // Enter to send, Shift+Enter for newline.
  input?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      form?.requestSubmit();
    }
  });

  // Clear chat — wipes this draft's conversation history (keeps the loaded doc).
  $('#ab-studio-clear')?.addEventListener('click', async () => {
    if (!conversation.length) return;
    const ok = await confirmModal({
      title: 'Clear this chat?',
      message: 'The agent already loaded into Setup stays - only the conversation is forgotten.',
      confirmLabel: 'Clear chat',
      danger: true,
    });
    if (!ok) return;
    clearChat();
  });

  $('#ab-studio-take-tour')?.addEventListener('click', startTour);
  $('#ab-studio-learn-more')?.addEventListener('click', () => {
    const modal = document.getElementById('ab-modal-guide');
    modal?.classList.add('visible');
    modal?.setAttribute('aria-hidden', 'false');
  });

  // Bind to the active draft id and restore any saved conversation for it.
  // By the time wireStudio runs, boot() has already re-pointed the active draft
  // id to the real agent.id (if one was loaded), so this reads the right key.
  // Mid-session renames are handled explicitly by migrateDraftToRealId on
  // import, so no render-tick watcher is needed.
  boundDraftId = activeDraftId();
  // Storage is async: render the log only once the conversation is back, or
  // the panel paints empty and never refills.
  Promise.all([restoreConversation(boundDraftId), loadAppliedFingerprint(boundDraftId)])
    .catch(() => {})
    .finally(() => { rerenderLog(); updateClearVisibility(); });

  // Always open on Studio — it is the entry point for both authoring and
  // review; Setup is one click away.
  showTab('studio');
}
