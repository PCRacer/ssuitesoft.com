/**
 * Studio tab — chat-driven agent authoring.
 *
 * The user describes the agent they want; we POST the running conversation to
 * /api/agent-builder/studio-chat, whose backend follows the authoring guide and
 * (when ready) replies with the agent doc inside a ```json fenced block. We
 * parse that out, adopt it as the Local version (adoptExternalDocAsLocal), and flip to
 * the Customizer tab so the author can refine and publish.
 *
 * Tab switching is independent of the wizard's pass system — it just toggles
 * the two .ab-tabpane elements.
 */

import {
  state, notify, activeDraftId,
  setActiveDraftId, draftStorageKey, previewOutputsStorageKey, cleanAgentForExport,
} from './state.js';
import { $, toast } from './utils.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';
import { adoptExternalDocAsLocal } from './version-picker.js';

// Running conversation: [{ role: 'user'|'assistant', content }]. Sent verbatim
// to the backend each turn so the model keeps context across messages. `content`
// is a plain string, or an array of Anthropic content blocks (text + image)
// when the user attached/pasted a screenshot — the model fetches the image url
// (a CDN url we uploaded to first) and analyzes it natively.
let conversation = [];

// Images the author has attached/pasted but not yet sent. Each entry is
// { url, status: 'uploading'|'ready'|'error' }; once ready, `url` is the CDN
// url we POST as an image block. Cleared after a successful send.
let pendingAttachments = [];

// localStorage scope for the Studio chat, keyed by the active draft id — same
// id the wizard's draft uses. A brand-new draft has a synthetic `_new-<rand>`
// id (the auto value assigned at boot when the real id is still undefined);
// once the author/agent settles a real `agent.id`, the wizard re-points the
// active draft id and we migrate this cache key onto it (see watchDraftId).
const STUDIO_CHAT_PREFIX = 'aitopia.agent-builder.v4.studio-chat.';
function chatStorageKey(id) {
  return `${STUDIO_CHAT_PREFIX}${id || '_unsaved'}`;
}

// The draft id this module currently persists under. Tracked so we can detect
// the `_new-*` → real-id rename and move the stored conversation across.
let boundDraftId = '';

/**
 * Read the builder agent doc currently saved for the active draft from
 * localStorage and return its EXPORT-CLEAN form — the same JSON the "Export
 * JSON" button produces, with internal `__`-prefixed runtime flags
 * (`__schemaMeta`, `__optionalAvailable`, …) stripped. Sent to the backend each
 * turn so the model edits the live agent doc (including manual Customizer
 * changes) instead of regenerating from scratch. Returns null when there's no
 * draft yet or it has no real substance (so the first "create from nothing"
 * turn behaves as before).
 *
 * Because the version picker writes whatever version is active (Local if there
 * are unpublished edits, otherwise the selected version) into this same
 * localStorage slot, this naturally sends "Local if present, else the selected
 * version". Studio's reply is then adopted as Local (adoptExternalDocAsLocal),
 * so every subsequent turn keeps editing Local.
 */
function readCurrentDoc() {
  const id = activeDraftId();
  if (!id) return null;
  try {
    const raw = localStorage.getItem(draftStorageKey(id));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const agent = parsed && typeof parsed === 'object' ? parsed.agent : null;
    if (!agent || typeof agent !== 'object') return null;
    // Only send it once the doc actually has content — an empty shell would
    // just constrain the model with blanks on the very first creation turn.
    const hasSubstance = agent.id || agent.name ||
      (Array.isArray(agent.steps) && agent.steps.length) ||
      (Array.isArray(agent.fields) && agent.fields.length);
    if (!hasSubstance) return null;
    // Strip internal `__`-flags so the model sees the publishable agent doc,
    // not the wizard's runtime bookkeeping.
    return cleanAgentForExport(agent);
  } catch {
    return null;
  }
}

function persistConversation() {
  const id = activeDraftId();
  if (!id) return;
  try {
    if (conversation.length) {
      localStorage.setItem(chatStorageKey(id), JSON.stringify(conversation));
    } else {
      localStorage.removeItem(chatStorageKey(id));
    }
  } catch { /* quota / disabled — chat just won't survive reload */ }
}

function restoreConversation(id) {
  conversation = [];
  if (!id) return;
  try {
    const raw = localStorage.getItem(chatStorageKey(id));
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        conversation = parsed.filter(
          (m) => m && (m.role === 'user' || m.role === 'assistant') &&
            (typeof m.content === 'string' || Array.isArray(m.content)),
        );
      }
    }
  } catch { /* corrupt entry — start fresh */ }
}

/** Re-render the whole log from the conversation array (used on restore). */
function rerenderLog() {
  const log = $('#ab-studio-log');
  if (!log) return;
  log.innerHTML = '';
  for (const m of conversation) appendMessage(m.role, m.content);
}

/** Show the Clear button only when there's a conversation to clear. */
function updateClearVisibility() {
  const btn = $('#ab-studio-clear');
  if (btn) btn.hidden = conversation.length === 0;
}

/**
 * Reset the Studio chat for the active draft: wipe the in-memory conversation,
 * drop its localStorage entry, and clear the log. The loaded agent doc in the
 * Customizer is left untouched — this only forgets the chat history so the next
 * message starts a fresh thread (the current doc is still sent as currentDoc).
 */
function clearChat() {
  conversation = [];
  pendingAttachments = [];
  renderAttachments();
  persistConversation(); // empty → removes the stored entry
  const log = $('#ab-studio-log');
  if (log) log.innerHTML = '';
  updateClearVisibility();
}

/** Move one localStorage entry from oldKey to newKey (no-op if old is absent). */
function moveKey(oldKey, newKey) {
  if (oldKey === newKey) return;
  try {
    const raw = localStorage.getItem(oldKey);
    if (raw != null) localStorage.setItem(newKey, raw);
    localStorage.removeItem(oldKey);
  } catch { /* best-effort */ }
}

/**
 * A Studio-generated agent arrives with a real `id` while the draft is still
 * filed under its synthetic `_new-*` slot. Nothing else re-points the draft
 * mid-session (the wizard only does this at boot), so the preview/publish
 * routes look up the real id and find nothing. Here we complete the rename the
 * moment an agent loads with an id:
 *   - carry the draft, preview-outputs and studio-chat entries onto the real id,
 *   - delete the old `_new-*` entries,
 *   - point the active draft id at the real id and update the URL.
 * After this the wizard's own persist() writes to the real-id key, and a manual
 * Preview finds the draft where it expects it.
 */
function migrateDraftToRealId(newId) {
  if (!newId) return;
  const oldId = activeDraftId();
  if (!oldId || oldId === newId) {
    boundDraftId = newId;
    return;
  }

  // Don't clobber an existing draft under the real id (e.g. the author is
  // re-generating into an id they already have a slot for) — but we still
  // re-point so edits land on it. The wizard's persist() will overwrite with
  // the freshly imported doc on the next notify().
  moveKey(draftStorageKey(oldId), draftStorageKey(newId));
  moveKey(previewOutputsStorageKey(oldId), previewOutputsStorageKey(newId));
  moveKey(chatStorageKey(oldId), chatStorageKey(newId));

  setActiveDraftId(newId);
  boundDraftId = newId;
  try { history.replaceState(null, '', `/agent-builder/edit/${encodeURIComponent(newId)}`); } catch {}
}

/** Switch the visible top-level tab. Exported so the Versions tab can call it. */
export function showTab(tab) {
  for (const name of ['studio', 'customizer', 'versions']) {
    const pane = $(`#ab-tab-${name}`);
    const btn = $(`#ab-tab-btn-${name}`);
    const active = name === tab;
    if (pane) pane.classList.toggle('active', active);
    if (btn) btn.classList.toggle('active', active);
  }
}

/**
 * Minimal markdown → HTML for chat bubbles: fenced code blocks, inline code,
 * bold, and line breaks. Everything is escaped first so model output can't
 * inject markup.
 */
function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

function renderMarkdown(text) {
  const parts = [];
  const fence = /```(\w*)\n([\s\S]*?)```/g;
  let last = 0;
  let m;
  while ((m = fence.exec(text)) !== null) {
    if (m.index > last) parts.push(inline(text.slice(last, m.index)));
    parts.push(codeBlock(m[2]));
    last = fence.lastIndex;
  }
  if (last < text.length) parts.push(inline(text.slice(last)));
  return parts.join('');

  // A fenced block. When its body parses as a builder agent doc, wrap it in a
  // schema block with an inline "Apply this schema" button (the delegated click
  // handler re-reads and applies the <pre>'s JSON). Otherwise it's a plain pre.
  function codeBlock(body) {
    const pre = `<pre><code>${escapeHtml(body)}</code></pre>`;
    let isSchema = false;
    try { isSchema = looksLikeAgentDoc(JSON.parse(body.trim())); } catch { /* not JSON */ }
    if (!isSchema) return pre;
    return `<div class="ab-schema-block">${pre}` +
      `<button type="button" class="ab-schema-apply">Apply this schema</button></div>`;
  }

  function inline(chunk) {
    return escapeHtml(chunk)
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/\n/g, '<br>');
  }
}

/** Open the lightbox modal showing `url` at full size. */
function openLightbox(url) {
  const box = $('#ab-studio-lightbox');
  const img = $('#ab-studio-lightbox-img');
  if (!box || !img || !url) return;
  img.src = url;
  box.hidden = false;
}

function closeLightbox() {
  const box = $('#ab-studio-lightbox');
  const img = $('#ab-studio-lightbox-img');
  if (box) box.hidden = true;
  if (img) img.src = '';
}

/**
 * Append a chat bubble. `content` is a plain string (markdown) or an array of
 * content blocks (text + image) — the latter renders the text plus a thumbnail
 * for each image url. Returns the bubble node so callers can mutate it.
 */
function appendMessage(role, content) {
  const log = $('#ab-studio-log');
  if (!log) return null;
  const wrap = document.createElement('div');
  wrap.className = `ab-msg ${role}`;
  const bubble = document.createElement('div');
  bubble.className = 'ab-msg-bubble';
  if (Array.isArray(content)) {
    const text = content.filter((b) => b?.type === 'text').map((b) => b.text).join('\n');
    if (text) bubble.innerHTML = renderMarkdown(text);
    for (const block of content) {
      if (block?.type === 'image' && block.source?.url) {
        const img = document.createElement('img');
        img.className = 'ab-studio-msg-img';
        img.src = block.source.url;
        img.alt = 'attached image';
        bubble.appendChild(img);
      }
    }
  } else {
    bubble.innerHTML = renderMarkdown(content);
  }
  wrap.appendChild(bubble);
  log.appendChild(wrap);
  log.scrollTop = log.scrollHeight;
  return { wrap, bubble };
}

/** Append a "✓ Loaded into Customizer" confirmation chip. */
function appendLoadedChip(agentName) {
  const log = $('#ab-studio-log');
  if (!log) return;
  const chip = document.createElement('button');
  chip.type = 'button';
  chip.className = 'ab-studio-loaded';
  chip.textContent = `✓ "${agentName || 'Agent'}" loaded — open Customizer`;
  chip.addEventListener('click', () => showTab('customizer'));
  log.appendChild(chip);
  log.scrollTop = log.scrollHeight;
}

/**
 * Does this parsed JSON object look like a builder agent doc? Same shape test
 * extractAgentDoc uses — an object carrying an id, a name, or a steps array.
 * Shared so the inline "apply this schema" button and the auto-adopt path agree
 * on what counts as an applicable schema.
 */
function looksLikeAgentDoc(parsed) {
  return !!parsed && typeof parsed === 'object' && !Array.isArray(parsed) &&
    (parsed.id || parsed.name || Array.isArray(parsed.steps));
}

/**
 * Adopt a builder agent doc into the Customizer as a new Local version — the
 * same pipeline the streamed `done` handler runs, factored out so the inline
 * "Apply this schema" button reuses it. Re-points the draft id onto the doc's
 * real id, persists, notifies, and refreshes the version surfaces. Returns the
 * effective agent name for the confirmation chip/toast.
 */
function applyDocToCustomizer(doc) {
  adoptExternalDocAsLocal(doc, false);
  migrateDraftToRealId(state.agent?.id || doc.id);
  persistConversation();
  notify();
  window.dispatchEvent(new CustomEvent('agent-builder:forked', { detail: { id: state.agent?.id } }));
  return doc.name || doc.id;
}

/**
 * Pull the agent doc out of an assistant reply. The guide tells the model to
 * emit the doc as a single ```json block; we take the last fenced JSON block
 * that parses into an object with the builder doc's shape.
 */
function extractAgentDoc(reply) {
  const fence = /```(?:json)?\s*\n([\s\S]*?)```/gi;
  let m;
  let found = null;
  while ((m = fence.exec(reply)) !== null) {
    try {
      const parsed = JSON.parse(m[1].trim());
      if (looksLikeAgentDoc(parsed)) found = parsed;
    } catch {
      // Not valid JSON — skip this block.
    }
  }
  return found;
}

/**
 * Read an SSE response body, invoking `onEvent(type, data)` for each event.
 * Mirrors the server's SSEWriter wire format: `event:` + `data:` lines, double
 * newline terminated, `:` comment lines (keep-alive) ignored. `data` is the
 * parsed JSON; the payload of interest lives under `.data` (and `.data.result`
 * for `done`), matching SSEWriter's envelope.
 */
async function readSSE(res, onEvent) {
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const chunks = buffer.split('\n\n');
    buffer = chunks.pop() || '';
    for (const chunk of chunks) {
      let eventType = 'message';
      let dataStr = '';
      for (const line of chunk.split('\n')) {
        if (line.startsWith('event:')) eventType = line.slice(6).trim();
        else if (line.startsWith('data:')) dataStr += line.slice(5).trim();
        // `:` comment (keep-alive) and `id:` lines are ignored.
      }
      if (!dataStr) continue;
      let parsed;
      try { parsed = JSON.parse(dataStr); } catch { continue; }
      onEvent(eventType, parsed?.data ?? parsed);
    }
  }
}

/**
 * Build the upload filename. Pasted screenshots arrive with a blank `File.name`,
 * so the CDN would file them as a generic `image`/`upload.bin`. Anchor the name
 * on the draft (agent) id instead — e.g. `my-agent-studio-3.png` — so uploads
 * are traceable to the chat that produced them. The backend appends the real
 * extension from the content-type, so we only supply the base name.
 */
function uploadFilename(file, index) {
  if (file.name) return file.name;
  const id = activeDraftId() || 'studio';
  const slug = String(id).replace(/^_new-/, '').replace(/[^a-zA-Z0-9._-]+/g, '-');
  return `${slug}-studio-${index}`;
}

/**
 * Upload one image file to the CDN via /api/uploads (same binary endpoint the
 * media uploaders use) and return the resulting CDN url. Throws on failure.
 */
async function uploadImage(file, index) {
  const qs = `?filename=${encodeURIComponent(uploadFilename(file, index))}`;
  const res = await fetchHelper(`https://aitopia.ai/api/uploads${qs}`, {
    method: 'POST',
    headers: { 'Content-Type': file.type || 'application/octet-stream' },
    body: file,
  });
  const json = await res.json().catch(() => null);
  if (!res.ok || !json?.url) {
    throw new Error(json?.message || json?.error || `Upload failed (${res.status}).`);
  }
  return json.url;
}

/** Re-render the pending-attachment thumbnail strip from `pendingAttachments`. */
function renderAttachments() {
  const strip = $('#ab-studio-attachments');
  if (!strip) return;
  strip.innerHTML = '';
  strip.hidden = pendingAttachments.length === 0;
  pendingAttachments.forEach((att, i) => {
    const thumb = document.createElement('div');
    thumb.className = 'ab-studio-thumb' + (att.status === 'ready' ? '' : ' loading');
    if (att.status === 'ready') {
      const img = document.createElement('img');
      img.src = att.url;
      img.alt = 'attachment';
      thumb.appendChild(img);
    } else {
      thumb.textContent = att.status === 'error' ? '⚠️' : '…';
    }
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'ab-studio-thumb-remove';
    remove.textContent = '×';
    remove.title = 'Remove';
    remove.addEventListener('click', () => {
      pendingAttachments.splice(i, 1);
      renderAttachments();
    });
    thumb.appendChild(remove);
    strip.appendChild(thumb);
  });
}

/**
 * Accept image files from the attach button, drop, or paste, upload each to the
 * CDN, and add it to the pending strip. Non-images are ignored.
 */
async function addImageFiles(files) {
  for (const file of files) {
    if (!file || !file.type?.startsWith('image/')) continue;
    const att = { url: '', status: 'uploading' };
    const index = pendingAttachments.push(att); // 1-based slot, used in the filename
    renderAttachments();
    try {
      att.url = await uploadImage(file, index);
      att.status = 'ready';
    } catch (err) {
      att.status = 'error';
      toast('Image upload failed: ' + (err?.message || 'error'), 'error', 5000);
    }
    renderAttachments();
  }
}

// Matches an image url anywhere in a chunk of text. We accept either a known
// image extension or our own CDN host (whose urls don't always end in an
// extension). Used to pull pasted/typed image links out of the textarea and
// turn them into attachments instead of plain text.
const IMAGE_URL_RE = /https?:\/\/[^\s]+?(?:\.(?:png|jpe?g|gif|webp)|cdn\.aitopia\.ai\/[^\s]+)/gi;

function looksLikeImageUrl(s) {
  const v = String(s || '').trim();
  if (!/^https?:\/\/\S+$/i.test(v)) return false;
  return /\.(png|jpe?g|gif|webp)(\?|#|$)/i.test(v) || /cdn\.aitopia\.ai\//i.test(v);
}

/**
 * Add an already-hosted image url as a ready attachment. No upload — the backend
 * downloads the url and inlines it for Claude, same as our CDN uploads. Skips
 * duplicates so pasting the same link twice doesn't stack thumbnails.
 */
function addImageUrl(url) {
  const clean = String(url || '').trim();
  if (!clean) return;
  if (pendingAttachments.some((a) => a.url === clean)) return;
  pendingAttachments.push({ url: clean, status: 'ready' });
  renderAttachments();
}

async function send(content) {
  const sendBtn = $('#ab-studio-send');
  const input = $('#ab-studio-text');
  conversation.push({ role: 'user', content });
  persistConversation();
  appendMessage('user', content);
  updateClearVisibility();
  if (input) input.value = '';
  pendingAttachments = [];
  renderAttachments();
  if (sendBtn) sendBtn.disabled = true;

  // Assistant bubble: a stage line on top (updated as work progresses) and a
  // text area below that fills in as tokens stream.
  const pending = appendMessage('assistant', '');
  const stageLine = document.createElement('div');
  stageLine.className = 'ab-studio-typing';
  stageLine.textContent = 'Starting…';
  const textArea = document.createElement('div');
  if (pending) {
    pending.bubble.innerHTML = '';
    pending.bubble.appendChild(stageLine);
    pending.bubble.appendChild(textArea);
  }
  const log = $('#ab-studio-log');
  const scroll = () => { if (log) log.scrollTop = log.scrollHeight; };

  let streamed = '';
  let finished = false;

  try {
    const res = await fetchHelper('https://aitopia.ai/api/agent-builder/studio-chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' },
      // currentDoc: the live draft from localStorage so the model edits it in
      // place (preserving manual Customizer tweaks) instead of regenerating.
      body: JSON.stringify({ messages: conversation, currentDoc: readCurrentDoc() }),
    });

    // A non-stream error (e.g. 402 credits) comes back as plain JSON.
    const ctype = res.headers.get('content-type') || '';
    if (!res.ok || !ctype.includes('text/event-stream')) {
      const json = await res.json().catch(() => null);
      const msg = json?.message || `Request failed (${res.status}).`;
      stageLine.remove();
      textArea.innerHTML = renderMarkdown(`⚠️ ${msg}`);
      toast('Studio: ' + msg, 'error', 5000);
      return;
    }

    await readSSE(res, (type, data) => {
      if (type === 'progress') {
        if (data?.message) stageLine.textContent = data.message;
        scroll();
      } else if (type === 'token') {
        if (data?.content) {
          streamed += data.content;
          textArea.innerHTML = renderMarkdown(streamed);
          scroll();
        }
      } else if (type === 'error') {
        finished = true;
        stageLine.remove();
        const msg = data?.message || 'Studio chat failed.';
        textArea.innerHTML = renderMarkdown(`⚠️ ${msg}`);
        toast('Studio: ' + msg, 'error', 5000);
      } else if (type === 'done') {
        finished = true;
        const result = data?.result || {};
        const reply = String(result.reply ?? streamed ?? '');
        stageLine.remove();
        textArea.innerHTML = renderMarkdown(reply || '(empty reply)');
        conversation.push({ role: 'assistant', content: reply });
        persistConversation();

        const doc = extractAgentDoc(reply);
        if (doc) {
          // Studio always edits "whatever is active" (Local if present, else the
          // selected version) and its result lands on Local as a new unpublished
          // branch — never overwriting a published/pending version. Same pipeline
          // the inline "Apply this schema" button runs.
          const name = applyDocToCustomizer(doc);
          appendLoadedChip(name);
          toast('Agent loaded into Customizer (as a new local version).', 'success');
        }
        scroll();
      }
    });

    // Stream closed without a done/error event (proxy dropped it). Keep whatever
    // streamed so the user isn't left with a blank bubble.
    if (!finished) {
      stageLine.remove();
      if (streamed) {
        textArea.innerHTML = renderMarkdown(streamed);
        conversation.push({ role: 'assistant', content: streamed });
        persistConversation();
      } else {
        textArea.innerHTML = renderMarkdown('⚠️ Connection ended unexpectedly. Please try again.');
      }
    }
  } catch (err) {
    console.error('[agent-builder] studio-chat failed', err);
    stageLine.remove();
    textArea.innerHTML = renderMarkdown('⚠️ ' + (err?.message || 'Network error'));
    toast('Studio request failed.', 'error', 5000);
  } finally {
    if (sendBtn) sendBtn.disabled = false;
    // Every Send moves credits (a flat charge is reserved + settled server-side),
    // but the navbar/drawer balance is cached and won't reflect it until a reload.
    // Force-refresh it here — same call the runner makes after a run — so the
    // displayed balance drops live. Best-effort; a logged-out/helper-less page
    // silently no-ops.
    try { window.AitopiaCredits?.loadCreditsBalance?.({ force: true }); } catch { /* display only */ }
  }
}

export function wireStudio() {
  // Studio tab is gated by a server flag (AGENT_BUILDER_STUDIO). The markup
  // ships with the Studio button hidden + the Customizer active so the page
  // never flashes Studio before config loads. When off, just leave it that way.
  // Temporary while Studio is iterated on; flip the env var to bring it back.
  // config is loaded before wireStudio in boot().
  if (state.config?.studioEnabled !== true) {
    return;
  }

  // Flag on — reveal the Studio tab the markup left hidden.
  $('#ab-tab-btn-studio')?.removeAttribute('hidden');

  // Show the per-Send credit cost on the send button's second line. The flat
  // price comes from /config (AGENT_BUILDER_STUDIO_CREDITS); hidden when absent.
  const studioCredits = Number(state.config?.studioChatCredits);
  if (Number.isFinite(studioCredits) && studioCredits > 0) {
    const amount = $('#ab-studio-send-credits');
    const cost = $('.ab-studio-send-cost');
    if (amount) amount.textContent = String(studioCredits);
    if (cost) cost.hidden = false;
  }

  // Tab buttons.
  $('#ab-tab-btn-studio')?.addEventListener('click', () => showTab('studio'));
  $('#ab-tab-btn-customizer')?.addEventListener('click', () => showTab('customizer'));

  const form = $('#ab-studio-form');
  const input = $('#ab-studio-text');

  /**
   * Build the message content from the textarea + any ready attachments. Returns
   * a plain string when there are no images (unchanged behavior), or an array of
   * content blocks (text + one image block per ready attachment) otherwise.
   * Returns null when there's nothing to send.
   */
  function buildContent() {
    const text = (input?.value || '').trim();
    const images = pendingAttachments.filter((a) => a.status === 'ready');
    if (!text && !images.length) return null;
    if (!images.length) return text;
    const blocks = [];
    if (text) blocks.push({ type: 'text', text });
    for (const att of images) {
      blocks.push({ type: 'image', source: { type: 'url', url: att.url } });
    }
    return blocks;
  }

  // Pull any image urls left in the textarea into attachments, stripping them
  // from the text so the message reads cleanly. Covers urls typed (not pasted)
  // into the box, or pasted before this handler existed.
  function harvestUrlsFromText() {
    if (!input) return;
    const text = input.value;
    const matches = text.match(IMAGE_URL_RE);
    if (!matches?.length) return;
    for (const url of matches) addImageUrl(url);
    input.value = text.replace(IMAGE_URL_RE, '').replace(/[ \t]{2,}/g, ' ').trim();
  }

  form?.addEventListener('submit', (e) => {
    e.preventDefault();
    harvestUrlsFromText();
    if (pendingAttachments.some((a) => a.status === 'uploading')) {
      toast('Wait for the image to finish uploading.', 'info', 3000);
      return;
    }
    const content = buildContent();
    if (!content) return;
    send(content);
  });

  // Attach button → file picker.
  const fileInput = $('#ab-studio-file');
  $('#ab-studio-attach')?.addEventListener('click', () => fileInput?.click());
  fileInput?.addEventListener('change', () => {
    if (fileInput.files?.length) addImageFiles(Array.from(fileInput.files));
    fileInput.value = '';
  });

  // Paste a screenshot — or an image url — directly into the textarea.
  input?.addEventListener('paste', (e) => {
    const items = Array.from(e.clipboardData?.items || []);
    const files = items.filter((it) => it.kind === 'file' && it.type.startsWith('image/'))
      .map((it) => it.getAsFile()).filter(Boolean);
    if (files.length) {
      e.preventDefault();
      addImageFiles(files);
      return;
    }
    // A clipboard whose entire text is an image url becomes an attachment
    // instead of pasted text — so the link doesn't clutter the message.
    const pasted = (e.clipboardData?.getData('text') || '').trim();
    if (pasted && looksLikeImageUrl(pasted)) {
      e.preventDefault();
      addImageUrl(pasted);
    }
  });

  // Drag-and-drop images onto the textarea.
  input?.addEventListener('dragover', (e) => { e.preventDefault(); });
  input?.addEventListener('drop', (e) => {
    const files = Array.from(e.dataTransfer?.files || []).filter((f) => f.type.startsWith('image/'));
    if (files.length) {
      e.preventDefault();
      addImageFiles(files);
    }
  });

  // Click any image (chat bubble or attachment strip) to open the lightbox.
  // Delegated so dynamically-added images are covered without per-image wiring.
  const openFromImg = (e) => {
    const img = e.target.closest('.ab-studio-msg-img, .ab-studio-thumb img');
    if (img?.src) openLightbox(img.src);
  };
  $('#ab-studio-log')?.addEventListener('click', openFromImg);
  $('#ab-studio-attachments')?.addEventListener('click', openFromImg);

  // "Apply this schema" — delegated so it covers every schema block, including
  // ones rendered after this wiring. Re-reads the sibling <pre>'s JSON (no state
  // to carry), parses it, and loads it into the Customizer via the shared path.
  $('#ab-studio-log')?.addEventListener('click', (e) => {
    const btn = e.target.closest('.ab-schema-apply');
    if (!btn) return;
    // Already applied — the button now reads as the "loaded" chip; a second click
    // just jumps to the Customizer (same as that chip does).
    if (btn.classList.contains('applied')) { showTab('customizer'); return; }
    const pre = btn.closest('.ab-schema-block')?.querySelector('pre code');
    if (!pre) return;
    let doc;
    try { doc = JSON.parse(pre.textContent.trim()); } catch { doc = null; }
    if (!looksLikeAgentDoc(doc)) {
      toast('This block is not a valid agent schema.', 'error', 4000);
      return;
    }
    const name = applyDocToCustomizer(doc);
    // The button itself becomes the "loaded" chip — same styling, same wording —
    // instead of stacking a separate chip below it.
    btn.classList.add('applied');
    btn.textContent = `✓ "${name || 'Agent'}" loaded — open Customizer`;
    toast('Schema loaded into Customizer (as a new local version).', 'success');
    showTab('customizer');
  });

  // Lightbox dismissal: backdrop click, close button, or Escape.
  $('#ab-studio-lightbox')?.addEventListener('click', (e) => {
    if (e.target.id === 'ab-studio-lightbox' || e.target.id === 'ab-studio-lightbox-close') {
      closeLightbox();
    }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !$('#ab-studio-lightbox')?.hidden) closeLightbox();
  });

  // Enter to send, Shift+Enter for newline.
  input?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      form?.requestSubmit();
    }
  });

  // Clear chat — wipes this draft's conversation history (keeps the loaded doc).
  $('#ab-studio-clear')?.addEventListener('click', () => {
    if (!conversation.length) return;
    if (!confirm('Clear this chat\'s history? The agent already loaded into the Customizer stays — only the conversation is forgotten.')) return;
    clearChat();
  });

  // Bind to the active draft id and restore any saved conversation for it.
  // By the time wireStudio runs, boot() has already re-pointed the active draft
  // id to the real agent.id (if one was loaded), so this reads the right key.
  // Mid-session renames are handled explicitly by migrateDraftToRealId on
  // import, so no render-tick watcher is needed.
  boundDraftId = activeDraftId();
  restoreConversation(boundDraftId);
  rerenderLog();
  updateClearVisibility();

  // If the draft already has substance (returning author, or imported doc),
  // start on the Customizer so we don't bury existing work behind an empty
  // chat. A brand-new draft with no chat history opens on Studio.
  const hasWork = state.agent?.id || state.agent?.name ||
    (state.agent?.steps?.length) || (state.agent?.fields?.length);
  showTab(hasWork && !conversation.length ? 'customizer' : 'studio');
}
