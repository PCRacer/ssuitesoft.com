/**
 * Studio surface for the auto-runner (MATA-4028, phase 1).
 *
 * Owns the "Test run" button and renders the run into a card in the Studio log.
 * All orchestration lives in tester.js — this file only shows what it reports.
 */

import { state, notify } from './state.js';
import {
  el, toast,
  validateMetadata, validateTemplate, validateFields, validateSteps, validateCredits,
} from './utils.js';
import {
  appendMessage, showTab, recordTestRun, registerTestRunRenderer, send,
  THINKING_SVG, BOLT_SVG,
} from './studio.js';
import { mediaGenerator } from './media-generator.js';
import { tester } from './tester.js';
import { renderOutput } from '/marketplace/js/runner/result-renderer.js';
import { publish } from './preview-pass.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';
import { openPublishSheet, closePublishSheet } from './publish-sheet.js';

/** Card markup, rebuilt on each state change. Kept in one node so it can be replaced wholesale. */
function stepRow(step, label) {
  const row = document.createElement('div');
  row.className = 'ab-test-step';
  const icon = {
    done: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    error: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M7 7l10 10M17 7L7 17"/></svg>',
  }[step.status] || '';
  row.innerHTML =
    `<span class="ab-test-step-icon ${step.status || 'pending'}">${icon}</span>` +
    `<span class="ab-test-step-name">${label}</span>` +
    `<span class="ab-test-step-meta">${step.meta || ''}</span>`;
  return row;
}


/** Price the cover render on its button — no modal, the cost is on the label. */
export function showCoverCredits(btn, kind = 'image') {
  mediaGenerator.quote(kind).then((n) => {
    if (!(n > 0) || !btn.isConnected) return;
    const badge = document.createElement('span');
    badge.className = 'ab-doc-credits';
    badge.innerHTML = `${BOLT_SVG}${Math.ceil(n)}`;
    btn.appendChild(badge);
  });
}

const ICON_SCAN = '<svg viewBox="0 0 20 20" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1.67 7.5V5.42c0-2.08 1.67-3.75 3.75-3.75H7.5M12.5 1.67h2.08c2.08 0 3.75 1.67 3.75 3.75V7.5M18.33 13.33v1.25c0 2.08-1.67 3.75-3.75 3.75h-1.25M7.5 18.33H5.42c-2.08 0-3.75-1.67-3.75-3.75V12.5"/><path d="M10.83 10a.83.83 0 1 1-1.66 0 .83.83 0 0 1 1.66 0z"/><path d="M10 13.45c1.47 0 2.84-.87 3.8-2.37.37-.59.37-1.57 0-2.16C12.84 7.42 11.47 6.55 10 6.55s-2.84.87-3.8 2.37c-.37.59-.37 1.57 0 2.16.96 1.5 2.33 2.37 3.8 2.37z"/></svg>';

/** Icon link to the agent's preview page, for a passing run's action row. */
export function previewLink() {
  const id = state.agent?.id;
  if (!id) return null;
  const a = document.createElement('a');
  a.className = 'ab-preview-iconbtn';
  a.href = `/agent-builder/preview/${encodeURIComponent(id)}`;
  a.setAttribute('data-tooltip', 'Preview Agent');
  a.setAttribute('aria-label', 'Preview Agent');
  a.innerHTML = ICON_SCAN;
  return a;
}

/** Submitted run renders as the marketplace listing card. */
export function paintSubmitted(card, view) {
  const media = (view.report?.outputs || []).find(o => o?.url && o.kind !== 'audio')
    || (state.agent?.showcase_videos?.[0] ? { url: state.agent.showcase_videos[0], kind: 'video' } : null)
    || (state.agent?.showcase_images?.[0] ? { url: state.agent.showcase_images[0], kind: 'image' } : null);
  card.classList.add('ab-submitted-card');

  if (media) {
    const cover = media.kind === 'video'
      ? el('video', { src: media.url, muted: true, playsinline: true, preload: 'metadata' })
      : el('img', { src: media.url, alt: '', loading: 'lazy' });
    card.appendChild(el('div', { class: 'ab-submitted-media' }, cover));
    const badge = el('span', { class: 'ab-submitted-badge' });
    badge.innerHTML = `${ICON_MEDIA_ON} Submitted for review`;
    badge.appendChild(el('span', {
      class: 'ab-info-tip', tabindex: '0',
      'data-tooltip': 'A moderator reviews the agent before it goes live on the marketplace. You can keep editing and submit a new version any time.',
    }, 'i'));
    card.appendChild(badge);   // outside the clipped cover so the tooltip is not cut
  }
  const credits = Math.max(0, Math.round(Number(state.creditsPerRun) || 0));
  const pill = credits > 0 ? el('span', { class: 'ab-submitted-credits' }) : null;
  if (pill) pill.innerHTML = `${ICON_SPARK} ${credits} credits`;
  card.appendChild(el('div', { class: 'ab-submitted-text' },
    el('div', { class: 'ab-submitted-title' }, view.agentName || state.agent?.name || 'Your agent'),
    el('div', { class: 'ab-submitted-sub' }, String(state.agent?.description || '').trim() || 'Your agent is being submitted for review.'),
    pill,
  ));

  const id = state.agent?.id;
  if (!id) return;
  card.classList.add('ab-submitted-link');
  card.setAttribute('role', 'link');
  card.tabIndex = 0;
  const go = () => { window.location.href = `/agent-builder/preview/${encodeURIComponent(id)}`; };
  card.addEventListener('click', (e) => { if (!e.target.closest('.ab-info-tip')) go(); });
  card.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
}

/** Repaint the card wholesale — a handful of rows, diffing would not pay. */
function paint(card, view) {
  card.innerHTML = '';
  card.classList.remove('ab-submitted-card');
  if (view.publishedAs) return paintSubmitted(card, view);

  const head = document.createElement('div');
  head.className = 'ab-doc-card-head';
  const when = view.at
    ? new Date(view.at).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
    : '';
  // While a run is in flight, reuse the Studio's thinking logo next to the label.
  const spinner = view.status === 'running'
    ? `<span class="ab-thinking-logo ab-test-spinner">${THINKING_SVG}</span>`
    : '';
  head.innerHTML =
    `<span class="ab-doc-name">Test run - ${view.agentName || 'agent'}${when ? ` · ${when}` : ''}</span>` +
    spinner +
    `<span class="ab-doc-status ${view.status}">${view.statusLabel}</span>`;
  card.appendChild(head);

  if (view.note) {
    const note = document.createElement('div');
    note.className = 'ab-test-note';
    note.textContent = view.note;
    card.appendChild(note);
  }

  if (view.steps.length) {
    const list = document.createElement('div');
    list.className = 'ab-test-steps';
    view.steps.forEach((s, i) => list.appendChild(stepRow(s, s.label || `Step ${i + 1}`)));
    card.appendChild(list);
  }

  if (view.error) {
    const err = document.createElement('div');
    err.className = 'ab-test-error';
    err.textContent = view.error;
    card.appendChild(err);
  }

  // One renderer for every output kind — the same one creation history and the
  // agent page use. Media renders inline; text/markdown/HTML gets the modal,
  // which the card is too small to hold.
  const finalOutput = view.report?.finalOutput;
  if (view.outputs?.length) {
    const strip = document.createElement('div');
    strip.className = 'ab-test-outputs';
    try {
      renderOutput(strip, finalOutput != null ? finalOutput : view.outputs.map(o => o.url));
    } catch (err) {
      console.debug('[tester] renderOutput failed', err);
    }
    // renderOutput wraps media in links that open a new tab. Inside the Studio
    // the modal is the better viewer, so intercept the click before the anchor
    // acts — capture phase, since the anchor's own handler runs on bubble.
    strip.addEventListener('click', (e) => {
      if (e.target.closest('button, input, select, textarea')) return; // slider controls
      const anchor = e.target.closest('a');
      const url = anchor?.getAttribute('href') || e.target?.currentSrc || e.target?.src;
      e.preventDefault();
      e.stopPropagation();
      openOutputModal(url || finalOutput);
    }, true);
    card.appendChild(strip);
  } else if (view.status === 'ok' && finalOutput != null) {
    // Nothing to show inline (text, markdown, HTML) — offer the viewer.
    const open = document.createElement('button');
    open.type = 'button';
    open.className = 'ab-test-view-output';
    open.innerHTML = `${ICON_VIEW} View output`;
    open.addEventListener('click', () => openOutputModal(finalOutput));
    card.appendChild(open);
  }

  if (view.footer) {
    const foot = document.createElement('div');
    foot.className = 'ab-test-foot';
    foot.textContent = view.footer;
    card.appendChild(foot);
  }

  // A passing run unlocks Publish; its output can also become the agent's media.
  if (view.status === 'ok') {
    const row = document.createElement('div');
    row.className = 'ab-doc-cta ab-test-cta';
    const secondary = document.createElement('div');
    secondary.className = 'ab-test-secondary';

    const submit = document.createElement('button');
    submit.type = 'button';
    submit.className = 'ab-doc-open primary';
    submit.innerHTML = view.publishedAs ? `Submitted as v${view.publishedAs}` : 'Publish Agent <span aria-hidden="true">›</span>';
    submit.disabled = !!view.publishedAs;
    submit.addEventListener('click', () => openPublishSheet(async (sheetBtn) => {
      await submitForReview(card, view, sheetBtn);
      if (view.publishedAs) closePublishSheet();
    }));
    row.appendChild(submit);

    // A passing run is the gate the media generator waits on, so this is the
    // first place the button can appear. Its own class, not ab-doc-open: that
    // one is claimed by the artifact-card handler, which looks for JSON this
    // card does not carry.
    const cover = document.createElement('button');
    cover.type = 'button';
    cover.className = 'ab-cover-btn';
    cover.textContent = 'Generate cover';
    showCoverCredits(cover);
    // `tested: true` — this card IS a passing run. The generator's own check
    // reads the live step cache, which a publish or a reload has already cleared.
    cover.addEventListener('click', () => {
      document.dispatchEvent(new CustomEvent('agent-builder:generate-media', {
        detail: { kind: 'image', tested: true },
      }));
    });
    secondary.appendChild(cover);

    // Opt-in per card: several runs sit in the log, and the author picks which
    // one's output the listing shows.
    const hasMedia = (view.report?.outputs || []).some(o => o?.url && o.kind !== 'audio');
    if (hasMedia) {
      const added = tester.inMedia(view.report);
      const media = document.createElement('button');
      media.type = 'button';
      media.className = `ab-doc-open ab-media-toggle ${added ? 'remove' : 'add'}`;
      media.innerHTML = added
        ? '<span class="ab-media-toggle-state">In showcase</span><span class="ab-media-toggle-hover">Remove</span>'
        : 'Add to showcase';
      // Tooltip names the action, not the state.
      media.title = added ? 'Remove from Showcase Media' : 'Add to Showcase Media';
      media.setAttribute('aria-label', media.title);
      media.addEventListener('click', () => {
        if (added) {
          tester.detachFromMedia(view.report);
        } else if (!tester.attachToMedia(view.report)) {
          toast('Showcase Media is full (5) — remove one in Setup › Media first.', 'error', 5000);
        }
        paint(card, view);
      });
      secondary.appendChild(media);
    }
    const preview = previewLink();
    if (preview) secondary.appendChild(preview);
    if (secondary.childElementCount) row.appendChild(secondary);
    card.appendChild(row);
  }

  // A failed run gets the same slot, but the action is repair rather than
  // publish: hand the error to the assistant and let it correct the doc.
  // Autofix routes through the Studio chat, so it is only offered when the
  // Studio is enabled (AGENT_BUILDER_STUDIO).
  if (view.status === 'error' && state.config?.studioEnabled === true) {
    const row = document.createElement('div');
    row.className = 'ab-doc-cta';

    const fix = document.createElement('button');
    fix.type = 'button';
    fix.className = 'ab-doc-open primary';
    fix.textContent = view.fixRequested ? 'Sent to assistant' : 'Autofix';
    fix.disabled = !!view.fixRequested;
    fix.addEventListener('click', () => requestAutofix(card, view, fix));
    row.appendChild(fix);

    // Retry re-sends the exact inputs of this run — same prompt, same media —
    // so a transient provider failure can be re-tested without re-generating.
    const retryInputs = view.report?.inputs;
    if (retryInputs && Object.keys(retryInputs).length) {
      const retry = document.createElement('button');
      retry.type = 'button';
      retry.className = 'ab-doc-open';
      retry.textContent = 'Retry';
      retry.disabled = _running;
      retry.addEventListener('click', () => {
        retry.disabled = true;
        startRun({ presetInputs: retryInputs });
      });
      row.appendChild(retry);
    }

    card.appendChild(row);
  }
}

/**
 * Hand a failed run to the assistant as a normal chat turn — send() already
 * extracts a corrected agent doc from the reply and applies it. Failure only;
 * a passing run needs no commentary.
 */
async function requestAutofix(card, view, btn) {
  view.fixRequested = true;
  btn.disabled = true;
  btn.textContent = 'Sent to assistant';
  paint(card, view);
  // Persist so a reload does not offer to re-send the same failure.
  if (view.report) recordTestRun({ ...view.report, fixRequested: true });

  showTab('studio');
  await send(buildFailurePrompt(view));
}

/** Media toggle icons — same stroke language as the Studio's card actions. */
const ICON_VIEW = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
  + '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>';
const ICON_SPARK = '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.67 5.67A4.33 4.33 0 0 1 9.99 9.99a4.33 4.33 0 0 0-3.98-3.98 4.33 4.33 0 1 1 8.66-.34z"/><path d="M10 10.33A4.33 4.33 0 1 1 6.01 6.01 4.33 4.33 0 0 1 10 10.33z"/><path d="m5.08 9.75.59-1.08.58 1.08 1.08.58-1.08.59-.58 1.08-.59-1.08L4 10.33z"/></svg>';
const ICON_MEDIA_ON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
  + '<path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

/** Newline for composed prompt text. */
const NL = '\n';

/**
 * First person on purpose: the Studio prompt already casts the assistant as the
 * agent builder, and a machine report reads as telemetry — it pulls the model
 * toward summarising instead of fixing.
 */
function buildFailurePrompt(view) {
  const failed = view.steps.findIndex(s => s.status === 'error');
  const label = failed >= 0 ? view.steps[failed].label : '';
  // Labels are "2. google/nano-banana-2" — the model id is what matters here.
  const model = label.replace(/^\d+\.\s*/, '');
  const ordinal = failed >= 0 ? failed + 1 : null;

  const lines = [
    `I just tested this agent and it failed${ordinal ? ` on step ${ordinal}` : ''}.`,
    '',
  ];

  if (view.testInputs && Object.keys(view.testInputs).length) {
    lines.push('These are the inputs I filled in:', '```json',
      JSON.stringify(view.testInputs, null, 2), '```', '');
  }

  lines.push(
    model
      ? `Running ${model} gave me this error:`
      : 'I got this error:',
    '',
    // view.error is display-prefixed ("Step 2 (model): ..."); the sentence above
    // already says which step and model, so quote just the provider's message.
    `> ${String(view.error || '').replace(/^Step \d+[^:]*:\s*/, '') || '(no error message came back)'}`,
    '',
  );

  const done = view.steps.filter(s => s.status === 'done').length;
  if (done > 0 && ordinal) {
    lines.push(done === 1
      ? 'Step 1 ran fine; it stopped there.'
      : `Steps 1-${done} ran fine; it stopped there.`, '');
  }

  lines.push(
    'What went wrong? Keep the explanation to a sentence or two.',
    '',
    'If it is something in the agent itself — a field wired to the wrong key, a',
    'value the model does not accept, an input the step needs but never gets —',
    'please fix it and give me the corrected agent. If it is on the provider side',
    '(an outage, a quota, a one-off glitch), just tell me and leave the agent',
    'alone; I would rather retry than change something that was already right.',
  );
  return lines.join(NL);
}

/**
 * Publish needs more than a passing run — metadata, fields, steps and a credit
 * price must all validate. Check here rather than let the server reject it.
 */
async function submitForReview(card, view, btn) {
  const problems = [
    ...validateMetadata(), ...validateTemplate(),
    ...validateFields(), ...validateSteps(), ...validateCredits(),
  ];
  if (problems.length) {
    toast(problems[0], 'error', 6000);
    state.pass = 5;
    notify();
    showTab('customizer');
    return;
  }

  // Nothing picked yet → use this run's output, so a listing never reaches
  // review with no media. An existing pick is left alone.
  const shots = (state.agent.showcase_images || []).length + (state.agent.showcase_videos || []).length;
  const willAdd = !shots && (view.report?.outputs || []).some(o => o?.url && o.kind !== 'audio');


  btn.disabled = true;
  const label = btn.innerHTML;
  btn.textContent = 'Submitting…';
  if (willAdd) tester.attachToMedia(view.report);
  const before = state.publishedVersion;
  await publish();
  // publish() reports its own errors; a changed publishedVersion is how we know
  // it actually landed.
  if (state.publishedVersion && state.publishedVersion !== before) {
    view.publishedAs = state.publishedVersion;
    // Re-record so a reload still shows this run as submitted.
    recordTestRun({ ...view.report, publishedAs: view.publishedAs });
  } else {
    btn.disabled = false;
    btn.innerHTML = label;
  }
  paint(card, view);
}

/** Fold a finished report into the view model. Shared by the live run and the restore path. */
function applyReport(view, report) {
  // Kept for the autofix prompt — the assistant needs to see what was submitted.
  if (report.inputs) view.testInputs = report.inputs;
  if (report.ok) {
    view.status = 'ok';
    view.statusLabel = 'Passed';
    view.note = '';
    // Clear a previous failed verdict (a recovered run repaints the same view).
    view.error = '';
    view.outputs = report.outputs || [];
    const n = report.steps.length;
    view.footer = `${n} step${n === 1 ? '' : 's'} · ${report.credits} credit${report.credits === 1 ? '' : 's'}`;
    for (const s of report.steps) {
      if (!view.steps[s.stepIndex]) continue;
      view.steps[s.stepIndex].status = 'done';
      view.steps[s.stepIndex].meta = s.durationMs ? `${(s.durationMs / 1000).toFixed(1)}s` : '';
    }
    return;
  }
  view.status = 'error';
  view.statusLabel = 'Failed';
  view.note = '';
  const where = Number.isInteger(report.stepIndex)
    ? `Step ${report.stepIndex + 1}${report.modelId ? ` (${report.modelId})` : ''}: `
    : '';
  view.error = `${where}${report.message}`;
  for (const s of (report.steps || [])) {
    if (!view.steps[s.stepIndex]) continue;
    view.steps[s.stepIndex].status = s.ok ? 'done' : 'error';
    view.steps[s.stepIndex].meta = s.ok && s.durationMs ? `${(s.durationMs / 1000).toFixed(1)}s` : '';
  }
  if (Number.isInteger(report.stepIndex) && view.steps[report.stepIndex]) {
    view.steps[report.stepIndex].status = 'error';
  }
}

/** Build a fresh view model for `steps` (the draft's pipeline). */
function blankView(steps, agentName) {
  return {
    agentName,
    status: 'running',
    statusLabel: 'Preparing…',
    note: '',
    // Always lead with the step number — a content-research step has no
    // model_id, so labelling by model alone numbers some rows and not others.
    steps: steps.map((s, i) => ({
      status: 'pending',
      label: `${i + 1}. ${s?.model_id || s?.kind || 'step'}`,
      meta: '',
    })),
    outputs: [],
    error: '',
    footer: '',
    // Set once the run has been submitted, so a restored card does not offer
    // to publish the same version twice.
    publishedAs: '',
    // Set once a failure has been handed to the assistant, for the same reason.
    fixRequested: false,
    testInputs: null,
    at: 0,
  };
}

/**
 * Show a non-media result (text, markdown, HTML) in a modal. Delegates to the
 * runner's renderOutput so the Studio shows exactly what creation history and
 * the agent page show — one renderer, every output kind.
 */
export function openOutputModal(value) {
  const modal = document.getElementById('ab-output-modal');
  const body = document.getElementById('ab-output-modal-body');
  if (!modal || !body) return;
  body.innerHTML = '';
  try {
    renderOutput(body, value);
  } catch (err) {
    body.innerHTML = `<pre>${String(value ?? '')}</pre>`;
    console.debug('[tester] renderOutput failed', err);
  }
  modal.hidden = false;
}

function closeOutputModal() {
  const modal = document.getElementById('ab-output-modal');
  const body = document.getElementById('ab-output-modal-body');
  if (modal) modal.hidden = true;
  // Drop the content so an embedded iframe/video stops running in the background.
  if (body) body.innerHTML = '';
}

/** Guards against a second run being started while one is on screen. */
let _running = false;
/** True while a restored run is being rebuilt from the jobs rows. */
let _recovering = false;

/** Re-draw a persisted run. Its own step labels, so later doc edits don't skew it. */
function renderStoredRun(report) {
  if (!report || typeof report !== 'object') return;
  const labels = Array.isArray(report.stepLabels) ? report.stepLabels : [];
  const view = blankView(
    labels.map(() => ({})),
    report.agentName || state.agent?.name || '',
  );
  labels.forEach((label, i) => { if (view.steps[i]) view.steps[i].label = label; });
  view.publishedAs = report.publishedAs || '';
  view.fixRequested = !!report.fixRequested;
  view.report = report;
  // Older entries predate the `at` field; runId starts with a base36 timestamp,
  // so recover the time from it rather than showing some cards undated.
  view.at = report.at || Number.parseInt(String(report.runId || '').split('-')[0], 36) || 0;
  if (report.running) {
    // Still in flight when the page closed. steps-pass re-attaches to the jobs
    // rows on boot, so mirror their live state instead of showing a verdict.
    view.status = 'running';
    view.statusLabel = 'Running';
  } else {
    applyReport(view, report);
  }

  const { bubble } = appendMessage('assistant', '');
  bubble.innerHTML = '';
  const card = document.createElement('div');
  card.className = 'ab-doc-card ab-test-card';
  bubble.appendChild(card);
  paint(card, view);

  if (report.running) {
    // The job survives server-side — re-attach so the remaining steps run.
    if (tester.hasPendingRun()) {
      _running = true;
      // Same step bookkeeping the live run does.
      const onEvent = (ev) => {
        const st = view.steps[ev?.stepIndex];
        if (st) {
          if (ev.type === 'step-progress') {
            st.status = 'running';
            st.meta = ev.percent ? `${Math.round(ev.percent)}%` : '';
          } else if (ev.type === 'step-done') {
            st.status = 'done';
            st.meta = ev.durationMs ? `${(ev.durationMs / 1000).toFixed(1)}s` : '';
          } else if (ev.type === 'step-error') {
            st.status = 'error';
            st.meta = '';
          }
        }
        paint(card, view);
      };
      tester.resume({ onEvent })
        .then((rep) => {
          _running = false;
          if (rep) { view.report = { ...view.report, ...rep, running: false }; applyReport(view, view.report); paint(card, view); recordTestRun(view.report); notify(); }
          else settleRestoredRun(card, view);
        })
        .catch(() => { _running = false; settleRestoredRun(card, view); });
      return;
    }
    followRestoredRun(card, view);
    return;
  }
  // A run that was settled as failed only because its step cache was gone (a
  // refresh mid-run) — the jobs rows may show it actually completed. Re-check
  // once and repaint if so, rather than leaving a wrong verdict on screen.
  if (report.ok === false && !report.recovered) {
    recoverOutputsFromJobs(view.steps.length).then((ok) => {
      // Stamp either way so a later reload does not re-query the jobs rows.
      view.report = { ...view.report, recovered: true };
      if (ok) settleRestoredRun(card, view);
      else recordTestRun(view.report);
    });
  }
}

/**
 * Recover a restored run whose step cache is gone (cleared storage, or a
 * reload that lost it). The jobs rows are authoritative, so ask the queue for
 * this agent's most recent builder-step jobs and rebuild the per-step records
 * instead of declaring a finished run failed. /api/queue is scoped to the
 * caller's own account, so a moderator only recovers runs they started.
 */
async function recoverOutputsFromJobs(stepCount) {
  try {
    const res = await fetchHelper('https://aitopia.ai/api/queue?status=completed,failed,dead,cancelled&limit=30', {
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) return false;
    const json = await res.json().catch(() => null);
    const items = Array.isArray(json?.items) ? json.items : [];
    const docId = state.agent?.id;
    if (!docId) return false;

    let recovered = false;
    for (let i = 0; i < stepCount; i++) {
      // Skip only a record that already holds a usable result. A settled entry
      // carrying an error is exactly what we are here to re-check.
      const cur = state.previewOutputs?.[i];
      if (cur && !cur.running && !cur.error && cur.exposed != null) continue;
      // Newest job for this doc + step wins; /api/queue is newest-first.
      const job = items.find(it => it?.input?.kind === 'builder-step'
        && it.input.docId === docId
        && Number(it.input.stepIndex) === i);
      if (!job || job.status !== 'completed') continue;

      const detail = await fetchHelper(`https://aitopia.ai/api/agent-builder/preview-step-job/${encodeURIComponent(job.refId)}`, {
        headers: { Accept: 'application/json' },
      }).then(r => (r.ok ? r.json() : null)).catch(() => null);
      if (!detail?.ok || detail.status !== 'done') continue;

      state.previewOutputs = state.previewOutputs || {};
      state.previewOutputs[i] = {
        ...(state.previewOutputs[i] || {}),
        running: false,
        error: '',
        exposed: detail.exposed ?? detail.output,
        output: detail.output,
        outputId: detail.outputId,
        modelId: detail.modelId || job.modelId || '',
        durationMs: detail.durationMs || 0,
        creditsCharged: detail.creditsCharged || 0,
        checkpoint: detail.checkpoint,
        jobId: job.refId,
      };
      recovered = true;
    }
    if (recovered) notify();
    return recovered;
  } catch {
    return false;
  }
}

/**
 * Track a run that was still going when the page closed. steps-pass re-attaches
 * to the jobs rows on boot and writes results into state.previewOutputs, so the
 * card only has to mirror that — no request of its own, no second charge.
 */
function followRestoredRun(card, view) {
  // Resumed jobs deliberately don't take steps-pass's _runInFlight mutex, so
  // hold the tester's own guard until this run settles.
  _running = true;
  const timer = setInterval(() => {
    let running = false;
    let failedAt = -1;
    for (let i = 0; i < view.steps.length; i++) {
      const rec = state.previewOutputs?.[i];
      if (!rec) continue;
      if (rec.running) { running = true; view.steps[i].status = 'running'; view.steps[i].meta = rec.progress ? `${Math.round(rec.progress)}%` : ''; continue; }
      if (rec.error) { view.steps[i].status = 'error'; failedAt = failedAt === -1 ? i : failedAt; continue; }
      view.steps[i].status = 'done';
      view.steps[i].meta = rec.durationMs ? `${(rec.durationMs / 1000).toFixed(1)}s` : '';
    }
    if (running) { paint(card, view); return; }

    clearInterval(timer);
    // Nothing usable in the cache — the jobs rows may still hold the result.
    const missing = view.steps.some((_, i) => !state.previewOutputs?.[i]);
    if (missing && !_recovering) {
      _recovering = true;
      recoverOutputsFromJobs(view.steps.length).then((ok) => {
        _recovering = false;
        if (ok) followRestoredRun(card, view);
        else settleRestoredRun(card, view);
      });
      return;
    }
    settleRestoredRun(card, view);
  }, 900);
}

/** Rebuild the report from the settled step cache and persist it. */
function settleRestoredRun(card, view) {
  let failedAt = -1;
  for (let i = 0; i < view.steps.length; i++) {
    const rec = state.previewOutputs?.[i];
    if (rec && !rec.running && !rec.error) { view.steps[i].status = 'done'; continue; }
    if (rec?.error) { view.steps[i].status = 'error'; if (failedAt === -1) failedAt = i; continue; }
    // No verdict at all — blame it, else failedAt stays -1 and renders "Step 0".
    view.steps[i].status = 'error';
    if (failedAt === -1) failedAt = i;
  }
  _running = false;
  // Settled: rebuild the report from the step cache, exactly as a live run
  // would have, and persist it under the same runId.
  const done = view.steps.filter(s => s.status === 'done').length;
  const ok = failedAt === -1 && done === view.steps.length;
  const last = state.previewOutputs?.[view.steps.length - 1];
  view.report = {
    ...view.report,
    running: false,
    ok,
    message: ok ? '' : (state.previewOutputs?.[failedAt]?.error
      || (failedAt >= 0 ? `Step ${failedAt + 1} never finished — the run was interrupted.` : 'The run did not finish.')),
    // undefined would survive the spread of a previously-failed report, so use
    // null to actively clear the old step pointer on a recovered success.
    stepIndex: ok ? null : failedAt,
    modelId: ok ? '' : (state.previewOutputs?.[failedAt]?.modelId || ''),
    credits: view.steps.reduce((n, _, i) => n + (state.previewOutputs?.[i]?.creditsCharged || 0), 0),
    outputs: ok ? outputsFrom(last) : [],
    finalOutput: ok ? capOutput(last?.exposed) : undefined,
    steps: view.steps.map((st, i) => ({
      stepIndex: i, ok: st.status === 'done', durationMs: state.previewOutputs?.[i]?.durationMs || 0,
    })),
  };
  applyReport(view, view.report);
  paint(card, view);
  recordTestRun(view.report);
  notify();
}

/** Keep a persisted output small enough that five runs still fit in storage. */
const MAX_PERSISTED_OUTPUT = 200_000;
function capOutput(value) {
  if (typeof value !== 'string') return value;
  return value.length > MAX_PERSISTED_OUTPUT ? value.slice(0, MAX_PERSISTED_OUTPUT) : value;
}

/** Media URLs exposed by a settled step record. */
function outputsFrom(rec) {
  const exposed = rec?.exposed;
  const list = Array.isArray(exposed) ? exposed : [exposed];
  return list
    .filter(v => typeof v === 'string' && /^https?:\/\//.test(v))
    .map(url => ({
      url,
      kind: /\.(mp4|mov|webm|m4v)(\?|#|$)/i.test(url) ? 'video'
        : /\.(mp3|wav|m4a|ogg)(\?|#|$)/i.test(url) ? 'audio' : 'image',
    }));
}

async function startRun({ userHint, presetInputs } = {}) {
  if (_running) {
    toast('A test run is already in progress.', 'error');
    return;
  }
  _running = true;
  const runId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

  try {
    const steps = state.agent?.steps || [];
    const view = blankView(steps, state.agent?.name || state.agent?.id || '');

    // Created lazily after the confirmation — step rows before the user agrees
    // read as if the run already started.
    let card = null;
    const ensureCard = () => {
      if (card) return card;
      const { bubble } = appendMessage('assistant', '');
      bubble.innerHTML = '';
      card = document.createElement('div');
      card.className = 'ab-doc-card ab-test-card';
      bubble.appendChild(card);
      return card;
    };
    const repaint = () => { if (card) paint(card, view); };

    const onEvent = (ev) => {
      switch (ev.type) {
        case 'preflight':
          // Fires twice (local estimate, then the server's) — the dialog is
          // the only surface, so draw nothing either time.
          return;
        case 'inputs-start':
          // First event after the user agreed: open the card so the wait for
          // generated inputs is visible rather than a dead click.
          view.statusLabel = 'Preparing';
          view.note = 'Generating test inputs…';
          ensureCard();
          break;
        case 'inputs-ready':
          view.note = '';
          // Keep them for Retry: a run that dies mid-flight (network error)
          // never returns a report, so this is the only place they surface.
          view.testInputs = ev.inputs || view.testInputs;
          break;
        case 'run-start':
          view.statusLabel = 'Running';
          view.note = '';
          ensureCard();
          // Persist immediately: the steps keep running server-side, so a
          // refresh mid-run must find the card and re-attach to them.
          view.report = {
            runId, at: Date.now(), running: true,
            agentName: view.agentName,
            stepLabels: view.steps.map(s => s.label),
          };
          view.at = view.report.at;
          recordTestRun(view.report);
          break;
        case 'step-progress':
          if (view.steps[ev.stepIndex]) {
            view.steps[ev.stepIndex].status = 'running';
            view.steps[ev.stepIndex].meta = ev.percent ? `${Math.round(ev.percent)}%` : '';
          }
          break;
        case 'step-done':
          if (view.steps[ev.stepIndex]) {
            view.steps[ev.stepIndex].status = 'done';
            view.steps[ev.stepIndex].meta = ev.durationMs ? `${(ev.durationMs / 1000).toFixed(1)}s` : '';
          }
          break;
        case 'step-error':
          if (view.steps[ev.stepIndex]) {
            view.steps[ev.stepIndex].status = 'error';
            view.steps[ev.stepIndex].meta = '';
          }
          break;
        default:
          return;
      }
      repaint();
    };

    let report;
    try {
      report = await tester.run({ onEvent, userHint, presetInputs });
    } catch (err) {
      report = { ok: false, phase: 'run', code: 'unexpected', message: err?.message || String(err), steps: [] };
    }

    // Declined at the confirmation — nothing ran, so leave no trace in the log.
    if (!report.ok && report.code === 'cancelled') return;

    applyReport(view, report);
    if (report.ok) toast('Test run passed — Publish is unlocked.', 'success', 4000);
    // Build the persisted report BEFORE painting: the showcase button reads
    // view.report.outputs, so painting first renders the card without it.
    view.report = {
      runId,
      at: view.at || Date.now(),
      ok: report.ok,
      code: report.code,
      message: report.message,
      stepIndex: report.stepIndex,
      modelId: report.modelId,
      credits: report.credits,
      outputs: report.outputs || [],
      // Final step's value, so the card can show text/HTML/markdown results —
      // `outputs` only carries media URLs and would leave those runs blank.
      // Capped: a full HTML report across five kept runs would blow the
      // localStorage quota, and persist() swallows that failure silently.
      finalOutput: capOutput(report.finalOutput),
      // Only what the card draws. The verbatim provider `output` already lives
      // in state.previewOutputs; copying it here would bloat the chat entry.
      steps: (report.steps || []).map(st => ({
        stepIndex: st.stepIndex, ok: st.ok, durationMs: st.durationMs,
      })),
      agentName: view.agentName,
      stepLabels: view.steps.map(s => s.label),
      publishedAs: view.publishedAs || '',
      fixRequested: view.fixRequested || false,
      // Only on failure: the autofix prompt quotes these, and a passing run has
      // no use for them.
      inputs: report.ok ? undefined : (report.inputs || view.testInputs),
    };
    view.at = view.report.at;
    paint(ensureCard(), view);
    recordTestRun(view.report);
    notify();
  } finally {
    _running = false;
  }
}

/** Triggered by the "Test run" button on a studio artifact card (studio.js). */
export function wireTester() {
  tester.primeRunJob?.().catch(() => {});
  registerTestRunRenderer(renderStoredRun);

  document.getElementById('ab-output-modal-close')?.addEventListener('click', closeOutputModal);
  document.getElementById('ab-output-modal')?.addEventListener('click', (e) => {
    if (e.target.id === 'ab-output-modal') closeOutputModal(); // backdrop only
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeOutputModal();
  });

  document.addEventListener('agent-builder:test-run', (e) => {
    void startRun({ userHint: e?.detail?.userHint });
  });
}
