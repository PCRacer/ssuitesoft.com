/**
 * Agent Builder auto-runner (MATA-4028).
 *
 * Automates the preview gate a draft must pass before it can be published:
 * generates test inputs, prices the run, executes every step, and returns a
 * machine-readable report.
 *
 * Usage:
 *   const report = await tester.run({ doc, onEvent });
 *
 * Runs on the whole-pipeline path (POST /preview-run): one job, every step
 * chained server-side, so a refresh re-attaches instead of stranding the run.
 * A clean run makes allStepsPassedFromBuilderRuns() true, unlocking Publish.
 *
 * See plans/MATA-4028-AGENT-BUILDER-AUTO-RUNNER-PLAN.md.
 */

import { state, notify, invalidatePreviewFrom, cleanAgentForExport } from './state.js';
import { isRunInFlight, collectFieldIdsUsedUpTo, stepDocHash } from './steps-pass.js';
import { floorCredits } from './utils.js';
import { fetchHelper } from '/marketplace/js/shared/fetch-helper.js';
import * as store from '/marketplace/js/services/browser-storage.js';

const FIXTURES_URL = '/marketplace/js/agent-builder/tester-fixtures.json';
const GENDER_KEY = 'aitopia.agent-builder.v4.tester-gender';

/**
 * Alternate the person fixture between runs so a draft is not always tested
 * against the same face. Only a hint — the model ignores it when the agent
 * itself implies a gender.
 */
async function nextPersonHint() {
  let last = '';
  try { last = (await store.getItem(GENDER_KEY)) || ''; } catch { /* private mode */ }
  const next = last === 'woman' ? 'man' : 'woman';
  try { await store.setItem(GENDER_KEY, next); } catch { /* ignore */ }
  return next;
}

/** Cached fixture file — it never changes within a page load. */
let _fixtures = null;

async function loadFixtures() {
  if (_fixtures) return _fixtures;
  try {
    const res = await fetch(FIXTURES_URL, { credentials: 'same-origin' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    _fixtures = json && typeof json === 'object' ? json : {};
  } catch (err) {
    console.warn('[tester] fixtures unavailable', err);
    _fixtures = {};
  }
  return _fixtures;
}

/** Media pools only — strip the `defaults` map and the `_comment` keys. */
function mediaPools(fixtures) {
  const out = {};
  for (const [k, v] of Object.entries(fixtures || {})) {
    if (k.startsWith('_') || k === 'defaults') continue;
    if (Array.isArray(v)) out[k] = v.filter(f => f && typeof f.url === 'string' && f.url);
  }
  return out;
}

function fail(phase, code, message, extra = {}) {
  return { ok: false, phase, code, message, steps: [], ...extra };
}

function emit(onEvent, type, payload) {
  if (typeof onEvent !== 'function') return;
  try { onEvent({ type, ...payload }); } catch { /* never let a hook break the run */ }
}

/**
 * Union of the fields the pipeline reads via `${id}` and the schema's required
 * list — neither alone is enough: a soul can reference a field the schema omits.
 * Builder fields are required-by-default, the inverse of JSON-schema.
 */
function fieldsToFill(doc, schema) {
  const lastIndex = (doc.steps || []).length - 1;
  const used = lastIndex >= 0 ? collectFieldIdsUsedUpTo(lastIndex) : new Set();
  const props = schema?.input?.properties || {};
  const schemaRequired = new Set(Array.isArray(schema?.input?.required) ? schema.input.required : []);

  const out = [];
  for (const f of (doc.fields || [])) {
    if (!f?.id) continue;
    const isUsed = used.has(f.id);
    if (!isUsed && !schemaRequired.has(f.id)) continue;
    const prop = props[f.id] || {};
    const xuap = prop['x-uap'] || {};
    out.push({
      id: f.id,
      title: (typeof f.title === 'string' && f.title.trim()) || prop.title || f.id,
      description: (typeof f.description === 'string' && f.description.trim()) || prop.description || '',
      // `schema.input.required` is the authority — the server derives it with
      // `required === true && no default` and enforces the same list on the run.
      required: schemaRequired.has(f.id),
      mediaKind: xuap.mediaKind || null,
      enum: Array.isArray(f.enum) && f.enum.length ? f.enum : (Array.isArray(prop.enum) ? prop.enum : undefined),
      type: prop.type || undefined,
    });
  }
  return out;
}

/**
 * Snap a pinned default onto what the field actually accepts.
 *
 * A model that only takes 5s or 8s would fail outright on a pinned 6, so pick
 * the closest option instead of forcing ours. Numbers compare numerically;
 * strings fall back to the first embedded number (720p vs 1080p), then to an
 * exact match. Nothing comparable → leave it to the model.
 */
function nearestAllowed(value, allowed) {
  if (!allowed || !allowed.length) return value;
  const exact = allowed.find(a => String(a) === String(value));
  if (exact !== undefined) return exact;

  const num = (v) => {
    if (typeof v === 'number') return Number.isFinite(v) ? v : null;
    const str = String(v);
    // Ratios ("16:9", "4x3") are two numbers, not one — compare the quotient so
    // 1:1 lands on the squarest option rather than on whatever starts with 1.
    const ratio = str.match(/^(\d+(?:\.\d+)?)\s*[:x/]\s*(\d+(?:\.\d+)?)$/i);
    if (ratio) return Number(ratio[2]) === 0 ? null : Number(ratio[1]) / Number(ratio[2]);
    const m = str.match(/\d+(?:\.\d+)?/);
    return m ? Number(m[0]) : null;
  };
  // Named sizes ("portrait_4_3", "square_hd") carry digits that mean nothing
  // numerically — comparing them would pick landscape for a portrait default.
  const named = (v) => /[a-z]{3,}/i.test(String(v)) && !/^\d+p$/i.test(String(v));
  if (named(value)) return undefined;

  const target = num(value);
  if (target == null) return undefined;

  // Ratios compare on a log scale: linearly, 1:1 (1.0) looks closer to 9:16
  // (0.5625) than to 16:9 (1.78), which is not how aspect ratios read.
  const isRatio = /^\d+(?:\.\d+)?\s*[:x/]\s*\d+(?:\.\d+)?$/i.test(String(value));
  const dist = isRatio
    ? (n) => Math.abs(Math.log(n) - Math.log(target))
    : (n) => Math.abs(n - target);

  let best; let bestGap = Infinity;
  for (const a of allowed) {
    const n = num(a);
    if (n == null || n <= 0) continue;
    const gap = dist(n);
    // Ties go to the smaller option — cheaper for sizes, and for a ratio like
    // 16:9 vs 9:16 (equidistant from 1:1) either is arbitrary anyway.
    if (gap < bestGap || (gap === bestGap && n < num(best))) { best = a; bestGap = gap; }
  }
  return best;
}

/** Reject anything the model invented instead of picking from the pool. */
function sanitizeInputs(generated, fields, pools) {
  const known = new Set();
  for (const list of Object.values(pools)) for (const f of list) known.add(f.url);

  const inputs = {};
  const rejected = [];
  for (const f of fields) {
    const v = generated?.[f.id];
    if (v === undefined || v === null || v === '') continue;
    if (f.mediaKind && typeof v === 'string' && !known.has(v)) {
      rejected.push(f.id);
      continue;
    }
    inputs[f.id] = v;
  }
  return { inputs, rejected };
}

/** Read the settled per-step records the run wrote into state.previewOutputs. */
function collectSteps(doc) {
  const steps = doc.steps || [];
  const out = [];
  for (let i = 0; i < steps.length; i++) {
    const rec = state.previewOutputs?.[i];
    if (!rec) continue;
    out.push({
      stepIndex: i,
      modelId: rec.modelId || steps[i]?.model_id || '',
      ok: !rec.error && !rec.running,
      error: rec.error || null,
      durationMs: rec.durationMs || 0,
      creditsCharged: rec.creditsCharged || 0,
      outputId: rec.outputId || steps[i]?.output_id || '',
      exposed: rec.exposed,
      output: rec.output,
    });
  }
  return out;
}

function isVideoUrl(url) {
  return /\.(mp4|mov|webm|m4v)(\?|#|$)/i.test(String(url || ''));
}
function isAudioUrl(url) {
  return /\.(mp3|wav|m4a|ogg)(\?|#|$)/i.test(String(url || ''));
}

/** Final step's media URLs, as { url, kind }. Text outputs yield nothing. */
function finalOutputs(steps) {
  const last = steps[steps.length - 1];
  const exposed = last?.exposed;
  const list = Array.isArray(exposed) ? exposed : [exposed];
  return list
    .filter(v => typeof v === 'string' && /^https?:\/\//.test(v))
    .map(url => ({ url, kind: isVideoUrl(url) ? 'video' : isAudioUrl(url) ? 'audio' : 'image' }));
}

/**
 * Run a draft end to end.
 *
 * @param {object}   params.doc      the agent doc (defaults to the live draft)
 * @param {function} [params.onEvent]  progress hook
 * @param {boolean}  [params.confirm]  called with the credit estimate; return
 *                                     false to abort before anything is spent
 * @param {string}   [params.userHint] plain-language steer for the generated
 *                                     inputs ("test it as a woman pharaoh")
 * @param {object}   [params.presetInputs] exact inputs to replay. When given,
 *                                     nothing is generated — Retry re-sends the
 *                                     previous run's values verbatim.
 */
async function run({ doc, onEvent, confirm, userHint, presetInputs } = {}) {
  const agent = doc || cleanAgentForExport(state.agent);

  if (!agent?.id || String(agent.id).startsWith('_new')) {
    return fail('inputs', 'missing_id',
      'Give the agent an id first — a run cannot register its preview pass without one.');
  }
  if (!Array.isArray(agent.steps) || agent.steps.length === 0) {
    return fail('inputs', 'no_steps', 'This agent has no steps to run.');
  }
  if (isRunInFlight()) {
    return fail('run', 'busy', 'Another run is still in progress.');
  }

  // --- 1. Schema + price ---------------------------------------------------
  // Before the confirmation so the dialog quotes what the wallet will be
  // debited, and an invalid doc is caught before the author agrees to anything.
  // The first `preflight` carries the local floor so the dialog opens at once.
  emit(onEvent, 'preflight', { credits: floorCredits(), pending: true });

  let schema;
  let credits = floorCredits();
  try {
    const res = await fetchHelper('https://aitopia.ai/api/agent-builder/preview-meta', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agent }),
    });
    const json = await res.json().catch(() => null);
    if (!res.ok || !json?.ok) {
      const detail = Array.isArray(json?.errors)
        ? json.errors.map(e => e.message || e.code).join('; ')
        : (json?.message || `HTTP ${res.status}`);
      return fail('inputs', 'invalid_agent', detail);
    }
    schema = json.schema;
    const quoted = Number(json.pricing?.floorCredits);
    if (Number.isFinite(quoted) && quoted > 0) credits = quoted;
  } catch (err) {
    return fail('inputs', 'preview_meta_failed', err?.message || String(err));
  }

  // --- 2. Pre-flight -------------------------------------------------------
  emit(onEvent, 'preflight', { credits });
  if (typeof confirm === 'function') {
    let go = false;
    try { go = await confirm({ credits }); } catch { go = false; }
    if (!go) return fail('preflight', 'cancelled', 'Run cancelled before it started.');
  }

  // --- 3. Inputs -----------------------------------------------------------
  const fixtures = await loadFixtures();
  const pools = mediaPools(fixtures);
  const defaults = (fixtures.defaults && typeof fixtures.defaults === 'object') ? fixtures.defaults : {};
  const fields = fieldsToFill(agent, schema);

  let inputs = {};
  // Retry: replay the exact inputs of the previous run — no generation, no
  // fixture defaults, no person-hint alternation.
  if (presetInputs && typeof presetInputs === 'object' && Object.keys(presetInputs).length) {
    inputs = { ...presetInputs };
  } else if (fields.length) {
    // A hint regenerates every field — cached values would leave it nothing to steer.
    const hinted = typeof userHint === 'string' && userHint.trim() !== '';
    // Anything already typed by the author on Pass 3 wins over generation.
    const preset = hinted ? {} : (state.testInputs || {});
    const missing = hinted ? fields : fields.filter(f => {
      const v = preset[f.id];
      return v === undefined || v === null || v === '' || (Array.isArray(v) && !v.length);
    });

    if (missing.length) {
      emit(onEvent, 'inputs-start', { count: missing.length });
      try {
        const res = await fetchHelper('https://aitopia.ai/api/agent-builder/autorun-inputs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            agent, fields: missing, fixtures: pools,
            personHint: await nextPersonHint(),
            userHint: userHint || undefined,
          }),
        });
        const json = await res.json().catch(() => null);
        if (!res.ok || !json?.ok) {
          return fail('inputs', json?.code || 'inputs_failed',
            json?.message || `Could not generate test inputs (HTTP ${res.status}).`);
        }
        const { inputs: clean, rejected } = sanitizeInputs(json.inputs, missing, pools);
        inputs = clean;
        if (rejected.length) {
          console.warn('[tester] discarded invented media urls for', rejected.join(', '));
        }
      } catch (err) {
        return fail('inputs', 'inputs_error', err?.message || String(err));
      }
    }

    // Author values beat generated ones; pinned defaults beat both.
    for (const f of fields) {
      const v = preset[f.id];
      if (v !== undefined && v !== null && v !== '') inputs[f.id] = v;
    }
    // Applies to any declared field, not just the ones we asked about — an
    // optional aspect_ratio never appears in `fields` but is worth pinning.
    const props = schema?.input?.properties || {};
    for (const f of (agent.fields || [])) {
      if (!f?.id || !(f.id in defaults)) continue;
      const allowed = Array.isArray(f.enum) && f.enum.length ? f.enum
        : (Array.isArray(props[f.id]?.enum) ? props[f.id].enum : null);
      const picked = nearestAllowed(defaults[f.id], allowed);
      if (picked !== undefined) inputs[f.id] = picked;
    }

    const stillMissing = fields.filter(f => f.required && (inputs[f.id] === undefined || inputs[f.id] === ''));
    if (stillMissing.length) {
      return fail('inputs', 'incomplete_inputs',
        `No value for required field${stillMissing.length > 1 ? 's' : ''}: ${stillMissing.map(f => f.id).join(', ')}.`);
    }
  }
  emit(onEvent, 'inputs-ready', { inputs });

  // --- 4. Run --------------------------------------------------------------
  state.testInputs = { ...(state.testInputs || {}), ...inputs };
  invalidatePreviewFrom(0);
  notify();

  emit(onEvent, 'run-start', { totalSteps: agent.steps.length });

  const result = await runWholePipeline(agent, inputs, onEvent);

  const steps = collectSteps(agent);

  if (!result.started) {
    return fail('run', result.code || 'kickoff_failed',
      result.message || 'The run never started — check the pipeline configuration.');
  }
  if (!result.ok) {
    const at = Number.isInteger(result.failedIndex) ? result.failedIndex : -1;
    const rec = steps.find(s => s.stepIndex === at);
    const message = result.message || rec?.error || (at >= 0 ? `Step ${at + 1} failed.` : 'The run did not finish.');
    const report = {
      ok: false,
      phase: 'run',
      stepIndex: at,
      modelId: rec?.modelId || agent.steps[at]?.model_id || '',
      code: /insufficient|credit/i.test(message) ? 'insufficient_credits' : 'step_failed',
      message,
      inputs,
      steps,
    };
    emit(onEvent, 'error', report);
    return report;
  }

  const report = {
    ok: true,
    inputs,
    outputs: finalOutputs(steps),
    // The final step's value itself, so text/markdown/HTML runs have something
    // to show — `outputs` only carries media URLs.
    finalOutput: steps[steps.length - 1]?.exposed,
    credits: result.credits || steps.reduce((sum, s) => sum + (s.creditsCharged || 0), 0),
    steps,
  };
  emit(onEvent, 'done', report);
  return report;
}

/** Live job id, so a refresh mid-run can re-attach instead of stranding it. */
const RUN_JOB_KEY = 'aitopia.agent-builder.v4.tester-run-job';
const POLL_INTERVAL_MS = 1500;
const MAX_POLLS = 1000; // ≈25 min — must outlast the 20-minute FAL queue wait

// In-memory mirror: storage is async, hasPendingRun() is not.
let _runJob = null;

function readRunJob() { return _runJob; }

async function primeRunJob() {
  try { _runJob = JSON.parse((await store.getItem(RUN_JOB_KEY)) || 'null'); }
  catch { _runJob = null; }
  return _runJob;
}

async function writeRunJob(value) {
  _runJob = value || null;
  try {
    if (value) await store.setItem(RUN_JOB_KEY, JSON.stringify(value));
    else await store.removeItem(RUN_JOB_KEY);
  } catch { /* private mode */ }
}

/** A run this tab left in flight, if it belongs to the draft on screen. */
function pendingRunJob(agentId) {
  const saved = readRunJob();
  if (!saved?.jobId || saved.agentId !== agentId) return null;
  return saved;
}

/** Remember the live step — the running poll returns only whole-job progress. */
async function saveRunPosition(agentId, stepIndex, progress) {
  const saved = readRunJob();
  if (!saved?.jobId || saved.agentId !== agentId) return;
  await writeRunJob({ ...saved, stepIndex, progress: typeof progress === 'number' ? progress : null });
}

/** Mirror the job's per-step results into the cache the gate and step UI read. */
function applyJobStepsToCache(agent, jobSteps, { running, outputs, progress } = {}) {
  const reported = Array.isArray(jobSteps) ? jobSteps : [];
  // Pipeline is sequential — only the first unreported step is in flight.
  const nextIndex = reported.length;
  for (let i = 0; i < agent.steps.length; i++) {
    const rec = reported.find(s => Number(s?.stepIndex) === i);
    if (rec) {
      const outputId = rec.outputId || agent.steps[i]?.output_id || '';
      // `output` is the raw provider response; the render-ready value is in
      // the run's `outputs` map, keyed by output_id.
      const exposed = rec.exposed !== undefined ? rec.exposed
        : (outputs && outputId in outputs ? outputs[outputId] : undefined);
      state.previewOutputs[i] = {
        ...(state.previewOutputs[i] || {}),
        running: false,
        error: null,
        modelId: rec.modelId || agent.steps[i]?.model_id || '',
        outputId,
        // In-flight polls carry step timing but no value yet — keep whatever
        // the cache already holds rather than blanking it.
        ...(rec.output !== undefined ? { output: rec.output } : {}),
        ...(exposed !== undefined ? { exposed } : {}),
        durationMs: rec.durationMs || 0,
        creditsCharged: rec.creditsCharged || 0,
        docHash: stepDocHash(agent.steps[i]),
        ranAt: Date.now(),
      };
    } else if (running && i === nextIndex) {
      state.previewOutputs[i] = {
        ...(state.previewOutputs[i] || {}),
        running: true,
        error: null,
        modelId: agent.steps[i]?.model_id || '',
        startedAt: Number(state.previewOutputs[i]?.startedAt) || Date.now(),
        progress: typeof progress === 'number' ? progress : null,
      };
    } else if (running) {
      // Not started yet — drop any stale record so the row reads as pending.
      delete state.previewOutputs[i];
    }
  }
  notify();
}

/** Point the spinner at `index`, leaving earlier steps as the cache has them. */
function markLiveStep(agent, index, progress) {
  if (index < 0 || index >= agent.steps.length) return;
  state.previewOutputs[index] = {
    ...(state.previewOutputs[index] || {}),
    running: true,
    error: null,
    modelId: agent.steps[index]?.model_id || '',
    startedAt: Number(state.previewOutputs[index]?.startedAt) || Date.now(),
    progress: typeof progress === 'number' ? progress : null,
  };
  notify();
}

/** Turn a settled/failed job into per-step errors so the report can point at one. */
function applyJobFailureToCache(agent, final) {
  const at = Number.isInteger(final?.error?.stepIndex) ? final.error.stepIndex : -1;
  const message = final?.error?.message || 'The run did not finish.';
  for (let i = 0; i < agent.steps.length; i++) {
    const rec = state.previewOutputs[i];
    if (!rec?.running) continue;
    state.previewOutputs[i] = (at === -1 || i === at)
      ? { running: false, error: message, ranAt: Date.now() }
      : { ...rec, running: false };
  }
  notify();
}

/** Kick off (or re-attach to) one whole-pipeline job and poll it to settle. */
async function runWholePipeline(agent, inputs, onEvent) {
  await primeRunJob();
  let jobId = pendingRunJob(agent.id)?.jobId || null;

  if (!jobId) {
    let kickRes;
    try {
      kickRes = await fetchHelper('https://aitopia.ai/api/agent-builder/preview-run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        // Author testing their own draft pays provider cost, not their retail price.
        body: JSON.stringify({ agent, input: inputs, atCost: true }),
      });
    } catch (err) {
      return { started: false, ok: false, code: 'network', message: err instanceof Error ? err.message : String(err) };
    }
    const kickJson = await kickRes.json().catch(() => null);
    if (!kickRes.ok || !kickJson?.ok || !kickJson.jobId) {
      const message = kickJson?.message
        || (Array.isArray(kickJson?.validationErrors) && kickJson.validationErrors.map(e => e.message || e.code).join('; '))
        || `Preview run failed to start (HTTP ${kickRes.status})`;
      return { started: false, ok: false, code: kickJson?.code || 'kickoff_failed', message };
    }
    jobId = kickJson.jobId;
    await writeRunJob({ jobId, agentId: agent.id, startedAt: Date.now() });
  }

  // Seed the live marker so a resumed card doesn't flash step 1 / 0%.
  const resumeAt = pendingRunJob(agent.id);
  const seedIndex = Number.isInteger(resumeAt?.stepIndex) ? resumeAt.stepIndex : 0;
  if (seedIndex > 0) {
    markLiveStep(agent, seedIndex, resumeAt?.progress);
    // Re-announce steps finished before the refresh so they aren't blank.
    for (let s = 0; s < seedIndex; s++) {
      const rec = state.previewOutputs?.[s];
      emit(onEvent, 'step-done', {
        stepIndex: s,
        modelId: rec?.modelId || agent.steps[s]?.model_id || '',
        durationMs: rec?.durationMs || 0,
        error: null,
      });
    }
    emit(onEvent, 'step-progress', { stepIndex: seedIndex, percent: resumeAt?.progress || 0 });
  } else {
    applyJobStepsToCache(agent, [], { running: true });
  }

  let final = null;
  let lastReported = seedIndex - 1;
  for (let i = 0; i < MAX_POLLS; i++) {
    await new Promise(r => setTimeout(r, POLL_INTERVAL_MS));
    let pollRes;
    try {
      pollRes = await fetchHelper(`https://aitopia.ai/api/agent-builder/preview-job/${encodeURIComponent(jobId)}`);
    } catch {
      continue; // transient blip — the loop's own budget bounds this
    }
    const pollJson = await pollRes.json().catch(() => null);
    if (!pollRes.ok || !pollJson?.ok) {
      await writeRunJob(null);
      return {
        started: true, ok: false, failedIndex: -1, code: pollJson?.code || 'poll_error',
        message: pollJson?.message || `Job poll failed (HTTP ${pollRes.status})`,
      };
    }

    if (pollJson.status === 'running') {
      applyJobStepsToCache(agent, pollJson.steps, {
        running: true,
        outputs: pollJson.outputs,
        progress: typeof pollJson.progress === 'number' ? pollJson.progress : null,
      });
      const liveIndex = Array.isArray(pollJson.steps) ? pollJson.steps.length : lastReported + 1;
      await saveRunPosition(agent.id, Math.min(liveIndex, agent.steps.length - 1), pollJson.progress);
      // Announce each step the job has newly finished, so the card ticks over.
      const done = Array.isArray(pollJson.steps) ? pollJson.steps.length : 0;
      for (let s = lastReported + 1; s < done; s++) {
        const rec = pollJson.steps[s];
        emit(onEvent, 'step-done', {
          stepIndex: s,
          modelId: rec?.modelId || agent.steps[s]?.model_id || '',
          durationMs: rec?.durationMs || 0,
          error: null,
        });
      }
      if (done > 0) lastReported = done - 1;
      if (typeof pollJson.progress === 'number') {
        emit(onEvent, 'step-progress', { stepIndex: Math.min(done, agent.steps.length - 1), percent: pollJson.progress });
      }
      continue;
    }

    final = pollJson;
    break;
  }

  await writeRunJob(null);

  if (!final) {
    applyJobFailureToCache(agent, { error: { message: 'The run exceeded the polling budget.' } });
    return { started: true, ok: false, failedIndex: -1, code: 'poll_timeout', message: 'The run exceeded the polling budget.' };
  }

  if (!final.success) {
    applyJobFailureToCache(agent, final);
    return {
      started: true, ok: false,
      failedIndex: Number.isInteger(final.error?.stepIndex) ? final.error.stepIndex : -1,
      message: final.error?.message || 'The run did not finish.',
    };
  }

  applyJobStepsToCache(agent, final.steps, { running: false, outputs: final.outputs });
  for (let s = lastReported + 1; s < agent.steps.length; s++) {
    const rec = Array.isArray(final.steps) ? final.steps.find(x => Number(x?.stepIndex) === s) : null;
    emit(onEvent, 'step-done', {
      stepIndex: s,
      modelId: rec?.modelId || agent.steps[s]?.model_id || '',
      durationMs: rec?.durationMs || 0,
      error: null,
    });
  }
  // Billed once per job, not per step.
  return { started: true, ok: true, credits: Number(final.creditsCharged) || 0 };
}

/** True when every step has a fresh, clean cached run — what unlocks Publish. */
function passed(doc) {
  const agent = doc || state.agent;
  const steps = agent?.steps || [];
  if (!steps.length) return false;
  for (let i = 0; i < steps.length; i++) {
    const rec = state.previewOutputs?.[i];
    if (!rec || rec.running || rec.error) return false;
    if (rec.output == null && rec.exposed == null) return false;
    if (rec.docHash !== stepDocHash(steps[i])) return false;
  }
  return true;
}

/** Mirrors MEDIA_GRID_MAX in main.js (private there; importing it would cycle). */
const SHOWCASE_MAX = 5;

/**
 * Attach the final output to the showcase gallery. The grid treats
 * showcase_images + videos as ONE capped list and re-splits by kind on write, so
 * this must too — appending to one array overflows the cap. Returns items added.
 */
function attachToMedia(report) {
  if (!report?.ok) return 0;
  const picks = (report.outputs || []).filter(o => o?.url && o.kind !== 'audio');
  if (!picks.length) return 0;

  const images = Array.isArray(state.agent.showcase_images) ? state.agent.showcase_images.filter(Boolean) : [];
  const videos = Array.isArray(state.agent.showcase_videos) ? state.agent.showcase_videos.filter(Boolean) : [];
  const combined = [...images, ...videos];
  const kindOf = (u) => (videos.includes(u) ? 'video' : images.includes(u) ? 'image' : (isVideoUrl(u) ? 'video' : 'image'));

  let added = 0;
  for (const p of picks) {
    if (combined.length >= SHOWCASE_MAX) break;
    if (combined.includes(p.url)) continue; // re-running must not duplicate
    combined.push(p.url);
    added++;
  }
  if (!added) return 0;

  state.agent.showcase_videos = combined.filter(u => kindOf(u) === 'video');
  state.agent.showcase_images = combined.filter(u => kindOf(u) !== 'video');
  notify();
  return added;
}

/** True when this report's outputs are already in the gallery. */
function inMedia(report) {
  const picks = (report?.outputs || []).filter(o => o?.url && o.kind !== 'audio');
  if (!picks.length) return false;
  const all = [...(state.agent.showcase_images || []), ...(state.agent.showcase_videos || [])];
  return picks.every(p => all.includes(p.url));
}

/** Drop this report's outputs from the gallery, so another run can take the slot. */
function detachFromMedia(report) {
  const urls = new Set((report?.outputs || []).map(o => o?.url).filter(Boolean));
  if (!urls.size) return 0;
  const images = state.agent.showcase_images || [];
  const videos = state.agent.showcase_videos || [];
  const removed = images.filter(u => urls.has(u)).length + videos.filter(u => urls.has(u)).length;
  if (!removed) return 0;
  state.agent.showcase_images = images.filter(u => !urls.has(u));
  state.agent.showcase_videos = videos.filter(u => !urls.has(u));
  notify();
  return removed;
}

/**
 * Re-attach to a run this tab left in flight before a refresh. Re-polls the
 * same job — no second kick-off, so nothing is charged twice. Returns null
 * when there is nothing pending for the draft on screen.
 */
async function resume({ doc, onEvent } = {}) {
  const agent = doc || cleanAgentForExport(state.agent);
  if (!agent?.id || !Array.isArray(agent.steps) || agent.steps.length === 0) return null;
  await primeRunJob();
  if (!pendingRunJob(agent.id)) return null;

  emit(onEvent, 'run-start', { totalSteps: agent.steps.length, resumed: true });
  const result = await runWholePipeline(agent, state.testInputs || {}, onEvent);
  const steps = collectSteps(agent);

  if (!result.ok) {
    const at = Number.isInteger(result.failedIndex) ? result.failedIndex : -1;
    const rec = steps.find(s => s.stepIndex === at);
    const report = {
      ok: false, phase: 'run', stepIndex: at,
      modelId: rec?.modelId || agent.steps[at]?.model_id || '',
      code: 'step_failed',
      message: result.message || rec?.error || 'The run did not finish.',
      inputs: state.testInputs || {}, steps,
    };
    emit(onEvent, 'error', report);
    return report;
  }

  const report = {
    ok: true,
    inputs: state.testInputs || {},
    outputs: finalOutputs(steps),
    finalOutput: steps[steps.length - 1]?.exposed,
    credits: result.credits || steps.reduce((sum, s) => sum + (s.creditsCharged || 0), 0),
    steps,
  };
  emit(onEvent, 'done', report);
  return report;
}

/** True when this tab has a whole-pipeline run still in flight. */
function hasPendingRun(agentId) {
  return !!pendingRunJob(agentId || state.agent?.id);
}

export const tester = { run, resume, hasPendingRun, primeRunJob, passed, attachToMedia, detachFromMedia, inMedia };
