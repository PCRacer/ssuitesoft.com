/**
 * Agent Builder — utilities.
 *
 * Validation, cost computation, placeholder extraction, DOM helpers.
 * All pure functions — no state mutation, no DOM side effects.
 */

import { state } from './state.js';

/* ---------------- Schema control resolution ----------------
 *
 * Given a schema key (the property name a model expects, e.g. "image_url")
 * and its property descriptor, decide which `ui_component` the editor should
 * render. The resolution mirrors what the runtime mapper does in
 * src/models/model-input-mapper.ts — the wizard would feel wrong if the
 * runner ends up showing a file uploader for `image_url` while the wizard
 * shows a textarea for the same key.
 *
 * Order, cheapest first:
 *   1. Catalog `concepts[<key>]` exists                 → use that concept's ui_component
 *   2. Some concept has `mapped_to` that includes <key> → use that concept's ui_component
 *   3. Property declares `enum`                         → 'select'
 *   4. Property `type`                                  → 'toggle' / 'input' (number) /
 *                                                          'textarea' (string fallback) /
 *                                                          'json-input' (object/array)
 *
 * Returns `{ uiComponent, source, conceptId, enum }`:
 *   - `source` ∈ 'catalog-id' | 'catalog-mapped_to' | 'enum' | 'type'
 *   - `conceptId` set when source is one of the catalog branches; useful when
 *     callers want to read further metadata (enum/range/description) from the
 *     concept.
 *   - `enum` echoed when the concept or property declares one, so the renderer
 *     doesn't have to re-derive it.
 */
export function resolveSchemaControl(key, prop) {
  const catalog = Array.isArray(state.config.catalog) ? state.config.catalog : [];
  const property = prop || {};

  // 1. Exact-id match — the most common case for canonical keys
  //    (aspect_ratio, duration, seed, …).
  const byId = catalog.find(c => c.id === key);
  if (byId && byId.ui_component) {
    return {
      uiComponent: byId.ui_component,
      source: 'catalog-id',
      conceptId: byId.id,
      enum: Array.isArray(byId.enum) ? byId.enum : (Array.isArray(property.enum) ? property.enum : null),
    };
  }

  // 2. Reverse lookup via mapped_to — provider-specific names like
  //    `image_url`, `first_frame_image`, `input_image` all map back to the
  //    canonical `image` concept.
  //
  // EXCEPTION: never resolve a key to the reserved `prompt` concept. The
  // `prompt` concept's mapped_to lists provider text keys (`text`, `gen_text`,
  // `llm_prompt`, …), but `prompt` is owned by the step's `soul`, not by a form
  // field — resolving here would wire `step.schema[key] = "${prompt}"`, which
  // points at a field that can't exist and breaks the run with "Placeholder
  // ${prompt} does not match…". A key like a TTS model's `text` must stay its
  // own key (→ custom field `${text}`), never collapse into `${prompt}`.
  for (const concept of catalog) {
    if (concept.id === 'prompt') continue;
    if (Array.isArray(concept.mapped_to) && concept.mapped_to.includes(key) && concept.ui_component) {
      return {
        uiComponent: concept.ui_component,
        source: 'catalog-mapped_to',
        conceptId: concept.id,
        enum: Array.isArray(concept.enum) ? concept.enum : (Array.isArray(property.enum) ? property.enum : null),
      };
    }
  }

  // 3. Enum on the property itself — even without a catalog hit, an enum is
  //    a closed choice list, so render a select.
  if (Array.isArray(property.enum) && property.enum.length > 0) {
    return { uiComponent: 'select', source: 'enum', conceptId: null, enum: property.enum };
  }

  // 4. Fall back to the property's JSON-Schema type.
  switch (property.type) {
    case 'boolean': return { uiComponent: 'toggle', source: 'type', conceptId: null, enum: null };
    case 'integer':
    case 'number':  return { uiComponent: 'input',  source: 'type', conceptId: null, enum: null };
    case 'array':
    case 'object':  return { uiComponent: 'json-input', source: 'type', conceptId: null, enum: null };
    case 'string':
    default:        return { uiComponent: 'textarea', source: 'type', conceptId: null, enum: null };
  }
}

/* ---------------- Auto-field detour (Pass 4 → Pass 3 sync) ----------------
 *
 * When a step's schema declares a key that has a canonical concept in
 * AGENT_INPUT_MAP, the wizard treats that as a strong signal: the end user
 * will need a form control for it (an `image_url` is something the end user
 * uploads, an `aspect_ratio` is something they pick). The author shouldn't
 * have to manually duplicate that wiring across passes.
 *
 * `ensureFieldForKey` is the bridge. Given a schema key + its property
 * descriptor:
 *
 *   - If `resolveSchemaControl` finds a catalog match, ensure a compact
 *     `{ id: <conceptId> }` entry exists in `state.agent.fields`. The
 *     resolver carries the conceptId; we use that as the field id so the
 *     mapper (and `${conceptId}` placeholders) all agree on naming.
 *
 *   - Returns `{ fieldId, added }`. `fieldId` is the canonical id to wire
 *     `step.schema[key] = '${' + fieldId + '}'`. `added` tells the caller
 *     whether a *new* field landed in `fields[]` this call (so the wizard
 *     can decide to detour to Pass 3 to show what changed).
 *
 *   - Returns `null` when the key has no catalog match. The caller leaves
 *     the value alone (literal entry / textarea fallback).
 *
 * Newly-added fields are tagged with `__autoAdded: true` so Pass 3 can
 * highlight them. The flag is `__`-prefixed and stripped from the export.
 */
export function ensureFieldForKey(key, prop) {
  const resolved = resolveSchemaControl(key, prop);
  if (!resolved.conceptId) return null;
  const conceptId = resolved.conceptId;

  // Already present (catalog entry or custom field with same id)?
  const existing = state.agent.fields.find(f => f.id === conceptId);
  if (existing) {
    return { fieldId: conceptId, added: false };
  }

  // Add a compact catalog entry. Defaults flow through from AGENT_INPUT_MAP
  // at render time — we don't snapshot anything here.
  state.agent.fields.push({ id: conceptId, __autoAdded: true });
  return { fieldId: conceptId, added: true };
}

/**
 * Scan a free-form string (typically a prompt template or any textarea-shaped
 * schema value) for `${id}` placeholders and auto-promote any unknown id into
 * a custom string field. The author's typing flow is:
 *
 *   "make it ${shadowPrompt}, with ${lighting}"
 *
 * — the moment they type `${shadowPrompt}`, the wizard recognizes that as an
 * intent to wire a form value in, and synthesizes a custom textarea field
 * `shadowPrompt` so Pass 3 has somewhere to capture the user's input. Ids
 * that already resolve (an existing field, an upstream output_id from the
 * same agent) are left alone.
 *
 * Returns the array of `field_id`s newly added. Callers (the textarea/input
 * `oninput` handlers) can ignore the value or use it to flash a toast.
 *
 * `upstreamOutputIds` lets callers pass the set of output ids that count as
 * "already known" — usually `state.agent.steps.map(s => s.output_id)`.
 */
// Placeholder ids the wizard refuses to synthesize a field for. `prompt` is
// reserved: the model's `schema.prompt` slot is filled by the resolver from
// `step.soul` at runtime — having a form field also named `prompt` would
// create a conflicting second source of truth.
const RESERVED_PLACEHOLDER_IDS = new Set(['prompt']);

// Placeholder-token patterns, in one place so the allowed id charset evolves
// uniformly. Two variants exist: the plain one (field/output ids) and the
// dot-path one (`${research.priceTrend}` — a content-research output's
// sub-fields). Returned as fresh instances from a factory because a shared
// `/g` regex carries `lastIndex` between calls and would desync reuse.
const PLACEHOLDER_CHARS = 'a-zA-Z0-9_-';
const PLACEHOLDER_DOT_CHARS = 'a-zA-Z0-9_.-';
/** Fresh global matcher for `${id}` tokens (dot-paths optional). */
const placeholderMatcher = (dotPaths = false) =>
  new RegExp('\\$\\{([' + (dotPaths ? PLACEHOLDER_DOT_CHARS : PLACEHOLDER_CHARS) + ']+)\\}', 'g');
/** Tests whether a whole string is exactly one `${id}` token (no dot-paths). */
const EXACT_PLACEHOLDER_RE = new RegExp('^\\$\\{([' + PLACEHOLDER_CHARS + ']+)\\}$');
/** Tests whether a string CONTAINS a dot-path-capable `${id}` token. */
const CONTAINS_DOT_PLACEHOLDER_RE = new RegExp('\\$\\{[' + PLACEHOLDER_DOT_CHARS + ']+\\}');

export function autoPromotePlaceholdersFromText(text, upstreamOutputIds = []) {
  if (typeof text !== 'string') return [];
  const known = new Set([
    ...state.agent.fields.map(f => f.id),
    ...upstreamOutputIds.filter(Boolean),
  ]);
  const added = [];
  const re = placeholderMatcher();
  let m;
  while ((m = re.exec(text)) !== null) {
    const id = m[1];
    if (RESERVED_PLACEHOLDER_IDS.has(id)) continue;
    if (known.has(id)) continue;
    // Skip canonical concept ids that have a catalog match — they should
    // route through `ensureFieldForKey` so they pick up the catalog's
    // ui_component (file-upload, select, etc.), not a default textarea.
    const resolved = resolveSchemaControl(id, null);
    if (resolved.conceptId) {
      const ensured = ensureFieldForKey(id, null);
      if (ensured?.added) {
        added.push(ensured.fieldId);
        known.add(ensured.fieldId);
      } else if (ensured) {
        known.add(ensured.fieldId);
      }
      continue;
    }
    // Pure custom string field — author wrote `${something_arbitrary}` in a
    // prompt. Seed as a textarea so the user can type free-form text.
    state.agent.fields.push({
      __custom: true,
      __autoAdded: true,
      id,
      title: id.replace(/[_-]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
      description: '',
      type: 'string',
      ui_component: 'textarea',
      default: null,
      visible: true,
      advanced: false,
      step: false,
    });
    known.add(id);
    added.push(id);
  }
  return added;
}

/* ---------------- Cost floor ---------------- */

/**
 * Pull the min/max numeric range a field can produce. Used to bound a step's
 * floor when a schema key is wired to `${field_id}` and the field has a
 * `costMultiplier` set. Numeric fields use their `range` (or the enum's
 * numeric values); enum fields use the multiplier map directly.
 */
function fieldMultiplierRange(field) {
  if (!field) return null;
  const cm = field.costMultiplier;
  if (cm == null) return null;

  // Numeric multiplier — single float. The end user's picked value scales
  // the floor; we use the field's declared range (or enum bounds) as
  // worst-case [min,max].
  if (typeof cm === 'number') {
    let lo = null, hi = null;
    if (Array.isArray(field.enum) && field.enum.length) {
      const nums = field.enum.map(Number).filter(Number.isFinite);
      if (nums.length) { lo = Math.min(...nums); hi = Math.max(...nums); }
    } else if (field.range && (typeof field.range.min === 'number' || typeof field.range.max === 'number')) {
      if (typeof field.range.min === 'number') lo = field.range.min;
      if (typeof field.range.max === 'number') hi = field.range.max;
    }
    if (lo == null && hi == null) {
      // No bounds — assume the picked value is 1× and the multiplier carries
      // the whole weight. Conservative: same min and max.
      return { min: cm, max: cm };
    }
    if (lo == null) lo = hi;
    if (hi == null) hi = lo;
    return { min: lo * cm, max: hi * cm };
  }

  // Per-value multiplier map — every option contributes its own multiplier.
  if (cm && typeof cm === 'object') {
    const values = Object.values(cm).filter(v => typeof v === 'number' && Number.isFinite(v));
    if (values.length === 0) return null;
    return { min: Math.min(...values), max: Math.max(...values) };
  }
  return null;
}

/**
 * Compute the per-step USD floor.
 *
 *   floor.min = model.cost.base × Π (multipliers.min)
 *   floor.max = model.cost.base × Π (multipliers.max)
 *
 * The base comes from the registry (per-image / per-run / per-second). Each
 * multiplier comes from a schema key that points at a form field with
 * `costMultiplier` set; everything else is fixed. The user's rule:
 * **a field without a costMultiplier has no price impact at all.**
 *
 * Literal values in `step.schema` are also ignored on purpose: they're a
 * fixed cost driver (e.g. `num_outputs: 4`) baked into the agent, but
 * without the author saying "this is a multiplier", the wizard doesn't
 * guess. The author can express that intent by promoting the literal to a
 * field with the appropriate `costMultiplier`.
 */
export function stepFloorUsd(step) {
  const model = state.config.models.find(m => m.id === step.model_id);
  if (!model || !model.cost) return { min: 0, max: 0 };
  const cost = model.cost;

  // 1. Base unit cost.
  let baseMin = 0, baseMax = 0;
  if (cost.unit === 'image' || cost.unit === 'run') {
    const per = Number(cost.perOutput || 0);
    baseMin = baseMax = per;
  } else if (cost.unit === 'video_sec') {
    const per = Number(cost.perSecond || 0);
    // Per-second pricing collapses to (perSecond × seconds). When a `duration`
    // field with costMultiplier supplies the seconds, the field-driven branch
    // below handles it. Otherwise the registry's `durations:` tag gives us a
    // safe envelope.
    let minDur = 1, maxDur = 10;
    if (Array.isArray(model.tags)) {
      const durTag = model.tags.find(t => /^durations:/.test(String(t)));
      if (durTag) {
        const nums = String(durTag).replace(/^durations:/, '').split(',')
          .map(n => Number(n)).filter(Number.isFinite);
        if (nums.length) { minDur = Math.min(...nums); maxDur = Math.max(...nums); }
      }
    }
    baseMin = per * minDur;
    baseMax = per * maxDur;
  } else {
    return { min: 0, max: 0 }; // unknown unit
  }

  // 2. Walk the schema. For every `${field_id}` reference whose field has a
  //    costMultiplier, fold that range in. Literals + non-multiplier fields
  //    don't contribute.
  let mulMin = 1, mulMax = 1;
  // exact match — partial references inside larger strings aren't multipliers
  const placeholderRe = EXACT_PLACEHOLDER_RE;
  const schema = step.schema && typeof step.schema === 'object' ? step.schema : {};
  for (const value of Object.values(schema)) {
    if (typeof value !== 'string') continue;
    const m = placeholderRe.exec(value.trim());
    if (!m) continue;
    const fieldId = m[1];
    const field = state.agent.fields.find(f => f.id === fieldId);
    const range = fieldMultiplierRange(field);
    if (!range) continue;
    mulMin *= range.min;
    mulMax *= range.max;
  }

  return { min: baseMin * mulMin, max: baseMax * mulMax };
}

/**
 * Per-step floor breakdown. The sidebar uses this to show one line per step
 * (and a total). It also surfaces whether the step is a checkpoint, so the
 * UI can label regenerate-eligible steps.
 */
export function stepwiseFloorUsd() {
  return state.agent.steps.map((s, idx) => ({
    index: idx,
    model_id: s.model_id,
    kind: s.kind,
    isCheckpoint: !!s.step,
    isFinal: idx === state.agent.steps.length - 1,
    ...stepFloorUsd(s),
  }));
}

export function totalFloorUsd() {
  let min = 0, max = 0;
  for (const s of state.agent.steps) {
    const { min: a, max: b } = stepFloorUsd(s);
    min += a; max += b;
  }
  return { min, max };
}

export function floorCredits() {
  const usdPerCredit = Number(state.config.billing?.usdPerCredit || 0.02);
  if (!Number.isFinite(usdPerCredit) || usdPerCredit <= 0) return 0;
  // Per-step minimum 1 credit. Token-based models (GPT etc.) compute to
  // <0.01 USD and round to 0 credits without this floor — they would
  // contribute nothing to the total even though the platform still bills
  // a non-zero reservation for them. Sum credits per step (not USD) so the
  // floor applies before aggregation; otherwise multiple sub-cent steps
  // would round to 0 collectively.
  let total = 0;
  for (const s of state.agent.steps) {
    // Non-model kinds (content-research, …) are priced by their kind catalog
    // entry from /config — base credits + each enabled tool's creditCost.
    if (s?.kind && s.kind !== 'model') {
      total += kindStepCredits(s);
      continue;
    }
    if (!s?.model_id) continue;
    const { max } = stepFloorUsd(s);
    total += Math.max(1, Math.ceil(max / usdPerCredit));
  }
  return total;
}

/**
 * Additive credits for a non-model step kind, read from the /config stepKinds
 * catalog: baseCredits + Σ each enabled tool's creditCost. Returns 0 when the
 * kind isn't in the catalog.
 */
export function kindStepCredits(step) {
  const kinds = Array.isArray(state.config?.stepKinds) ? state.config.stepKinds : [];
  const spec = kinds.find(k => k.kind === step?.kind);
  if (!spec) return 0;
  let credits = Number(spec.baseCredits) || 0;
  const enabled = Array.isArray(step.tools) ? step.tools : [];
  for (const toolId of enabled) {
    const tool = (spec.tools || []).find(t => t.id === toolId);
    if (tool) credits += Number(tool.creditCost) || 0;
  }
  return credits;
}

/**
 * Convert a step's USD range to credits. Reused by the sidebar breakdown and
 * by Pass 4 publish gating.
 */
export function usdToCredits(usd) {
  const usdPerCredit = Number(state.config.billing?.usdPerCredit || 0.02);
  if (!Number.isFinite(usdPerCredit) || usdPerCredit <= 0) return 0;
  return Math.ceil(usd / usdPerCredit);
}

/* ---------------- Placeholder discovery ---------------- */

/**
 * Walk a step's schema object collecting every ${id} placeholder. Returns the unique
 * set of ids referenced. Used both for validation (every id must resolve) and for
 * the prompt-editor tag rows.
 */
export function placeholdersInSchema(schema) {
  const found = new Set();
  const stack = [schema];
  while (stack.length) {
    const v = stack.pop();
    if (typeof v === 'string') {
      const re = placeholderMatcher();
      let m;
      while ((m = re.exec(v)) !== null) found.add(m[1]);
    } else if (Array.isArray(v)) {
      for (const item of v) stack.push(item);
    } else if (v && typeof v === 'object') {
      for (const item of Object.values(v)) stack.push(item);
    }
  }
  return Array.from(found);
}

/* ---------------- Per-pass validation ---------------- */

export function validateMetadata() {
  const errors = [];
  const a = state.agent;
  if (!a.id || !/^[a-z0-9][a-z0-9-]*$/.test(a.id)) errors.push('ID must be kebab-case (a-z, 0-9, dash).');
  else if (state.idTaken) errors.push(`ID "${a.id}" is already used by a published agent. Pick a different id.`);
  if (!a.name.trim()) errors.push('Name is required.');
  // version is server-owned (read-only in the UI); we don't validate it here.
  if (!a.description.trim()) errors.push('Description is required.');
  if (!a.category.trim()) errors.push('Category is required.');
  return errors;
}

export function validateTemplate() {
  const errors = [];
  if (!state.config.templates.includes(state.agent.template)) {
    errors.push(`Template must be one of: ${state.config.templates.join(', ')}.`);
  }
  return errors;
}

/**
 * For a field row, return the effective enum if any. Catalog fields inherit
 * their concept's enum unless the author has narrowed it; custom fields read
 * their own. Returns `null` when no enum applies.
 */
function effectiveEnumFor(field) {
  if (field.__custom) {
    return Array.isArray(field.enum) && field.enum.length ? field.enum : null;
  }
  const concept = state.config.catalog.find(c => c.id === field.id);
  const base = Array.isArray(concept?.enum) ? concept.enum : null;
  const override = Array.isArray(field.enum) ? field.enum : null;
  const eff = override ?? base;
  return Array.isArray(eff) && eff.length ? eff : null;
}

export function validateFields() {
  const errors = [];
  const seen = new Set();
  for (const f of state.agent.fields) {
    if (!f.id || !/^[a-zA-Z0-9_-]+$/.test(f.id)) errors.push(`Field "${f.id}" has an invalid id.`);
    if (seen.has(f.id)) errors.push(`Duplicate field id: ${f.id}`);
    seen.add(f.id);
    // `field.step` (wizard-form gating) is no longer template-gated — it's
    // valid under every template now. The old V2-only check has been removed.

    // Enum-locked default: when a field declares an enum, its `default` MUST
    // be one of those values (or null/absent). The wizard's editor already
    // renders a <select> for enum defaults, but a stale value from before the
    // enum was narrowed could still slip through — catch it here.
    const enumOpts = effectiveEnumFor(f);
    if (enumOpts && f.default != null && f.default !== '' && !enumOpts.map(String).includes(String(f.default))) {
      errors.push(`Field "${f.id}": default "${f.default}" is not in enum [${enumOpts.join(', ')}].`);
    }
  }
  return errors;
}

export function validateSteps() {
  const errors = [];
  const steps = state.agent.steps;
  if (steps.length === 0) errors.push('Add at least one step.');
  if (steps.length > 5) errors.push('Maximum 5 steps allowed.');

  const fieldIds = new Set(state.agent.fields.map(f => f.id));
  const allOutputs = new Set(steps.map(x => x.output_id).filter(Boolean));
  // Collect every ${id} (dot-paths allowed) reachable from a value tree.
  const collectRefs = (node, acc) => {
    if (typeof node === 'string') {
      const re = placeholderMatcher(true);
      let m;
      while ((m = re.exec(node)) !== null) acc.push(m[1]);
    } else if (Array.isArray(node)) {
      node.forEach(v => collectRefs(v, acc));
    } else if (node && typeof node === 'object') {
      Object.values(node).forEach(v => collectRefs(v, acc));
    }
    return acc;
  };
  const outputIds = new Set();
  steps.forEach((s, i) => {
    const isContentResearch = s.kind === 'content-research';

    if (!isContentResearch && !s.model_id) errors.push(`Step ${i + 1}: pick a model.`);
    if (!s.output_id) errors.push(`Step ${i + 1}: set an output_id.`);
    else {
      if (outputIds.has(s.output_id)) errors.push(`Step ${i + 1}: duplicate output_id "${s.output_id}".`);
      if (fieldIds.has(s.output_id)) errors.push(`Step ${i + 1}: output_id "${s.output_id}" collides with a field id.`);
      outputIds.add(s.output_id);
    }

    if (isContentResearch) {
      // No model_id / schema requirement. Validate placeholder roots across
      // soul + outputSchema (a dot-path only needs its root to be known).
      const refs = [];
      if (typeof s.soul === 'string' && s.soul) collectRefs(s.soul, refs);
      if (s.outputSchema && typeof s.outputSchema === 'object') collectRefs(s.outputSchema, refs);
      for (const ref of refs) {
        const root = ref.split('.')[0];
        if (!fieldIds.has(root) && !allOutputs.has(root)) {
          errors.push(`Step ${i + 1}: unresolved \${${ref}}.`);
        }
      }
      return; // content-research step done
    }

    if (!s.schema || typeof s.schema !== 'object') {
      errors.push(`Step ${i + 1}: schema is empty.`);
    } else {
      // Placeholder resolution covers both the schema values AND the soul
      // (the wizard's top-level prompt for this step). Auto-promote handles
      // the typing path; this is the safety net for hand-edited imports or
      // edge cases the proactive scan missed.
      const refs = placeholdersInSchema(s.schema);
      if (typeof s.soul === 'string' && s.soul) {
        const re = placeholderMatcher(true);
        let m;
        while ((m = re.exec(s.soul)) !== null) refs.push(m[1]);
      }
      for (const ref of refs) {
        const root = ref.split('.')[0];
        if (!fieldIds.has(root) && !allOutputs.has(root)) {
          errors.push(`Step ${i + 1}: unresolved \${${ref}}.`);
        }
      }
      // Enum-locked literal: when the model's schema declares an enum for a
      // key and the author wrote a literal value (not a placeholder), it must
      // be in the enum. Placeholders bypass this check because their runtime
      // value isn't known at edit time — the runner validates them.
      const props = s.__schemaMeta?.properties || {};
      for (const [key, value] of Object.entries(s.schema)) {
        const prop = props[key];
        if (!prop || !Array.isArray(prop.enum) || prop.enum.length === 0) continue;
        if (typeof value === 'string' && CONTAINS_DOT_PLACEHOLDER_RE.test(value)) continue; // placeholder
        if (value == null || value === '') continue; // empty (optional unset)
        if (!prop.enum.map(String).includes(String(value))) {
          errors.push(`Step ${i + 1}: ${key} = "${value}" is not in enum [${prop.enum.join(', ')}].`);
        }
      }
    }
  });
  if (steps.length > 0 && steps[steps.length - 1].step === true) {
    errors.push('The final step must be silent (step=false).');
  }
  return errors;
}

export function validateCredits() {
  const errors = [];
  const floor = floorCredits();
  if (!Number.isFinite(state.creditsPerRun) || state.creditsPerRun < floor) {
    errors.push(`Credits per run must be ≥ floor (${floor}).`);
  }
  return errors;
}

/* ---------------- Derived fields ---------------- */

export function recomputeDerived() {
  // inputTypes: union of file-upload field kinds; default to "text"
  const inputTypes = new Set();
  for (const f of state.agent.fields) {
    if (f.ui_component === 'file-upload') inputTypes.add('image'); // safe default
  }
  if (inputTypes.size === 0) inputTypes.add('text');
  state.agent.inputTypes = Array.from(inputTypes);

  // outputTypes: from the final step's model tags
  const out = new Set();
  const last = state.agent.steps[state.agent.steps.length - 1];
  if (last) {
    const model = state.config.models.find(m => m.id === last.model_id);
    if (model?.tags) {
      for (const t of model.tags) {
        if (/^video/.test(t)) out.add('video/mp4');
        if (/^image/.test(t)) out.add('image/png');
        if (/^audio/.test(t)) out.add('audio/mpeg');
      }
    }
  }
  state.agent.outputTypes = Array.from(out);

  // costEstimate
  const { min, max } = totalFloorUsd();
  const usdPerCredit = Number(state.config.billing?.usdPerCredit || 0.02);
  const creditsUsd = state.creditsPerRun * usdPerCredit;
  state.agent.costEstimate = {
    minCost: Number(min.toFixed(6)),
    maxCost: Number((max + Math.max(creditsUsd - min, 0)).toFixed(6)),
    currency: 'USD',
  };
}

/* ---------------- DOM helpers ---------------- */

export function $(sel, root = document) { return root.querySelector(sel); }
export function $$(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }

export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') node.className = v;
    else if (k === 'dataset') Object.assign(node.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v === true) node.setAttribute(k, '');
    else if (v === false || v == null) { /* skip */ }
    else node.setAttribute(k, String(v));
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return node;
}

export function toast(msg, kind = 'info', ms = 3000) {
  const node = document.getElementById('ab-toast');
  if (!node) return;
  node.textContent = msg;
  node.className = 'ab-toast visible' + (kind ? ' ' + kind : '');
  setTimeout(() => { node.className = 'ab-toast'; }, ms);
}
