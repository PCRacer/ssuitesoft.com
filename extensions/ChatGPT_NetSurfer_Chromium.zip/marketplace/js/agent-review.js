/**
 * Agent Review Module
 */

(() => {
  const blocks = Array.from(document.querySelectorAll('[data-agent-rating-block]'));
  const modal = document.getElementById('agent-review-modal');
  if (blocks.length === 0 || !modal) return;

  const agentId = blocks[0].dataset.agentId;
  if (!agentId) return;

  const triggers = Array.from(document.querySelectorAll('[data-rate-agent-trigger]'));

  /* ============================================================================
   * REAL RATINGS — disabled by default. Uncomment this block to switch the pill
   * from build-time seeded values (load-agents.mjs) to the live /summary feed.
   *
   * To enable, you also need to edit scripts/generate-pages.mjs. Then uncomment the four marked sections below.
   *
   * ============================================================================ */

  // --- (1) element refs ------------------------------------------------------
  // const pillEls  = Array.from(document.querySelectorAll('[data-agent-rating-pill]'));
  // const avgEls   = Array.from(document.querySelectorAll('[data-agent-rating-avg]'));
  // const countEls = Array.from(document.querySelectorAll('[data-agent-rating-count]'));

  // --- (2) helpers + loader --------------------------------------------------
  // function formatReviewCount(n) {
  //   if (n === 0) return 'No reviews yet';
  //   if (n < 1000) return `${n} ${n === 1 ? 'review' : 'reviews'}`;
  //   return `${(n / 1000).toFixed(1).replace(/\.0$/, '')}K reviews`;
  // }
  //
  // async function loadSummary() {
  //   try {
  //     const res = await fetch(`https://aitopia.ai/api/agents/${encodeURIComponent(agentId)}/reviews/summary`, { credentials: 'include' });
  //     if (res.ok) {
  //       const { avg, count } = await res.json();
  //       const c = Number(count) || 0;
  //       avgEls.forEach((el) => { el.textContent = c > 0 ? Number(avg).toFixed(1) : '—'; });
  //       countEls.forEach((el) => { el.textContent = formatReviewCount(c); });
  //     }
  //   } finally {
  //     pillEls.forEach((el) => el.classList.remove('invisible'));
  //   }
  // }

  const starsContainer = modal.querySelector('[data-review-stars]');
  const halfButtons = Array.from(modal.querySelectorAll('[data-review-half]'));
  const fillEls = Array.from(modal.querySelectorAll('[data-review-star-fill]'));
  const commentEl = modal.querySelector('[data-review-comment]');
  const submitEl = modal.querySelector('[data-review-submit]');
  const errorEl = modal.querySelector('[data-review-error]');
  const closeBtn = modal.querySelector('[data-review-modal-close]');

  let currentRating = 0;
  let isOpen = false;

  // For each star slot N (1..5), compute the clip-path right inset based on rating value.
  function paintStars(value) {
    fillEls.forEach((el, idx) => {
      const slot = idx + 1;
      let inset;
      if (value >= slot) inset = 0;
      else if (value >= slot - 0.5) inset = 50;
      else inset = 100;
      el.style.clipPath = `inset(0 ${inset}% 0 0)`;
    });
  }

  function setRating(value) {
    currentRating = value;
    paintStars(value);
    submitEl.disabled = value < 0.5;
  }

  function showError(msg) {
    errorEl.textContent = msg;
    errorEl.classList.remove('hidden');
  }

  function clearError() {
    errorEl.textContent = '';
    errorEl.classList.add('hidden');
  }

  function openModal() {
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    isOpen = true;
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    isOpen = false;
    document.body.style.overflow = '';
    clearError();
  }

  async function isUserLoggedIn() {
    const cached = window.AitopiaCache?.getUserProfile?.();
    if (cached) return true;
    try {
      const res = await fetch('https://aitopia.ai/auth/me', { credentials: 'include' });
      if (!res.ok) return false;
      const json = await res.json().catch(() => null);
      const userData = json?.data?.user || json?.data || json?.user || json;
      return Boolean(userData && typeof userData === 'object' && !Array.isArray(userData) && (userData.email || userData.key));
    } catch (_) {
      return false;
    }
  }

  async function loadMyReview() {
    const res = await fetch(`https://aitopia.ai/api/agents/${encodeURIComponent(agentId)}/reviews/me`, {
      credentials: 'include',
    });
    if (res.status === 401) return { authed: false };
    if (!res.ok) return { authed: true, review: null };
    const data = await res.json();
    return { authed: true, review: data.review || null };
  }

  function redirectToLogin() {
    const back = window.location.pathname + window.location.search;
    const url = `/login?redirect=${encodeURIComponent(back)}`;
    if (typeof window.showToast === 'function') {
      window.showToast({
        title: 'Login Required',
        message: 'Please log in to rate this agent.',
        type: 'warning',
        duration: 1500,
      });
      setTimeout(() => { window.location.href = url; }, 1500);
    } else {
      window.location.href = url;
    }
  }

  async function onTriggerClick() {
    clearError();
    if (!(await isUserLoggedIn())) {
      redirectToLogin();
      return;
    }
    const me = await loadMyReview();
    if (!me.authed) {
      redirectToLogin();
      return;
    }

    if (me.review) {
      setRating(Number(me.review.rating) || 0);
      commentEl.value = me.review.comment || '';
    } else {
      setRating(0);
      commentEl.value = '';
    }
    openModal();
  }

  async function onSubmit() {
    if (currentRating < 0.5) return;
    submitEl.disabled = true;
    clearError();

    try {
      const res = await fetch(`https://aitopia.ai/api/agents/${encodeURIComponent(agentId)}/reviews`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rating: currentRating,
          comment: commentEl.value.trim() || undefined,
        }),
      });

      if (res.status === 401) {
        redirectToLogin();
        return;
      }

      if (res.status === 403) {
        closeModal();
        if (typeof window.showToast === 'function') {
          window.showToast({
            title: 'Generation Required',
            message: 'Please run the agent before rating.',
            type: 'warning',
          });
        }
        return;
      }

      if (!res.ok) {
        showError('Could not submit your review. Please try again.');
        submitEl.disabled = false;
        return;
      }

      closeModal();
      // --- (3) refresh pill after submit -------------------------------------
      // loadSummary();
      if (typeof window.showToast === 'function') {
        window.showToast({
          title: 'Your rating has been submitted!',
          message: 'It will be added to the overall score soon.',
          type: 'success',
        });
      }
    } catch (_) {
      showError('Network error. Please try again.');
      submitEl.disabled = false;
    }
  }

  halfButtons.forEach((btn) => {
    const value = Number(btn.dataset.value);
    btn.addEventListener('click', () => setRating(value));
    btn.addEventListener('mouseenter', () => paintStars(value));
  });

  if (starsContainer) {
    starsContainer.addEventListener('mouseleave', () => paintStars(currentRating));
  }

  triggers.forEach((trigger) => trigger.addEventListener('click', onTriggerClick));

  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isOpen) closeModal();
  });
  if (submitEl) submitEl.addEventListener('click', onSubmit);

  // --- (4) initial pill load ---------------------------------------------------
  // loadSummary();
})();
