/**
 * Access Gate
 *
 * Cookie-backed access control for AgenticAI.
 * Keeps only a verified marker in localStorage and migrates legacy raw-code storage once.
 */

(function () {
  "use strict";

  const STORAGE_KEY = "superagent_access_code";
  const STORAGE_LABEL_KEY = "superagent_access_label";
  const STORAGE_EXPIRES_KEY = "superagent_access_expires";
  const VERIFIED_FLAG = "verified";

  function getStoredAccessValue() {
    return localStorage.getItem(STORAGE_KEY);
  }

  function getLegacyStoredCode() {
    const storedValue = getStoredAccessValue();
    if (!storedValue || storedValue === VERIFIED_FLAG) return null;
    return storedValue;
  }

  function hasVerifiedAccess() {
    return getStoredAccessValue() === VERIFIED_FLAG;
  }

  function storeAccess(label, expiresAt) {
    localStorage.setItem(STORAGE_KEY, VERIFIED_FLAG);
    if (label) {
      localStorage.setItem(STORAGE_LABEL_KEY, label);
    } else {
      localStorage.removeItem(STORAGE_LABEL_KEY);
    }
    if (expiresAt) {
      localStorage.setItem(STORAGE_EXPIRES_KEY, expiresAt);
    } else {
      localStorage.removeItem(STORAGE_EXPIRES_KEY);
    }
  }

  function clearAccess() {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(STORAGE_LABEL_KEY);
    localStorage.removeItem(STORAGE_EXPIRES_KEY);
  }

  function isExpired() {
    const expires = localStorage.getItem(STORAGE_EXPIRES_KEY);
    if (!expires) return false;
    return new Date(expires) < new Date();
  }

  async function verifyCode(code) {
    try {
      const res = await fetch("https://aitopia.ai/api/superagent/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
      });
      const json = await res.json();
      if (res.ok && json.success) {
        return { valid: true, label: json.label, expiresAt: json.expiresAt };
      }
      return { valid: false, error: json.error || "Invalid access code" };
    } catch (e) {
      return { valid: false, error: "Connection error. Please try again." };
    }
  }

  async function fetchStatus() {
    try {
      const res = await fetch("https://aitopia.ai/api/superagent/status");
      const json = await res.json();
      if (!res.ok) {
        return { enabled: true, authorized: false };
      }
      return {
        enabled: json.enabled !== false,
        authorized: Boolean(json.authorized),
        label: typeof json.label === "string" ? json.label : null,
        expiresAt: typeof json.expiresAt === "string" ? json.expiresAt : null,
      };
    } catch (_error) {
      return { enabled: true, authorized: false };
    }
  }

  function createGateOverlay() {
    const overlay = document.createElement("div");
    overlay.id = "superagent-gate";
    overlay.innerHTML = `
      <style>
        #superagent-gate {
          position: fixed;
          inset: 0;
          z-index: 99999;
          display: flex;
          align-items: center;
          justify-content: center;
          background: hsl(var(--ait-m-background));
        }
        #superagent-gate .gate-card {
          width: 100%;
          max-width: 400px;
          margin: 1rem;
          padding: 2rem;
          border-radius: 1.5rem;
          background: hsl(var(--ait-m-card));
          border: 1px solid hsl(var(--ait-m-border));
          text-align: center;
        }
        #superagent-gate .gate-logo {
          width: 64px;
          height: 64px;
          margin: 0 auto 1.5rem;
          background: linear-gradient(135deg, hsl(var(--ait-m-primary)), hsl(280, 80%, 60%));
          border-radius: 1rem;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 2rem;
        }
        #superagent-gate h1 {
          font-size: 1.5rem;
          font-weight: 700;
          color: hsl(var(--ait-m-foreground));
          margin-bottom: 0.5rem;
        }
        #superagent-gate p {
          color: hsl(var(--ait-m-muted-foreground));
          font-size: 0.875rem;
          margin-bottom: 1.5rem;
        }
        #superagent-gate input {
          width: 100%;
          padding: 0.875rem 1rem;
          font-size: 1rem;
          border-radius: 0.75rem;
          border: 1px solid hsl(var(--ait-m-border));
          background: hsl(var(--ait-m-background));
          color: hsl(var(--ait-m-foreground));
          outline: none;
          transition: border-color 0.15s;
        }
        #superagent-gate input:focus {
          border-color: hsl(var(--ait-m-primary));
        }
        #superagent-gate button {
          width: 100%;
          margin-top: 1rem;
          padding: 0.875rem;
          font-size: 1rem;
          font-weight: 600;
          border-radius: 0.75rem;
          border: none;
          background: hsl(var(--ait-m-primary));
          color: hsl(var(--ait-m-primary-foreground));
          cursor: pointer;
          transition: opacity 0.15s;
        }
        #superagent-gate button:hover {
          opacity: 0.9;
        }
        #superagent-gate button:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }
        #superagent-gate .gate-error {
          margin-top: 1rem;
          padding: 0.75rem;
          border-radius: 0.5rem;
          background: hsl(0, 70%, 50%, 0.1);
          color: hsl(0, 70%, 60%);
          font-size: 0.875rem;
        }
        #superagent-gate .gate-error.hidden {
          display: none;
        }
        #superagent-gate .gate-back {
          margin-top: 1.5rem;
        }
        #superagent-gate .gate-back a {
          color: hsl(var(--ait-m-muted-foreground));
          font-size: 0.875rem;
          text-decoration: none;
        }
        #superagent-gate .gate-back a:hover {
          color: hsl(var(--ait-m-foreground));
        }
      </style>
      <div class="gate-card">
        <div class="gate-logo">🔐</div>
        <h1>Access Required</h1>
        <p>Enter your access code to continue.</p>
        <form id="gate-form">
          <input type="password" id="gate-code" placeholder="Enter access code" autocomplete="off" required>
          <button type="submit" id="gate-submit">Continue</button>
        </form>
        <div id="gate-error" class="gate-error hidden"></div>
        <div class="gate-back">
          <a href="/marketplace/owner.html?owner=store">← Back to Store</a>
        </div>
      </div>
    `;
    return overlay;
  }

  function showGate() {
    // Hide the main app content
    const app = document.querySelector(".app");
    document.querySelectorAll("body > *").forEach((item) => {
      item.style.display = "none";
    });
    if (app) app.style.display = "none";

    // Create and show gate
    const gate = createGateOverlay();
    document.body.appendChild(gate);

    const form = document.getElementById("gate-form");
    const input = document.getElementById("gate-code");
    const submit = document.getElementById("gate-submit");
    const errorEl = document.getElementById("gate-error");

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const code = input.value.trim();
      if (!code) return;

      submit.disabled = true;
      submit.textContent = "Verifying…";
      errorEl.classList.add("hidden");

      const result = await verifyCode(code);

      if (result.valid) {
        storeAccess(result.label, result.expiresAt);
        gate.remove();
        if (app) app.style.display = "";
        document.querySelectorAll("body > *").forEach((item) => {
          item.style.display = "";
        });
      } else {
        errorEl.textContent = result.error;
        errorEl.classList.remove("hidden");
        submit.disabled = false;
        submit.textContent = "Continue";
        input.focus();
        input.select();
      }
    });

    input.focus();
  }

  async function checkAccess() {
    const legacyCode = getLegacyStoredCode();

    // Check if expired locally
    if (hasVerifiedAccess() && isExpired()) {
      clearAccess();
      showGate();
      return;
    }

    // One-time legacy migration for browsers/tests that still have a raw code stored.
    if (legacyCode) {
      const legacyResult = await verifyCode(legacyCode);
      if (!legacyResult.valid) {
        clearAccess();
        showGate();
        return;
      }

      storeAccess(legacyResult.label, legacyResult.expiresAt);
      return;
    }

    const status = await fetchStatus();
    if (!status.enabled || status.authorized) {
      storeAccess(status.label, status.expiresAt);
      return;
    }

    clearAccess();
    showGate();
  }

  // Run check when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", checkAccess);
  } else {
    checkAccess();
  }
})();
