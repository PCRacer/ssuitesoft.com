(function() {
  const CT_VERSION = 'creative-tabs-v1';
  if (window.__AITOPIA_CREATIVE_TABS__ === CT_VERSION) return;
  window.__AITOPIA_CREATIVE_TABS__ = CT_VERSION;

  const TABS = [
    {
      verb: 'generate',
      agents: [
        { image: 'https://aitopia.ai/agent-images/music-generator-1.webp', preTitle: 'Create sounds with', title: 'AI Music Generator', href: '/agents/music-generator' },
        { image: 'https://aitopia.ai/agent-images/mockup-studio-1.webp', preTitle: 'Generate product mockups with', title: 'AI Mockup Studio', href: '/agents/mockup-studio' },
        { image: 'https://aitopia.ai/agent-images/chibi-sticker-1.webp', preTitle: 'Transform your photo with', title: 'AI Chibi Sticker Maker', href: '/agents/chibi-sticker-maker' },
        { image: 'https://aitopia.ai/agent-images/youtube-thumbnail-generator-1.webp', preTitle: 'Create click-worthy thumbnails', title: 'AI Youtube Thumbnail Generator', href: '/agents/youtube-thumbnail-gen' },
      ],
    },
    {
      verb: 'analyze',
      agents: [
        { image: 'https://aitopia.ai/agent-images/ask-heurist-crypto-1.webp', preTitle: 'To get crypto insights,', title: 'AI Ask Heurist Crypto', href: '/agents/askheurist' },
        { image: 'https://aitopia.ai/agent-images/data-visualization-advisor-1.webp', preTitle: 'Get AI-powered suggestions with', title: 'AI Data Visualisation Advisor', href: '/agents/data-visualization' },
        { image: 'https://aitopia.ai/agent-images/amazon-product-search-1.webp', preTitle: 'Search and analyze products with', title: 'AI Amazon Product Search', href: '/agents/amazon-product-search' },
        { image: 'https://aitopia.ai/agent-images/smart-q-analytics-1.webp', preTitle: 'Answer questions about data with', title: 'AI Smart Q Analytics', href: '/agents/smart-q' },
      ],
    },
    {
      verb: 'edit',
      agents: [
        { image: 'https://aitopia.ai/agent-images/background-remover-1.webp', preTitle: 'Transform any scene,', title: 'AI Background Changer', href: '/agents/background-remover' },
        { image: 'https://aitopia.ai/agent-images/object-remover-1.webp', preTitle: 'Clean up any photo,', title: 'AI Object Remover', href: '/agents/object-remover' },
        { image: 'https://aitopia.ai/agent-images/watermark-remover-1.webp', preTitle: 'Remove marks instantly,', title: 'AI Watermark Remover', href: '/agents/watermark-remover-image' },
        { image: 'https://aitopia.ai/agent-images/upscaler-1.webp', preTitle: 'Boost resolution with', title: 'AI Image Upscaler', href: '/agents/image-upscaler' },
      ],
    },
  ];

  const ROTATE_INTERVAL = 3000;
  let currentIndex = 0;
  let intervalId = null;

  function arrowIcon() {
    return '<svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>';
  }

  function renderAgentCard(agent) {
    return `<a href="${agent.href}" class="group block rounded-2xl overflow-hidden bg-[#F5F5F7] dark:bg-[#0E0F0F] shadow-sm dark:shadow-none">
      <div class="relative h-[140px] lg:h-[160px] overflow-hidden">
        <img src="${agent.image}" alt="${agent.title}" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy">
      </div>
      <div class="flex items-center justify-between p-3 lg:p-4">
        <div class="min-w-0">
          <p class="hidden lg:block text-[#6B7280] dark:text-[#6B7280] text-[12px] font-[500] leading-[20px] truncate">${agent.preTitle}</p>
          <h4 class="text-gray-900 dark:text-white text-[12px] font-[500] lg:text-[16px] lg:font-[700] leading-[20px] truncate">${agent.title}</h4>
        </div>
        <div class="hidden lg:flex w-7 h-7 rounded-full border border-gray-200 dark:border-white/10 items-center justify-center text-gray-400 dark:text-white/40 group-hover:text-gray-700 dark:group-hover:text-white group-hover:border-gray-300 dark:group-hover:border-white/30 transition-colors duration-200 shrink-0 ml-2">
          ${arrowIcon()}
        </div>
      </div>
    </a>`;
  }

  function render() {
    const container = document.getElementById('creative-tabs-container');
    if (!container) return;

    container.innerHTML = `
<section class="bg-white dark:bg-[#0a0a0a] px-3 sm:px-4 lg:px-6 pb-4 lg:pb-4">
  <div class="max-w-[1370px] mx-auto">
    <div class="bg-[#F5F5F7] dark:bg-[#111] rounded-3xl p-6 sm:p-8 lg:p-10">
      <div class="flex flex-col lg:flex-row lg:items-center lg:gap-10">

        <!-- Left: Title + Description + CTA -->
        <div class="lg:w-[44%] shrink-0 mb-4 lg:mb-0">
          <div class="font-bold text-gray-900 dark:text-white mb-2 lg:mb-5 text-[24px] leading-[40px] sm:text-[38px] sm:leading-[44px] lg:text-[46px] lg:leading-[52px] xl:text-[54px] xl:leading-[58px]">
            What would you like to <br class="lg:hidden"><span id="ct-verb" class="text-primary" style="transition:opacity 0.3s ease">generate</span><span class="text-primary">?</span>
          </div>
          <p class="font-[400] text-[#9CA3AF] mb-2 lg:mb-8 text-[14px] leading-[22px] sm:text-[16px] sm:leading-[24px] lg:text-[16px]" style="max-width:420px">
            Select an AI agent to generate images, edit videos, remove backgrounds, or upscale photos in seconds.
          </p>
          <a href="/marketplace/agents.html" class="hidden lg:inline-flex items-center gap-2 py-3 px-7 text-[15px] font-[600] text-primary-foreground bg-primary hover:bg-primary/90 active:scale-[0.97] rounded-full transition-all duration-200">
            Explore All AI Tools
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </a>
        </div>

        <!-- Right: Agent Cards 2x2 Grid -->
        <div class="flex-1">
          <div id="ct-cards" class="grid grid-cols-2 gap-3 lg:gap-4">
            ${TABS[0].agents.map(a => renderAgentCard(a)).join('')}
          </div>
        </div>

      </div>
      <!-- Mobile CTA: below cards -->
      <div class="flex lg:hidden justify-center mt-6">
        <a href="/marketplace/agents.html" class="inline-flex items-center justify-center gap-2 h-[48px] px-7 text-[14px] font-[600] text-primary-foreground bg-primary hover:bg-primary/90 active:scale-[0.97] rounded-full transition-all duration-200">
          Explore All AI Tools
          <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        </a>
      </div>
    </div>
  </div>
</section>`;

    startRotation();
  }

  function updateTab(index) {
    const verbEl = document.getElementById('ct-verb');
    const cardsEl = document.getElementById('ct-cards');
    if (!verbEl || !cardsEl) return;

    const tab = TABS[index];
    const cards = cardsEl.children;

    verbEl.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    verbEl.style.opacity = '0';
    verbEl.style.transform = 'translateY(8px)';

    Array.from(cards).forEach((card, i) => {
      card.style.transition = `opacity 0.25s ease ${i * 60}ms, transform 0.25s ease ${i * 60}ms`;
      card.style.opacity = '0';
      card.style.transform = 'translateY(12px) scale(0.97)';
    });

    setTimeout(() => {
      verbEl.textContent = tab.verb;
      cardsEl.innerHTML = tab.agents.map(a => renderAgentCard(a)).join('');

      const newCards = cardsEl.children;
      Array.from(newCards).forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(16px) scale(0.97)';
      });

      requestAnimationFrame(() => {
        verbEl.style.opacity = '1';
        verbEl.style.transform = 'translateY(0)';

        Array.from(newCards).forEach((card, i) => {
          card.style.transition = `opacity 0.4s ease ${i * 80}ms, transform 0.4s ease ${i * 80}ms`;
          requestAnimationFrame(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0) scale(1)';
          });
        });
      });
    }, 350);
  }

  function startRotation() {
    if (intervalId) clearInterval(intervalId);
    intervalId = setInterval(() => {
      currentIndex = (currentIndex + 1) % TABS.length;
      updateTab(currentIndex);
    }, ROTATE_INTERVAL);
  }

  function init() {
    render();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
