function SSuiteTranslate(info,tab){chrome.tabs.create({url:"https://translate.google.com/?sl=auto&tl=en&text="+info.selectionText+"&op=translate"});};
chrome.contextMenus.removeAll(function(){chrome.contextMenus.create({id:"Translate",title:"Translate: %s",contexts:["selection"]});});
chrome.contextMenus.onClicked.addListener(function(info,tab){if(info.menuItemId=="Translate"){SSuiteTranslate(info,tab);}});
chrome.runtime.onInstalled.addListener(function(){chrome.tabs.create({url:"https://www.ssuiteoffice.com/software.htm"});});
chrome.runtime.setUninstallURL("https://www.ssuiteoffice.com/software.htm");