French Version 1.0

http://www.ssuitesoft.com/freedownlaods.htm